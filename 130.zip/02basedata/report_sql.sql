
begin
 for x in(select object_name From user_objects where object_type='TABLE') loop
     execute immediate 'drop table '||x.object_name||' cascade constraint';
 end loop;
end;
/

--数据源
CREATE TABLE  REPORT_DATASOURCE(
CNNID VARCHAR2(16) NOT NULL,
CNNAME VARCHAR2(100) NOT NULL,
TYPE VARCHAR2(16),
JDBCNAME VARCHAR2(100),
USERNAME VARCHAR2(50),
PASSWORD VARCHAR2(100)
);
--数据源表列表
CREATE TABLE REPORT_DATASOURCE_TABLE(
CNNID VARCHAR2(16) NOT NULL,
TABLENAME VARCHAR2(100),
TBTYPE VARCHAR2(16),
TABLEID VARCHAR2(19)NOT NULL
);

-- 增加 字段 增加主键
alter table REPORT_DATASOURCE_TABLE
  add constraint TABLEID primary key (TABLEID);
--立方
CREATE TABLE REPORT_CUBE(
CNNID VARCHAR2(16) NOT NULL,
CUBEID VARCHAR2(16) NOT NULL,
CUBENAME VARCHAR2(100),
CUBEDESC VARCHAR2(3000),
DEPTFIELD VARCHAR2(100),
WHEREFIELD VARCHAR2(3000),
TABLESFIELD VARCHAR2(3000)
);

CREATE TABLE REPORT_CUBE_TABLE_REL(
CUBEID VARCHAR2(16) NOT NULL,
TABLEID VARCHAR2(16)
);

--指标
CREATE TABLE REPORT_TARGET(
CUBEID VARCHAR2(16) NOT NULL,
TARGETID VARCHAR2(16) NOT NULL,
TARGETNAME VARCHAR2(100),
CLASSID VARCHAR2(16),
CLASSNAME VARCHAR2(100),
TARGETSQL VARCHAR2(255),
TARGETTYPE VARCHAR2(16),
WHERESQL VARCHAR2(255),
TARGETDESC VARCHAR2(255),
ISCLASS VARCHAR2(16)
);
--指标参数
CREATE TABLE REPORT_TARGET_P(
TARGETID  VARCHAR2(16),
TARGETNAME VARCHAR2(255),
TARGETSQL VARCHAR2(255),
TARGETPARAM VARCHAR2(255)
);
--对象树定义
CREATE TABLE REPORT_OBJECT(
OBJECTID VARCHAR2(16),
OBJECTNAME VARCHAR2(50),
OBJECTDESC VARCHAR2(255)
);
--报表类型
CREATE TABLE REPORT_TYPE(
REPORTTYPE VARCHAR2(16),
TYPENAME VARCHAR2(50),
TYPEDESC VARCHAR2(50)
);
--模板信息
CREATE TABLE REPORT_TEMPLATE(
TMPID VARCHAR2(16),
TMPNAME VARCHAR2(255),
TMPFILE VARCHAR2(255),
TMPKEY VARCHAR2(50),
TMPDESC VARCHAR2(255),
REPORTTYPE VARCHAR2(16),
TMPFILENAME VARCHAR2(255)
);
--报表设计
CREATE TABLE REPORT_REPORT_DESIGN(
REPORTID VARCHAR2(16),
QUERYID VARCHAR2(16),
QUERYSERIAL VARCHAR2(16),
TOEXCEL VARCHAR2(50),
DEPTID VARCHAR2(16)
);




--数据源表字段列表
-- CREATE TABLE
CREATE TABLE REPORT_DATASOURCE_TABLE_FILED
(
  CNNID           VARCHAR2(16) NOT NULL,
  TABLENAME       VARCHAR2(100),
  TBTYPE          VARCHAR2(16),
  FILEDID         VARCHAR2(19) NOT NULL,
  TABLEFILED      VARCHAR2(100),
  TABLEFILEDSQL   VARCHAR2(100),
  TABLEFILEDALIAS VARCHAR2(100),
  TABLEID         VARCHAR2(16)
);

-- CREATE/RECREATE PRIMARY, UNIQUE AND FOREIGN KEY CONSTRAINTS 
ALTER TABLE REPORT_DATASOURCE_TABLE_FILED
  ADD CONSTRAINT PK_DATASOURCE_TABLE_FILEDID PRIMARY KEY (FILEDID);



--new 
CREATE TABLE REPORT_DATA_POSITION
(
  DATAID    VARCHAR2(16),
  TMPID     VARCHAR2(16),
  DATANAME  VARCHAR2(255),
  SHEETNAME VARCHAR2(255),
  POSITION  VARCHAR2(255)
);


--系统参数表
CREATE TABLE REPORT_SYS_PARAMETER
(
  ID     VARCHAR2(16) NOT NULL,
  MODULE VARCHAR2(64) NOT NULL,
  NAME   VARCHAR2(64) NOT NULL,
  VALUE  VARCHAR2(1024) NOT NULL,
  REMARK VARCHAR2(256),
  IS_PASSWORD NUMBER
);

 
CREATE TABLE REPORT_QUERY
(
  QUERYID     VARCHAR2(16) NOT NULL,
  CNNID       VARCHAR2(16),
  CUBEID      VARCHAR2(16),
  QUERYNAME   VARCHAR2(100),
  QUERYOPTION VARCHAR2(50),
  MAXROW      NUMBER(5),
  QUERYDESC   VARCHAR2(512),
  QUERYTYPE   VARCHAR2(1),
  CREATORID   VARCHAR2(16),
  ISPUBLISH   NUMBER(1),
  QUERYSQL    CLOB,
  CREATORNAME VARCHAR2(256),
  CREATETIME  DATE,
  UPDATETIME  DATE,
  KEY         VARCHAR2(50),
  SQLJSON     CLOB
);

CREATE TABLE  REPORT_SHEET_HTML(
ID VARCHAR2(16) NOT NULL,
SHEET_NAME VARCHAR2(100) NOT NULL,
HTML_TYPE VARCHAR2(1),
HTML_PATH VARCHAR2(255),
HTML_NAME VARCHAR2(255),
SHOW_NAME VARCHAR2(255)
);



CREATE TABLE  REPORT_FUNCTION(
ID VARCHAR2(16) NOT NULL,
FUNCTION_NAME VARCHAR2(100) NOT NULL,
FUNCTION_VALUE VARCHAR2(255),
FUNCTION_TYPE VARCHAR2(10)
);

CREATE TABLE REPORT_REPORT_FILE(
REPORTID VARCHAR2(16),
REPORTNAME VARCHAR2(255),
REPORTTYPE VARCHAR2(16),
TEMPID VARCHAR2(16),
TMPKEY VARCHAR2(50),
REPORTDESC VARCHAR2(50),
REPORTPATH VARCHAR2(255),
SUBTYPE VARCHAR2(16),
REPORTSTATUS VARCHAR2(10)
);

--角色 用户表
CREATE TABLE REPORT_USER
(
  ID                    VARCHAR2(16) NOT NULL,
  LOGINNAME             VARCHAR2(64) NOT NULL,
  NAME                  VARCHAR2(64) NOT NULL,
  PASSWORD              VARCHAR2(128) NOT NULL,
  SEX                   NUMBER(2) NOT NULL,
  AGE                   NUMBER(2),
  USERTYPE              NUMBER(2) NOT NULL,
  STATUS                NUMBER(2) NOT NULL,
  ORGANIZATION_ID       VARCHAR2(16),
  CREATEDATE            DATE,
  PHONE                 VARCHAR2(20),
  STAFF_NO              VARCHAR2(16),
  PHOTO                 VARCHAR2(256),
  POS_NAME              VARCHAR2(64),
  POSITION              VARCHAR2(8),
  WORK_TYPE_CODE        VARCHAR2(8),
  TECH_LEVEL_CODE       VARCHAR2(8),
  YMD                   DATE,
  DEGREE_CODE           VARCHAR2(8),
  SRV_LEVEL_CODE        VARCHAR2(8),
  CERT_FLAG             VARCHAR2(8),
  FIXED_FLAG            VARCHAR2(8),
  ON_POS_FLAG           VARCHAR2(8),
  PROFESSION_CODE       VARCHAR2(8),
  PROFESSION_BGN_DATE   DATE,
  JOIN_DATE             DATE,
  TITEL                 VARCHAR2(256),
  POLITICAL_STATUS_CODE VARCHAR2(8),
  TITLE_LEVEL_CODE      VARCHAR2(8),
  STATUS_CODE           VARCHAR2(8),
  REMARK                VARCHAR2(256),
  P_ORGANIZATION_ID     VARCHAR2(16),
  PWD_FIRST_UPDATE      VARCHAR2(8),
  PWD_UPDATE_TIME       DATE,
  ICON                  VARCHAR2(100),
  WEB_GUIDE_FIRST       VARCHAR2(8),
  WEB_GUIDE_UPDATE_TIME DATE,
  source_userid varchar2(16),
  source_username varchar2(64),
  source_system varchar2(64),
  email VARCHAR2(64)
);

CREATE TABLE REPORT_ROLE
(
  ID          NUMBER(19) NOT NULL,
  NAME        VARCHAR2(64) NOT NULL,
  SEQ         NUMBER(2) NOT NULL,
  DESCRIPTION VARCHAR2(255),
  STATUS      NUMBER(2) NOT NULL,
  ISINDEX     NUMBER(2)
);

CREATE TABLE REPORT_USER_ROLE
(
  ID      NUMBER(19) NOT NULL,
  USER_ID VARCHAR2(16),
  ROLE_ID NUMBER(19)
);

CREATE TABLE REPORT_ROLE_RESOURCE
(
  ID          NUMBER(19) NOT NULL,
  ROLE_ID     NUMBER(19) NOT NULL,
  RESOURCE_ID NUMBER(19) NOT NULL
);
CREATE TABLE REPORT_RESOURCE
(
  ID           NUMBER(19) NOT NULL,
  NAME         VARCHAR2(64) NOT NULL,
  URL          VARCHAR2(100),
  DESCRIPTION  VARCHAR2(255),
  ICON         VARCHAR2(32),
  PID          NUMBER(19),
  SEQ          NUMBER(2) NOT NULL,
  STATUS       NUMBER(2) NOT NULL,
  RESOURCETYPE NUMBER(2) NOT NULL,
  CREATEDATE   DATE,
  NAME_CN      VARCHAR2(64),
  MENU_CODE    VARCHAR2(64)
);


CREATE TABLE REPORT_OBJECT_TREE(
OBJECTID VARCHAR2(16),
TREEID VARCHAR2(16),
TREENAME VARCHAR2(255),
TREEPID VARCHAR2(16),
TREECODE VARCHAR2(255),
TREELEVEL NUMBER(5)
);

-- 角色立方关系
CREATE TABLE REPORT_ROLE_CUBE
(
  ID          NUMBER(19) NOT NULL,
  CUBE_ID     VARCHAR2(19) NOT NULL,
  ROLE_ID NUMBER(19) NOT NULL,
  CNNID     VARCHAR2(19) NOT NULL
);
--角色数据源
CREATE TABLE REPORT_ROLE_DATASOURCE
(
  ID          NUMBER(19) NOT NULL,
  CNNID     VARCHAR2(19) NOT NULL,
  ROLE_ID NUMBER(19) NOT NULL
);

--角色报表
CREATE TABLE REPORT_ROLE_REPORT
(
  ID          NUMBER(19) NOT NULL,
  REPORT_ID     VARCHAR2(19) NOT NULL,
  ROLE_ID NUMBER(19) NOT NULL
);

-- 用户立方关系
CREATE TABLE REPORT_USER_CUBE
(
  ID          NUMBER(19) NOT NULL,
  CUBE_ID     VARCHAR2(19) NOT NULL,
  USER_ID     VARCHAR2(19) NOT NULL
);
--用户数据源
CREATE TABLE REPORT_USER_DATASOURCE
(
  ID          NUMBER(19) NOT NULL,
  CNNID       VARCHAR2(19) NOT NULL,
  USER_ID     VARCHAR2(19) NOT NULL
);

--用户报表
CREATE TABLE REPORT_USER_TEMPLATE
(
  ID          NUMBER(19) NOT NULL,
  REPORT_ID   VARCHAR2(19) NOT NULL,
  USER_ID     VARCHAR2(19) NOT NULL
);


CREATE TABLE REPORTER_USER_OBJTREE
(
  ID      NUMBER(19),
  USER_ID VARCHAR2(19),
  OBJ_ID  VARCHAR2(19)
);




-- 数据集与对象的关系表
CREATE TABLE  REPORT_DATASET_OBJECT(
ID VARCHAR2(16) NOT NULL,
QUERYID VARCHAR2(16),
OBJECTID VARCHAR2(16)
);
alter table REPORT_DATASET_OBJECT add constraint PK_REPORT_DATASET_OBJECT primary key(ID);

-- 生成报表文件与对象树关系
CREATE TABLE  REPORT_FILE_TREE(
ID VARCHAR2(16) NOT NULL,
REPORTID VARCHAR2(16),
TREEID VARCHAR2(16)
);
alter table REPORT_FILE_TREE add constraint PK_REPORT_FILE_TREE primary key(ID);


ALTER TABLE REPORT_REPORT_FILE ADD CREATETIME DATE;



--二类展示字段
CREATE TABLE REPORT_QUERY_COL
(
  QUERYID    VARCHAR2(16) NOT NULL,
  FILEDID    VARCHAR2(16),
  FIELDSQL   VARCHAR2(128),
  FIELDNAME  VARCHAR2(128),
  FIELDALIAS VARCHAR2(128),
  TABLEID    VARCHAR2(16),
  TABLENAME  VARCHAR2(128)
);


--增加记录表
CREATE TABLE REPORT_LOG
(
  REPORTID      VARCHAR2(16) PRIMARY KEY NOT NULL,
  CURRENT_TIME  VARCHAR2(20),
  START_TIME    VARCHAR2(20),
  END_TIME      VARCHAR2(20),
  TREEPARAM     VARCHAR2(2000),
  STATUS        VARCHAR2(10),
  CREATORID     VARCHAR2(16),
  CREATETIME    DATE
);


INSERT INTO REPORT_FUNCTION(ID, FUNCTION_NAME, FUNCTION_VALUE, FUNCTION_TYPE)VALUES('1','%当前日期%',' between %开始日期% and %结束日期% ','');
INSERT INTO REPORT_FUNCTION(ID, FUNCTION_NAME, FUNCTION_VALUE, FUNCTION_TYPE)VALUES('2','%上一日%',' between %开始日期% and %结束日期% ','');
INSERT INTO REPORT_FUNCTION(ID, FUNCTION_NAME, FUNCTION_VALUE, FUNCTION_TYPE)VALUES('3','%开始日期%',' between %开始日期% and %结束日期% ','');
INSERT INTO REPORT_FUNCTION(ID, FUNCTION_NAME, FUNCTION_VALUE, FUNCTION_TYPE)VALUES('4','%结束日期%',' between %开始日期% and %结束日期% ','');
INSERT INTO REPORT_FUNCTION(ID, FUNCTION_NAME, FUNCTION_VALUE, FUNCTION_TYPE)VALUES('5','%本月初%',' between %开始日期% and %结束日期% ','');
INSERT INTO REPORT_FUNCTION(ID, FUNCTION_NAME, FUNCTION_VALUE, FUNCTION_TYPE)VALUES('6','%本月末%',' between %开始日期% and %结束日期% ','');




delete from REPORT_RESOURCE;
insert into report_resource (ID, NAME, URL, DESCRIPTION, ICON, PID, SEQ, STATUS, RESOURCETYPE, CREATEDATE, NAME_CN, MENU_CODE)
values ('1000000', '数据源管理', null, '数据源管理', null, null, '1', '0', '0', to_date('22-11-2017 14:37:24', 'dd-mm-yyyy hh24:mi:ss'), null, null);

insert into report_resource (ID, NAME, URL, DESCRIPTION, ICON, PID, SEQ, STATUS, RESOURCETYPE, CREATEDATE, NAME_CN, MENU_CODE)
values ('1000003', '数据源管理', '/dataSource/dataSourceManager', '数据源管理', null, '1000000', '1', '0', '0', to_date('22-11-2017 14:37:24', 'dd-mm-yyyy hh24:mi:ss'), null, null);

insert into report_resource (ID, NAME, URL, DESCRIPTION, ICON, PID, SEQ, STATUS, RESOURCETYPE, CREATEDATE, NAME_CN, MENU_CODE)
values ('1000010', '数据集管理', null, '数据集管理', null, null, '2', '0', '0', to_date('22-11-2017 14:37:24', 'dd-mm-yyyy hh24:mi:ss'), null, null);

insert into report_resource (ID, NAME, URL, DESCRIPTION, ICON, PID, SEQ, STATUS, RESOURCETYPE, CREATEDATE, NAME_CN, MENU_CODE)
values ('1000011', '自定义SQL', '/customDataSet/dataSetList', '自定义SQL', null, '1000010', '1', '0', '0', to_date('22-11-2017 14:37:24', 'dd-mm-yyyy hh24:mi:ss'), null, null);

insert into report_resource (ID, NAME, URL, DESCRIPTION, ICON, PID, SEQ, STATUS, RESOURCETYPE, CREATEDATE, NAME_CN, MENU_CODE)
values ('1000100', '模板管理', null, '模板管理', null, null, '3', '0', '0', to_date('22-11-2017 14:37:24', 'dd-mm-yyyy hh24:mi:ss'), null, null);

insert into report_resource (ID, NAME, URL, DESCRIPTION, ICON, PID, SEQ, STATUS, RESOURCETYPE, CREATEDATE, NAME_CN, MENU_CODE)
values ('1000101', '模板管理', '/templateManagement', '模板管理', null, '1000100', '1', '0', '0', to_date('22-11-2017 14:37:24', 'dd-mm-yyyy hh24:mi:ss'), null, null);

insert into report_resource (ID, NAME, URL, DESCRIPTION, ICON, PID, SEQ, STATUS, RESOURCETYPE, CREATEDATE, NAME_CN, MENU_CODE)
values ('1001000', '报表管理', null, '报表管理', null, null, '4', '0', '0', to_date('22-11-2017 14:37:24', 'dd-mm-yyyy hh24:mi:ss'), null, null);

insert into report_resource (ID, NAME, URL, DESCRIPTION, ICON, PID, SEQ, STATUS, RESOURCETYPE, CREATEDATE, NAME_CN, MENU_CODE)
values ('1001001', '报表生成', '/report/index', '报表生成', null, '1001000', '1', '0', '0', to_date('22-11-2017 14:37:24', 'dd-mm-yyyy hh24:mi:ss'), null, null);

insert into report_resource (ID, NAME, URL, DESCRIPTION, ICON, PID, SEQ, STATUS, RESOURCETYPE, CREATEDATE, NAME_CN, MENU_CODE)
values ('1001002', '报表查询', '/reportFile', '报表查询', null, '1001000', '2', '0', '0', to_date('22-11-2017 14:37:24', 'dd-mm-yyyy hh24:mi:ss'), null, null);

insert into report_resource (ID, NAME, URL, DESCRIPTION, ICON, PID, SEQ, STATUS, RESOURCETYPE, CREATEDATE, NAME_CN, MENU_CODE)
values ('1010000', '任务管理', null, '任务管理', null, null, '5', '0', '0', to_date('22-11-2017 14:37:24', 'dd-mm-yyyy hh24:mi:ss'), null, null);

insert into report_resource (ID, NAME, URL, DESCRIPTION, ICON, PID, SEQ, STATUS, RESOURCETYPE, CREATEDATE, NAME_CN, MENU_CODE)
values ('1010001', '任务管理', '/reportTask', '任务管理', null, '1010000', '1', '0', '0', to_date('22-11-2017 14:37:24', 'dd-mm-yyyy hh24:mi:ss'), null, null);

insert into report_resource (ID, NAME, URL, DESCRIPTION, ICON, PID, SEQ, STATUS, RESOURCETYPE, CREATEDATE, NAME_CN, MENU_CODE)
values ('1100000', '系统管理', null, '系统管理', null, null, '6', '0', '0', to_date('22-11-2017 14:37:24', 'dd-mm-yyyy hh24:mi:ss'), null, null);

insert into report_resource (ID, NAME, URL, DESCRIPTION, ICON, PID, SEQ, STATUS, RESOURCETYPE, CREATEDATE, NAME_CN, MENU_CODE)
values ('1100001', '用户管理', '/user/manager', '用户管理', null, '1100000', '1', '0', '0', to_date('22-11-2017 14:37:24', 'dd-mm-yyyy hh24:mi:ss'), null, null);

insert into report_resource (ID, NAME, URL, DESCRIPTION, ICON, PID, SEQ, STATUS, RESOURCETYPE, CREATEDATE, NAME_CN, MENU_CODE)
values ('1100002', '角色管理', '/role', '角色管理', null, '1100000', '2', '0', '0', to_date('22-11-2017 14:37:24', 'dd-mm-yyyy hh24:mi:ss'), null, null);

insert into report_resource (ID, NAME, URL, DESCRIPTION, ICON, PID, SEQ, STATUS, RESOURCETYPE, CREATEDATE, NAME_CN, MENU_CODE)
values ('1100003', '参数设置', '/systemParameter', '参数设置', null, '1100000', '3', '0', '0', to_date('22-11-2017 14:37:24', 'dd-mm-yyyy hh24:mi:ss'), null, null);

insert into report_resource (ID, NAME, URL, DESCRIPTION, ICON, PID, SEQ, STATUS, RESOURCETYPE, CREATEDATE, NAME_CN, MENU_CODE)
values ('1100004', '对象树设置', '/objectTree/index', '对象树设置', null, '1100000', '4', '0', '0', to_date('22-11-2017 17:25:45', 'dd-mm-yyyy hh24:mi:ss'), null, null);

insert into report_resource (ID, NAME, URL, DESCRIPTION, ICON, PID, SEQ, STATUS, RESOURCETYPE, CREATEDATE, NAME_CN, MENU_CODE)
values ('100000301', '查看', '/searchDataSource', '查看', null, '1000003', '1', '0', '1', to_date('23-11-2017 11:23:00', 'dd-mm-yyyy hh24:mi:ss'), null, null);

insert into report_resource (ID, NAME, URL, DESCRIPTION, ICON, PID, SEQ, STATUS, RESOURCETYPE, CREATEDATE, NAME_CN, MENU_CODE)
values ('100000302', '添加数据源', '/addDataSource', '添加数据源', null, '1000003', '2', '0', '1', to_date('22-11-2017 17:25:45', 'dd-mm-yyyy hh24:mi:ss'), null, null);

insert into report_resource (ID, NAME, URL, DESCRIPTION, ICON, PID, SEQ, STATUS, RESOURCETYPE, CREATEDATE, NAME_CN, MENU_CODE)
values ('100000303', '修改数据源', '/editDataSource', '修改数据源', null, '1000003', '3', '0', '1', to_date('22-11-2017 17:25:45', 'dd-mm-yyyy hh24:mi:ss'), null, null);

insert into report_resource (ID, NAME, URL, DESCRIPTION, ICON, PID, SEQ, STATUS, RESOURCETYPE, CREATEDATE, NAME_CN, MENU_CODE)
values ('100000304', '删除数据源', '/deleteDataSource', '删除数据源', null, '1000003', '4', '0', '1', to_date('22-11-2017 17:25:45', 'dd-mm-yyyy hh24:mi:ss'), null, null);

insert into report_resource (ID, NAME, URL, DESCRIPTION, ICON, PID, SEQ, STATUS, RESOURCETYPE, CREATEDATE, NAME_CN, MENU_CODE)
values ('100000305', '刷新数据源', '/reflushDataSource', '刷新数据源', null, '1000003', '5', '0', '1', to_date('22-11-2017 17:25:45', 'dd-mm-yyyy hh24:mi:ss'), null, null);

insert into report_resource (ID, NAME, URL, DESCRIPTION, ICON, PID, SEQ, STATUS, RESOURCETYPE, CREATEDATE, NAME_CN, MENU_CODE)
values ('100000306', '添加立方', '/addCube', '添加立方', null, '1000003', '6', '0', '1', to_date('22-11-2017 17:25:45', 'dd-mm-yyyy hh24:mi:ss'), null, null);

insert into report_resource (ID, NAME, URL, DESCRIPTION, ICON, PID, SEQ, STATUS, RESOURCETYPE, CREATEDATE, NAME_CN, MENU_CODE)
values ('100000307', '修改立方', '/editCube', '修改立方', null, '1000003', '7', '0', '1', to_date('22-11-2017 17:25:45', 'dd-mm-yyyy hh24:mi:ss'), null, null);

insert into report_resource (ID, NAME, URL, DESCRIPTION, ICON, PID, SEQ, STATUS, RESOURCETYPE, CREATEDATE, NAME_CN, MENU_CODE)
values ('100000308', '删除立方', '/deleteCube', '删除立方', null, '1000003', '8', '0', '1', to_date('22-11-2017 17:25:45', 'dd-mm-yyyy hh24:mi:ss'), null, null);

insert into report_resource (ID, NAME, URL, DESCRIPTION, ICON, PID, SEQ, STATUS, RESOURCETYPE, CREATEDATE, NAME_CN, MENU_CODE)
values ('100000309', '重命名指标', '/renameTableFiled', '重命名指标', null, '1000003', '9', '0', '1', to_date('22-11-2017 17:25:45', 'dd-mm-yyyy hh24:mi:ss'), null, null);

insert into report_resource (ID, NAME, URL, DESCRIPTION, ICON, PID, SEQ, STATUS, RESOURCETYPE, CREATEDATE, NAME_CN, MENU_CODE)
values ('100001101', '查看', '/searchSQL', '查看', null, '1000011', '1', '0', '1', to_date('22-11-2017 17:25:45', 'dd-mm-yyyy hh24:mi:ss'), null, null);

insert into report_resource (ID, NAME, URL, DESCRIPTION, ICON, PID, SEQ, STATUS, RESOURCETYPE, CREATEDATE, NAME_CN, MENU_CODE)
values ('100001102', '新增sql', '/addSQL', '新增sql', null, '1000011', '2', '0', '1', to_date('22-11-2017 17:25:45', 'dd-mm-yyyy hh24:mi:ss'), null, null);

insert into report_resource (ID, NAME, URL, DESCRIPTION, ICON, PID, SEQ, STATUS, RESOURCETYPE, CREATEDATE, NAME_CN, MENU_CODE)
values ('100001103', '修改sql', '/editSQL', '修改sql', null, '1000011', '3', '0', '1', to_date('22-11-2017 17:25:45', 'dd-mm-yyyy hh24:mi:ss'), null, null);

insert into report_resource (ID, NAME, URL, DESCRIPTION, ICON, PID, SEQ, STATUS, RESOURCETYPE, CREATEDATE, NAME_CN, MENU_CODE)
values ('100001104', '删除sql', '/deleteSQL', '删除sql', null, '1000011', '4', '0', '1', to_date('22-11-2017 17:25:45', 'dd-mm-yyyy hh24:mi:ss'), null, null);

insert into report_resource (ID, NAME, URL, DESCRIPTION, ICON, PID, SEQ, STATUS, RESOURCETYPE, CREATEDATE, NAME_CN, MENU_CODE)
values ('100010101', '查看', '/searchTemplate', '查看', null, '1000101', '1', '0', '1', to_date('22-11-2017 17:25:45', 'dd-mm-yyyy hh24:mi:ss'), null, null);

insert into report_resource (ID, NAME, URL, DESCRIPTION, ICON, PID, SEQ, STATUS, RESOURCETYPE, CREATEDATE, NAME_CN, MENU_CODE)
values ('100010102', '新增模板', '/addTemplate', '新增模板', null, '1000101', '2', '0', '1', to_date('22-11-2017 17:25:45', 'dd-mm-yyyy hh24:mi:ss'), null, null);

insert into report_resource (ID, NAME, URL, DESCRIPTION, ICON, PID, SEQ, STATUS, RESOURCETYPE, CREATEDATE, NAME_CN, MENU_CODE)
values ('100010103', '预览模板', '/seeTemplate', '预览模板', null, '1000101', '3', '0', '1', to_date('22-11-2017 17:25:45', 'dd-mm-yyyy hh24:mi:ss'), null, null);

insert into report_resource (ID, NAME, URL, DESCRIPTION, ICON, PID, SEQ, STATUS, RESOURCETYPE, CREATEDATE, NAME_CN, MENU_CODE)
values ('100010104', '修改模板', '/editTemplate', '修改模板', null, '1000101', '4', '0', '1', to_date('22-11-2017 17:25:45', 'dd-mm-yyyy hh24:mi:ss'), null, null);

insert into report_resource (ID, NAME, URL, DESCRIPTION, ICON, PID, SEQ, STATUS, RESOURCETYPE, CREATEDATE, NAME_CN, MENU_CODE)
values ('100010105', '删除模板', '/deleteTemplate', '删除模板', null, '1000101', '5', '0', '1', to_date('22-11-2017 17:25:45', 'dd-mm-yyyy hh24:mi:ss'), null, null);

insert into report_resource (ID, NAME, URL, DESCRIPTION, ICON, PID, SEQ, STATUS, RESOURCETYPE, CREATEDATE, NAME_CN, MENU_CODE)
values ('100010106', '数据绑定查看', '/seeTemplateDesgin', '数据绑定查看', null, '1000101', '6', '0', '1', to_date('22-11-2017 17:25:45', 'dd-mm-yyyy hh24:mi:ss'), null, null);

insert into report_resource (ID, NAME, URL, DESCRIPTION, ICON, PID, SEQ, STATUS, RESOURCETYPE, CREATEDATE, NAME_CN, MENU_CODE)
values ('100010107', '数据绑定保存', '/saveTemplateDesgin', '数据绑定保存', null, '100010106', '7', '0', '1', to_date('22-11-2017 17:25:45', 'dd-mm-yyyy hh24:mi:ss'), null, null);

insert into report_resource (ID, NAME, URL, DESCRIPTION, ICON, PID, SEQ, STATUS, RESOURCETYPE, CREATEDATE, NAME_CN, MENU_CODE)
values ('100100101', '查看', '/searchBuildReport', '查看', null, '1001001', '1', '0', '1', to_date('22-11-2017 17:25:45', 'dd-mm-yyyy hh24:mi:ss'), null, null);

insert into report_resource (ID, NAME, URL, DESCRIPTION, ICON, PID, SEQ, STATUS, RESOURCETYPE, CREATEDATE, NAME_CN, MENU_CODE)
values ('100100102', '生成报表', '/buildReport', '生成报表', null, '1001001', '2', '0', '1', to_date('22-11-2017 17:25:45', 'dd-mm-yyyy hh24:mi:ss'), null, null);

insert into report_resource (ID, NAME, URL, DESCRIPTION, ICON, PID, SEQ, STATUS, RESOURCETYPE, CREATEDATE, NAME_CN, MENU_CODE)
values ('100100201', '查看', '/searchReportFile', '查看', null, '1001002', '1', '0', '1', to_date('22-11-2017 17:25:45', 'dd-mm-yyyy hh24:mi:ss'), null, null);

insert into report_resource (ID, NAME, URL, DESCRIPTION, ICON, PID, SEQ, STATUS, RESOURCETYPE, CREATEDATE, NAME_CN, MENU_CODE)
values ('100100202', '预览报表', '/seeReportFile', '预览报表', null, '1001002', '2', '0', '1', to_date('22-11-2017 17:25:45', 'dd-mm-yyyy hh24:mi:ss'), null, null);

insert into report_resource (ID, NAME, URL, DESCRIPTION, ICON, PID, SEQ, STATUS, RESOURCETYPE, CREATEDATE, NAME_CN, MENU_CODE)
values ('100100203', '下载报表', '/downReportFile', '下载报表', null, '1001002', '3', '0', '1', to_date('22-11-2017 17:25:45', 'dd-mm-yyyy hh24:mi:ss'), null, null);

insert into report_resource (ID, NAME, URL, DESCRIPTION, ICON, PID, SEQ, STATUS, RESOURCETYPE, CREATEDATE, NAME_CN, MENU_CODE)
values ('100100204', '修改报表', '/editReportFile', '修改报表', null, '1001002', '4', '0', '1', to_date('22-11-2017 17:25:45', 'dd-mm-yyyy hh24:mi:ss'), null, null);

insert into report_resource (ID, NAME, URL, DESCRIPTION, ICON, PID, SEQ, STATUS, RESOURCETYPE, CREATEDATE, NAME_CN, MENU_CODE)
values ('100100205', '删除报表', '/deleteReportFile', '删除报表', null, '1001002', '5', '0', '1', to_date('22-11-2017 17:25:45', 'dd-mm-yyyy hh24:mi:ss'), null, null);

insert into report_resource (ID, NAME, URL, DESCRIPTION, ICON, PID, SEQ, STATUS, RESOURCETYPE, CREATEDATE, NAME_CN, MENU_CODE)
values ('101000101', '查看', '/searchTask', '查看', null, '1010001', '1', '0', '1', to_date('22-11-2017 17:25:45', 'dd-mm-yyyy hh24:mi:ss'), null, null);

insert into report_resource (ID, NAME, URL, DESCRIPTION, ICON, PID, SEQ, STATUS, RESOURCETYPE, CREATEDATE, NAME_CN, MENU_CODE)
values ('101000102', '新增任务', '/addTask', '新增任务', null, '1010001', '2', '0', '1', to_date('22-11-2017 17:25:45', 'dd-mm-yyyy hh24:mi:ss'), null, null);

insert into report_resource (ID, NAME, URL, DESCRIPTION, ICON, PID, SEQ, STATUS, RESOURCETYPE, CREATEDATE, NAME_CN, MENU_CODE)
values ('101000103', '修改任务', '/editTask', '修改任务', null, '1010001', '3', '0', '1', to_date('22-11-2017 17:25:45', 'dd-mm-yyyy hh24:mi:ss'), null, null);

insert into report_resource (ID, NAME, URL, DESCRIPTION, ICON, PID, SEQ, STATUS, RESOURCETYPE, CREATEDATE, NAME_CN, MENU_CODE)
values ('101000104', '删除任务', '/deleteTask', '删除任务', null, '1010001', '4', '0', '1', to_date('22-11-2017 17:25:45', 'dd-mm-yyyy hh24:mi:ss'), null, null);

insert into report_resource (ID, NAME, URL, DESCRIPTION, ICON, PID, SEQ, STATUS, RESOURCETYPE, CREATEDATE, NAME_CN, MENU_CODE)
values ('101000105', '执行任务', '/doTask', '执行任务', null, '1010001', '5', '0', '1', to_date('22-11-2017 17:25:45', 'dd-mm-yyyy hh24:mi:ss'), null, null);

insert into report_resource (ID, NAME, URL, DESCRIPTION, ICON, PID, SEQ, STATUS, RESOURCETYPE, CREATEDATE, NAME_CN, MENU_CODE)
values ('101000106', '模板', '/tempConf', '模板', null, '1010001', '6', '0', '1', to_date('22-11-2017 17:25:45', 'dd-mm-yyyy hh24:mi:ss'), null, null);

insert into report_resource (ID, NAME, URL, DESCRIPTION, ICON, PID, SEQ, STATUS, RESOURCETYPE, CREATEDATE, NAME_CN, MENU_CODE)
values ('101000107', '对象', '/objConf', '对象', null, '1010001', '7', '0', '1', to_date('22-11-2017 17:25:45', 'dd-mm-yyyy hh24:mi:ss'), null, null);

insert into report_resource (ID, NAME, URL, DESCRIPTION, ICON, PID, SEQ, STATUS, RESOURCETYPE, CREATEDATE, NAME_CN, MENU_CODE)
values ('110000101', '查看', '/searchUser', '查看', null, '1100001', '1', '0', '1', to_date('22-11-2017 17:25:45', 'dd-mm-yyyy hh24:mi:ss'), null, null);

insert into report_resource (ID, NAME, URL, DESCRIPTION, ICON, PID, SEQ, STATUS, RESOURCETYPE, CREATEDATE, NAME_CN, MENU_CODE)
values ('110000102', '新增用户', '/addUser', '新增用户', null, '1100001', '2', '0', '1', to_date('22-11-2017 17:25:45', 'dd-mm-yyyy hh24:mi:ss'), null, null);

insert into report_resource (ID, NAME, URL, DESCRIPTION, ICON, PID, SEQ, STATUS, RESOURCETYPE, CREATEDATE, NAME_CN, MENU_CODE)
values ('110000103', '修改用户', '/editUser', '修改用户', null, '1100001', '3', '0', '1', to_date('22-11-2017 17:25:45', 'dd-mm-yyyy hh24:mi:ss'), null, null);

insert into report_resource (ID, NAME, URL, DESCRIPTION, ICON, PID, SEQ, STATUS, RESOURCETYPE, CREATEDATE, NAME_CN, MENU_CODE)
values ('110000104', '删除用户', '/deleteUser', '删除用户', null, '1100001', '4', '0', '1', to_date('22-11-2017 17:25:45', 'dd-mm-yyyy hh24:mi:ss'), null, null);

insert into report_resource (ID, NAME, URL, DESCRIPTION, ICON, PID, SEQ, STATUS, RESOURCETYPE, CREATEDATE, NAME_CN, MENU_CODE)
values ('110000105', '用户授权', '/userGrant', '用户授权', null, '1100001', '5', '0', '1', to_date('22-11-2017 17:25:45', 'dd-mm-yyyy hh24:mi:ss'), null, null);

insert into report_resource (ID, NAME, URL, DESCRIPTION, ICON, PID, SEQ, STATUS, RESOURCETYPE, CREATEDATE, NAME_CN, MENU_CODE)
values ('110000201', '查看', '/searchRole', '查看', null, '1100002', '1', '0', '1', to_date('22-11-2017 17:25:45', 'dd-mm-yyyy hh24:mi:ss'), null, null);

insert into report_resource (ID, NAME, URL, DESCRIPTION, ICON, PID, SEQ, STATUS, RESOURCETYPE, CREATEDATE, NAME_CN, MENU_CODE)
values ('110000202', '新增角色', '/addRole', '新增角色', null, '1100002', '2', '0', '1', to_date('22-11-2017 17:25:45', 'dd-mm-yyyy hh24:mi:ss'), null, null);

insert into report_resource (ID, NAME, URL, DESCRIPTION, ICON, PID, SEQ, STATUS, RESOURCETYPE, CREATEDATE, NAME_CN, MENU_CODE)
values ('110000203', '修改角色', '/editRole', '修改角色', null, '1100002', '3', '0', '1', to_date('22-11-2017 17:25:45', 'dd-mm-yyyy hh24:mi:ss'), null, null);

insert into report_resource (ID, NAME, URL, DESCRIPTION, ICON, PID, SEQ, STATUS, RESOURCETYPE, CREATEDATE, NAME_CN, MENU_CODE)
values ('110000204', '删除角色', '/deleteRole', '删除角色', null, '1100002', '4', '0', '1', to_date('22-11-2017 17:25:45', 'dd-mm-yyyy hh24:mi:ss'), null, null);

insert into report_resource (ID, NAME, URL, DESCRIPTION, ICON, PID, SEQ, STATUS, RESOURCETYPE, CREATEDATE, NAME_CN, MENU_CODE)
values ('110000205', '角色授权', '/roleGrant', '角色授权', null, '1100002', '5', '0', '1', to_date('22-11-2017 17:25:45', 'dd-mm-yyyy hh24:mi:ss'), null, null);

insert into report_resource (ID, NAME, URL, DESCRIPTION, ICON, PID, SEQ, STATUS, RESOURCETYPE, CREATEDATE, NAME_CN, MENU_CODE)
values ('110000301', '查看', '/searchSystemParameter', '查看', null, '1100003', '1', '0', '1', to_date('22-11-2017 17:25:45', 'dd-mm-yyyy hh24:mi:ss'), null, null);

insert into report_resource (ID, NAME, URL, DESCRIPTION, ICON, PID, SEQ, STATUS, RESOURCETYPE, CREATEDATE, NAME_CN, MENU_CODE)
values ('110000302', '修改参数', '/editSystemParameter', '修改参数', null, '1100003', '2', '0', '1', to_date('22-11-2017 17:25:45', 'dd-mm-yyyy hh24:mi:ss'), null, null);

insert into report_resource (ID, NAME, URL, DESCRIPTION, ICON, PID, SEQ, STATUS, RESOURCETYPE, CREATEDATE, NAME_CN, MENU_CODE)
values ('110000401', '查看', '/searchObjTree', '查看', null, '1100004', '1', '0', '1', to_date('22-11-2017 17:25:45', 'dd-mm-yyyy hh24:mi:ss'), null, null);

insert into report_resource (ID, NAME, URL, DESCRIPTION, ICON, PID, SEQ, STATUS, RESOURCETYPE, CREATEDATE, NAME_CN, MENU_CODE)
values ('110000402', '新增对象树', '/addObjTree', '新增对象树', null, '1100004', '2', '0', '1', to_date('22-11-2017 17:25:45', 'dd-mm-yyyy hh24:mi:ss'), null, null);

insert into report_resource (ID, NAME, URL, DESCRIPTION, ICON, PID, SEQ, STATUS, RESOURCETYPE, CREATEDATE, NAME_CN, MENU_CODE)
values ('110000403', '修改对象树', '/editObjTree', '修改对象树', null, '1100004', '3', '0', '1', to_date('22-11-2017 17:25:45', 'dd-mm-yyyy hh24:mi:ss'), null, null);

insert into report_resource (ID, NAME, URL, DESCRIPTION, ICON, PID, SEQ, STATUS, RESOURCETYPE, CREATEDATE, NAME_CN, MENU_CODE)
values ('110000404', '维护对象树', '/maintainObjTree', '维护对象树', null, '1100004', '4', '0', '1', to_date('22-11-2017 17:25:45', 'dd-mm-yyyy hh24:mi:ss'), null, null);

insert into report_resource (ID, NAME, URL, DESCRIPTION, ICON, PID, SEQ, STATUS, RESOURCETYPE, CREATEDATE, NAME_CN, MENU_CODE)
values ('110000405', '删除对象树', '/deleteObjTree', '删除对象树', null, '1100004', '5', '0', '1', to_date('22-11-2017 17:25:45', 'dd-mm-yyyy hh24:mi:ss'), null, null);


commit;



--!QAZ2wsx
delete from REPORT_USER;

insert into REPORT_USER ( ID, LOGINNAME, NAME, PASSWORD, SEX, AGE, USERTYPE, STATUS, ORGANIZATION_ID, CREATEDATE, PHONE, STAFF_NO, PHOTO, POS_NAME, POSITION, WORK_TYPE_CODE, TECH_LEVEL_CODE, YMD, DEGREE_CODE, SRV_LEVEL_CODE, CERT_FLAG, FIXED_FLAG, ON_POS_FLAG, PROFESSION_CODE, PROFESSION_BGN_DATE, JOIN_DATE, TITEL, POLITICAL_STATUS_CODE, TITLE_LEVEL_CODE, STATUS_CODE, REMARK, P_ORGANIZATION_ID, PWD_FIRST_UPDATE, PWD_UPDATE_TIME, ICON, WEB_GUIDE_FIRST, WEB_GUIDE_UPDATE_TIME)
values ( '1', 'root', 'root', 'f01ee7e230e47fa04ec8a41e06987076', '0', null, '1', '0', null, null, '', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, '1', sysdate, null, null, null);


delete from REPORT_ROLE;

insert into REPORT_ROLE (ID, NAME, SEQ, DESCRIPTION, STATUS)
values ('1', 'Root', '0', 'System Administrator', '0');

insert into REPORT_USER_ROLE ( ID, USER_ID, ROLE_ID)
values ('1', '1', '1');

delete from report_role_resource;

insert into report_role_resource (ID, ROLE_ID, RESOURCE_ID)
values ('1', '1', '1000000');

insert into report_role_resource (ID, ROLE_ID, RESOURCE_ID)
values ('2', '1', '1000003');

insert into report_role_resource (ID, ROLE_ID, RESOURCE_ID)
values ('3', '1', '1000010');

insert into report_role_resource (ID, ROLE_ID, RESOURCE_ID)
values ('4', '1', '1000011');

insert into report_role_resource (ID, ROLE_ID, RESOURCE_ID)
values ('5', '1', '1000100');

insert into report_role_resource (ID, ROLE_ID, RESOURCE_ID)
values ('6', '1', '1000101');

insert into report_role_resource (ID, ROLE_ID, RESOURCE_ID)
values ('7', '1', '1001000');

insert into report_role_resource (ID, ROLE_ID, RESOURCE_ID)
values ('8', '1', '1001001');

insert into report_role_resource (ID, ROLE_ID, RESOURCE_ID)
values ('9', '1', '1001002');

insert into report_role_resource (ID, ROLE_ID, RESOURCE_ID)
values ('10', '1', '1010000');

insert into report_role_resource (ID, ROLE_ID, RESOURCE_ID)
values ('11', '1', '1010001');

insert into report_role_resource (ID, ROLE_ID, RESOURCE_ID)
values ('12', '1', '1010002');

insert into report_role_resource (ID, ROLE_ID, RESOURCE_ID)
values ('13', '1', '1100000');

insert into report_role_resource (ID, ROLE_ID, RESOURCE_ID)
values ('14', '1', '1100001');

insert into report_role_resource (ID, ROLE_ID, RESOURCE_ID)
values ('15', '1', '1100002');

insert into report_role_resource (ID, ROLE_ID, RESOURCE_ID)
values ('16', '1', '1100003');

insert into report_role_resource (ID, ROLE_ID, RESOURCE_ID)
values ('17', '1', '1100004');

insert into report_role_resource (ID, ROLE_ID, RESOURCE_ID)
values ('18', '1', '100001101');

insert into report_role_resource (ID, ROLE_ID, RESOURCE_ID)
values ('19', '1', '100001102');

insert into report_role_resource (ID, ROLE_ID, RESOURCE_ID)
values ('20', '1', '100001103');

insert into report_role_resource (ID, ROLE_ID, RESOURCE_ID)
values ('21', '1', '100001104');

insert into report_role_resource (ID, ROLE_ID, RESOURCE_ID)
values ('22', '1', '100010101');

insert into report_role_resource (ID, ROLE_ID, RESOURCE_ID)
values ('23', '1', '100010102');

insert into report_role_resource (ID, ROLE_ID, RESOURCE_ID)
values ('24', '1', '100010103');

insert into report_role_resource (ID, ROLE_ID, RESOURCE_ID)
values ('25', '1', '100010104');

insert into report_role_resource (ID, ROLE_ID, RESOURCE_ID)
values ('26', '1', '100010105');

insert into report_role_resource (ID, ROLE_ID, RESOURCE_ID)
values ('27', '1', '100010106');

insert into report_role_resource (ID, ROLE_ID, RESOURCE_ID)
values ('28', '1', '100010107');

insert into report_role_resource (ID, ROLE_ID, RESOURCE_ID)
values ('29', '1', '100100101');

insert into report_role_resource (ID, ROLE_ID, RESOURCE_ID)
values ('30', '1', '100100102');

insert into report_role_resource (ID, ROLE_ID, RESOURCE_ID)
values ('31', '1', '100100201');

insert into report_role_resource (ID, ROLE_ID, RESOURCE_ID)
values ('32', '1', '100100202');

insert into report_role_resource (ID, ROLE_ID, RESOURCE_ID)
values ('33', '1', '100100203');

insert into report_role_resource (ID, ROLE_ID, RESOURCE_ID)
values ('34', '1', '100100204');

insert into report_role_resource (ID, ROLE_ID, RESOURCE_ID)
values ('35', '1', '100100205');

insert into report_role_resource (ID, ROLE_ID, RESOURCE_ID)
values ('36', '1', '101000101');

insert into report_role_resource (ID, ROLE_ID, RESOURCE_ID)
values ('37', '1', '101000102');

insert into report_role_resource (ID, ROLE_ID, RESOURCE_ID)
values ('38', '1', '101000103');

insert into report_role_resource (ID, ROLE_ID, RESOURCE_ID)
values ('39', '1', '101000104');

insert into report_role_resource (ID, ROLE_ID, RESOURCE_ID)
values ('40', '1', '110000101');

insert into report_role_resource (ID, ROLE_ID, RESOURCE_ID)
values ('41', '1', '110000102');

insert into report_role_resource (ID, ROLE_ID, RESOURCE_ID)
values ('42', '1', '110000103');

insert into report_role_resource (ID, ROLE_ID, RESOURCE_ID)
values ('43', '1', '110000104');

insert into report_role_resource (ID, ROLE_ID, RESOURCE_ID)
values ('44', '1', '110000105');

insert into report_role_resource (ID, ROLE_ID, RESOURCE_ID)
values ('45', '1', '110000201');

insert into report_role_resource (ID, ROLE_ID, RESOURCE_ID)
values ('46', '1', '110000202');

insert into report_role_resource (ID, ROLE_ID, RESOURCE_ID)
values ('47', '1', '110000203');

insert into report_role_resource (ID, ROLE_ID, RESOURCE_ID)
values ('48', '1', '110000204');

insert into report_role_resource (ID, ROLE_ID, RESOURCE_ID)
values ('49', '1', '110000205');

insert into report_role_resource (ID, ROLE_ID, RESOURCE_ID)
values ('50', '1', '110000401');

insert into report_role_resource (ID, ROLE_ID, RESOURCE_ID)
values ('51', '1', '110000402');

insert into report_role_resource (ID, ROLE_ID, RESOURCE_ID)
values ('52', '1', '110000403');

insert into report_role_resource (ID, ROLE_ID, RESOURCE_ID)
values ('53', '1', '110000404');

insert into report_role_resource (ID, ROLE_ID, RESOURCE_ID)
values ('54', '1', '110000405');

insert into report_role_resource (ID, ROLE_ID, RESOURCE_ID)
values ('55', '1', '110000301');

insert into report_role_resource (ID, ROLE_ID, RESOURCE_ID)
values ('56', '1', '110000302');

insert into report_role_resource (ID, ROLE_ID, RESOURCE_ID)
values ('57', '1', '100000301');

insert into report_role_resource (ID, ROLE_ID, RESOURCE_ID)
values ('58', '1', '100000302');

insert into report_role_resource (ID, ROLE_ID, RESOURCE_ID)
values ('59', '1', '100000303');

insert into report_role_resource (ID, ROLE_ID, RESOURCE_ID)
values ('60', '1', '100000304');

insert into report_role_resource (ID, ROLE_ID, RESOURCE_ID)
values ('61', '1', '100000305');

insert into report_role_resource (ID, ROLE_ID, RESOURCE_ID)
values ('62', '1', '100000306');

insert into report_role_resource (ID, ROLE_ID, RESOURCE_ID)
values ('63', '1', '100000307');

insert into report_role_resource (ID, ROLE_ID, RESOURCE_ID)
values ('64', '1', '100000308');

insert into report_role_resource (ID, ROLE_ID, RESOURCE_ID)
values ('65', '1', '100000309');

insert into report_role_resource (ID, ROLE_ID, RESOURCE_ID)
values ('66', '1', '101000105');

insert into report_role_resource (ID, ROLE_ID, RESOURCE_ID)
values ('67', '1', '101000106');

insert into report_role_resource (ID, ROLE_ID, RESOURCE_ID)
values ('68', '1', '101000107');



commit;

--系统参数表
insert into REPORT_SYS_PARAMETER (ID, MODULE, NAME, VALUE, REMARK, IS_PASSWORD)
values ('10002', 'Report', 'Daily Type', '日报表', null, '0');

insert into REPORT_SYS_PARAMETER (ID, MODULE, NAME, VALUE, REMARK, IS_PASSWORD)
values ('10003', 'Report', 'Monthly Type', '月报表', null, '0');

--insert into REPORT_SYS_PARAMETER (ID, MODULE, NAME, VALUE, REMARK, IS_PASSWORD)
--values ('10004', 'Report', '目录', '/test', null, '0');

insert into REPORT_SYS_PARAMETER (ID, MODULE, NAME, VALUE, REMARK, IS_PASSWORD)
values ('10004', 'Report', 'Catalog', '/test', null, '0');

insert into REPORT_SYS_PARAMETER (ID, MODULE, NAME, VALUE, REMARK, IS_PASSWORD)
values ('10001', 'Report', 'Expiry Time', '180', '天', '0');

insert into REPORT_SYS_PARAMETER (ID, MODULE, NAME, VALUE, REMARK, IS_PASSWORD)
values ('10005', 'Report', 'Date Format', 'yyyy-MM-dd HH:mm:ss', null, '0');

insert into REPORT_SYS_PARAMETER (ID, MODULE, NAME, VALUE, REMARK, IS_PASSWORD)
values ('10006', 'Report', 'FTPHOST', '192.168.80.11', 'HOST', '0');

insert into REPORT_SYS_PARAMETER (ID, MODULE, NAME, VALUE, REMARK, IS_PASSWORD)
values ('10007', 'Report', 'FTPPORT', '21', 'PORT', '0');

insert into REPORT_SYS_PARAMETER (ID, MODULE, NAME, VALUE, REMARK, IS_PASSWORD)
values ('10008', 'Report', 'FTPUSERNAME', 'amiftpuser', 'USERNAME', '0');

insert into REPORT_SYS_PARAMETER (ID, MODULE, NAME, VALUE, REMARK, IS_PASSWORD)
values ('10009', 'Report', 'FTPPASSWORD', '7a6237b6df19fb6e6dd209815f5a6bac', 'PASSWORD', '1');

commit;


-- 报表定时任务脚本


create table P_TASK
(
  TASK_ID          NUMBER(16) primary key,
  NAME             VARCHAR2(256) not null,
  REPEAT_MODE      VARCHAR2(8) not null,
  REPEAT_INTERVAL  NUMBER(32),
  RUN_TIME         DATE,
  VALID_TIME       DATE,
  INVALID_TIME     DATE,
  RETRY_TIMES      NUMBER(5),
  RETRY_INTERVAL   DATE,
  FAIL_NOTICE_MODE VARCHAR2(8),
  FAIL_RECEIVER_NO VARCHAR2(16),
  PRIO             NUMBER(8),
  NOTIFY_MODE      VARCHAR2(8),
  NOTIFY_EMP_NO    VARCHAR2(16),
  SET_EMP_NO       VARCHAR2(16),
  SET_TIME         DATE,
  CONTENT          VARCHAR2(4000),
  STATUS           NUMBER(5),
  CRON_EXPRE       VARCHAR2(256),
  IS_VALID         NUMBER(5),
  HANDLE           VARCHAR2(256) not null,
  ALIAS            VARCHAR2(256) not null,
  REPEAT_TIMES     NUMBER(5),
  TASK_TYPE        VARCHAR2(8),
  TASK_CODE        VARCHAR2(16),
  TIMEOUT_MIN      NUMBER(8),
  FAIL_PHONE       VARCHAR2(2000),
  FAIL_EMAILL      VARCHAR2(3000),
  SERVICE_URL      VARCHAR2(256),
  P_TASKCODE       VARCHAR2(16)
);

create table P_TASK_LOG
(
  TASK_LOG_ID      NUMBER(16) primary key not null,
  TASK_ID          NUMBER(16) not null,
  RUN_RSLT         VARCHAR2(8),
  RUN_DESC         VARCHAR2(4000),
  ACCTUAL_RUN_TIME DATE,
  START_RUN_TIME   DATE,
  END_RUN_TIME     DATE,
  TASK_NAME        VARCHAR2(256),
  TASK_NAME_ALIAS  VARCHAR2(256),
  CONS_TIME        NUMBER(16)
);

create table P_TASK_PARA
(
  PARA_ID   NUMBER(16) primary key  not null,
  TASK_ID   NUMBER(16) not null,
  NAME      VARCHAR2(256),
  TYPE_CODE VARCHAR2(8),
  PARA_DESC VARCHAR2(256),
  CONTENT   VARCHAR2(256)
);

create table P_TASK_SCHEDULE_LOG
(
  ID             NUMBER(16)  primary key not null,
  TASK_ID        NUMBER(16),
  TASK_NAME      VARCHAR2(256),
  RUN_RSLT       VARCHAR2(8),
  RUN_DESC       VARCHAR2(4000),
  START_RUN_TIME TIMESTAMP(6),
  END_RUN_TIME   TIMESTAMP(6),
  TASK_TYPE      VARCHAR2(16),
  TASK_DESC      VARCHAR2(1000),
  CONS_TIME      NUMBER(16),
  HANDLE         VARCHAR2(64)
);

truncate table p_task;

insert into P_TASK (TASK_ID, NAME, REPEAT_MODE, REPEAT_INTERVAL, RUN_TIME, VALID_TIME, INVALID_TIME, RETRY_TIMES, RETRY_INTERVAL, FAIL_NOTICE_MODE, FAIL_RECEIVER_NO, PRIO, NOTIFY_MODE, NOTIFY_EMP_NO, SET_EMP_NO, SET_TIME, CONTENT, STATUS, CRON_EXPRE, IS_VALID, HANDLE, ALIAS, REPEAT_TIMES, TASK_TYPE, TASK_CODE, TIMEOUT_MIN, FAIL_PHONE, FAIL_EMAILL, SERVICE_URL, P_TASKCODE)
values (2, 'IntervalTimeJob', '0', 60, null, to_date('01-09-2017 10:48:09', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-02-2027', 'dd-mm-yyyy'), 3, null, null, null, 1, null, null, null, null, null, 1, null, 1, 'generateReportScheduleJob', 'generateReportScheduleJob', 10, null, null, null, null, null, null, null);

commit;


-- 报表任务表

create table REPORT_TASK
(
  id              varchar2(16) not null,
  name            varchar2(256),
  code            varchar2(8),
  start_time      DATE,
  end_time        DATE,
  offset          integer,
  type            varchar2(8),
  status          varchar2(8),
  handle          varchar2(128),
  remark          VARCHAR2(3000),
  create_time     DATE
);

create table REPORT_TASK_TEMP
(
  id              varchar2(16) not null,
  task_id         varchar2(16),
  tmp_id          varchar2(16)
);

-- 任务对象表
create table REPORT_TASK_OBJECT
(
  id              varchar2(16) not null,
  task_id         varchar2(16),
  obj_id          varchar2(16),
  obj_name        varchar2(255),
  tree_id         varchar2(16),
  tree_code       varchar2(255),
  tree_name       varchar2(255)
);


-- Quartz表


create table QRTZ_JOB_DETAILS
(
  SCHED_NAME        VARCHAR2(120) not null,
  JOB_NAME          VARCHAR2(200) not null,
  JOB_GROUP         VARCHAR2(200) not null,
  DESCRIPTION       VARCHAR2(250),
  JOB_CLASS_NAME    VARCHAR2(250) not null,
  IS_DURABLE        NUMBER(11) not null,
  IS_NONCONCURRENT  NUMBER(11) not null,
  IS_UPDATE_DATA    NUMBER(11) not null,
  REQUESTS_RECOVERY NUMBER(11) not null,
  JOB_DATA          BLOB,
  primary key (SCHED_NAME, JOB_NAME, JOB_GROUP) 
);

create table QRTZ_TRIGGERS
(
  SCHED_NAME     VARCHAR2(120) not null,
  TRIGGER_NAME   VARCHAR2(200) not null,
  TRIGGER_GROUP  VARCHAR2(200) not null,
  JOB_NAME       VARCHAR2(200) not null,
  JOB_GROUP      VARCHAR2(200) not null,
  DESCRIPTION    VARCHAR2(250),
  NEXT_FIRE_TIME NUMBER(20),
  PREV_FIRE_TIME NUMBER(20),
  PRIORITY       NUMBER(13),
  TRIGGER_STATE  VARCHAR2(32) not null,
  TRIGGER_TYPE   VARCHAR2(16) not null,
  START_TIME     NUMBER(20) not null,
  END_TIME       NUMBER(20),
  CALENDAR_NAME  VARCHAR2(200),
  MISFIRE_INSTR  NUMBER(12),
  JOB_DATA       BLOB,
  primary key (SCHED_NAME, TRIGGER_NAME, TRIGGER_GROUP) 
);

create table QRTZ_BLOB_TRIGGERS
(
  SCHED_NAME    VARCHAR2(120) not null,
  TRIGGER_NAME  VARCHAR2(200) not null,
  TRIGGER_GROUP VARCHAR2(200) not null,
  BLOB_DATA     BLOB,
  primary key (SCHED_NAME, TRIGGER_NAME, TRIGGER_GROUP) 
);

create table QRTZ_CALENDARS
(
  SCHED_NAME    VARCHAR2(120) not null,
  CALENDAR_NAME VARCHAR2(200) primary key  not null,
  CALENDAR      BLOB not null
);

create table QRTZ_CRON_TRIGGERS
(
  SCHED_NAME      VARCHAR2(120) not null,
  TRIGGER_NAME    VARCHAR2(200) not null,
  TRIGGER_GROUP   VARCHAR2(200) not null,
  CRON_EXPRESSION VARCHAR2(120) not null,
  TIME_ZONE_ID    VARCHAR2(80),
  primary key (SCHED_NAME, TRIGGER_NAME, TRIGGER_GROUP) 
);

create table QRTZ_FIRED_TRIGGERS
(
  SCHED_NAME        VARCHAR2(120) not null,
  ENTRY_ID          VARCHAR2(95) not null,
  TRIGGER_NAME      VARCHAR2(200) not null,
  TRIGGER_GROUP     VARCHAR2(200) not null,
  INSTANCE_NAME     VARCHAR2(200) not null,
  FIRED_TIME        NUMBER(20) not null,
  SCHED_TIME        NUMBER(20) not null,
  PRIORITY          NUMBER(12) not null,
  STATE             VARCHAR2(16) not null,
  JOB_NAME          VARCHAR2(200),
  JOB_GROUP         VARCHAR2(200),
  IS_NONCONCURRENT  NUMBER(11),
  REQUESTS_RECOVERY NUMBER(11),
  primary key (SCHED_NAME, ENTRY_ID) 
);

create table QRTZ_JOB_LISTENERS
(
  SCHED_NAME   VARCHAR2(120) not null,
  JOB_NAME     VARCHAR2(200) not null,
  JOB_GROUP    VARCHAR2(200) not null,
  JOB_LISTENER VARCHAR2(200) not null
);

create table QRTZ_LOCKS
(
  SCHED_NAME VARCHAR2(120) not null,
  LOCK_NAME  VARCHAR2(40) not null,
  primary key (SCHED_NAME, LOCK_NAME) 
);

create table QRTZ_PAUSED_TRIGGER_GRPS
(
  SCHED_NAME    VARCHAR2(120) not null,
  TRIGGER_GROUP VARCHAR2(200) not null,
  primary key (SCHED_NAME, TRIGGER_GROUP) 
);

create table QRTZ_SCHEDULER_STATE
(
  SCHED_NAME        VARCHAR2(120) not null,
  INSTANCE_NAME     VARCHAR2(200) not null,
  LAST_CHECKIN_TIME NUMBER(20) not null,
  CHECKIN_INTERVAL  NUMBER(20) not null,
  primary key (SCHED_NAME, INSTANCE_NAME) 
);

create table QRTZ_SIMPLE_TRIGGERS
(
  SCHED_NAME      VARCHAR2(120) not null,
  TRIGGER_NAME    VARCHAR2(200) not null,
  TRIGGER_GROUP   VARCHAR2(200) not null,
  REPEAT_COUNT    NUMBER(20) not null,
  REPEAT_INTERVAL NUMBER(20) not null,
  TIMES_TRIGGERED NUMBER(20) not null,
  primary key (SCHED_NAME, TRIGGER_NAME, TRIGGER_GROUP) 
);

create table QRTZ_SIMPROP_TRIGGERS
(
  SCHED_NAME    VARCHAR2(120) not null,
  TRIGGER_NAME  VARCHAR2(200) not null,
  TRIGGER_GROUP VARCHAR2(200) not null,
  STR_PROP_1    VARCHAR2(512),
  STR_PROP_2    VARCHAR2(512),
  STR_PROP_3    VARCHAR2(512),
  INT_PROP_1    NUMBER(11),
  INT_PROP_2    NUMBER(11),
  LONG_PROP_1   NUMBER(20),
  LONG_PROP_2   NUMBER(20),
  DEC_PROP_1    NUMBER(13,4),
  DEC_PROP_2    NUMBER(13,4),
  BOOL_PROP_1   VARCHAR2(4),
  BOOL_PROP_2   VARCHAR2(4),
  primary key (SCHED_NAME, TRIGGER_NAME, TRIGGER_GROUP) 
);

create table QRTZ_TRIGGER_LISTENERS
(
  SCHED_NAME       VARCHAR2(120) not null,
  TRIGGER_NAME     VARCHAR2(200) not null,
  TRIGGER_GROUP    VARCHAR2(200) not null,
  TRIGGER_LISTENER VARCHAR2(200) not null
);


truncate table qrtz_fired_triggers;
truncate table qrtz_locks;

insert into QRTZ_FIRED_TRIGGERS (SCHED_NAME, ENTRY_ID, TRIGGER_NAME, TRIGGER_GROUP, INSTANCE_NAME, FIRED_TIME, SCHED_TIME, PRIORITY, STATE, JOB_NAME, JOB_GROUP, IS_NONCONCURRENT, REQUESTS_RECOVERY)
values ('taskSchedulerFactory', 'linux-k60p15064078671506407960130', '2', 'SCANTASK', 'linux-k60p1506407867', 1506672849642, 1506672864705, 5, 'ACQUIRED', null, null, 0, 0);
insert into QRTZ_FIRED_TRIGGERS (SCHED_NAME, ENTRY_ID, TRIGGER_NAME, TRIGGER_GROUP, INSTANCE_NAME, FIRED_TIME, SCHED_TIME, PRIORITY, STATE, JOB_NAME, JOB_GROUP, IS_NONCONCURRENT, REQUESTS_RECOVERY)
values ('dufy_test', 'NON_CLUSTERED1487230171387', 'trigger1', 'group1', 'NON_CLUSTERED', 1487230212028, 1487230214000, 5, 'ACQUIRED', null, null, 0, 0);

insert into QRTZ_LOCKS (SCHED_NAME, LOCK_NAME)
values ('dufy_test', 'TRIGGER_ACCESS');
insert into QRTZ_LOCKS (SCHED_NAME, LOCK_NAME)
values ('quartzScheduler', 'TRIGGER_ACCESS');
insert into QRTZ_LOCKS (SCHED_NAME, LOCK_NAME)
values ('scheduler', 'TRIGGER_ACCESS');
insert into QRTZ_LOCKS (SCHED_NAME, LOCK_NAME)
values ('taskSchedulerFactory', 'STATE_ACCESS');
insert into QRTZ_LOCKS (SCHED_NAME, LOCK_NAME)
values ('taskSchedulerFactory', 'TRIGGER_ACCESS');

commit;


alter table report_report_file add USERID VARCHAR2(16);


insert into report_task (ID, NAME, CODE, START_TIME, END_TIME, OFFSET, TYPE, STATUS, HANDLE, REMARK, CREATE_TIME)
values ('252289702000002', '月报表任务', '01', to_date('20-12-2017', 'dd-mm-yyyy'), to_date('31-12-2024', 'dd-mm-yyyy'), '0', '1', '01', '0 0 1 1 1/1 ?', '每月1号1点执行', to_date('20-12-2017 10:50:29', 'dd-mm-yyyy hh24:mi:ss'));

insert into report_task (ID, NAME, CODE, START_TIME, END_TIME, OFFSET, TYPE, STATUS, HANDLE, REMARK, CREATE_TIME)
values ('252289702000001', '日报表任务', '01', to_date('20-12-2017', 'dd-mm-yyyy'), to_date('31-12-2026', 'dd-mm-yyyy'), '0', '0', '01', '0 0 1 1/1 * ?', '每天1点执行', to_date('20-12-2017 10:49:59', 'dd-mm-yyyy hh24:mi:ss'));



commit;






--日志
CREATE TABLE REPORT_SYS_SYSLOG
(
  ID          NUMBER(20) NOT NULL,
  LOGIN_NAME  VARCHAR2(64),
  ROLE_NAME   VARCHAR2(64),
  OPT_CONTENT VARCHAR2(256),
  CLIENT_IP   VARCHAR2(64),
  CREATE_TIME TIMESTAMP(3),
  USER_ID     VARCHAR2(16),
  PARAMS      VARCHAR2(3000),
  LOG_TYPE    VARCHAR2(8),
  OPT_DETAIL  VARCHAR2(3000),
  SESSION_ID  VARCHAR2(64)
);



insert into REPORT_RESOURCE (ID, NAME, URL, DESCRIPTION, ICON, PID, SEQ, STATUS, RESOURCETYPE, CREATEDATE, NAME_CN, MENU_CODE)
values ('1100005', '操作日志', '/syslog', '操作日志', null, '1100000', '5', '0', '0', null, null, null);

insert into REPORT_RESOURCE (ID, NAME, URL, DESCRIPTION, ICON, PID, SEQ, STATUS, RESOURCETYPE, CREATEDATE, NAME_CN, MENU_CODE)
values ('110000501', '查看', '/searchSyslog', '查看', null, '1100005', '1', '0', '1', null, null, null);

insert into REPORT_ROLE_RESOURCE (ID, ROLE_ID, RESOURCE_ID)
values ('69', '1', '1100005');

insert into REPORT_ROLE_RESOURCE (ID, ROLE_ID, RESOURCE_ID)
values ('70', '1', '110000501');

commit;
