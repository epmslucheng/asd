spool &1 append

prompt 1.Close User Connection
begin
  for x in(select sid,serial# from v$session where username='REPORTER') loop
        execute immediate 'alter system kill session '''||x.sid||','||x.serial#||'''';
  end loop;
end;
/
prompt
prompt 1.Close User Connection  End
prompt
prompt 2.Drop User Begin...
declare
begin
    execute immediate 'drop user REPORTER cascade';
exception
    when others then
       dbms_output.put_line('drop user exception');  
end;
/
prompt
prompt 2.Drop User End...

spool OFF
spool &1 append

prompt
prompt 3.Drop TABLESPACE
declare
begin
    execute immediate 'DROP TABLESPACE REPORTER_DATA INCLUDING CONTENTS AND DATAFILES CASCADE CONSTRAINTS';
exception
    when others then
       dbms_output.put_line('drop tablespace exception');  
end;
/
prompt
prompt 3.Drop TABLESPACE End...
commit;

spool OFF