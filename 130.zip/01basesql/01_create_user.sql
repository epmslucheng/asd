spool &1 append
prompt
prompt 1.Creating tablespace REPORTER_DATA Begin...
create tablespace REPORTER_DATA datafile '&2/REPORTER_DATA01.dbf' SIZE 1G autoextend on NEXT 300M;
prompt 1.Creating tablespace REPORTER_DATA End...


spool OFF
spool &1 append

prompt
prompt 3.Creating user REPORTER Begin...
create user REPORTER identified by REPORTER_123 DEFAULT TABLESPACE REPORTER_DATA;
prompt 3.Creating user REPORTER End...

spool OFF
spool &1 append

prompt
prompt 4.Granting user REPORTER Begin...
grant CONNECT,RESOURCE to REPORTER;
alter user REPORTER quota unlimited on REPORTER_DATA;
grant select any dictionary to REPORTER;
grant insert any table to REPORTER;
grant update any table to REPORTER;
grant delete any table to REPORTER; 
grant EXECUTE ON  dbms_lock to REPORTER;
grant create procedure to EPMS;
grant create session,create job,create external job to REPORTER; 
grant create any view to REPORTER; 
--GRANT debug any procedure, debug connect session TO EPMS;  
commit;
prompt
prompt 4.Granting user REPORTER End...

spool OFF