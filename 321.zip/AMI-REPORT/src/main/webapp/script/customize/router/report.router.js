//var app = angular.module("main.webapp", ["ui.router"]);
//(function($,app,path){
//	"use strict";
//	
//	app.config(function ($stateProvider, $urlRouterProvider,$httpProvider) {
//		$httpProvider.interceptors.push('httpInterceptor'); 
//		$urlRouterProvider.otherwise("login");
//	     $stateProvider
//	        .state("login", { url: "/login",  templateUrl: path + "/login"})
//	        .state("home", { url:"/home",  templateUrl: path + "/home"});
//	});
//	
//	app.factory('httpInterceptor', [ '$q', '$injector',function($q, $injector) { 
//	    var httpInterceptor = { 
//	      'responseError' : function(response) {  return $q.reject(response);  }, 
//	      'response' : function(response) { return response;  }, 
//	      'request' : function(config) {config.headers['token'] = true; return config;  }, 
//	      'requestError' : function(config){  return $q.reject(config);  } 
//	    } 
//	  return httpInterceptor; 
//	}]); 
//})(jQuery,app,basePath || '/REPORT');