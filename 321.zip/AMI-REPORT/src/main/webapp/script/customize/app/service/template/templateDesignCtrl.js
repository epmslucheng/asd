;
(function($, app) {
  "use strict";
  // 模板管理
  app.controller("templateDesignCtrl", function($scope, $http, $timeout, $compile, $element) {

    function extendDeep(parent) {
      var i, proxy;
      proxy = JSON.stringify(parent); // 把parent对象转换成字符串
      proxy = JSON.parse(proxy) // 把字符串转换成对象，这是parent的一个副本
      var child = [];
      for (i in proxy) {
        if (proxy.hasOwnProperty(i)) {
          child[i] = proxy[i];
        }
      }
      proxy = null; // 因为proxy是中间对象，可以将它回收掉
      return child;
    }

    var leng = 0;
    var nindex = null;
    var template = $scope.template;
    var datalist = [];
    var oldlength = 0;
    $.post(basePath + "/templateManagement/getData?date=" + new Date(), {
      tmpid: template.tmpid
    }, function(result) {
      var odatalist = [];
      if (result) {
        result = JSON.parse(result);
      }
      var dataList = result.list;
      $scope.dataList = dataList;
      oldlength = dataList.length;
      for (var k = 0; k < oldlength; k++) {
        var obj = {
          insertPosition: dataList[k].position,
          positionName: dataList[k].sheetname + '->' + dataList[k].dataname
        };
        odatalist.push(obj);
      }
      $http.get(basePath + '/customDataSet/queryAll?date=' + new Date()).success(function(result) {
        datalist = extendDeep(result);
        $scope.dataCollection = extendDeep(result);
        $.post(basePath + "/templateManagement/getDesgin?date=" + new Date(), {
          tmpid: template.tmpid
        }, function(result) {
          if (result) {
            result = JSON.parse(result);
          }
          var deslist = result.list;
          // $scope.dataGrid
          // =
          // result.list;
          var len = $scope.dataCollection.length;
          for (var i = 0; i < len; i++) {
            var ret = 0;
            var ret2 = 0;
            for (var j = 0; j < deslist.length; j++) {
              if ($scope.dataCollection[i].queryId == deslist[j].queryid) {
                var jj = 0;
                for (var m = 0; m < odatalist.length; m++) {
                  if (deslist[j].toexcel == odatalist[m].insertPosition) {
                    jj++;
                    odatalist[m].queryId = $scope.dataCollection[i].queryId;
                    odatalist[m].queryName = $scope.dataCollection[i].queryName;
                  }
                }
                ret++;
                if (jj == 0) {
                  var ttt = extendDeep($scope.dataCollection);
                  ttt[i].insertPosition = deslist[j].toexcel;
                  odatalist.push(ttt[i]);
                }
              }
            }
          }
          for (var u = 0; u < odatalist.length; u++) {
            odatalist[u].index = u;
          }
          $scope.$apply(function() {
            $scope.dataCollection = extendDeep(datalist);
            $scope.dataGrid = extendDeep(odatalist);
          })
        });
      });

    });

    var dragid = "";

    $scope.currentContainer = "";
    $scope.currentD = "";
    $scope.dropContainer = function(event) {
      $scope.currentContainer = event.target.parentElement;
      var i = $scope.currentContainer.children[0].innerHTML;
      nindex = i - 1;
      $scope.currentD = $scope.dataGrid[nindex];
    }
    // $scope.dataGrid = [];
    $scope.drag = function(o, index) {
      $('#drag_' + index).draggable({
        handle: '#item_' + (index - leng),
        revert: true,
        deltaX: 0,
        deltaY: 0,
        proxy: function(source) {
          var p = $('<div class="drag-item"></div>');
          p.html($(source).html().replace("drag-div", "")).appendTo('body');
          return p;
        },
        onBeforeDrag: function() {
          $(".drag-table").droppable({
            accept: '#drag_' + (index - leng),
            onDrop: function(e, source) {
              dragid = source.id;
              $scope.$apply(function() {
                if ($scope.currentContainer.className.indexOf("drag-table") != -1) {
                  $scope.dataGrid.push(o);
                } else {
                  $scope.dataGrid[nindex].queryId = o.queryId;
                  $scope.dataGrid[nindex].queryName = o.queryName;
                }
              });
              $(source).css("left", "0px");
              $(source).css("top", "0px");
            },
          });
        },
        onStopDrag: function() {
          $("#" + dragid).css("left", "0px");
          $("#" + dragid).css("top", "0px");
          $scope.$apply(function() {
            $scope.dataCollection = extendDeep(datalist);
          })
        }
      });
    }
    $scope.saveDesgin = function() {
      $.parser.parse($("#designForm").parent());
      if (!$("#designForm").form('enableValidation').form("validate")) return;
      var list = $scope.dataGrid;
      var designList = [];
      var hangList = [];
      for (var dataset = 0; dataset < list.length; dataset++) {
        var design = new Object();
        design.reportid = template.tmpid;
        design.queryid = list[dataset].queryId;
        design.toexcel = list[dataset].insertPosition;
        hangList.push(list[dataset].insertPosition.substring(list[dataset].insertPosition.lastIndexOf('$') + 1, list[dataset].insertPosition.length));
        designList.push(design);
      }

      var nary = hangList.sort();
      for (var y = 0; y < nary.length - 1; y++) {
        if (nary[y] == nary[y + 1]) {
          $.messager.alert($.i18n.prop('ami.common.warning'), $.i18n.prop('ami.template.hangrepeat'), 'warning');
          return;
        }
      }

      $.ajax({
        type: "post",
        data: {
          designList: JSON.stringify(designList),
          tmpid: template.tmpid
        },
        url: basePath + "/templateManagement/saveDesgin",
        beforeSend: function() {
          $("#save").attr("disabled", "disabled");
        },
        success: function(result) {
          if (result) {
            result = JSON.parse(result);
          }
          if (result.success) {
            $.messager.alert($.i18n.prop('ami.template.notice'), $.i18n.prop('ami.template.bind_success'), 'warning');
            $("#main").tabs("close", $scope.template.tmpname + $.i18n.prop('ami.template.bind'));
          } else {
            $.messager.alert($.i18n.prop('ami.template.notice'), $.i18n.prop('ami.template.bind_failed'), 'warning');
          }
        },
        complete: function() {
          $("#save").removeAttr("disabled");
        },
        error: function(data) {
          console.info("error: " + data.responseText);
        }
      });
    }

    $scope.deleteDesign = function(index) {
      if (oldlength > index) {
        $scope.dataGrid[index] = {
          insertPosition: $scope.dataGrid[index].insertPosition,
          positionName: $scope.dataGrid[index].positionName
        };
      } else {
        $scope.dataGrid.splice(index, 1);
      }
      $scope.dataGrid = extendDeep($scope.dataGrid);
    }

  });
})(jQuery, app)