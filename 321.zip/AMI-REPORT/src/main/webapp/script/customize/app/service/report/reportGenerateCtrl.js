;
(function($, app) {
	"use strict";
	// 模板管理
	app
			.controller(
					"reportGenerateCtrl",
					function($scope, $http, $timeout, $compile, $element) {
						$scope.tableHeader = [
								{
									field : 'id',
									title : 'ID',
									width : '10%',
									align : 'left',
									hidden : true
								},
								{
									field : 'name',
									title : $.i18n.prop('ami.object.name'),
									width : '40%',
									align : 'left'
								},
								{
									field : 'treeName',
									title : $.i18n.prop('ami.report.objectkey'),
									width : '58%',
									align : 'left',
									formatter : function(value, row, index) {
										var objectId = row.id;
										return '<input id="'
												+ objectId
												+ '_treeName_'
												+ index
												+ '" value="'
												+ value
												+ '"  data-options="editable:false" class="treeNameClass" style="width:80%"/>';
										/*
										 * 
										 * return '<select-tree
										 * select-btn-ok="sure()"
										 * input-text="content"> '+ '<epms-tree
										 * tree-data="objTreeList"
										 * parent-id="treePid"
										 * text-field="treeName"
										 * value-field="treeId"
										 * search-filter="treeSearch1" '+
										 * 'item-edit="true"
										 * item-checkbox="true"></epms-tree> '+ '</select-tree> ';
										 */

									}
								},
								{
									field : 'treeCode',
									formatter : function(value, row, index) {
										return '<input id="treeCode' + index
												+ '" value="' + value
												+ '" style="width:80%"/>';
									},
									hidden : true
								},
								{
									field : 'treeId',
									formatter : function(value, row, index) {
										return '<input id="treeId' + index
												+ '" value="' + value
												+ '" style="width:80%"/>';
									},
									hidden : true
								} ];

						$scope.tableUrl = basePath
								+ '/objectTree/queryForReport?tmpId='
								+ $scope.template.tmpid;
						$scope
								.$on(
										"loadSuccess",
										function(e, data) {
											$(".treeNameClass")
													.searchbox(
															{
																width : 203,
																height : 24,
																searcher : function(
																		value,
																		name) {
																	var treeCodeId = "";
																	var treeNameId = $(
																			this)
																			.attr(
																					"id");
																	var treeCode = "";
																	var objectId = "";
																	if (treeNameId) {
																		var index = treeNameId
																				.split("_");
																		objectId = index[0];
																		treeCodeId = ("treeCode" + index[2]);
																		treeCode = $(
																				"#"
																						+ treeCodeId)
																				.val();
																	}
																	choseTree(
																			objectId,
																			treeNameId,
																			treeCodeId,
																			treeCode);
																},
																prompt : $.i18n
																		.prop('ami.report.key_message')
															});

											$compile(
													$(data.target)
															.find(
																	"td[field='operation'] > div"))
													($scope);// 手动编译表格最后一列，同步angularjs事件操作
										});

						function choseTree(objectId, treeNameId, treeCodeId,
								treeCode) {
							$scope.objectTree = {};
							$scope.objectTree.id = objectId;

							$.model($.i18n.prop('ami.report.object'), basePath
									+ "/objectTree/choosePage",
									$scope.objectTree, function(result) {
										return $compile(result)($scope)
									}, function(m) {

									}, 600, 400);

						}
					});

})(jQuery, app)