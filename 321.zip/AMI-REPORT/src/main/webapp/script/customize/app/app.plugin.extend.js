$.ajaxSetup({ 
	cache: false,
    global: true,
    jsonp: null,
    jsonpCallback: null,
    complete:function(XMLHttpRequest,status){   
    	var sessionstatus=XMLHttpRequest.getResponseHeader("sessionstatus"); /**通过XMLHttpRequest取得响应头,sessionstatus， **/ 
    	if(sessionstatus=='timeout') {
        	window.location.href = basePath + "/login";/** 如果超时就处理 ，指定要跳转的页面 **/
        }
    }   
});


// 扩展tree，使其支持平滑数据格式
$.fn.tree.defaults.loadFilter = function(e, h) {
  var b = $(this).data().tree.options;
  var a, c, g;
  if (b.parentField) {
    a = b.idFiled || "id";
    c = b.textFiled || "text";
    g = b.parentField;
    var f, d, j = [], k = [];
    for (f = 0, d = e.length; f < d; f++) {
      k[e[f][a]] = e[f]
    }
    for (f = 0, d = e.length; f < d; f++) {
      if (k[e[f][g]] && e[f][a] != e[f][g]) {
        if (!k[e[f][g]]["children"]) {
          k[e[f][g]]["children"] = []
        }
        e[f]["text"] = e[f][c];
        k[e[f][g]]["children"].push(e[f])
      } else {
        e[f]["text"] = e[f][c];
        j.push(e[f])
      }
    }
    return j
  }
  return e
};
// tab选项卡关闭、关闭其他、关闭全部
$.extend($.fn.tabs.methods, {
  allTabs: function(c) {
    var a = $(c).tabs("tabs");
    var b = [];
    b = $.map(a, function(e, d) {
      return $(e).panel("options")
    });
    return b
  },
  closeCurrent: function(d) {
    var c = $(d).tabs("getSelected"), b = $(d).tabs("getTabIndex", c);
    var a = c.panel("options");
    if (a.closable) {
      $(d).tabs("close", b)
    }
  },
  closeAll: function(b) {
    var a = $(b).tabs("allTabs");
    $.each(a, function(c, d) {
      if (d.closable) {
        $(b).tabs("close", d.title)
      }
    })
  },
  closeOther: function(d) {
    var a = $(d).tabs("allTabs");
    var c = $(d).tabs("getSelected"), b = $(d).tabs("getTabIndex", c);
    $.each(a, function(e, f) {
      if (b != e && f.closable) {
        $(d).tabs("close", f.title)
      }
    })
  },
  closeLeft: function(e) {
    var b = $(e).tabs("allTabs");
    var d = $(e).tabs("getSelected"), c = $(e).tabs("getTabIndex", d);
    var a = c - 1;
    while (a > -1) {
      $(e).tabs("close", b[a].title);
      a--
    }
  },
  closeRight: function(f) {
    var c = $(f).tabs("allTabs");
    var e = $(f).tabs("getSelected"), d = $(f).tabs("getTabIndex", e);
    var b = d + 1, a = c.length;
    while (b < a) {
      $(f).tabs("close", c[b].title);
      b++
    }
  }
});
//$.extend($.messager.defaults, {
//  top: '10%'
//});
//$.extend($.fn.dialog.defaults, {
//  top: '10%'
//});
// 扩展数组删除指定元素的方法
Array.prototype.remove = function(val) {
  var index = this.indexOf(val);
  if (index > -1) {
    this.splice(index, 1);
  }
};

// 模态框参数说明（按顺序）：标题、请求地址、参数、编译后的html、点击保存时回调
$.model = function(title, url, param, compile, callback, width, height) {
  width = width || 750;
  height = height || 480;
  $.ajax({
    type: "POST",
    url: url,
    dataType: "html",
    contentType: "application/json",
    data: angular.toJson(param),
    success: function(result) {
      // 获取当前tabs的panel元素
      // var tabPanel = $('#main').tabs('getSelected');
      // var d = $('<div class="dialog-s"/>').appendTo(tabPanel).dialog({
      var d = $('<div class="dialog-s"/>').dialog({
        title: title,
        // inline:true,//将模态框显示在父容器上
        width: width,
        height: height,
        content: compile(result),
        modal: true,
        onClose: function() {
          $(d).dialog('destroy');
        }
      }).hide().fadeIn(50);
      d.find(".ami-close").on("click", function() {
        $(d).dialog('destroy');
      });
      d.find(".ami-save").on("click", function() {
        callback(d);
      });
    }
  });
}

$.model.close = function(m) {
  $(m).dialog('destroy');
};

$.fileUpload = function(fileId, url, data, callback) {
  $.ajaxFileUpload({
    url: url, // 上传处理程序地址。
    data: data || {}, // 自定义参数
    fileElementId: fileId, // 文件选择框的id属性 注：如果这里是EasyUi 不用id属性，用name
    secureuri: false, // 是否启用安全提交,默认为false
    dataType: 'json',
    beforeSend: function() {
      $("#save").attr("disabled", "disabled");
    },
    success: function(data, status) { // 服务器响应成功时的处理函数
      callback(data);
    },
    complete: function() {
      $("#save").removeAttr("disabled");
    },
    error: function(data, status, e) {
      $.messager.alert($.i18n.prop("ami.report.prompt"), $.i18n.prop("ami.report.upload.error") + e, 'warning');
    }
  });
}

$.reload = function(id, url, param) {
  var options = $('#' + id).datagrid('options');
  if (url) options.url = url;
  options.queryParams = param;
  $('#' + id).datagrid(options);
}

$.tree = function(data) {
  var checked = [], unchecked = [];
  angular.forEach(data, function(tree, index) {
    if (tree.checked) {
      checked.push(tree);
    } else {
      unchecked.push(tree);
    }
  });
  return {
    checked: checked,
    unchecked: unchecked
  };
}

$.fn.pop = function(html, dom, $compile, $scope) {
  $(".popover").remove();
  var tooltip = ['<div class="popover bottom popver-flow">', '<div class="arrow"></div>', '<h3 class="popover-title" style="display: none;"></h3>', '<div class="popover-content">', html, '</div>',
      '</div>'].join("");
  var tool = $compile(tooltip)($scope);
  var popover = angular.element(tool);
  popover.appendTo($(dom));
  popover.css({
    left: $(this).offset().left - popover.width() / 2 + $(this).outerWidth() / 2,
    top: $(this).offset().top + $(this).outerHeight()
  }).fadeIn("fast");
}

// 创建流程图实例对象
// instance.recalculateOffsets(toId);
// instance.repaintEverything();
$.jsplumb = function(canvasId) {
  var instance = jsPlumb.getInstance({
    DragOptions: {
      cursor: 'pointer',
      zIndex: 2000
    },
    ConnectionOverlays: [["Arrow", {
      location: 1,
      visible: true,
      width: 8,
      length: 8,
      id: "arrow"
    /**
     * , events:{ click:function() { alert("you clicked on the arrow
     * overlay")}}*
     */
    }], ["Label", {
      location: 0.45,
      id: "label",
      cssClass: "aLabel"
    /** , events:{ tap:function() { alert("hey");}} * */
    }]],
    Container: canvasId
  });
  instance.setSuspendDrawing(false);
  // instance.draggable(jsPlumb.getSelector(".flowchart .jtk-node"), { grid: [0,
  // 0] })// 每个流程图框可拖动
  instance.draggable
  return instance;
}

// 绑定连接线
$.jsplumb.bind = function(instance) {
  instance.unbind("connection").bind("connection", function(connInfo, originalEvent) {
    // var connection = connInfo.connection;
    // var label = connection.getOverlay("label");
    // connection.label=label.getLabel();// 连接线上的描述
  });
}

// 添加每个节点的连接圆点
$.jsplumb.addPoint = function(instance, toId) {
  var sourceAnchors = ["Left", "Right"];// "Top", "Bottom","Left", "Right"
  // 给图形四周添加可拖拽连线的空心点。
  angular.forEach(sourceAnchors, function(chart, i) {
    var sourceUUID = toId + '-' + chart;
    var endpoint = instance.addEndpoint(toId, defineHollowCircle(), {
      anchor: chart,
      uuid: sourceUUID,
      maxConnections: -1
    /** 添加此属性支持配置多个连接形成一对多的效果 * */
    });
    instance.destroyDraggable(endpoint.canvas, "internal");// 取消点的拖拽
    instance.destroyDroppable(endpoint.canvas, "internal");// 取消点的拖拽
  });
}

// 删除每个节点的连接圆点
$.jsplumb.deletePoint = function(instance, toId) {
  var ele = $("#" + toId)[0];
  instance.remove(ele);
}

$.jsplumb.connect = function(instance, conn) {
  // $.jsplumb.bind(instance);
  var connect = instance.connect({
    uuids: [conn.target, conn.source]
  });
  if (!connect) return false;
  connect.getOverlay("label").setLabel(conn.label);
  $(connect).data("serviceData", conn);// 为当前连接线绑定业务数据
  return true;
}

// 定义空心圆
function defineHollowCircle() {
  var connectorPaintStyle = {
    strokeWidth: 1.5,
    stroke: "#61B7CF",
    joinstyle: "round",
    outlineStroke: "white",
    outlineWidth: 1.5
  };// 连接线的样式
  // var connectorHoverStyle = { strokeWidth: 3, stroke: "#216477",
  // outlineWidth: 5, outlineStroke: "white" };// 鼠标移入连接线hover样式
  var endpointHoverStyle = {
    radius: 3,
    fill: "#61B7CF",
    stroke: "#61B7CF"
  };
  return {
    endpoint: "Dot",
    paintStyle: {
      visible: false
    },
    connector: ["Flowchart", {
      stub: [20, 40],
      gap: 3,
      cornerRadius: 5,
      alwaysRespectStubs: true
    }],
    connectorStyle: connectorPaintStyle,
    hoverPaintStyle: endpointHoverStyle, // connectorHoverStyle:
    // connectorHoverStyle,
    dragOptions: {
      hoverClass: "hover",
      activeClass: "active"
    },
    isTarget: true,
    isSource: true
  // connector: ["Flowchart", { stub: [70, 0], gap: 2, cornerRadius: 1,
  // alwaysRespectStubs: true }], //连接线的样式种类有[Bezier],[Flowchart],[StateMachine
  // ],[Straight ]
  };
}
