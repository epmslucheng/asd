;
(function($, app) {
  "use strict";
  // 模板管理
  app.controller("roleGrantCtrl", function($scope, $http, $timeout, $compile, $element) {
    $scope.demo = {};

    $.ajax({
      type: "POST",
      url: basePath + "/role/getTreeListByRoleId",
      dataType: "html",
      contentType: "application/json",
      data: JSON.stringify($scope.role),
      success: function(result) {
        if (result) {
          result = JSON.parse(result);
        }
        if (result.success) {
          $timeout(function() {
            for (var i = 0; i < result.obj.list.length; i++) {
              result.obj.list[i].name = $.i18n.prop(result.obj.list[i].id);
            }
            $scope.demo.tree = eval(result.obj.list);
          });

        } else {
          $.messager.alert($.i18n.prop('ami.common.warning'), $.i18n.prop('ami.role.waring_message'), 'warning');
        }
      }
    });

    $scope.checkAll = function() {
      for (var i = 0; i < $scope.demo.tree.length; i++) {
        $scope.demo.tree[i].checked = true;
      }
    }

    $scope.checkInverse = function() {
      for (var i = 0; i < $scope.demo.tree.length; i++) {
        if ($scope.demo.tree[i].checked) {
          $scope.demo.tree[i].checked = false;
        } else {
          $scope.demo.tree[i].checked = true;
        }
      }
    }

    $scope.uncheckAll = function() {
      for (var i = 0; i < $scope.demo.tree.length; i++) {
        $scope.demo.tree[i].checked = false;
      }
    }
    //		
    // $scope.saveTree = function(){
    //			
    // }

  });

})(jQuery, app)