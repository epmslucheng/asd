;
(function($, app) {
	"use strict";
	// 模板管理
	app.controller("userGrantCtrl", function($scope, $http, $timeout, $compile,
			$element) {
		$scope.demo = {};

		$scope.tmpList = [];
		$scope.selectTmpList = [];

		$.post(basePath + "/user/getTreeListByUserId", {
			id : $scope.treeuser.id
		}, function(result) {
			if (result) {
				result = JSON.parse(result);
			}
			if (result.success) {
				$timeout(function() {
					$scope.demo.tree = eval(result.obj.list);
					$scope.tmpList = eval(result.obj.tmpList);
					$scope.selectTmpList = eval(result.obj.selectTmpList);
					$scope.demo.objtree = eval(result.obj.objlist);
				});

			} else {
				$.messager.alert($.i18n.prop('ami.common.warning'), $.i18n
						.prop('ami.role.waring_message'), 'warning');
			}
		});

		$scope.selectTmp = function($event, row, index) {
			$scope.selectTmpList.push(row);
			$scope.tmpList.splice(index, 1);
		}

		$scope.unselectTmp = function($event, row, index) {
			$scope.tmpList.push(row);
			$scope.selectTmpList.splice(index, 1);
		}

		$scope.checkAll = function(tree) {
			for (var i = 0; i < tree.length; i++) {
				tree[i].checked = true;
			}
		}

		$scope.checkInverse = function(tree) {
			for (var i = 0; i < tree.length; i++) {
				if (tree[i].checked) {
					tree[i].checked = false;
				} else {
					tree[i].checked = true;
				}
			}
		}

		$scope.uncheckAll = function(tree) {
			for (var i = 0; i < tree.length; i++) {
				tree[i].checked = false;
			}
		}
		//		
		// $scope.saveTree = function(){
		//			
		// }

	});

})(jQuery, app)