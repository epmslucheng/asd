;
(function($, app) {
  "use strict";
  app.controller("editFirstPwdCtrl", function($scope, $http, $timeout, $compile, $element) {

    $scope.userPassword = {};

    $scope.editFirstPwd = function() {
      if ($(".easyui-form").form('enableValidation').form('validate')) {
        $http.post(basePath + "/user/editUserPwd", $scope.userPassword).success(function(result) {
          if (result.success) {
            // 加载结果
            setTimeout(function() {
              reLogin();
            }, 500);
          } else {
            $.messager.alert($.i18n.prop('ami.common.warning'), result.msg, 'warning');
          }
        })
      }

    }

    function reLogin() {
      $http.post(basePath + "/logout", {}).success(function(result) {
        window.location.href = basePath;
      })
    }

  });

})(jQuery, app)