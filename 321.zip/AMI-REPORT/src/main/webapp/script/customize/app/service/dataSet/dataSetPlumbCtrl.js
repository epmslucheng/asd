;
(function($, app) {
  "use strict";

  // 跳转测试用。。。。======================================
  app.controller("dataSetPlumbCtrl", function($scope, $http, $timeout, $compile, $element) {
    // 页面初始化时生成流程图
    $scope.$watch('$viewContentLoaded',
            function() {
              var domId = "window";
              // 初始化画图工具
              var instance = $.jsplumb("canvas");
              jsPlumbUtil.logEnabled = false;
              instance.reset();// * 词句非常重要，进入ctrl方法必须将jsplumb内存重置（销毁）

              var popoverHTML = ['<form id="popoverForm" name="popoverForm">', '<div class="flowpopover">', '<div  class="row">', '<div class="form-group col-sm-12 ami-menu-group">',
                  '<label class="ami-float control-label">' + $.i18n.prop("ami.report.popover.label") + ': </label>', '<div class="ami-float">',
                  '<select class="form-control" ng-model="popover.relatedWays">', '<option ng-repeat="item in popover.relatedWaysOptions" value="{{item}}">{{item}}</option>', '</select>', '</div>',
                  '</div>', '</div>', '<div  class="row">', '<label class="control-label col-sm-6 ami-menu-group" ng-bind="popover.tableName1"></label>',
                  '<label class="control-label col-sm-6 ami-menu-group" ng-bind="popover.tableName2"></label>', '</div>', '<div  class="row" ng-repeat="field in popover.fieldList track by $index">',
                  '<div class="col-sm-5 ami-menu-group">', '<select class="form-control easyui-validatebox" validType="selectRequired[]" required="true" ng-model="field.sourceModel">',
                  '<option  value="">--' + $.i18n.prop("ami.common.pleaseSelect") + '--</option>', '<option ng-repeat="item in popover.fieldList1" value="{{item}}">{{item.tableFiledAlias}}</option>',
                  '</select>', '</div>', '<div class="col-sm-1 ami-menu-group ami-panel-header"><label class="control-label">=</label></div>', '<div class="col-sm-5 ami-menu-group">',
                  '<select class="form-control easyui-validatebox" validType="selectRequired[]" required="true"  ng-model="field.targetModel">',
                  '<option  value="">--' + $.i18n.prop("ami.common.pleaseSelect") + '--</option>', '<option ng-repeat="item in popover.fieldList2" value="{{item}}">{{item.tableFiledAlias}}</option>',
                  '</select>', '</div>', '<div ng-if="$index==0" class="col-sm-1 ami-menu-group ami-panel-header">', '<span class="glyphicon glyphicon-plus" ng-click="addItem()"></span>',
                  '<span class="glyphicon glyphicon-minus" ng-click="removeItem()"></span>', '</div>', '</div> ', '<div  class="row">', '<div class="col-sm-11 ami-menu-group btn-align">',
                  '<button type="button" class="btn btn-info ami-save" ng-click="saveConnection(connection,$event)">' + $.i18n.prop("ami.report.sure") + '</button>&nbsp;&nbsp;',
                  '<button type="button" class="btn btn-default ami-close" ng-click="popoverHide($event)">' + $.i18n.prop("ami.common.cancel") + '</button>', '</div>', '</div>', '</div>', '</form>']
                      .join("");
              $scope.popover = {};
              $scope.popover.relatedWaysOptions = ["left join", "right join", "inner join"];
              $scope.popoverHide = function($event) {
                $(".popover").remove();
              }
              $scope.saveConnection = function(conn, $event) {
                $.parser.parse($("#popoverForm").parent());
                if (!$("#popoverForm").form("validate")) return;
                conn.getOverlay("label").setLabel($scope.popover.relatedWays);
                if (!$(conn).data("serviceData")) {
                  createSingleConnection(conn);
                }// 如果不存在，则需要重新绑定连接数据
                $(conn).data("serviceData").label = $scope.popover.relatedWays;
                $(conn).data("serviceData").fieldList = $scope.popover.fieldList;
                // 入库保存。。。。。
                $scope.popoverHide($event);
              }

              $scope.addItem = function() {
                $scope.popover.fieldList.push({
                  sourceModel: "",
                  targetModel: ""
                });
              }

              $scope.removeItem = function() {
                if ($scope.popover.fieldList.length > 1) {
                  $scope.popover.fieldList.pop();
                }
              }

              // 连接label点击事件触发
              function popover(connection, event) {
                $scope.popover.tableName1 = connection.target.innerText;
                $scope.popover.tableName2 = connection.source.innerText;
                $scope.popover.relatedWays = connection.getOverlay("label").getLabel() || "";
                var oldfieldList = $(connection).data("serviceData") ? $(connection).data("serviceData").fieldList : [];
                var fieldList = [];
                angular.copy(oldfieldList, fieldList);
                $scope.popover.fieldList = fieldList && fieldList.length > 0 ? fieldList : [{
                  sourceModel: "",
                  targetModel: ""
                }];
                $scope.popover.fieldList1 = getFieldListByNodeName($scope.dataSourceTables, $scope.popover.tableName1);// 下拉框列表
                $scope.popover.fieldList2 = getFieldListByNodeName($scope.dataSourceTables, $scope.popover.tableName2);// 下拉框列表
                $scope.connection = connection;
                $(event.target).pop(popoverHTML, "#canvas", $compile, $scope);
                if (!$(event.target).next("div.popover").length) {
                  $(event.target).popover("show");
                }
              }
              // 修改页面加载数据
              $scope.dataSourceTables = [];
              $scope.colTree = [];
              // 页面元素保存的数据
              $scope.dataSourceItems = $scope.dataSet.tableModels;

              $scope.cube = {};
              $scope.cube.id = $scope.dataSet.cnnId;
              refreshCube($scope.cube.id);
              function refreshCube(cnnId) {
                if (cnnId) {
                  $scope.cube.id = cnnId;

                  $.ajax({
                    type: "POST",
                    url: basePath + "/cube/getJumbTreeByDsId",
                    dataType: "html",
                    contentType: "application/json",
                    data: JSON.stringify($scope.cube),
                    success: function(result) {
                      if (result) {
                        result = JSON.parse(result);
                      }
                      if (result.success) {
                        $timeout(function() {
                          $scope.dataSourceTables = eval(result.obj.list);

                          var flowIds = [];
                          // 渲染数据
                          if (($scope.colTree.length < 1) && $scope.dataSourceItems) {
                            // 组装colTree
                            angular.forEach($scope.dataSourceItems, function(item, i) {
                              flowIds.push(item.nodeId);
                              var table = getTableByNodeName($scope.dataSourceTables, item.nodeName);
                              var tableNew = {};
                              angular.copy(table, tableNew);
                              addCols(tableNew);
                              // TODO
                            });
                          }
                          if (flowIds && flowIds.length > 0) {
                            angular.forEach($scope.dataSourceTables, function(s, j) {
                              if ($scope.dataSet.cubeId && $scope.dataSet.cubeId == s.parentId) {
                                s.disabled = true;
                                s.draggable = false;
                              }
                              if (s.hasOwnProperty("draggable")) {
                                if ($.inArray(s.id, flowIds) > -1) {
                                  s.disabled = true;
                                  s.draggable = false;
                                }
                              }
                            });
                          }
                        });

                      } else {
                        $.messager.alert($.i18n.prop('ami.common.warning'), $.i18n.prop('ami.role.waring_message'), 'warning');
                      }
                    }
                  });

                }

              }
              
              
              $scope.dragThis = {};
              // 拖拽
              $scope.dragZD = function(item) {
                $('.coltreedrag #drag-tree-' + item.id).draggable({
                  revert: true,
                  deltaX: 0,
                  deltaY: 0,
                  proxy: function(source) {
                    var p = $('<div class="drag-item"></div>');
                    p.html($(source).text()).appendTo('body');
                    return p;
                  },
                  onBeforeDrag: function(e) {
                    $scope.dragThis = item;
                    $("#sqlWhere").droppable({
                      accept: '.coltreedrag #drag-tree-' + item.id,
                      onDrop: function(e, source) {
                        // 实现拖拽逻辑
                        $scope.$apply(function() {
                          if ($scope.dragThis.tableFiledSql) {
                            $("#sqlWhere").insertContent($scope.dragThis.tableFiledSql);
                            $scope.dataSet.sqlWhere = $("#sqlWhere").val();
                          }
                        })
                      },
                    });
                  }
                });
              }
              
              
              
              
              
              
              
              

              // 删除节点
              $scope.closeNode = function(item, $event) {
                $scope.dataSourceItems.remove(item);
                removeCols(item);
                $(".popover").remove();
                if (!$event) return;
                $scope.prevRemoveNode = item;
              }

              function getFieldListByNodeName(list, nodeName) {
                var fieldList = null;
                $.each(list, function(i, n) {
                  if (n.name === $.trim(nodeName)) {
                    fieldList = n.fieldList;
                    return false;
                  }
                });
                return fieldList || [];
              }

              function getTableByNodeName(list, nodeName) {
                var table = null;
                $.each(list, function(i, n) {
                  if (n.name === $.trim(nodeName)) {
                    table = n;
                    return false;
                  }
                });
                return table || [];
              }
              function createSingleConnection(conn) {
                $(conn).data("serviceData", {
                  target: conn.getUuids()[0],
                  source: conn.getUuids()[1],
                  label: conn.getOverlay("label").getLabel(),
                  fieldList: []
                });
              }

              // 监听流程图是否已经有当前节点，如果重复，则不允许拖拽
              $scope.$watch("dataSourceItems", function(n, o) {
                var flowIds = [];
                angular.forEach(n, function(v, i) {
                  flowIds.push(v.nodeId);
                });
                angular.forEach($scope.dataSourceTables, function(s, j) {
                  if (s.hasOwnProperty("draggable") && !s.hasOwnProperty("tableFiled")) {
                    s.draggable = $.inArray(s.id, flowIds) < 0;
                    s.disabled = !s.draggable;
                  }
                  $scope.treeDrag(s);
                });
                // 内部存在timeout延迟操作，这是必要的，否则js先执行而页面后加载，导致连接线不显示问题。后续有待优化
                $scope.completeCallback(domId);

              }, true);

              $scope.$watch("treeSearch", function(n, o) {
                if (n == undefined) return;
                $timeout(function() {
                  angular.forEach($scope.dataSourceTables, function(s, j) {
                    $scope.treeDrag(s);
                  });
                }, 50)
              })

              $scope.completeCallback = function(flowId) {
                $timeout(function() {
                  instance.reset();// * 词句非常重要，进入ctrl方法必须将jsplumb内存重置（销毁）
                  angular.forEach($scope.dataSourceItems, function(item, i) {
                    $.jsplumb.addPoint(instance, flowId + item.nodeId);
                    if (item.connectLine && !$.jsplumb.connect(instance, item.connectLine)) {
                      $scope.closeNode(item);// 如果连接失败，则删除当前节点
                    }
                    instance.unbind("click").bind("click", function(connection, event) {
                      if ($(event.target).hasClass("aLabel")) {
                        popover(connection, event);
                      }
                    })
                  });

                  angular.forEach($scope.retainItem, function(item, i) {
                    if (!item.parentId) return;
                    var jtkNode = $("#" + item.parentId);
                    // var left=jtkNode.position().left + jtkNode.width() + 200;
                    var p = jtkNode.position();
                    if (!p) return;
                    var top = p.top + i * (80 + jtkNode.height());
                    animateTop(item, top)
                    // 将此节点下的所有子节点按top偏移
                    angular.forEach($scope.childeNodes[domId + item.nodeId], function(child, index) {
                      animateTop(child, top)
                    })
                  })
                })
              }
              function animateTop(dom, top) {
                var $$dom = $("#" + domId + dom.nodeId);
                instance.animate($$dom[0], {
                  top: top
                }, {
                  complete: function() {
                    $scope.$apply(function() {
                      dom.style.top = top;
                    });
                  }
                });
              }

              $scope.fulshCube = function(cnnId) {
                $scope.treeSearch = "";
                refreshCube(cnnId);
              }

              // 判断删除节点时，对当前节点下所有的平级节点进行位置适应.
              $scope.$watch("prevRemoveNode", function(n, o) {
                if (n && n.connectLine) {
                  $scope.retainItem = [];
                  $scope.childeNodes = {};
                  var source = n.connectLine.source;// 指向同一个父节点的元素
                  angular.forEach($scope.dataSourceItems, function(item, i) {
                    if (item.connectLine && item.connectLine.source === source) {
                      $scope.retainItem.push(item);
                      $scope.childeNodes[domId + item.nodeId] = [];
                    }
                  });

                  angular.forEach($scope.retainItem, function(target, i) {
                    findeNodes(target, $scope.childeNodes)
                  });
                }
              });

              function findeNodes(target, childeNodes) {
                angular.forEach($scope.dataSourceItems, function(item, i) {
                  if ((domId + target.nodeId) === item.parentId) {
                    childeNodes[domId + target.nodeId].push(item);
                    findeNodes(item, childeNodes);
                  }
                });
              }

              // 拖拽生成表关联关系
              $scope.treeDrag = function(item) {
                var $$drag = $('#drag-tree-' + item.id);
                $$drag.draggable({
                  revert: true,
                  deltaX: 0,
                  deltaY: 0,
                  proxy: function(source) {
                    var p = $('<div class="drag-item"></div>');
                    p.html($(source).text()).appendTo('body');
                    return p;
                  },
                  onBeforeDrag: function(e) {
                    $("#flowchart_box").droppable({
                      accept: '#drag-tree-' + item.id,
                      onDrop: function(e, source) {
                        // 默认显示位置
                        var node = {
                          nodeId: item.id,
                          nodeName: item.name,
                          tableSql: item.tableSql,
                          tableType: item.tableType,
                          style: {
                            "left": event.pageX - $(e.target).offset().left,
                            "top": event.pageY - $(e.target).offset().top
                          }
                        }
                        // 判断鼠标落座的标签是否是在节点上
                        var jtkNode = $(event.target).closest("div.jtk-node");

                        // 判断放置区域内是否已经存在root节点，若存在则不允许重新拖拽新元素入放置区
                        if ($scope.dataSourceItems.length == 0 || jtkNode.length) {
                          $scope.$apply(function() {
                            node.parentId = undefined;
                            $scope.dataSourceItems.push(node);
                            addCols(item);/* 动态生成flow流程图item项 */
                          });
                        }

                        if (jtkNode.length) {
                          var target = $("#" + domId + node.nodeId);
                          var left, top;
                          var sourceId = jtkNode.attr("id"), targetId = target.attr("id");
                          var options = {
                            complete: function(el) {
                              // 自动连接时构造连接线对象
                              var conn = {
                                target: targetId + "-Left",
                                source: sourceId + "-Right",
                                label: $scope.popover.relatedWaysOptions[0],
                                fieldList: [{
                                  sourceModel: "",
                                  targetModel: ""
                                }]
                              };
                              $scope.$apply(function() {
                                node.style.left = $(el).position().left;
                                node.style.top = $(el).position().top;
                                node.parentId = sourceId;
                                node.connectLine = conn;
                              });
                            }
                          };

                          // 位置自适应动画
                          var targetItems = []
                          angular.forEach(instance.getAllConnections(), function(conn, i) {
                            if (sourceId === conn.targetId) targetItems.push(conn);
                          });
                          left = jtkNode.position().left + jtkNode.width() + 200;
                          top = jtkNode.position().top + (targetItems.length) * (80 + jtkNode.height());
                          instance.animate(target[0], {
                            left: left,
                            top: top
                          }, options);
                        }
                      }
                    });
                  }
                });
                $$drag.draggable(item.draggable ? "enable" : "disable");
              }

              function addCols(item) {
                var itemNew = angular.copy(item);
                var itemMain = {}
                itemMain.id = itemNew.id;
                itemMain.parentId = "";
                itemMain.name = itemNew.name;
                $scope.colTree.push(itemMain);
                angular.forEach(itemNew.fieldList, function(field, i) {
                  if ($scope.dataSet.colTree) {
                    angular.forEach($scope.dataSet.colTree, function(col, i) {
                      if (field.id == col.id) {
                        field.checked = true;
                      }
                    });
                  }
                  field.draggable=true;
                  $scope.colTree.push(field);
                });
              }
              function removeCols(item) {
                var colLength = $scope.colTree.length;
                for (var i = colLength - 1; i >= 0; i--) {
                  var tree = $scope.colTree[i];
                  if (tree.id == item.nodeId || tree.parentId == item.nodeId) {
                    $scope.colTree.remove(tree);
                  }
                }
              }
              $scope.testSql = function() {

                var newflag = true;

                if ($scope.dataSet.tableModels && $scope.dataSet.tableModels.length > 1) {
                  for (var i = 0; i < $scope.dataSet.tableModels.length; i++) {
                    if ($scope.dataSet.tableModels[i].connectLine) {
                      for (var j = 0; j < $scope.dataSet.tableModels[i].connectLine.fieldList.length; j++) {
                        if ($scope.dataSet.tableModels[i].connectLine.fieldList[j].sourceModel == "" || $scope.dataSet.tableModels[i].connectLine.fieldList[j].targetModel == "") {
                          newflag = false;
                        }
                      }
                    }
                  }
                }
                if (!newflag) {
                  $.messager.alert($.i18n.prop('ami.common.warning'), $.i18n.prop('ami.dataset.display.field01'), 'warning');
                  return;
                }

                var temp = [];
                angular.copy($scope.colTree, temp);
                $scope.dataSet.colTree = temp;
                if (temp) {
                  $scope.dataSet.colTree = [];
                  var colLength = temp.length;
                  for (var i = colLength - 1; i >= 0; i--) {
                    var tree = temp[i];
                    if (tree.checked && tree.parentId) {

                      $scope.dataSet.colTree.push(tree);
                    }
                  }
                }
                if (!$scope.dataSet.colTree || $scope.dataSet.colTree.length == 0) {
                  $.messager.alert($.i18n.prop('ami.common.warning'), $.i18n.prop('ami.dataset.display.field'), 'warning');
                  return;
                } else {
                  if (isrepeat($scope.dataSet.colTree)) {
                    $.messager.alert($.i18n.prop('ami.common.warning'), $.i18n.prop('ami.dataset.field.repeat'), 'warning');
                    return;
                  }
                }
                $http.post(basePath + "/customDataSet/testSql", $scope.dataSet).success(function(result) {
                  if (result.success) {
                    // 加载结果
                    var str = assembleDatagrid(result.obj.colname);
                    $scope.sqlTestHeader = eval(str);
                    $scope.sqlTestUrl = basePath + '/customDataSet/sqlList';
                    var param = {
                      "querySql": result.obj.querySql,
                      "cnnId": result.obj.cnnId
                    };
                    $("#mydatagrid").datagrid({
                      url: basePath + '/customDataSet/sqlList',
                      queryParams: param,
                      columns: [$scope.sqlTestHeader],
                      rownumbers: false,
                      singleSelect: true,
                      autoRowHeight: false,
                      pagination: true,
                      pageSize: 10,
                      pageList: [10, 20, 50, 100]
                    });
                  } else {
                    $.messager.alert($.i18n.prop('ami.common.warning'), $.i18n.prop('ami.dataset.model.test.error'), 'warning');
                  }
                })
              }
            $scope.previewSql = function() {previewSql();}
            
            function previewSql(){

              var temp = [];
              angular.copy($scope.colTree, temp);
              $scope.dataSet.colTree = temp;
              if (temp) {
                $scope.dataSet.colTree = [];
                var colLength = temp.length;
                for (var i = colLength - 1; i >= 0; i--) {
                  var tree = temp[i];
                  if (tree.checked && tree.parentId) {

                    $scope.dataSet.colTree.push(tree);
                  }
                }
              }
              $http.post(basePath + "/customDataSet/previewSql", $scope.dataSet).success(function(result) {
                if (result.success) {
                  $("#sqlPre").val(result.msg);
                } 
              })
              
            
            }
              
              function isrepeat(list) {
                if (list && list.length > 1) {
                  for (var i = 0; i < list.length; i++) {
                    for (var j = i + 1; j < list.length; j++) {
                      if (list[i].tableFiledAlias == list[j].tableFiledAlias) { return true; }
                    }
                  }

                }
                return false;
              }
              function assembleDatagrid(list) {
                var s = "[";
                if (list) {
                  // 循环处理
                  var colWidth = "120px"; // 默认给10列

                  for (var i = 0; i < list.length; i++) {
                    if ('R' == list[i]) {
                      continue;
                    }
                    var temp = "{field:'" + list[i] + "',title:'" + list[i] + "',width:'" + colWidth + "',align:'left'},"
                    s = s + temp;
                  }
                  if (s && "" != s) {
                    s = s.substr(0, s.length - 1);
                  }
                }
                s = s + "]";
                return s;
              }
              $scope.functionToSql = function(myValue,type) {

                if (myValue) {
                  if("date" == type){
                    myValue = "TO_DATE('"+myValue+"','yyyy-MM-dd HH24:mi:ss')";
                  }
                  $("#sqlWhere").insertContent(myValue);
                  $scope.dataSet.sqlWhere = $("#sqlWhere").val();
                }
              }

            });
  });
})(jQuery, app)