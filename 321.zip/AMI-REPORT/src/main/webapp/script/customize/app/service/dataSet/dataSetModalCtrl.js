;
(function($, app) {
  "use strict";
  // 模板管理
  app.controller("dataSetModalCtrl", function($scope, $http, $timeout, $compile, $element) {
    $scope.cube = {};
    $scope.cube.id = $scope.dataSet.cnnId;
    $scope.demo = {};

    function refreshCube(cnnId) {
      if (cnnId) {
        $scope.cube.id = cnnId;

        $.ajax({
          type: "POST",
          url: basePath + "/cube/getTreeListByDsId",
          dataType: "html",
          contentType: "application/json",
          data: JSON.stringify($scope.cube),
          success: function(result) {
            if (result) {
              result = JSON.parse(result);
            }
            if (result.success) {
              $timeout(function() {
                $scope.demo.tree = eval(result.obj.list);
              });

            } else {
              $.messager.alert($.i18n.prop('ami.common.warning'), $.i18n.prop('ami.role.waring_message'), 'warning');
            }
          }
        });

      }

    }
    refreshCube($scope.cube.id);
    $scope.fulshCube = function(cnnId) {
      $scope.treeSearch = "";
      refreshCube(cnnId);
    }
    $scope.dragOne = {};
    // 拖拽
    $scope.treeDrag = function(item) {
      $('#drag-tree-' + item.id).draggable({
        revert: true,
        deltaX: 0,
        deltaY: 0,
        proxy: function(source) {
          var p = $('<div class="drag-item"></div>');
          p.html($(source).text()).appendTo('body');
          return p;
        },
        onBeforeDrag: function(e) {
          $scope.dragOne = item;
          $("#querySql").droppable({
            accept: '#drag-tree-' + item.id,
            onDrop: function(e, source) {
              // 实现拖拽逻辑
              $scope.$apply(function() {
                if ($scope.dragOne.tableFiledSql) {
                  $("#querySql").insertContent($scope.dragOne.tableFiledSql);
                  $scope.dataSet.querySql = $("#querySql").val();
                }
                if ($scope.dragOne.tableSql) {
                  var tableSql = $scope.dragOne.tableSql;
                  if("target" == $scope.dragOne.tableType){
                    tableSql = " (" + $scope.dragOne.tableSql + ") " + $scope.dragOne.tableName;
                  }
                  
                  $("#querySql").insertContent(tableSql);
                  $scope.dataSet.querySql = $("#querySql").val();
                }
              })
            },
          });
        }
      });
    }

    $scope.testSql = function() {
      
      
      
      $http.post(basePath + "/customDataSet/testSql", $scope.dataSet).success(function(result) {
        if (result.success) {
          // 加载结果
          var str = assembleDatagrid(result.obj.colname);
          $scope.sqlTestHeader = eval(str);
          $scope.sqlTestUrl = basePath + '/customDataSet/sqlList';
          var param = {
            "querySql": result.obj.querySql,
            "cnnId": result.obj.cnnId
          };
          $("#mydatagrid").datagrid({
            url: basePath + '/customDataSet/sqlList',
            queryParams: param,
            columns: [$scope.sqlTestHeader],
            rownumbers: false,
            singleSelect: true,
            autoRowHeight: false,
            pagination: true,
            pageSize: 10,
            pageList: [10, 20, 50, 100]
          });
        } else {
          
          if(result.msg){
            
            $.messager.alert($.i18n.prop('ami.common.warning'), result.msg, 'warning');
          }else{
            
            $.messager.alert($.i18n.prop('ami.common.warning'), $.i18n.prop('ami.dataset.test.error'), 'warning');
          }
        }
      })
    }
    
    function checkSql(querySql){
      
    }
    
    
    $scope.functionToSql = function(myValue,type) {

      if (myValue) {
        if("date" == type){
          myValue = "TO_DATE('"+myValue+"','yyyy-MM-dd HH24:mi:ss')";
        }
        $("#querySql").insertContent(myValue);
        $scope.dataSet.querySql = $("#querySql").val();
      }
    }

    function assembleDatagrid(list) {
      var s = "[";
      if(list){
        // 循环处理
        var colWidth = "120px"; // 默认给10列
        
        for (var i = 0; i < list.length; i++) {
          if('R' == list[i]){
            continue;
          }
          var temp = "{field:'" + list[i] + "',title:'" + list[i] + "',width:'" + colWidth + "',align:'left'},"
          s = s + temp;
        }
        if (s && "" != s) {
          s = s.substr(0, s.length - 1);
        }
      }
      s = s + "]";
      return s;
    }

  });

  (function($) {
    $.fn.extend({
      insertContent: function(myValue, t) {
        var $t = $(this)[0];
        if (document.selection) { // ie
          this.focus();
          var sel = document.selection.createRange();
          sel.text = myValue;
          this.focus();
          sel.moveStart('character', -l);
          var wee = sel.text.length;
          if (arguments.length == 2) {
            var l = $t.value.length;
            sel.moveEnd("character", wee + t);
            t <= 0 ? sel.moveStart("character", wee - 2 * t - myValue.length) : sel.moveStart("character", wee - t - myValue.length);
            sel.select();
          }
        } else if ($t.selectionStart || $t.selectionStart == '0') {
          var startPos = $t.selectionStart;
          var endPos = $t.selectionEnd;
          var scrollTop = $t.scrollTop;
          $t.value = $t.value.substring(0, startPos) + myValue + $t.value.substring(endPos, $t.value.length);
          this.focus();
          $t.selectionStart = startPos + myValue.length;
          $t.selectionEnd = startPos + myValue.length;
          $t.scrollTop = scrollTop;
          if (arguments.length == 2) {
            $t.setSelectionRange(startPos - t, $t.selectionEnd + t);
            this.focus();
          }
        } else {
          this.value += myValue;
          this.focus();
        }
      }
    })
  })(jQuery);

})(jQuery, app)