;
(function($, app) {
  "use strict";
  // 连接管理
  app.controller("dataSourceManagerCtrl", function($scope, $http, $timeout, $compile, $element, $permission) {
    // 权限按钮控制
    $permission.contains("/reflushDataSource", function(data) {
      $scope.showDataSourceRef = data;
    });

    $permission.contains("/editDataSource", function(data) {
      $scope.showDataSourceEdit = data;
    });

    $permission.contains("/deleteDataSource", function(data) {
      $scope.showDataSourceDel = data;
    });

    $permission.contains("/addDataSource", function(data) {
      $scope.showDataSourceAdd = data;
    });

    $permission.contains("/addCube", function(data) {
      if (!data) {
        $("#cubeAdd + div.panel .panel-tool").remove();
      }
    });

    $permission.contains("/editCube", function(data) {
      $scope.showCubeEdit = data;
    });

    $permission.contains("/deleteCube", function(data) {
      $scope.showCubeDel = data;
    });

    $permission.contains("/renameTableFiled", function(data) {
      $scope.showObjectEdit = data;
    });

    // 请求所有数据源
    $.ajax({
      type: "POST",
      url: basePath + "/dataSource/getAllDataList",
      dataType: "html",
      contentType: "application/json",
      data: {},
      success: function(result) {
        if (result) {
          result = JSON.parse(result);
        }
        if (result.success) {
          $scope.$apply(function() {
            $scope.dsList = eval(result.obj.dsList);
          });

        } else {
          $.messager.alert($.i18n.prop('ami.common.warning'), $.i18n.prop('ami.dataSource.getFailed'), 'warning');
        }
      }
    });

    refreshCubeList();
    
    $scope.urlMessChange = function(value){
    	if(undefined==value||''==value){
    		$("#urlMess").attr("placeholder","");
    	}
    	if('01'==value){
    		$("#urlMess").attr("placeholder","jdbc:oracle:thin:@127.0.0.1:1521:devdb");
    	}
    	if('02'==value){
    		$("#urlMess").attr("placeholder","jdbc:mysql://127.0.0.1:3306/mysql");
    	}
    }
    
    
    
    // 新增数据源
    $scope.addDataSourceNew = function() {

      $scope.dataSource = {};

      $.model($.i18n.prop('ami.dataSource.add'), basePath + "/dataSource/addPage", $scope.dataSource, function(result) {
        return $compile(result)($scope)
      }, function(m) {
        if ($(".easyui-form").form('enableValidation').form('validate')) {
          $.ajax({
            type: "POST",
            url: basePath + "/dataSource/genertateDsId",
            dataType: "html",
            contentType: "application/json",
            data: {},
            success: function(result) {
              if (result) {
                result = JSON.parse(result);
              }
              if (result.success) {
                $scope.$apply(function() {
                  $scope.dataSource.id = eval(result.obj.id);
                });

                $http.post(basePath + "/dataSource/save", $scope.dataSource || {}).success(function(result) {
                  if (result.success) {
                    $scope.dsList.unshift($scope.dataSource);
                    $.model.close(m);
                    $.messager.alert($.i18n.prop('ami.common.info'), $.i18n.prop('ami.common.save.success'), 'info');
                  }else{
                	  $.messager.alert($.i18n.prop('ami.common.warning'), result.msg, 'warning');
                  }
                })

              } else {
                $.messager.alert($.i18n.prop('ami.common.warning'), $.i18n.prop('ami.common.id.fail'), 'warning');
              }
            }
          });
        }

      });
    }
    // 请求所有立方
    function refreshCubeList() {
      $.ajax({
        type: "POST",
        url: basePath + "/cube/getAllCubeList",
        dataType: "html",
        contentType: "application/json",
        data: {},
        success: function(result) {
          if (result) {
            result = JSON.parse(result);
          }
          if (result.success) {
            $scope.$apply(function() {
              $scope.cubeList = eval(result.obj.cubeList);
            });
            if ($scope.cubeList.length > 0) {
              // 初始化调用生成树
              $scope.cube = $scope.cubeList[0];
              $scope.viewTree(null, $scope.cube);
            }else{
            	$scope.viewTree(null, null);
            }
          } else {
            $.messager.alert($.i18n.prop('ami.common.warning'), $.i18n.prop('ami.cube.get.fail'), 'warning');
          }
        }
      });
    }

    // 点击每个item，刷新下方立方区
    $scope.reflushItem = function($event, row) {
      $event.stopPropagation();// 阻止事件冒泡

      $scope.cube = {};
      $scope.cube.id = row.id;

      $.ajax({
        type: "POST",
        url: basePath + "/cube/getCubeListByDsId",
        dataType: "html",
        contentType: "application/json",
        data: JSON.stringify($scope.cube),
        success: function(result) {
          if (result) {
            result = JSON.parse(result);
          }
          if (result.success) {
            $scope.$apply(function() {
              $scope.cubeList = eval(result.obj.cubeList);
            });
            if ($scope.cubeList.length > 0) {
                // 初始化调用生成树
                $scope.cube = $scope.cubeList[0];
                $scope.viewTree(null, $scope.cube);
              }else{
            	  $scope.viewTree(null, null);
            }

          } else {
            $.messager.alert($.i18n.prop('ami.common.warning'), $.i18n.prop('ami.cube.refresh.fail'), 'warning');
          }
        }
      });

    }

    // 点击删除
    $scope.closeItem = function($event, row, index) {
      $event.stopPropagation();// 阻止事件冒泡
      $scope.dataSource = row;
      parent.$.messager.confirm($.i18n.prop('ami.common.info'), $.i18n.prop('ami.template.notice_message'), function(b) {
        if (b) {
          $http.post(basePath + "/dataSource/delete", JSON.stringify($scope.dataSource)).success(function(result) {
            if (result.success) {
              $scope.dsList.splice(index, 1);
              $.messager.alert($.i18n.prop('ami.common.info'), $.i18n.prop('ami.common.del.success'), 'info');
              // $("#dataSourceTable").datagrid('reload');

              refreshCubeList();
            }
          })
        }
      })

    }

    $scope.modifyItem = function($event, row, index) {
      $event.stopPropagation();// 阻止事件冒泡
      $scope.dataSource = angular.copy(row);
      $.model($.i18n.prop('ami.dataSource.edit'), basePath + "/dataSource/editPage", $scope.dataSource, function(result) {
        return $compile(result)($scope)
      }, function(m) {
        if ($(".easyui-form").form('enableValidation').form('validate')) {
          $http.post(basePath + "/dataSource/edit", $scope.dataSource || {}).success(function(result) {
            if (result.success) {
              $.model.close(m);
              $.messager.alert($.i18n.prop('ami.common.info'), $.i18n.prop('ami.common.edit.success'), 'info');
              angular.extend(row,$scope.dataSource);
              // $("#dataSourceTable").datagrid('reload');
            }
          })
        }
      });
    }
    $scope.refreshItem = function($event, row, index) {
      $event.stopPropagation();// 阻止事件冒泡
      $scope.dataSource = angular.copy(row);
      parent.$.messager.confirm($.i18n.prop('ami.common.info'), '是否更新数据源中所有表及表结构', function(b) {
        if (b) {
          $http.post(basePath + "/dataSource/updateTable", $scope.dataSource).success(function(result) {
            if (result.success) {
              $.messager.alert($.i18n.prop('ami.common.info'), '更新需要时间,请稍候查看', 'info');
            }
          })
        }
      })
    }

    // 点击删除
    $scope.closeCubeItem = function($event, row, index) {
      $event.stopPropagation();// 阻止事件冒泡
      $scope.cube = angular.copy(row);
      parent.$.messager.confirm($.i18n.prop('ami.common.info'), $.i18n.prop('ami.template.notice_message'), function(b) {
        if (b) {
          $http.post(basePath + "/cube/delete", JSON.stringify($scope.cube)).success(function(result) {
            if (result.success) {
              $scope.cubeList.splice(index, 1);
              $.messager.alert($.i18n.prop('ami.common.info'), $.i18n.prop('ami.common.del.success'), 'info');
              // $("#dataSourceTable").datagrid('reload');
            }
          })
        }
      })
    }

    // 点击添加立方
    $scope.addCubeItem = function(obj) {
      if (!obj) {
        // ami.cube.seldatasource
        $.messager.alert($.i18n.prop('ami.common.info'), $.i18n.prop('ami.cube.seldatasource'), 'info');
        return;
      } else {
        $scope.cube = {};
        $scope.cube.id = obj.id;

        $scope.tableList = [];
        $scope.selTableList = [];

        $.ajax({
          type: "POST",
          url: basePath + "/cube/genertateCubeId",
          dataType: "html",
          contentType: "application/json",
          data: {},
          success: function(result) {
            if (result) {
              result = JSON.parse(result);
            }
            if (result.success) {
              $scope.$apply(function() {
                $scope.cube.cubeId = eval(result.obj.id);
              });

              // 请求表列表
              $.ajax({
                type: "POST",
                url: basePath + "/cube/getTableListByDSId",
                dataType: "html",
                contentType: "application/json",
                data: JSON.stringify($scope.cube),
                success: function(result) {
                  if (result) {
                    result = JSON.parse(result);
                  }
                  if (result.success) {
                    $timeout(function() {
                      $scope.tableList = eval(result.obj.tableList);
                    }, 100);

                  } else {
                    $.messager.alert($.i18n.prop('ami.common.warning'), '获取数据源表列表失败', 'warning');
                  }
                }
              });

              $scope.cube.tableList = $scope.selTableList;
              $.model($.i18n.prop('ami.cube.add'), basePath + "/cube/addPage", $scope.cube || {}, function(result) {
                return $compile(result)($scope)
              }, function(m) {
                if ($(".easyui-form").form('enableValidation').form('validate')) {
                  $http.post(basePath + "/cube/save", $scope.cube || {}).success(function(result) {
                    if (result.success) {
                      $.model.close(m);
                      $.messager.alert($.i18n.prop('ami.common.info'), $.i18n.prop('ami.common.save.success'), 'info');
                      $scope.cubeList.unshift($scope.cube);

                      // $("#dataSourceTable").datagrid('reload');
                    }
                  })
                }

              });

            }

          }
        })
      }
    }
    $scope.addCubeTable = function($event, row, index) {
	  delete $scope.cube['leftIndex'];
      delete $scope.cube['leftCacheRow'];
      for (var i = 0; i < $scope.selTableList.length; i++) {
        var item = $scope.selTableList[i];
        if (item.tableName == row.tableName) { return; }
      }
      $scope.selTableList.push(row);
    }

    $scope.delCubeTable = function($event, row, index) {
      $scope.selTableList.remove(row);
      delete $scope.cube['rightIndex'];
      delete $scope.cube['rightCacheRow'];
    }

    $scope.selectedRow=function(row,direction){
    	$scope.cube[direction+'CacheRow']=row;
    }
    
    $scope.toTarget=function(direction){
    	var $$row = $scope.cube[direction+'CacheRow'];
    	if(!$$row)
    	{
    		$.messager.alert($.i18n.prop('ami.common.info'),$.i18n.prop('ami.cube.messager.cube'),"info");
    		return;
    	}
    	
    	if(direction==='left') { $scope.addCubeTable(null,$$row,null); }	else { $scope.delCubeTable(null,$$row,null); }
    }
    
    // 修改立方
    $scope.modifyCubeNew = function($event, row, index) {
      $event.stopPropagation();// 阻止事件冒泡

      $scope.cube = {};
      $scope.cube = angular.copy(row);;

      $scope.tableList = [];
      $scope.selTableList = [];

      // 请求表列表
      $.ajax({
        type: "POST",
        url: basePath + "/cube/getTableListByDSId",
        dataType: "html",
        contentType: "application/json",
        data: JSON.stringify($scope.cube),
        success: function(result) {
          if (result) {
            result = JSON.parse(result);
          }
          if (result.success) {
            $scope.$apply(function() {
              $scope.tableList = eval(result.obj.tableList);
            });

          } else {
            $.messager.alert($.i18n.prop('ami.common.warning'), '获取数据源表列表失败', 'warning');
          }
        }
      });

      // 请求已添加表列表
      $.ajax({
        type: "POST",
        url: basePath + "/cube/getTableListByCubeId",
        dataType: "html",
        contentType: "application/json",
        data: JSON.stringify($scope.cube),
        success: function(result) {
          if (result) {
            result = JSON.parse(result);
          }
          if (result.success) {
            $scope.$apply(function() {
              $scope.selTableList = eval(result.obj.selTableList);
            });

          } else {
            $.messager.alert($.i18n.prop('ami.common.warning'), '获取已添加表列表失败', 'warning');
          }
        }
      });

      $.model($.i18n.prop('ami.cube.edit'), basePath + "/cube/editPage", $scope.cube, function(result) {
        return $compile(result)($scope)
      }, function(m) {
        if ($(".easyui-form").form('enableValidation').form('validate')) {
          $scope.cube.tableList = $scope.selTableList;
          $http.post(basePath + "/cube/edit", $scope.cube || {}).success(function(result) {
            if (result.success) {
              $.model.close(m);
              $.messager.alert($.i18n.prop('ami.common.info'), $.i18n.prop('ami.common.edit.success'), 'info');
              angular.extend(row,$scope.cube);
              // $("#dataSourceTable").datagrid('reload');
            }
          })
        }
      });
    }
    // 树
    $scope.demo = {};
    $scope.viewTree = function($event, c) {
      $scope.treeSearch = "";
      var e = $event || window.event;
      e.stopPropagation();// 阻止事件冒泡
      
      if(null==c || undefined == c){
    	  $scope.$apply(function() {
              $scope.demo.tree = [];
    	  })
      }else{
    	  $.ajax({
    	        type: "POST",
    	        url: basePath + "/cube/getTableTreeByCubeId",
    	        dataType: "html",
    	        contentType: "application/json",
    	        data: JSON.stringify(c),
    	        success: function(result) {
    	          if (result) {
    	            result = JSON.parse(result);
    	          }
    	          if (result.success) {
    	            $scope.$apply(function() {
    	              $scope.demo.tree = eval(result.obj.list);
    	              $scope.demo.tree.push({
    	                "id": c.id,
    	                "dsId": c.id,
    	                "name": c.cubeName,
    	                parentId: "",
    	                treeId: c.cubeId,
    	                editable: false
    	              });
    	            });

    	          } else {
    	            $.messager.alert($.i18n.prop('ami.common.warning'), '获取失败', 'warning');
    	          }
    	        }
    	      });
      }
      
    }

    // 重命名
    $scope.rename = function($item) {
      // 重命名 字段别名
      // alert($item.name);
    	
    	if($item.name==""){
    		$item.name = $item.tableFiled;
    		return;
    	}

      $scope.tableFiled = {};
      $scope.tableFiled.id = $item.id;
      $scope.tableFiled.tableName = $item.tableName;
      $scope.tableFiled.tableFiled = $item.tableFiled;
      $scope.tableFiled.tableFiledAlias = $item.name;
      $.ajax({
        type: "POST",
        url: basePath + "/cube/reNameTableFiledAlias",
        dataType: "html",
        contentType: "application/json",
        data: JSON.stringify($scope.tableFiled),
        success: function(result) {
          if (result) {
            result = JSON.parse(result);
          }
          if (result.success) {

          } else {
            $.messager.alert($.i18n.prop('ami.common.warning'), '字段别名修改失败', 'warning');
          }
        }
      });
    }

    $scope.sure = function() {
      var checkedData = $.tree($scope.demo.tree).checked;
      var content = [];
      angular.forEach(checkedData, function(data, index) {
        content.push(data.name);
      });
      $scope.content = content.join(",");
    }
  });
})(jQuery, app)