;
(function ($, app) {
    "use strict";
    // 模板管理
    app.controller("systemParameterCtrl", function ($scope, $http, $timeout, $compile, $element, $permission) {
        $scope.tableHeader = [{
            field: 'name',
            title: $.i18n.prop('ami.sysParameter.name'),
            width: '20%',
            align: 'left'
        }, {
            field: 'value',
            title: $.i18n.prop('ami.sysParameter.value'),
            width: '20%',
            align: 'left',
            formatter: function (value, row) {
                return row.isPassword ? '********' : value;
            }
        }, {
            field: 'remark',
            title: $.i18n.prop('ami.sysParameter.remark'),
            width: '40%',
            align: 'left'
        }, {
            field: 'operation',
            title: $.i18n.prop('ami.common.func'),
            width: '20%',
            align: 'left',
            formatter: function (value, row, index) {
                $scope['rowData_' + index] = row;
                var str = '';
                str += '<a href="javascript:void(0)" ng-if="showEdit" ng-click="editFn(rowData_' + index + ')">' + $.i18n.prop('ami.common.edit'), +'</a>';
                return str;
            }
        }];

        $scope.tableUrl = basePath + '/systemParameter/datagrid';

        $scope.editFn = function (row) {
            $scope.systemParameter = angular.copy(row) || {};
            $.model($.i18n.prop('ami.sysParameter.editParameter'), basePath + "/systemParameter/editPage", $scope.systemParameter, function (result) {
                return $compile(result)($scope)
            }, function (m) {
                if ($(".easyui-form").form('enableValidation').form('validate')) {
                    $http.post(basePath + "/systemParameter/edit", $scope.systemParameter || {}).success(function (result) {
                        if (result.success) {
                            $.model.close(m);
                            $.messager.alert($.i18n.prop("ami.common.prompt"), result.msg, 'success');
                            $("#systemParameterTable").datagrid('reload');
                        } else {
                            $.messager.alert($.i18n.prop("ami.common.prompt"), result.msg, 'error');
                        }
                    })
                }

            });
        }

        // 表格加载数据完成后，执行
        $scope.$on("loadSuccess", function (e, data) {
            $compile($(data.target).find("td[field='operation'] > div"))($scope);// 手动编译表格最后一列，同步angularjs事件操作

            $permission.contains("/editSystemParameter", function (data) {
                $scope.showEdit = data;
            });
        });
    });
})(jQuery, app)
