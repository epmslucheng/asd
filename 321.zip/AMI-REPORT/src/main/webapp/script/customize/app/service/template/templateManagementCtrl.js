;
(function($, app) {
  "use strict";
  // 模板管理
  app.controller("templateManagementCtrl", function($scope, $http, $timeout, $compile, $element, $permission) {
    $scope.tableHeader = [
        {
          field: 'tmpid',
          title: 'id',
          width: '20%',
          align: 'left',
          hidden: 'true'
        },
        {
          field: 'tmpname',
          title: $.i18n.prop('ami.template.name'),
          width: '20%',
          align: 'left'
        },
        {
          field: 'tmpfile',
          title: 'tmpfile',
          width: '20%',
          align: 'left',
          hidden: 'true'
        },
        {
          field: 'tmpkey',
          title: $.i18n.prop('ami.template.key'),
          width: '20%',
          align: 'left'
        },
        {
          field: 'reporttype',
          title: $.i18n.prop('ami.template.type'),
          width: '20%',
          align: 'left',
          formatter: function(value) {
            switch (value) {
            case "0":
              return $.i18n.prop('ami.template.day');
            case "1":
              return $.i18n.prop('ami.template.month');
            }
          }
        },
        {
          field: 'tmpdesc',
          title: $.i18n.prop('ami.template.desc'),
          width: '20%',
          align: 'left'
        },
        {
          field: 'operation',
          title: $.i18n.prop('ami.common.func'),
          width: '10%',
          align: 'left',
          formatter: function(value, row, index) {
            $scope['rowData_' + index] = row;
            return '<a href="javascript:void(0)" ng-if="showTmpSee" class="organization-easyui-linkbutton-edit" ng-click="view(rowData_' + index + ')" data-options="plain:true">'
                    + $.i18n.prop('ami.template.preview') + '</a> | <a href="javascript:void(0)" ng-if="showTmpEdit" class="organization-easyui-linkbutton-edit" ng-click="operationTemplate(rowData_'
                    + index + ')" data-options="plain:true">' + $.i18n.prop('ami.common.edit')
                    + '</a> | <a href="javascript:void(0)" ng-if="showTmpDel" class="organization-easyui-linkbutton-edit" ng-click="del(rowData_' + index + ')" data-options="plain:true">'
                    + $.i18n.prop('ami.common.delete') + '</a>';
          }
        },
        {
          field: 'design',
          title: $.i18n.prop('ami.template.design'),
          width: '10%',
          align: 'left',
          formatter: function(value, row, index) {
            $scope['rowData_' + index] = row;
            return '<a href="javascript:void(0)" ng-if="showTmpDesgin" class="organization-easyui-linkbutton-edit" ng-click="design(rowData_' + index + ')" data-options="plain:true">'
                    + $.i18n.prop('ami.template.bind') + '</a>';
          }
        }, ];

    $scope.htmlList = [];

    // 数据绑定
    $scope.design = function(row) {
      $scope.template = row;
      var designurl = basePath + "/templateDesign";
      if ($("#main").tabs("exists", $.i18n.prop('ami.template.bind'))) {
        $("#main").tabs('select', $.i18n.prop('ami.template.bind'));
        updateTab($("#main"), designurl, $scope.template);
        return;
      }

      $http.post(designurl, $scope.template).success(function(result) {
        $("#main").tabs('add', {
          title: $.i18n.prop('ami.template.bind'),
          content: $compile(result)($scope.$new()),
          closable: true
        });
      })
    }

    // 删除
    $scope.del = function(row) {
      parent.$.messager.confirm($.i18n.prop('ami.template.notice'), $.i18n.prop('ami.template.notice_message'), function(b) {
        if (b) {
          $.post(basePath + "/templateManagement/delete?date=" + new Date(), {
            tmpid: row.tmpid
          }, function(result) {
            if (result) {
              result = JSON.parse(result);
            }
            if (result.success) {
              $('#templateManagementTable').datagrid('load');
              $.messager.alert($.i18n.prop('ami.template.notice'), $.i18n.prop('ami.template.delete_success'), 'info');
            } else {
              $.messager.alert($.i18n.prop('ami.template.notice'), $.i18n.prop('ami.template.delete_failed') + ":" + result.messgae, 'warning');
            }

          });
        }
      })
    }

    // 新增 | 修改
    $scope.operationTemplate = function(row) {
      // 如果是新增
      var url = basePath + "/templateModel";
      $scope.template = angular.copy(row);
      // $scope.template = row;
      $.model(row ? $.i18n.prop('ami.template.edit_template') : $.i18n.prop('ami.template.add_template'), url, $scope.template, function(result) {
        return $compile(result)($scope)
      }, function(m) {
        $(".easyui-form").form('enableValidation');
        if (($("#excelFile").filebox('isValid') || !!$scope.linkbuttonshow) && $("#tmpname").validatebox('isValid') && $("#reporttype").validatebox('isValid')) {
          // 点击保存后回调
          var fileboxId = $(m).find("#excelFile").filebox("options").fileboxId;
          var url = basePath + '/templateManagement/uploadFile';
          if (($("#" + fileboxId).val() != "" && ($("#" + fileboxId).val().indexOf(".xlsx") > 0 || $("#" + fileboxId).val().indexOf(".xls") > 0)) || $("#" + fileboxId).val() == "") {
            $("#save").attr("disabled", "disabled");
            $.fileUpload(fileboxId, url, $scope.template || {}, function(data) {
              if (data.success) {
                $.messager.confirm($.i18n.prop('ami.template.confirm'), $.i18n.prop('ami.template.upload_confirm'), function(r) {
                  if (r) {
                    $scope.design(data.template);
                  }
                });
                $.model.close(m);
                $('#templateManagementTable').datagrid('load');
              } else {
                $.messager.alert($.i18n.prop('ami.template.notice'), $.i18n.prop('ami.template.upload_failed') + data.error, 'warning');
              }

            });
          } else {
            $.messager.alert($.i18n.prop('ami.template.notice'), $.i18n.prop('ami.template.upload_notice'), 'warning');
          }
        }

      });
    }

    $scope.tableUrl = basePath + '/templateManagement/query';

    // 表格加载数据完成后，执行
    $scope.$on("loadSuccess", function(e, data) {
      $compile($(data.target).find("td[field='operation'] > div"))($scope);// 手动编译表格最后一列，同步angularjs事件操作
      $compile($(data.target).find("td[field='design'] > div"))($scope);// 手动编译表格最后一列，同步angularjs事件操作

      // 菜单权限
      $permission.contains("/addTemplate", function(data) {
        $scope.showTmpAdd = data;
      });

      $permission.contains("/seeTemplate", function(data) {
        $scope.showTmpSee = data;
      });

      $permission.contains("/editTemplate", function(data) {
        $scope.showTmpEdit = data;
      });

      $permission.contains("/deleteTemplate", function(data) {
        $scope.showTmpDel = data;
      });

      $permission.contains("/seeTemplateDesgin", function(data) {
        $scope.showTmpDesgin = data;
      });

      $permission.contains("/saveTemplateDesgin", function(data) {
        $scope.saveTemplateDesgin = data;
      });
    });

    $scope.view = function(row) {
      $scope.htmlParam = {
        tmpid: row.tmpid
      };
      var viewurl = basePath + "/templateManagement/view"

      if ($("#main").tabs("exists", $.i18n.prop('ami.template.select'))) {
        $("#main").tabs('select', $.i18n.prop('ami.template.select'));
        updateTab($("#main"), viewurl, $scope.htmlParam);
        return;
      }

      $.ajax({
        url: viewurl + "?timeStasp=" + new Date(),
        type: 'post',
        data: {
          tmpid: row.tmpid
        },
        async: false,
        success: function(result) {
          $("#main").tabs('add', {
            title: $.i18n.prop('ami.template.select'),
            content: $compile(result)($scope.$new()),
            closable: true
          });
        }
      });

    }

    function updateTab($tab, url, obj) {
      $.ajax({
        url: url + "?timeStasp=" + new Date(),
        type: 'post',
        data: obj,
        async: false,
        success: function(result) {
          var tab = $tab.tabs("getSelected");
          $tab.tabs('update', {
            tab: tab,
            options: {
              content: $compile(result)($scope.$new())
            }
          });
        }
      });

    }

  });
})(jQuery, app)