var app = angular.module("advance.webapp", ["ui.bootstrap"]);
;
(function($, app) {
  "use strict";

  // 登陆页面处理表单、数据等。。。======================================
  app.controller("loginCtrl", function($scope, $http, $timeout) {
    $scope.user = {};
    $scope.exception = {};
    $scope.login = function() {
      $http.post(basePath + "/doLogin", $scope.user || {}).success(function(result) {
        if (result.success) {
          window.location.href = basePath + "/home";
        } else {
          $scope.exception.message = result.msg;
          return;
        }
      })
    }
    $scope.selectHistoryUser = function(username, pwd) {
      $scope.user.username = username;
      $scope.user.password = pwd;
    }
    $scope.hideMenu = function() {
      $timeout(function() {
        $scope.menushow = false;
      }, 100);
    }

    $scope.createCode = function() {
      var code = "";
      var codeLength = 4; // 验证码的长度
      var codeChars = new Array(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'A',
              'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'); // 所有候选组成验证码的字符，当然也可以用中文的
      for (var i = 0; i < codeLength; i++) {
        var charNum = Math.floor(Math.random() * 52);
        code += codeChars[charNum];
      }
      $scope.user.code = code;
    }

    $scope.$watch("exception", function(n, o) {
      if (n.message) {
        // 页面初始化自动生成验证码填充
        $scope.createCode();
      }
    }, true)
  });

  // 主页处理表单、数据等。。。======================================
  app.controller("homeCtrl", function($scope, $http, $timeout, $compile, $modal) {
    // 语言切换
    $scope.localLanguage = lang;
    $http.get(basePath + '/resource/tree').success(function(result) {
      $scope.menus = result.menu;
      // $scope.menus.push({id:'测试',name:'页面公共组件demo',list:[{id:'页面公共组件demo',name:'模板',url:'/test'},{id:'拖拽流程图demo',name:'流程图demo',url:'/jsPlumb'}]});
      $timeout(function() {
        $("#menu").accordion().hide().fadeIn("fast");
        /** 只是为了显示动态效果 * */
      });
    })
    // 点击左侧导航菜单跳转对应页面
    var $main = $("#main");
    $scope.addTab = function(s, index, native, e) {
      if (s) {
        $(e.target).next("ul").slideDown('fast');
      } else {
        $(e.target).next("ul").slideUp('fast');
      }
      if (!native.url) return;
      var url = basePath + native.url;
      var nativeI18n = $.i18n.prop(native.id);
      if ($main.tabs("exists", nativeI18n)) {
        $main.tabs('select', nativeI18n);
        updateTab($main, url);
        return;
      }
      // **** 为了适应angularjs，此处需要通过请求获取html片段并对其进行编译后设置tab。****
      $http.post(basePath + native.url).success(function(result) {
        $main.tabs('add', {
          title: nativeI18n,
          content: $compile(result)($scope.$new()),
          closable: true
        });
      })
    }

    // tabs页签绑定右击事件
    $main.tabs({
      onContextMenu: function(e, title, index) {
        if (index === 0) return;
        $main.tabs('select', index);
        $('#mm').menu('show', {
          left: mousePos(e).x,
          top: mousePos(e).y
        });
      }
    });
    function mousePos(e) {
      var e = e || window.event;
      return {
        x: e.clientX + document.body.scrollLeft + document.documentElement.scrollLeft,
        y: e.clientY + document.body.scrollTop + document.documentElement.scrollTop
      };
    }

    function updateTab($tab, url) {
      $http.post(url).success(function(result) {
        var tab = $tab.tabs("getSelected");
        $tab.tabs('update', {
          tab: tab,
          options: {
            content: $compile(result)($scope.$new())
          }
        });
      })
    }

    $scope.close = function() {
      $main.tabs("closeCurrent");
    }
    $scope.closeAll = function() {
      $main.tabs("closeAll");
    }
    $scope.closeOther = function() {
      $main.tabs("closeOther");
    }

    $scope.logout = function() {
      $http.post(basePath + "/logout", {}).success(function() {
        window.location.href = basePath + "/login";
      });
    }
    
    $scope.changePassword = function() {
      $scope.userInfo = {};

      $.model($.i18n.prop('ami.report.home.editPassword'), basePath + "/editPassWord", $scope.userInfo, function(result) {
        return $compile(result)($scope)
      }, function(m) {
        if ($(".easyui-form").form('enableValidation').form('validate')) {
          $http.post(basePath + "/user/editUserPwd", $scope.userInfo).success(function(result) {
            if (result.success) {
              // 加载结果
              setTimeout(function() {
                $http.post(basePath + "/logout", {}).success(function() {
                  window.location.href = basePath + "/login";
                });
              }, 500);
            } else {
              $.messager.alert($.i18n.prop('ami.common.warning'), result.msg, 'warning');
            }
          })
        }
        
      },450,350);
      
    }
    

    // 查看修改个人信息
	$scope.openPersonModel = function(username) {
	            var modalInstance = $modal.open({
	            	templateUrl:basePath + "/systemParameter/personInfo",
	            	scope:false,
	            	backdrop:'static',
	            	keyboard:true,
	            	size:"defalut",
	            	controller:function($scope,$modalInstance){
	            		$scope.username=username;
	            		$scope.close=function(){$modalInstance.dismiss('cancel');}
	            		$scope.ok=function(){
	            			if($(".easyui-form").form('enableValidation').form('validate'))
	            			{
	            				$modalInstance.dismiss('cancel');
	            			}	
	            		}
	            	}
	            });
    }

    $scope.languageList = [{
      langName: $.i18n.prop("ami.report.login.chinese"),
      lang: 'zh_CN'
    },// 中文
    {
      langName: $.i18n.prop("ami.report.login.english"),
      lang: 'en_US'
    }// 英文
    ];
    var langList = ['<ul class="list-group ami-popover-list">', '<li class="list-group-item" ng-repeat="l in languageList">',
        '<span class="badge" ng-if="localLanguage == l.lang"><span class="glyphicon glyphicon-ok-circle"></span></span><a href="?lang={{l.lang}}" ng-bind="l.langName"></a>', '</li>', '</ul>']
            .join("");
    var userList = ['<ul class="list-group ami-popover-list">', '<li class="list-group-item">',
                    '<a href="javascript:;" ng-click="changePassword()">'+$.i18n.prop('ami.report.home.editPassword')+'</a>', '</li>', '</ul>']
                        .join("");

    $(function() {
      $(".popover-options").popover({
        html: true,
        content: $compile(langList)($scope),
        delay: 300
      }).on("mouseenter", function() {
        var _this = this;
        $(_this).addClass("active").popover("show");
        $(".popover").on("mouseleave", function() {
          $timeout(function() {
            $(_this).removeClass("active").popover('hide');
          }, 100)
        });
      }).on("mouseleave", function() {
        var _this = this;
        $timeout(function() {
          if (!$(".popover:hover").length) {
            $(_this).removeClass("active").popover("hide")
          }
        }, 100);
      });
      
      $(".popover-options1").popover({
        html: true,
        content: $compile(userList)($scope),
        delay: 300
      }).on("mouseenter", function() {
        var _this = this;
        $(_this).addClass("active").popover("show");
        $(".popover").on("mouseleave", function() {
          $timeout(function() {
            $(_this).removeClass("active").popover('hide');
          }, 100)
        });
      }).on("mouseleave", function() {
        var _this = this;
        $timeout(function() {
          if (!$(".popover:hover").length) {
            $(_this).removeClass("active").popover("hide")
          }
        }, 100);
      });
    });
  });
})(jQuery, app)