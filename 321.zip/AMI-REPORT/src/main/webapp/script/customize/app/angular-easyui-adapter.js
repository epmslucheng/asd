(function($){
	"use strict";
	
	var app = angular.module("main.webapp", ['advance.webapp']);
	
	app.config(["$httpProvider", function ($httpProvider) {   
        $httpProvider.interceptors.push('loadingInterceptor');  
    }]);
	
	app.factory('loadingInterceptor', ["$rootScope", function ($rootScope) {return { request: function (config) { $rootScope.loading = true; return config;  }, response: function (response) { $rootScope.loading = false; return response; }};}]);  

	// 自定义enter键入操作指令
	app
	 .run(function($templateCache) {
		 var treeHtm = [
					                '<script id="treeRecursion" type="text/ng-template">',
					                '<span ng-dblclick="warpDblclickCallback(\'itemDblclick\',item,$event)"  ng-click="warpCallback(\'itemClicked\', item, $event)" context-menu="item" class="item-tree {{item.disabled ? \'item-disabled\':\'\'}}" id="drag-tree-{{item[valueField]}}" ng-drag="drag(item)">',
					                '<i class="	glyphicon glyphicon-file" ng-if="isLeaf(item)"></i>',
					                '<i ng-click="expendItem(item,$event)" ng-if="!isLeaf(item)" ng-class="{\'true\':\'glyphicon glyphicon-folder-close\',\'false\':\'glyphicon glyphicon-folder-open\'}[!item.$$isExpend]"></i>',
					                '<input type="checkbox" class="checkbox" ng-if="itemCheckbox" ng-checked="item.checked"></input>',
					                '<span class="checkicon glyphicon glyphicon-ok {{item.$$state}} " ng-if="itemCheckbox" ng-click="checkItem(item,$event);sure(item,\'itemChecked\')"></span>',
					                '<i ng-if="item.editable &&  itemEdit && !item.$$showEdit" class="glyphicon glyphicon-pencil item-edit" ng-click="edit(item,$event)" ng-init="item.$$showEdit=false"></i>',
					                '<i ng-if="item.editable && itemEdit && item.$$showEdit" class="glyphicon glyphicon-ok item-save" ng-click="edit(item,$event,\'itemSave\')"></i>',
					                '<dd ng-if="!item.$$showEdit" ng-bind="item[textField]"></dd>',
					                '<input focus type="text" class="form-control" ng-if="item.$$showEdit" ng-model="item[textField]">',
					                '</span><a href=""></a>',
					                '<ul ng-if="!isLeaf(item)" ng-show="item.$$isExpend">',
					                '<li ng-repeat="item in item.children track by $index" ng-class="{\'true\':\'parent_li\',\'false\':\'child_li\'}[!isLeaf(item)]" ng-include="\'treeRecursion\'">',
					                '</li>',
					                '</ul>',
					                '</script>'].join("");
		 var selectTreeHtm=[
									'<div class="select-tree" >',
									'<div ng-click="selectShow=!selectShow" ng-init="selectShow=false">',
										  '<input type="text" class="form-control  ami-readonly" ng-attr-title="{{inputText}}" ng-model="inputText" placeholder="'+$.i18n.prop("ami.report.keyword")+'" readonly="readonly"/>',
										  '<span class="tool-icon" ng-class="{true:\'glyphicon glyphicon-chevron-up\',false:\'glyphicon glyphicon-chevron-down\'}[selectShow]"></span>',
									'</div>',
									'<div class="tree-body ami-shadow"  ng-show="selectShow">',
										 '<div class="tree-body-content full-width">',
										 	'<div ng-transclude></div>',
										 '</div>',
										 '<div class="tree-body-foot">',
												'<button type="button" class="btn btn-default" ng-click="selectShow=false">'+$.i18n.prop("ami.common.close")+'</button>',
										 '</div>',
									'</div>',
									'</div>'
		                    ].join("");
		 
	        $templateCache.put('tree.htm',treeHtm);
	        $templateCache.put('selectTree.htm',selectTreeHtm);
	})
	.directive('ngEnter', function () {return function (scope, element, attrs) { element.bind("keydown keypress", function (event) { if (event.which === 13) { scope.$apply(function () { scope.$eval(attrs.ngEnter); }); event.preventDefault(); } }); };})
	.directive("sycnEasyui",function($filter,$compile,$parse){
		return {
            require : '?^ngModel',
            scope:{},
            link : function(scope,element,attrs){
            	if(element.hasClass("easyui-datebox") || element.hasClass("easyui-datetimebox"))
            	{
            		scope.$watch(attrs.ngModel,function(){
            			element.datebox("setValue",scope.$parent.$eval(attrs.ngModel) || "");
            		});
            		element.datebox({onChange:function(date){
            			var model = $parse(attrs.ngModel);
        				model.assign(scope.$parent,date);
            		}});
            	}	
            	if(element.hasClass("easyui-datetimebox"))
              {
                scope.$watch(attrs.ngModel,function(){
                  element.datetimebox("setValue",scope.$parent.$eval(attrs.ngModel) || "");
                });
                element.datetimebox({onChange:function(date){
                  var model = $parse(attrs.ngModel);
                model.assign(scope.$parent,date);
                }});
              } 
            	else if(element.hasClass("easyui-combobox"))
            	{
            		scope.$watch(attrs.ngModel,function(){
            			element.combobox("setValue",scope.$parent.$eval(attrs.ngModel) || "");
            		});
            		element.combobox({onSelect:function(item){
            			var model = $parse(attrs.ngModel);
        				model.assign(scope.$parent,item[element.combo("options").valueField]);
            		}});
            	}
            }
        }
	})
	.directive('epmsTable', function($timeout) {
        return {
        	restrict: 'E',
            scope:{
            	epmsTableUrl:'=epmsTableUrl',
            	epmsTableTitle:'@epmsTableTitle',
            	epmsTableOptions:'@epmsTableOptions',
            	epmsTableHeader:'=epmsTableHeader',
            	epmsTableParam:'=epmsTableParam'
            },
            template: '<table class="emps-table" style="width:100%;height:100%;display:none;"></table>',
            replace: true,
            link:function(scope,element,attr)
            {
            	var options = {
            			title:scope.epmsTableTitle,
                		emptyMsg:'<div style="height:30px;line-height:30px;border-bottom:1px dotted #ddd">'+ $.i18n.prop("ami.report.noData") +'</div>',
                		columns:[scope.epmsTableHeader],
                		url:scope.epmsTableUrl,
                		queryParams:scope.epmsTableParam,
                        onLoadSuccess : function(data){scope.$emit("loadSuccess",{target:$(element).datagrid("getPanel")[0],row:data});}
                    };
            	var option = scope.epmsTableOptions ? (new Function('return ' + '{' + scope.epmsTableOptions + '}'))() : {};
            	$.extend(options,option);
            	$timeout(function(){
            		$(element).datagrid(options).closest("div.datagrid").hide().fadeIn('fast');
            	})
            }
        };
    })
     .directive('selectTree', function($templateCache) {
    	 return {
     		     restrict: 'E',
     			 replace: true,
     			 transclude: true,
     		     template: $templateCache.get("selectTree.htm"),
     		     scope: {
     				inputText:'='
     			},
     		     controller:function($scope,$element,$attrs,$filter){
     				angular.element(document).bind("click",function(e){
     					var _yes = $(e.target).hasClass("select-tree") || $(e.target).closest("div.select-tree").length;
     					if(!_yes)
     						$scope.$apply(function(){
     							$scope.selectShow=false; 
     						})
     				});
     			}
    	 }
     })
    .directive('epmsTree', function($templateCache) {
    	var template = [
    	                			'<div class="tree well">',
							 		'<div class="item-search" ng-show="searchShow && treeData.length">',
							 			'<input type="text" class="form-control" ng-model="searchFilter" placeholder="'+ $.i18n.prop("ami.report.keyword") +'"/>',
							 			'<span class="glyphicon glyphicon-search tool-icon"></span>',
							 		'</div>',
										'<ul style="padding:0;"><li ng-class="{\'true\':\'parent_li\',\'false\':\'child_li\'}[!isLeaf(item)]" ng-repeat="item in tree track by $index" ng-include="\'treeRecursion\'" ></li></ul>',
										$templateCache.get("tree.htm"),
										'</div>'
									].join("");
    	
    	return {
    		     restrict: 'E',
    			 replace: true,
    		     template: template,
    		     scope: {
    		       treeData: '=',
    		       textField: '@',
    			   valueField:'@',
    			   parentId:'@',
    			   searchFilter:'=',
    			   itemEdit:'=',
    			   itemSave:'&',
    			   itemDrag:'&',
    			   itemCheckbox:'=',
    			   itemTool:'@',
    			   itemDblclick:'&',
    			   itemChecked:'&'
    		     },
    		     controller:function($scope,$element,$attrs,$filter){
    				if($scope.itemTool)
    				{
    					var $$controller = $($element).closest("div[ng-controller]");
    					var $$itemTool = $($element).next("#" + $scope.itemTool);
    					$$itemTool.appendTo($$controller);
    				}	
    			
    				$scope.searchShow = !!$attrs.searchFilter;// 如果页面没有配置searchFilter属性，则不显示检索框
    				$scope.expendItem=function(item,$event){$event.stopPropagation();if($($event.target).is("input"))return; item.$$isExpend=!item.$$isExpend};
    				$scope.isLeaf = function(item){ return !item.children || !item.children.length;};
    				$scope.warpCallback = function(callback, item, $event){
    					$scope.expendItem(item,$event);
    					// 外部调用方法。
    					($scope[callback] || angular.noop)({ $item:item, $event:$event });
    				};
    				
    				$scope.warpDblclickCallback = function(callback, item, $event){
    					$event.stopPropagation();
    					// 外部调用方法。
    					($scope[callback] || angular.noop)({ $item:item, $event:$event });
    				};
    				
    				$scope.drag = function(item)
    				{
    					if(item.draggable)
    					{
    						// 外部调用方法。
        					($scope.itemDrag || angular.noop)({ $item:item});
    					}	
    				}
    				
    				$scope.sure = function(item,callback){
     					($scope[callback] || angular.noop)({ $item:item});
     				}
    				
    				// 树节点复选框
    				$scope.checkItem = function(item,$event){
    					$event.stopPropagation();
    					delete item.$$state;
    					item.checked=!item.checked;
    					// 如果存在子节点，勾选input时，将子节点同步与当前节点的状态
    					$scope.check(item);
    					// 判断父节点进行全部选中，否则去除勾选状态
    					$scope.parentCheck(item);
    				}
    				
    				$scope.check=function(item)
    				{
    					if(item.children)
    					{
    						angular.forEach(item.children,function(v,i){
    							v.checked = item.checked;
    							delete item.$$state;
    							$scope.check(v);
    						})
    					}	
    				}
    				
    				$scope.parentCheck=function(item)
    				{
    					var $$parent;
    					angular.forEach($scope.treeData,function(tree,index){
    						if(!$$parent && item[$scope.parentId] === tree[$scope.valueField])
    						{
    							$$parent = tree;
    						}
    					});
    					// 找到父节点后，对父节点进行状态判断
    					if($$parent && $$parent.children)
    					{
    						var checkedlength = $scope.checked($$parent.children).checked.length;
    						var $$allchecked = $$parent.children.length == checkedlength;//全选中
    						if($$allchecked){
    							for(var i = 0;i<$$parent.children.length&&$$allchecked;i++){
    								if($$parent.children[i].$$state){
    									$$allchecked = false;
    								}
    							}
    						}
    						delete $$parent.$$state;
    						if($$allchecked)
    						{
    							$$parent.checked = true;
    							if(item.$$state){$$parent.$$state = item.$$state;}
    						}
    						else if(0 != checkedlength)
    						{
    							$$parent.checked = true;
    							$$parent.$$state ='indeterminate';//半选中
    						}
    						else
    						{
    							$$parent.checked = false;
    						}	
    						$scope.parentCheck($$parent);
    					}	
    				}
    				
    				// 分类选中和未选中状态的item
    				$scope.checked=function(treeData){
    					var checked =[],unchecked=[];
    					angular.forEach(treeData,function(tree,index){
    						if(tree.checked){checked.push(tree);}
    						else{unchecked.push(tree);}
    					});
    					return {checked:checked,unchecked:unchecked};
    				}
    				
    				$scope.edit = function(item,$event,callback)
    				{
    					$event.stopPropagation();
    					item.$$showEdit = !item.$$showEdit;
    					$scope.focus = item.$$showEdit;
    					($scope[callback] || angular.noop)({ $item:item, $event:$event });
    				}
    				
    				//javascript  树形结构
    				function generateTree(a){angular.forEach(a,function(d){delete d.children});var b={};angular.forEach(a,function(d){b[d[$scope.valueField]]=d});var c=[];angular.forEach(a,function(e){var d=b[e[$scope.parentId]];if(d){(d.children||(d.children=[])).push(e)}else{c.push(e)}});return c};
			
    				$scope.$watch("treeData",function(newValue,oldValue){
    					if(undefined != newValue && newValue != oldValue)
    					{
    						if(!$scope.filter) { $scope.tree = generateTree(newValue); }// 生成树结构
    						var lineData = [];
    						angular.forEach($scope.tree,function(v,index){$scope.tree2LineData(lineData,v)});
    						angular.forEach(lineData,function(item,index){if(item.checked){$scope.parentCheck(item);}	});
    					}
    				},true);
    				
    				//监控输入框的变化，如果输入框字段发生变化，然后就执行最开始设计的函数setDepartListShow和setDepartListHide
                    $scope.$watch('searchFilter',function(newValue,oldValue){
                    	$scope.filter=false;
                        if(undefined != newValue && newValue!=oldValue)
                        {
                        	$scope.tree = generateTree($scope.searchTree($scope.treeData,newValue));
                            if(newValue!=""){ $scope.filter=true;$scope.setTreeShow($scope.tree) }
                            else{ $scope.setTreeHide($scope.tree);}
                        }
                    });
    				
                    $scope.tree2LineData = function(lineData,tree)
                    {
                    	lineData.push(tree);
                    	if(tree.children && tree.children.length!=0)
                    	{
                    		angular.forEach(tree.children,function(v,index){
                    			$scope.tree2LineData(lineData,v)
                    		});
                    	}	
                    }
                    
                    // 检索树
                    $scope.searchTree = function(data,search)
                    {
                    	if(!search)return data;
                    	var $$key = this.textField;
                    	var $$parentId = this.parentId;
                    	var filterTree = [];
                    	angular.forEach(data,function(item){ if(angular.lowercase(item[$$key]).indexOf(angular.lowercase(search)) >=0  && !$scope.exist(filterTree,item)) {filterTree.push(item); $scope.overTree(filterTree,data,item[$$parentId])}});
                    	// 数组去重算法
                    	return filterTree;
                    }

                    $scope.overTree=function(filterTree,data,parentId)
                    {
                    	var $$parentId = this.parentId;
                    	var $$value = this.valueField;
                    	angular.forEach(data,function(item){if(item[$$value] === parentId && !$scope.exist(filterTree,item)) { filterTree.push(item); $scope.overTree(filterTree,data,item[$$parentId]);return false;}})
                    	
                    }
                    
                    // 判断数组中是否存在
                    $scope.exist = function(trees,item)
                    {
                    	var $$value = this.valueField;
                    	var $idList = $.map(trees,function(n){return n[$$value]});
                    	return $.inArray(item[$$value],$idList) >= 0;
                    }
                    
    				//这段代码意思是如果要搜索树形，先展开树形所有节点
    				$scope.setTreeShow=function(node){
    				        for(var i=0;i<node.length;i++){
    				        	var children = node[i].children;
    				            if(children && children.length!=0){
    				                node[i].$$isExpend=true;
    				                $scope.setTreeShow(children);
    				            }
    				        }
    				    }
    				//这段代码意思是如果要搜索树形，然后隐藏跟搜索框不匹配的节点，这样2步就达到了 只展示出了跟搜索字段相匹配的结果
				    $scope.setTreeHide=function(node){
				        for(var i=0;i<node.length;i++){
				        	var children = node[i].children;
				            if(children && children.length!=0){
				                node[i].$$isExpend=false;
				                $scope.setTreeHide(children);
				            }
				        }
				    }
    			}};
    })
    .directive('epmsMultipleSelect', function($compile) {
        return {
        	restrict: 'E',
            scope:{
            	selectList:'=selectList',
            	select:'=select',
            	value:'@value',
            	label:'@label'
            },
            template: '<select class="selectpicker form-control" multiple data-live-search="true"></select>',
            replace: true,
            link:function(scope,element,attr)
            {
            	scope.$watchCollection("selectList",function(){
            		var options = [];
                	angular.forEach(scope.selectList,function(v,i){
                		options.push('<option  value="'+v[scope.value]+'">'+v[scope.label]+'</option>');
                	});
                	$(element).empty().append(options.join(""));
                	$(element).selectpicker({
            	        'selectedText': 'cat',
            	        'noneSelectedText':$.i18n.prop("ami.report.noneSelectedText"),
            	        'noneResultsText':$.i18n.prop("ami.report.noneResultsText")
            	    });
                	$(element).selectpicker('refresh');
                	scope.select=null;
            	});
            	// 设置值
            	scope.$watch("select",function(){
            		$(element).selectpicker('val', scope.select);
            	});
            	// 选中时设置
            	$(element).on('changed.bs.select', function(e) {
            		var val = $(this).val();
            		scope.$apply(function(){
            			scope.select=val;
            		})
            	});
            }
        };
    })
    .directive('ngDrag', function($parse) { return { restrict: 'A', scope:true, link:function(scope,element,attr) {
	    	scope.$watch('$viewContentLoaded', function() {
	    		var func = $parse(attr.ngDrag);func(scope);
			});
    	} 
    };
   })
	 .directive('easyuiForm', function($parse) { return { restrict: 'C', scope:false, link:function(scope,element,attr) {
		 $.parser.parse($(element)[0]);
		 $(element).form({novalidate:true}).find(".easyui-validatebox").blur(function () {$(this).validatebox('enableValidation').validatebox('validate') });
	 } 
 };
})
.directive('contextMenu', ['$window','$compile', '$timeout',function($window,$compile,$timeout) {
	 return { restrict: 'A', scope:true, link:function($scope,$element,$attr) {
		 // 绑定dom树隐藏menu菜单
		 var $$itemTool = $($element).closest("div[ng-controller]").find("#" + $scope.itemTool);
		 $element.bind('contextmenu', function(e) {
			 	e.preventDefault();
			 	var offset = $($element).closest("div.tree").offset();
			 	$$itemTool.css({left:e.pageX - 1,top:e.pageY - 1}).fadeIn("fast").data("tree.menu.item",$scope.item)
				.unbind("mouseleave").bind("mouseleave",function(e){$(this).fadeOut("fast"); });
			})
			.bind("mousemove",function(e){$$itemTool.fadeOut("fast"); });
 	}};
}])
.directive('menuClick', ['$window', function($window) {
	 return { restrict: 'A', scope:{menuClick:'&'}, link:function($scope,$element,$attr) {
		 $element.on("click",function(e){
			 e.stopPropagation();
			 var $$menu = $($element).closest(".tree-menu");
			 $scope.$apply(function() {
				 ($scope['menuClick'] || angular.noop)({ $item:$$menu.data("tree.menu.item")});
				 $$menu.hide();
			 });
		 })
 	}};
}])
.directive('focus',[ function(){
    return { scope:false, link:function(scope, element){               
       scope.$watch("focus",function(newValue,oldValue, scope) {  if(newValue){ element[0].focus(); /**获取焦点**/ } }, true);
    }};
}])
.filter('i18n',function(){
    return function(value){ return $.i18n.prop(value); }
})
.directive('repeatFinish',function(){
    return { restrict: 'A', link: function(scope,element,attr){if(scope.$last == true){scope.$eval(attr.repeatFinish);}}}
});
})(jQuery)