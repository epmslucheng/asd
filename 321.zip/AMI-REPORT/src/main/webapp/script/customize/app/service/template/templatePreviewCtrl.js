;
(function($, app) {
  "use strict";
  // 模板管理
  app.controller("templatePrrviewCtrl", function($scope, $http, $timeout, $compile, $element) {

    $.post(basePath + '/templateManagement/htmlDatagrid?date=' + new Date(), $scope.htmlParam, function(result) {
      var htmlList = JSON.parse(result).rows;
      for (var i = 0; i < htmlList.length; i++) {
        /*
         * $("#tab").tabs('add', { title: htmlList[i].sheetName, : basePath +
         * htmlList[i].downPath + "?timeStasp=" + new Date(), closable: false,
         * cache: false });
         */
        $.ajax({
          url: basePath + htmlList[i].downPath + "?timeStasp=" + new Date(),
          type: 'get',
          async: false,
          success: function(data) {
            $("#tab").tabs('add', {
              title: htmlList[i].sheetName,
              content: $compile(data)($scope.$new()),
              closable: false,
              cache: false
            });
          }
        });

      }
      $('#tab').tabs({
        onSelect: function(title, index) {
          var tab = $('#tab').tabs('getSelected'); // 获取选择的面板
          $('#tab').tabs('update', {
            tab: tab
          });
        }
      });

      $("#tab").tabs('select', 0);
    });
  });
})(jQuery, app)