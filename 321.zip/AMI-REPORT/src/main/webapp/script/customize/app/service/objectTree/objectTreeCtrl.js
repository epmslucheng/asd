;
(function($, app) {
  "use strict";
  // 模板管理
  app.controller("objectTreeCtrl", function($scope, $http, $timeout, $compile, $element, $permission) {

    $scope.tableHeader = [{
      field: 'id',
      title: 'ID',
      width: '10%',
      align: 'left',
      hidden: 'true'
    }, {
      field: 'name',
      title: $.i18n.prop('ami.object.name'),
      width: '30%',
      align: 'left'
    }, {
      field: 'desc',
      title: $.i18n.prop('ami.object.desc'),
      width: '40%',
      align: 'left',
    }, {
      field: 'operation',
      title: $.i18n.prop('ami.common.func'),
      width: '20%',
      align: 'left',
      formatter: function(value, row, index) {
        $scope['rowData_' + index] = row;
        var str = '';
        str += ' <shiro:hasPermission name="assetInfo/query">';
        str += '<a href="javascript:void(0)" ng-if="showEdit" ng-click="editObjectFn(rowData_' + index + ')">' + $.i18n.prop('ami.common.edit') + '</a>';
        str += '</shiro:hasPermission>';
        str += ' | ';
        str += '<a href="javascript:void(0)" ng-if="showMaintain" ng-click="maintainObjectFn(rowData_' + index + ')">' + $.i18n.prop('ami.common.maintain') + '</a>';
        str += ' | ';
        str += '<a href="javascript:void(0)" ng-if="showDelete" ng-click="deleteObjectFn(rowData_' + index + ')">' + $.i18n.prop('ami.common.delete') + '</a>';
        return str;
      }
    }];

    $scope.tableUrl = basePath + '/objectTree/query';

    // 新增
    $scope.addObjectTree = function(row) {
      $scope.objectTree = {};
      $.model($.i18n.prop('ami.common.add'), basePath + "/objectTree/addPage", $scope.objectTree, function(result) {
        return $compile(result)($scope)
      }, function(m) {
        $http.post(basePath + "/objectTree/save", $scope.objectTree || {}).success(function(result) {
          if (result.success) {
            $.model.close(m);
            $.messager.alert($.i18n.prop('ami.common.info'), $.i18n.prop('ami.common.save.success'), 'info');
            $("#objectTreeTableSet").datagrid('reload');
          }
        })
      });
    }

    $scope.editObjectFn = function(row) {
      $scope.objectTree = row;
      $.model($.i18n.prop('ami.common.edit'), basePath + "/objectTree/editPage", $scope.objectTree, function(result) {
        return $compile(result)($scope)
      }, function(m) {
        $http.post(basePath + "/objectTree/edit", $scope.objectTree || {}).success(function(result) {
          if (result.success) {
            $.model.close(m);
            $.messager.alert($.i18n.prop('ami.common.info'), result.msg, 'success');
            $("#objectTreeTableSet").datagrid('reload');
          } else {
            $.messager.alert($.i18n.prop('ami.common.info'), result.msg, 'error');
          }
        })
      });
    }

    $scope.maintainObjectFn = function(row) {
      $scope.objectTree = row;

      var treeObjectUrl = basePath + "/objectTree/maintainPage";
      if ($("#main").tabs("exists", $.i18n.prop('ami.object.maintain'))) {
        $("#main").tabs('select', $.i18n.prop('ami.object.maintain'));
        updateTab($("#main"), treeObjectUrl, $scope.objectTree);
        return;
      }

      $http.post(treeObjectUrl, $scope.objectTree).success(function(result) {
        $("#main").tabs('add', {
          title: $.i18n.prop('ami.object.maintain'),
          content: $compile(result)($scope.$new()),
          closable: true
        });
      })

    }

    function updateTab($tab, url, obj) {

      $http.post(url, obj).success(function(result) {
        var tab = $tab.tabs("getSelected");
        $tab.tabs('update', {
          tab: tab,
          options: {
            content: $compile(result)($scope.$new())
          }
        });
      })

      // $.post(url,angular.toJson(obj),function(result){
      // var tab = $tab.tabs("getSelected");
      // $tab.tabs('update', { tab: tab, options: {
      // content: $compile(result)($scope.$new()) } });
      // });
    }

    $scope.deleteObjectFn = function(row) {
      $scope.objectTree = row;
      parent.$.messager.confirm('info', $.i18n.prop('ami.template.notice_message'), function(b) {
        if (b) {
          $http.post(basePath + "/objectTree/delete", $scope.objectTree || {}).success(function(result) {
            if (result.success) {
              $.messager.alert($.i18n.prop('ami.common.info'), result.msg, 'success');
              $("#objectTreeTableSet").datagrid('reload');
            } else {
              $.messager.alert($.i18n.prop('ami.common.info'), result.msg, 'error');
            }
          })
        }
      })
    }

    // 表格加载数据完成后，执行
    $scope.$on("loadSuccess", function(e, data) {
      $compile($(data.target).find("td[field='operation'] > div"))($scope);// 手动编译表格最后一列，同步angularjs事件操作

      $permission.contains("/addObjTree", function(data) {
        $scope.showAdd = data;
      });
      $permission.contains("/editObjTree", function(data) {
        $scope.showEdit = data;
      });
      $permission.contains("/maintainObjTree", function(data) {
        $scope.showMaintain = data;
      });
      $permission.contains("/deleteObjTree", function(data) {
        $scope.showDelete = data;
      });
    });
  });
})(jQuery, app)
