;
(function($, app) {
  "use strict";
  // 模板管理
  app.controller("objectTreeNodeCtrl", function($scope, $http, $timeout, $compile, $element) {

    $scope.objectTreeData = {};
    function pushData() {
      $scope.objectTree;
      $.ajax({
        type: "POST",
        url: basePath + "/objectTree/getObjectTreeByObjectId",
        dataType: "html",
        contentType: "application/json",
        data: JSON.stringify($scope.objectTree),
        success: function(result) {
          if (result) {
            result = JSON.parse(result);
          }
          if (result.success) {
            $timeout(function() {
              $scope.objectTreeData = eval(result.obj.list);
            });
            // $scope.$apply(function(){
            // $scope.objectTreeData = eval(result.obj.list);
            // });

          } else {
            $.messager.alert($.i18n.prop('ami.common.warning'), $.i18n.prop('ami.role.waring_message'), 'warning');
          }
        }
      });
    }
    pushData();

    // 获取生成id
    $scope.addObjectTreeRoot = function() {
      var id = $scope.objectTree.id;
      $scope.objectTreeNode = {};
      $scope.objectTreeNode.objectTreeId = id;
      $scope.objectTreeNode.level = 1;

      // 先生成节点id
      $.ajax({
        type: "POST",
        url: basePath + "/objectTree/genertateId?date=" + new Date(),
        dataType: "html",
        contentType: "application/json",
        data: {},
        async: false,
        success: function(result) {
          if (result) {
            result = JSON.parse(result);
          }
          if (result.success) {
            $scope.objectTreeNode.treeId = eval(result.obj.id);

          } else {
            $.messager.alert($.i18n.prop('ami.common.warning'), $.i18n.prop('ami.object.id_fail'), 'warning');
          }
        }
      });

      $.model($.i18n.prop('ami.object.add_node'), basePath + "/objectTree/addRootNodePage", $scope.objectTreeNode, function(result) {
        return $compile(result)($scope)
      }, function(m) {

        if ($scope.objectTreeData.length == 0) {
        	if ($(".easyui-form").form('enableValidation').form('validate')) {
	          $http.post(basePath + "/objectTree/saveRootNode", $scope.objectTreeNode || {}).success(function(result) {
	            if (result.success) {
	              $scope.objectTreeNode.level = 1;
	              $scope.objectTreeData.push($scope.objectTreeNode);
	              $.model.close(m);
	              $.messager.alert($.i18n.prop('ami.common.info'), result.msg, 'success');
	            } else {
	              $.messager.alert($.i18n.prop('ami.common.info'), result.msg, 'error');
	            }
	          })
        	}
        } else {
          $.model.close(m);
          $.messager.alert($.i18n.prop('ami.common.info'), $.i18n.prop('ami.object.add_message'), 'info');
        }

      });

    }

    $scope.addTreeNode = function(v) {
      var id = $scope.objectTree.id;
      $scope.objectTreeNode = {};
      $scope.objectTreeNode.objectTreeId = id;
      $scope.objectTreeNode.level = v.level++;
      $scope.objectTreeNode.treePid = v.treeId;

      // 先生成节点id
      $.ajax({
        type: "POST",
        url: basePath + "/objectTree/genertateId?date=" + new Date(),
        dataType: "html",
        contentType: "application/json",
        data: {},
        async: false,
        success: function(result) {
          if (result) {
            result = JSON.parse(result);
          }
          if (result.success) {
            $scope.objectTreeNode.treeId = eval(result.obj.id);
          } else {
            $.messager.alert($.i18n.prop('ami.common.warning'), $.i18n.prop('ami.object.id_fail'), 'warning');
          }
        }
      });

      $.model($.i18n.prop('ami.object.add'), basePath + "/objectTree/addNodePage", $scope.objectTreeNode, function(result) {
        return $compile(result)($scope)
      }, function(m) {
    	  if ($(".easyui-form").form('enableValidation').form('validate')) {
	        $http.post(basePath + "/objectTree/saveNode", $scope.objectTreeNode || {}).success(function(result) {
	          if (result.success) {
	            $.model.close(m);
	            $.messager.alert($.i18n.prop('ami.common.info'), result.msg, 'success');
	            $scope.objectTreeData.push($scope.objectTreeNode);
	          } else {
	            $.messager.alert($.i18n.prop('ami.common.info'), result.msg, 'error');
	          }
	        })
    	  }
      });
    }
    $scope.eidtTreeNode = function(v) {
      var id = $scope.objectTree.id;
      $scope.objectTreeNode = {};
      $scope.objectTreeNode.objectTreeId = id;
      $scope.objectTreeNode = angular.copy(v);
      $.model($.i18n.prop('ami.object.edit'), basePath + "/objectTree/editNodePage", $scope.objectTreeNode, function(result) {
        return $compile(result)($scope)
      }, function(m) {
    	  if ($(".easyui-form").form('enableValidation').form('validate')) {
	        $http.post(basePath + "/objectTree/editNode", $scope.objectTreeNode || {}).success(function(result) {
	          if (result.success) {
	            $.model.close(m);
	            $.messager.alert($.i18n.prop('ami.common.info'), result.msg, 'success', function() {
	              $scope.$apply(function() {
	                angular.extend(v, $scope.objectTreeNode);
	              })
	            });
	          } else {
	            $.messager.alert($.i18n.prop('ami.common.info'), result.msg, 'error');
	          }
	        })
    	  }
      });
    }

    $scope.removeTreeNode = function(v) {
      var id = $scope.objectTree.id;
      $scope.objectTreeNode = {};
      $scope.objectTreeNode.objectTreeId = id;
      $scope.objectTreeNode.treeId = v.treeId;

      if (v.children) {
        $.messager.alert($.i18n.prop('ami.common.info'), $.i18n.prop('ami.object.delete_message'), 'info');
      } else {
        $http.post(basePath + "/objectTree/delNode", $scope.objectTreeNode || {}).success(function(result) {
          if (result.success) {

            // 删除节点
            var _arr = $scope.objectTreeData;
            var _obj = $scope.objectTreeNode;
            var length = _arr.length;
            for (var i = 0; i < length; i++) {
              if (_arr[i].treeId == _obj.treeId) {
                if (i == 0) {
                  _arr.shift(); // 删除并返回数组的第一个元素
                  return;
                } else if (i == length - 1) {
                  _arr.pop(); // 删除并返回数组的最后一个元素
                  return;
                } else {
                  _arr.splice(i, 1); // 删除下标为i的元素
                  return;
                }
              }
            }

            $.messager.alert($.i18n.prop('ami.common.info'), result.msg, 'success');
          } else {
            $.messager.alert($.i18n.prop('ami.common.info'), result.msg, 'error');
          }
        })
      }

    }

    // 双击回填input
    $scope.choose = function(item) {
      var $$treeId = $scope.$parent.objectTree.id;
      $("input[id^='" + $$treeId + "_treeName_" + "']").searchbox("setValue", item.treeName);
      $("#objectTreeTable").datagrid("getSelected").treeCode = item.treeCode;
      $("#objectTreeCloseBtn").trigger("click");
    }
  });
})(jQuery, app)
