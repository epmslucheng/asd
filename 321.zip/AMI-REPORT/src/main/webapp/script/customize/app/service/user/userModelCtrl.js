;
(function($, app) {
	"use strict";
	// 模板管理
	app.controller("userModelCtrl", function($scope, $http, $timeout, $compile,
			$element) {

		// 树
		$scope.demo = {};

		$.ajax({
			type : "POST",
			url : basePath + '/role/tree',
			dataType : "html",
			contentType : "application/json",
			data : JSON.stringify($scope.user),
			async : true,
			success : function(result) {
				if (result) {
					result = JSON.parse(result);
				}
				if (result.success) {
					$timeout(function() {
						$scope.$apply(function() {
							$scope.demo.tree = eval(result.obj.list);
							var checkedData = $.tree($scope.demo.tree).checked;
							var content = [];
							angular.forEach(checkedData, function(data, index) {
								content.push(data.text);
							});
							$scope.content = content.join(",");
						});
					});

				} else {
					$.messager.alert($.i18n.prop('ami.common.warning'), $.i18n
							.prop('ami.role.waring_message'), 'warning');
				}
			}
		});

		$scope.sure = function() {
			var checkedData = $.tree($scope.demo.tree).checked;
			var content = [];
			var roleId = [];
			angular.forEach(checkedData, function(data, index) {
				content.push(data.text);
				roleId.push(data.id);
			});
			$scope.content = content.join(",");
			$scope.user.roleIds = roleId.join(",");

		}

	});

})(jQuery, app)