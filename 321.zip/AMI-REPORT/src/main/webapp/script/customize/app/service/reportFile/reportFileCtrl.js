;
(function ($, app) {
    "use strict";
    // 模板管理
    app.controller("reportFileCtrl", function ($scope, $http, $timeout, $compile, $element, $permission) {
        $scope.tableHeader = [{
            field: 'reportName',
            title: $.i18n.prop('ami.file.name'),
            width: '15%',
            align: 'left',
            formatter: function (value) {
                return value && "<span title='" + value + "'>" + value + "</span>";
            }
        }, {
            field: 'reportType',
            title: $.i18n.prop('ami.file.type'),
            width: '6%',
            align: 'left',
            formatter: function (value) {
                switch (value) {
                    case "0":
                        return "<span title='" + $.i18n.prop('ami.common.daily') + "'>" + $.i18n.prop('ami.common.daily') + "</span>";
                    case "1":
                        return "<span title='" + $.i18n.prop('ami.common.monthly') + "'>" + $.i18n.prop('ami.common.monthly') + "</span>";
                    default:
                        return value;
                }
            }
        }, {
            field: 'tempName',
            title: $.i18n.prop('ami.file.tmpName'),
            width: '10%',
            align: 'left',
            formatter: function (value) {
                return value && "<span title='" + value + "'>" + value + "</span>";
            }
        }, {
            field: 'tmpKey',
            title: $.i18n.prop('ami.file.tmpKey'),
            width: '8%',
            align: 'left',
            formatter: function (value) {
                return value && "<span title='" + value + "'>" + value + "</span>";
            }
        }, {
            field: 'reportStatus',
            title: $.i18n.prop('ami.file.status'),
            width: '6%',
            align: 'left',
            formatter: function (value) {
                return value && "<span title='" + value + "'>" + value + "</span>";
            }
        }, {
            field: 'reportDesc',
            title: $.i18n.prop('ami.file.reportDesc'),
            width: '13%',
            align: 'left',
            formatter: function (value) {
                return value && "<span title='" + value + "'>" + value + "</span>";
            }
        }, {
            field: 'reportPath',
            title: $.i18n.prop('ami.file.reportPath'),
            width: '10%',
            align: 'left',
            formatter: function (value) {
                return value && "<span title='" + value + "'>" + value + "</span>";
            }
        }, {
            field: 'userName',
            title: $.i18n.prop('ami.file.user'),
            width: '10%',
            align: 'left',
            formatter: function (value) {
                return value && "<span title='" + value + "'>" + value + "</span>";
            }
        }, {
            field: 'createTime',
            title: $.i18n.prop('ami.file.createTime'),
            width: '10%',
            align: 'left'
        }, {
            field: 'operation',
            title: $.i18n.prop('ami.common.func'),
            width: '12%',
            align: 'left',
            formatter: function (value, row, index) {
                $scope['rowData_' + index] = row;
                var str = '';
                str += '<a href="javascript:void(0)" ng-if="showSee" ng-click="viewFn(rowData_' + index + ')">' + $.i18n.prop("ami.file.view") + '</a>';
                str += ' | ';
                str += '<a href="javascript:void(0)" ng-if="showDown" ng-click="downloadFn(rowData_' + index + ')">' + $.i18n.prop("ami.file.download") + '</a>';
                str += ' | ';
                str += '<a href="javascript:void(0)" ng-if="showEdit" ng-click="editFn(rowData_' + index + ')">' + $.i18n.prop("ami.common.edit") + '</a>';
                str += ' | ';
                str += '<a href="javascript:void(0)" ng-if="showDelete" ng-click="deleteFn(rowData_' + index + ')">' + $.i18n.prop("ami.common.delete") + '</a>';
                return str;
            }
        }];

        $scope.tableUrl = basePath + '/reportFile/datagrid';

        $scope.submit = function () {
            $.reload('reportFileTable', null, serializeObject($("#reportFileFrom")));
        };

        $scope.downloadFn = function (row) {
            window.location.href = basePath + "/reportFile/download?id=" + row.reportId;
        };

        $scope.editFn = function (row) {
            $scope.reportFile = angular.copy(row) || {};
            $.model($.i18n.prop("ami.file.editReport"), basePath + "/reportFile/editPage", $scope.reportFile, function (result) {
                return $compile(result)($scope)
            }, function (m) {
                if ($(".easyui-form").form('enableValidation').form('validate')) {
                    $http.post(basePath + "/reportFile/edit", $scope.reportFile || {}).success(function (result) {
                        if (result.success) {
                            $.model.close(m);
                            $.messager.alert($.i18n.prop("ami.common.prompt"), result.msg, 'success');
                            $("#reportFileTable").datagrid('reload');
                        } else {
                            $.messager.alert($.i18n.prop("ami.common.prompt"), result.msg, 'error');
                        }
                    })
                }

            });
        };

        $scope.deleteFn = function (row) {
            $scope.reportFile = row;
            parent.$.messager.confirm('info', $.i18n.prop("ami.common.isDel"), function (b) {
                if (b) {
                    $http.post(basePath + "/reportFile/delete", $scope.reportFile || {}).success(function (result) {
                        if (result.success) {
                            $.messager.alert($.i18n.prop("ami.common.prompt"), result.msg, 'success');
                            $("#reportFileTable").datagrid('reload');
                        } else {
                            $.messager.alert($.i18n.prop("ami.common.prompt"), result.msg, 'error');
                        }
                    })
                }
            })
        };

        $scope.viewFn = function (row) {
            $scope.reportId = row.reportId;


            $http.get(basePath + "/reportFile/viewPage?id=" + row.reportId).success(function (result) {
                var main = $("#main");
                var title = $.i18n.prop("ami.file.viewReport");
                if(!main.tabs("exists", title)){
                    main.tabs("add", {
                        title: title,
                        content: $compile(result)($scope.$new()),
                        closable: true
                    });
                } else {
                    main.tabs("update",{
                        tab: main.tabs("getTab", title),
                        options: {
                            content: $compile(result)($scope.$new()),
                        }
                    }
                );
                }

                main.tabs("select", title);
            })
        };

        $scope.noteName = function (e) {
            $scope.lastReportName = e.target.value;
        };

        $scope.checkName = function () {
            var suffix = $scope.reportFile.reportName.slice($scope.reportFile.reportName.lastIndexOf("."));
            var lastSuffix = $scope.lastReportName.slice($scope.lastReportName.lastIndexOf("."));
            if (suffix !== lastSuffix) {
                $.messager.alert($.i18n.prop("ami.common.prompt"), $.i18n.prop("ami.file.sameSuffix"), 'error');
                $scope.reportFile.reportName = $scope.lastReportName;
            }
        };

        // 表格加载数据完成后，执行
        $scope.$on("loadSuccess", function (e, data) {
            $compile($(data.target).find("td[field='operation'] > div"))($scope);// 手动编译表格最后一列，同步angularjs事件操作

            $permission.contains("/searchReportFile", function (data) {
                $scope.showSearch = data;
            });

            $permission.contains("/seeReportFile", function (data) {
                $scope.showSee = data;
            });
            $permission.contains("/downReportFile", function (data) {
                $scope.showDown = data;
            });
            $permission.contains("/editReportFile", function (data) {
                $scope.showEdit = data;
            });
            $permission.contains("/deleteReportFile", function (data) {
                $scope.showDelete = data;
            });

        });
    });
})(jQuery, app)
