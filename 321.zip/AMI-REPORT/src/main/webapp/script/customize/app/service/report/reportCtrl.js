;
(function($, app) {
  "use strict";
  // 模板管理
  app.controller("reportCtrl", function($scope, $http, $timeout, $compile, $element, $permission) {
    $scope.tableHeader = [
        {
          field: 'tmpid',
          title: 'id',
          width: '20%',
          align: 'left',
          hidden: 'true'
        },
        {
          field: 'tmpname',
          title: $.i18n.prop('ami.template.name'),
          width: '20%',
          align: 'left'
        },
        {
          field: 'tmpfile',
          title: 'tmpfile',
          width: '20%',
          align: 'left',
          hidden: 'true'
        },
        {
          field: 'tmpkey',
          title: $.i18n.prop('ami.template.key'),
          width: '20%',
          align: 'left'
        },
        {
          field: 'reporttype',
          title: $.i18n.prop('ami.template.type'),
          width: '20%',
          align: 'left',
          formatter: function(value) {
            switch (value) {
            case "0":
              return $.i18n.prop('ami.template.day');
            case "1":
              return $.i18n.prop('ami.template.month');
            }
          }
        },
        {
          field: 'tmpdesc',
          title: $.i18n.prop('ami.template.desc'),
          width: '20%',
          align: 'left'
        },
        {
          field: 'operation',
          title: $.i18n.prop('ami.common.func'),
          width: '10%',
          align: 'left',
          formatter: function(value, row, index) {
            $scope['rowData_' + index] = row;
            return '<a href="javascript:void(0)" class="organization-easyui-linkbutton-edit" ng-if="showBuild" ng-click="generateReport(rowData_' + index + ')" data-options="plain:true">'
                    + $.i18n.prop('ami.report.report_build') + '</a> ';
          }
        }];

    // 修改
    $scope.generateReport = function(row) {
      $scope.template = row;
      $.model($.i18n.prop('ami.report.report_build'), basePath + "/report/gotoGenerateReport", row, function(result) {
        return $compile(result)($scope)
      }, function(m) {
        if ($(".easyui-form").form('enableValidation').form('validate')) {
          $scope.template.currentTime = $("#currentTime").val();
          $scope.template.startTime = $("#startTime").val();
          $scope.template.endTime = $("#endTime").val();
          var dataList = $("#objectTreeTable").datagrid("getData").rows;
          var ids = "";
          for ( var i in dataList) {
            if (dataList[i].treeCode) {
              ids += dataList[i].name;
              ids += ",";
              ids += dataList[i].treeCode;
              ids += ",";
              ids += dataList[i].treeId;
              ids += ";"
            }
          }
          $scope.template.treeMap = ids;
          $http.post(basePath + "/report/generateReport", $scope.template || {}).success(function(result) {
            if (result.success) {
            	$.model.close(m);
            	$.messager.alert($.i18n.prop('ami.common.info'), $.i18n.prop('ami.report.message'), 'info');
            } else {
            	$.messager.alert($.i18n.prop('ami.common.info'), $.i18n.prop('ami.report.false_message'), 'info');
            }
          })
        }

      });
    }

    /*
     * $scope.geneteReport = function(row){ $scope.template = row
     * $http.post(basePath + "/report/generateReport", $scope.template || {})
     * .success( function(result) { if(result.success){ $.messager.alert('提示',
     * '生成成功', 'info'); }else{ $.messager.alert('提示', '生成失败', 'info'); } } ) }
     */

    $scope.tableUrl = basePath + '/report/query';
    $scope.$on("loadSuccess", function(e, data) {
      $compile($(data.target).find("td[field='operation'] > div"))($scope);// 手动编译表格最后一列，同步angularjs事件操作

      $permission.contains("/buildReport", function(data) {
        $scope.showBuild = data;
      });
    });

  });

})(jQuery, app)