;(function ($, app) {
    "use strict";
    // 模板管理
    app.controller("reportTaskCtrl",function ($scope, $http, $timeout, $compile, $element, $permission) {
        $scope.tableHeader = [{
            field: 'id',
            title: 'ID',
            width: '10%',
            align: 'left',
            formatter: function (value) {
                return value && "<span title='" + value + "'>" + value + "</span>";
            }
        }, {
            field: 'name',
            title: $.i18n.prop("ami.task.name"),
            width: '10%',
            align: 'left',
            formatter: function (value) {
                return value && "<span title='" + value + "'>" + value + "</span>";
            }
        }, {
            field: 'startTime',
            title: $.i18n.prop("ami.task.startTime"),
            width: '10%',
            align: 'left',
            formatter: function (value) {
                return value && "<span title='" + value + "'>" + value + "</span>";
            }
        }, {
            field: 'endTime',
            title: $.i18n.prop("ami.task.endTime"),
            width: '10%',
            align: 'left',
            formatter: function (value) {
                return value && "<span title='" + value + "'>" + value + "</span>";
            }
        }, {
            field: 'offset',
            title: $.i18n.prop("ami.task.offset"),
            width: '10%',
            align: 'left',
            formatter: function (value) {
                return value && "<span title='" + value + "'>" + value + "</span>";
            }
        }, {
            field: 'type',
            title: $.i18n.prop("ami.task.type"),
            width: '10%',
            align: 'left',
            formatter: function (value) {
                switch (value) {
                    case "0":
                        return "<span title='" + $.i18n.prop('ami.common.daily') + "'>" + $.i18n.prop('ami.common.daily') + "</span>";
                    case "1":
                        return "<span title='" + $.i18n.prop('ami.common.monthly') + "'>" + $.i18n.prop('ami.common.monthly') + "</span>";
                    default:
                        return value;
                }
            }
        }, {
            field: 'status',
            title: $.i18n.prop("ami.task.status"),
            width: '10%',
            align: 'left',
            formatter: function (value) {
                switch (value) {
                    case "01":
                        return "<span title='" + $.i18n.prop('ami.task.suspend') + "'>" + $.i18n.prop('ami.task.suspend') + "</span>";
                    case "02":
                        return "<span title='" + $.i18n.prop('ami.task.running') + "'>" + $.i18n.prop('ami.task.running') + "</span>";
                    default:
                        return value;
                }
            }
        }, {
            field: 'remark',
            title: $.i18n.prop("ami.task.remark"),
            width: '12%',
            align: 'left',
            formatter: function (value) {
                return value && "<span title='" + value + "'>" + value + "</span>";
            }
        }, {
            field: 'operation',
            title: $.i18n.prop('ami.common.func'),
            width: '18%',
            align: 'left',
            formatter: function (value, row, index) {
                $scope['rowData_' + index] = row;
                var str = '';
                str += '<a href="javascript:void(0)" ng-if="showEdit" ng-click="detailFn(\'' + $.i18n.prop("ami.task.editTask") + '\',rowData_' + index + ')">' + $.i18n.prop('ami.common.edit') + '</a>';
                str += ' | ';
                str += '<a href="javascript:void(0)" ng-if="showDelete" ng-click="deleteFn(rowData_' + index + ')">' + $.i18n.prop('ami.common.delete') + '</a>';
                str += ' | ';
                str += '<a href="javascript:void(0)" ng-if="showTempConf" ng-click="tempConfig(rowData_' + index + ')">' + $.i18n.prop('ami.task.tempConfig') + '</a>';
                str += ' | ';
                str += '<a href="javascript:void(0)" ng-if="showObjConf" ng-click="objConfig(rowData_' + index + ')">' + $.i18n.prop('ami.task.objConfig') + '</a>';
                str += ' | ';
                str += '<a href="javascript:void(0)" ng-if="showDo" ng-click="doTask(rowData_' + index + ')">' + $.i18n.prop('ami.task.doTask') + '</a>';
                return str;
            }
        }];

        $scope.tableUrl = basePath + '/reportTask/datagrid';
        $scope.reportTask={};
        $scope.detailFn = function (title, row) {
            $scope.reportTask = angular.copy(row) || {"status":"01","type":"0"};
            $.model(title,basePath + "/reportTask/detailPage",$scope.reportTask,
                function (result) {
                    return $compile(result)($scope);
                },
                function (m) {
                    if ($(".easyui-form").form('enableValidation').form('validate')) {
                        $http.post(basePath + "/reportTask/update",$scope.reportTask || {}).success(function (result) {
                            if (result.success) {
                                $.model.close(m);
                                $.messager.alert($.i18n.prop("ami.common.prompt"),result.msg,'success');
                                $("#taskTable").datagrid('reload');
                            } else {
                                $.messager.alert($.i18n.prop("ami.common.prompt"),result.msg,'error');
                            }
                        })
                    }
                });
        };
        

        $scope.objConfig = function (row) {
            $scope.reportTask = angular.copy(row) || {};
            $scope.objectTreeParam = {"tmpIds":$scope.reportTask.tmpIds};
            selfModel($.i18n.prop("ami.task.configTask"),basePath + "/reportTask/objConfPage",$scope.reportTask,
                function () {
                    $("#objectTreeTable").datagrid({
                        idField : "id"
                    });
                    document.querySelector("#treeMaps").value = $scope.reportTask.objTreeMaps;
                },
                function (m) {
                    var rows = $("#objectTreeTable").datagrid("getData").rows;

                    var o = "";
                    rows.forEach(function (item) {
                        if(item.treeCode){
                            o += item.id;
                            o += ",";
                            o += item.name;
                            o += ",";
                            o += item.treeCode;
                            o += ",";
                            o += item.treeName;
                            o += ",";
                            o += item.treeId;
                            o += ";"
                        }
                    });
                    $scope.reportTask.objTreeMaps = o;

                    $http.post(basePath + "/reportTask/objConfig",$scope.reportTask || {}).success(function (result) {
                        if (result.success) {
                            $.model.close(m);
                            $.messager.alert($.i18n.prop("ami.common.prompt"),result.msg,'success');
                            $("#taskTable").datagrid('reload');
                        } else {
                            $.messager.alert($.i18n.prop("ami.common.prompt"),result.msg,'error');
                        }
                    })
                });
        };

        $scope.deleteFn = function (row) {
            $scope.reportTask = row;
            parent.$.messager.confirm('info',$.i18n.prop("ami.common.isDel"),function (b) {
                if (b) {
                    $http.post(basePath + "/reportTask/delete", $scope.reportTask || {}).success(function (result) {
                        if (result.success) {
                            $.messager.alert($.i18n.prop("ami.common.prompt"),result.msg,'success');
                            $("#taskTable").datagrid('reload');
                        } else {
                            $.messager.alert($.i18n.prop("ami.common.prompt"),result.msg,'error');
                        }
                    })
                }
            })
        };

        $scope.doTask = function (row) {
            $http.post(basePath + "/reportTask/doTask",{"id":row.id || ""}).success(function (result) {
                if (result.success) {
                    $.messager.alert($.i18n.prop("ami.common.prompt"),result.msg,'success');
                } else {
                    $.messager.alert($.i18n.prop("ami.common.prompt"),result.msg,'error');
                }
            })
        };

        $scope.objectTreeHeader =[ {
            field : 'name',
            title : $.i18n.prop('ami.object.name'),
            width : '40%',
            align : 'left'
        },
        {
            field : 'treeName',
            title : $.i18n.prop('ami.report.objectkey'),
            width : '58%',
            align : 'left',
            formatter : function(value, row, index) {
                var objectId = row.id;
                return '<input id="' + objectId + '_treeName_' + index + '" value="' + value + '"  data-options="editable:false" class="treeNameClass" style="width:80%"/>';
            }
        }];

        $scope.objectTreeUrl = basePath + '/reportTask/queryObject';

        // 表格加载数据完成后，执行
        $scope.$on("loadSuccess", function (e, data) {
            $compile($(data.target).find("td[field='operation'] > div"))($scope);// 手动编译表格最后一列，同步angularjs事件操作

            $(".treeNameClass").searchbox({
                width: 203,
                height: 24,
                searcher: function() {
                    var treeCodeId = "";
                    var treeNameId = $(this).attr("id");
                    var treeCode = "";
                    var objectId = "";
                    if (treeNameId) {
                        var index = treeNameId.split("_");
                        objectId = index[0];
                        treeCodeId = ("treeCode" + index[2]);
                        treeCode = $("#" + treeCodeId).val();
                    }
                    choseTree(objectId,treeNameId,treeCodeId,treeCode);
                },
                prompt: $.i18n.prop('ami.report.key_message')
            });

            // 对象树回选
            feedback("#treeMaps",function (value) {
                var v = value.split(";");
                var treeTable = $("#objectTreeTable");

                treeTable.datagrid('updateRow',{
                    index: treeTable.datagrid("getRowIndex",v[0]),
                    row: {
                        treeId: v[3],
                        treeCode: v[2],
                        treeName: v[1]
                    }
                });
            });

            $permission.contains("/addTask", function (data) {
                $scope.showAdd = data;
            });
            $permission.contains("/editTask", function (data) {
                $scope.showEdit = data;
            });
            $permission.contains("/deleteTask", function (data) {
                $scope.showDelete = data;
            });
            $permission.contains("/tempConf", function (data) {
                $scope.showTempConf = data;
            });
            $permission.contains("/objConf", function (data) {
                $scope.showObjConf = data;
            });
            $permission.contains("/doTask", function (data) {
                $scope.showDo = data;
            });
        });

        function changeIdsField (id,isUnSelect) {
            var target = document.querySelector("#tempIds");
            var ids = target.value ? target.value.split(",") : [];
            ids.indexOf(id) === -1 && ids.push(id);
            ids.splice(ids.indexOf(id),isUnSelect);
            target.value = ids.join(",");
        }

        function choseTree(objectId) {
            $scope.objectTree = {};
            $scope.objectTree.id = objectId;

            $.model($.i18n.prop('ami.report.object'), basePath + "/objectTree/choosePage", $scope.objectTree,
                function(result) {
                    return $compile(result)($scope)
                },
                function(m) {
                },600, 400
            );
        }

        function feedback(id,fn) {
            var dom = document.querySelector(id);
            var value = dom && dom.value;
            var list = value ? value.split(",") : [];
            list.forEach(fn);
        }

        function selfModel(title,url,param,onOpen,callback) {
            $.ajax({
                type:"POST",
                url:url,
                dataType:"html",
                contentType:"application/json",
                data:angular.toJson(param),
                success:function(result){
                    var d = $('<div class="dialog-s"/>').dialog({
                        title: title,
                        width: 750,
                        height: 600,
                        content: $compile(result)($scope),
                        modal: true,
                        onOpen : onOpen,
                        onClose: function () { $(d).dialog('destroy'); }
                    }).hide().fadeIn(50);
                    d.find(".ami-close").on("click",function(){
                        $(d).dialog('destroy');
                    });
                    d.find(".ami-save").on("click",function(){
                        callback(d);
                    });
                }
            });
        }

        // 点击添加模板
        $scope.tempConfig = function(row) {
            $scope.reportTask = angular.copy(row) || {};
            $scope.taskTempList = [];
            $scope.selTaskTempList = [];

            $.ajax({
                type: "POST",
                url: basePath + '/templateManagement/queryList?timestamp=' + (new Date()).valueOf(),
                dataType: "html",
                contentType: "application/json",
                data: JSON.stringify(row),
                success: function(result) {
                    if (result) {
                        result = JSON.parse(result);
                    }
                    if (result.success) {
                        var taskTempList = result.obj;
                        var selTaskTempList = [];
                        if(taskTempList && taskTempList.length){
                            if(row.tmpIds){
                                var ids = row.tmpIds.split(",");
                                ids.forEach(function(id){
                                    for (var i = 0; i < taskTempList.length; i++) {
                                        var item = taskTempList[i];
                                        if(id === item.tmpid){
                                            selTaskTempList.push(item);
                                            break;
                                        }
                                    }
                                })
                            }
                        }
                        $scope.$apply(function() {
                            $scope.taskTempList = taskTempList;
                            $scope.selTaskTempList = selTaskTempList;
                        });

                        $.model($.i18n.prop('ami.task.configTask'), basePath + "/reportTask/tempConfPage", $scope.reportTask || {}, function(result) {
                            return $compile(result)($scope)
                        }, function(m) {
                            delete $scope.reportTask['leftIndex'];
                            delete $scope.reportTask['leftCacheRow'];
                            delete $scope.reportTask['rightIndex'];
                            delete $scope.reportTask['rightCacheRow'];

                            var ids = "";
                            var len = $scope.selTaskTempList.length;
                            for (var i = 0; i < len; i++) {
                                ids += $scope.selTaskTempList[i].tmpid + (i === len - 1 ? "" : ",");
                            }
                            $scope.reportTask.tmpIds = ids;
                            $http.post(basePath + "/reportTask/tempConfig",$scope.reportTask || {}).success(function (result) {
                                if (result.success) {
                                    $.model.close(m);
                                    $.messager.alert($.i18n.prop("ami.common.prompt"),result.msg,'success');
                                    $("#taskTable").datagrid('reload');
                                } else {
                                    $.messager.alert($.i18n.prop("ami.common.prompt"),result.msg,'error');
                                }
                            })
                        });
                    } else {
                        $.messager.alert($.i18n.prop('ami.common.warning'), $.i18n.prop('ami.task.tempTableErr'), 'warning');
                    }
                }
            })
        };

        $scope.addTempTable = function($event, row, index) {
            delete $scope.reportTask['leftIndex'];
            delete $scope.reportTask['leftCacheRow'];
            for (var i = 0; i < $scope.selTaskTempList.length; i++) {
                var item = $scope.selTaskTempList[i];
                if (item.tmpname === row.tmpname) { return; }
            }
            $scope.selTaskTempList.push(row);
        };

        $scope.delTempTable = function($event, row, index) {
            $scope.selTaskTempList.remove(row);
            delete $scope.reportTask['rightIndex'];
            delete $scope.reportTask['rightCacheRow'];
        };

        $scope.selectedTempRow=function(row,direction){
            $scope.reportTask[direction+'CacheRow']=row;
        };

        $scope.toTargetTable=function(direction){
            var $$row = $scope.reportTask[direction+'CacheRow'];
            if(!$$row)
            {
                return;
            }
            if(direction==='left') { $scope.addTempTable(null,$$row,null); }	else { $scope.delTempTable(null,$$row,null); }
        };
        
        $scope.generateCron=function(){
          $scope.cron={};
          $.model($.i18n.prop('ami.report.Cron'), basePath + "/reportTask/generateCron", $scope.cron, function(result) {
                    return $compile(result)($scope)
                  }, function(m) {
                    debugger
                    var cronStr = "* * * * * ?";
                    if ($("#cronForm").form('enableValidation').form('validate')) {
                      if($scope.cron.periodTime){
                        if("month" == $scope.cron.periodType){
                          cronStr= "0 0 0 0 1/"+$scope.cron.periodTime+" ? ";
                        }else if("week" == $scope.cron.periodType){
                          cronStr= "0 0 0 0 0 1#"+$scope.cron.periodTime;
                        }else if("day" == $scope.cron.periodType){
                          cronStr= "0 0 0 1/"+$scope.cron.periodTime+" * ? ";
                        }else if("hour" == $scope.cron.periodType){
                          cronStr= "0 0 0/"+$scope.cron.periodTime+" * * ? ";
                        }else if("minute" == $scope.cron.periodType){
                          cronStr= "0 0/"+$scope.cron.periodTime+" * * * ? ";
                        }
                      }else{
                        var month="*";
                        var week="?";
                        var day="*";
                        var hour="*";
                        var minute="*";
                        if($scope.cron.month){
                          month=$scope.cron.month;
                        }
                        if($scope.cron.week){
                          week=$scope.cron.week;
                        }
                        if($scope.cron.day){
                          day=$scope.cron.day;
                        }
                        if($scope.cron.hour){
                          hour=$scope.cron.hour;
                        }
                        if($scope.cron.minute){
                          minute=$scope.cron.minute;
                        }
                        
                        cronStr="* "+minute+" "+hour+" "+day+" "+month+" "+week;
                      }
                      
                      $scope.reportTask.handle=cronStr;
                      $("#reportTaskhandle").val(cronStr);
                      $("#reportTaskhandle").attr("value",cronStr);
                      $.model.close(m);
                    }
                  }, 600, 300);
        };
        
    });
})(jQuery, app)
