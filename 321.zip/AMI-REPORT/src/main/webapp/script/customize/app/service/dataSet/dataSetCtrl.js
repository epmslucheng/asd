;
(function($, app) {
  "use strict";
  // 模板管理
  app.controller("dataSetCtrl", function($scope, $http, $timeout, $compile, $element, $permission) {
    $scope.tableHeader = [
        {
          field: 'queryId',
          title: 'queryId',
          align: 'left',
          hidden: 'true'
        },
        {
          field: 'queryName',
          title: $.i18n.prop('ami.dataset.name'),
          width: '20%',
          align: 'left'
        },
        {
          field: 'creatorName',
          title: $.i18n.prop('ami.dataset.creator'),
          width: '20%',
          align: 'left'
        },
        {
          field: 'createTime',
          title: $.i18n.prop('ami.dataset.createtime'),
          width: '20%',
          align: 'left'
        },
        {
          field: 'key',
          title: $.i18n.prop('ami.dataset.key'),
          width: '15%',
          align: 'left'
        },
        {
          field: 'queryType',
          title: $.i18n.prop('ami.dataset.querytype'),
          width: '10%',
          align: 'left',
          formatter: function(value, row, index) {
            if ("0" == value) { return $.i18n.prop('ami.dataSet.createSet'); }
            if ("1" == value) { return $.i18n.prop('ami.dataSet.multables'); }
          }
        },
        {
          field: 'operation',
          title: $.i18n.prop('ami.common.func'),
          width: '14%',
          align: 'left',
          formatter: function(value, row, index) {
            $scope['rowData_' + index] = row;
            return '<a href="javascript:void(0)" class="organization-easyui-linkbutton-edit" ng-if="showDataSetEdit" ng-click="gotoEditDataSet(rowData_' + index
                    + ')" data-options="plain:true,iconCls:\'icon-edit\'">' + $.i18n.prop('ami.common.edit')
                    + '</a> | <a href="javascript:void(0)" ng-id="showDataSetDel" class="organization-easyui-linkbutton-del" ng-click="delDataSet(rowData_' + index
                    + ')" data-options="plain:true,iconCls:\'icon-del\'">' + $.i18n.prop('ami.common.delete') + '</a>';
          }
        }];

    $scope.sqlOperateSelect = function(row) {
      $scope.dataSet = {};
      $.model($.i18n.prop('ami.dataSet.selMethod'), basePath + "/customDataSet/sqlOperateSelect", $scope.dataSet, function(result) {
        return $compile(result)($scope)
      }, function(m) {
      }, 600, 300);

    }
    // 新增
    $scope.gotoAddDataSet = function(dataSetType) {
      $(".dialog-s").dialog('destroy');
      $scope.sqlTestHeader = [];
      $scope.sqlTestUrl = "";
      $scope.dataSet = {};
      $scope.dataSet.tableModels = [];
      $scope.dataSet.colTree = [];
      $scope.dataSet.queryType = dataSetType;
      $.ajax({
        type: "POST",
        url: basePath + "/dataSource/getAllDataList",
        dataType: "html",
        contentType: "application/json",
        data: {},
        success: function(result) {
          if (result) {
            result = JSON.parse(result);
          }
          if (result.success) {
            $scope.$apply(function() {
              $scope.dataSet.dsList = eval(result.obj.dsList);
            });

          }
        }
      });
      $.ajax({
        type: "POST",
        url: basePath + "/objectTree/queryAll",
        dataType: "html",
        contentType: "application/json",
        data: {},
        success: function(result) {
          if (result) {
            result = JSON.parse(result);
          }
          if (result.success) {
            $scope.$apply(function() {
              $scope.dataSet.objectTreeList = eval(result.obj.objectTreeList);
            });

          }
        }
      });

      var addViewUrl = basePath + "/customDataSet/gotoDataSetAddView";
      if ('1' == dataSetType) {
        addViewUrl = basePath + "/customDataSet/jsPlumb";
      }
      if ($("#main").tabs("exists", $.i18n.prop('ami.dataset.add_dataset'))) {
        $("#main").tabs("close", $.i18n.prop('ami.dataset.add_dataset'));
      }
      if ($("#main").tabs("exists", $.i18n.prop('ami.dataset.edit_dataset'))) {
        $("#main").tabs("close", $.i18n.prop('ami.dataset.edit_dataset'));
      }

      $http.post(addViewUrl, $scope.dataSet).success(function(result) {
        $("#main").tabs('add', {
          title: $.i18n.prop('ami.dataset.add_dataset'),
          content: $compile(result)($scope.$new()),
          closable: true
        });
      })
    }
    $scope.addDataSet = function(row) {
      $(".easyui-form").form('enableValidation');
      if ($(".easyui-form").form('validate')) {
        addDS();
      }
    }

    function addDS() {
      $http.post(basePath + "/customDataSet/addDataSet", $scope.dataSet || {}).success(function(result) {
        if (result.success) {
          $("#main").tabs("close", $.i18n.prop('ami.dataset.add_dataset'));
          $.messager.alert($.i18n.prop('ami.template.notice'), $.i18n.prop('ami.dataset.add_success'), 'info');
          $("#dataSetTable").datagrid('reload');
        } else {
          if (result.msg) {
            $.messager.alert($.i18n.prop('ami.common.warning'), result.msg, 'warning');
          }
        }
      })
    }
    function editDS() {
      $http.post(basePath + "/customDataSet/editDataSet", $scope.dataSet || {}).success(function(result) {
        if (result.success) {
          $("#main").tabs("close", $.i18n.prop('ami.dataset.edit_dataset'));
          $.messager.alert($.i18n.prop('ami.template.notice'), $.i18n.prop('ami.dataset.edit_success'), 'info');
          $("#dataSetTable").datagrid('reload');
        } else {
          if (result.msg) {
            $.messager.alert($.i18n.prop('ami.common.warning'), result.msg, 'warning');
          }
        }
      })
    }
    $scope.gotoEditDataSet = function(row) {

      $scope.sqlTestHeader = [];
      $scope.sqlTestUrl = "";
      $scope.dataSet = angular.copy(row);
      $.ajax({
        type: "POST",
        url: basePath + "/dataSource/getAllDataList",
        dataType: "html",
        contentType: "application/json",
        data: {},
        success: function(result) {
          if (result) {
            result = JSON.parse(result);
          }
          if (result.success) {
            $scope.$apply(function() {
              $scope.dataSet.dsList = eval(result.obj.dsList);
            });

          }
        }
      });
      $.ajax({
        type: "POST",
        url: basePath + "/objectTree/queryAll",
        dataType: "html",
        contentType: "application/json",
        data: {},
        success: function(result) {
          if (result) {
            result = JSON.parse(result);
          }
          if (result.success) {
            $scope.$apply(function() {
              $scope.dataSet.objectTreeList = eval(result.obj.objectTreeList);
            });

          }
        }
      });

      var editViewUrl = basePath + "/customDataSet/gotoDataSetEditView";
      if ('1' == $scope.dataSet.queryType) {
        editViewUrl = basePath + "/customDataSet/jsPlumb";
      }
      if ($("#main").tabs("exists", $.i18n.prop('ami.dataset.edit_dataset'))) {
        $("#main").tabs("close", $.i18n.prop('ami.dataset.edit_dataset'));
      }
      if ($("#main").tabs("exists", $.i18n.prop('ami.dataset.add_dataset'))) {
        $("#main").tabs("close", $.i18n.prop('ami.dataset.add_dataset'));
      }

      $http.post(editViewUrl, $scope.dataSet).success(function(result) {
        $("#main").tabs('add', {
          title: $.i18n.prop('ami.dataset.edit_dataset'),
          content: $compile(result)($scope.$new()),
          closable: true
        });
      })

    }

    // 修改
    $scope.editDataSet = function(row) {
      var newflag = true;

      if ($scope.dataSet.tableModels && $scope.dataSet.tableModels.length > 1) {
        for (var i = 0; i < $scope.dataSet.tableModels.length; i++) {
          if ($scope.dataSet.tableModels[i].connectLine) {
            for (var j = 0; j < $scope.dataSet.tableModels[i].connectLine.fieldList.length; j++) {
              if ($scope.dataSet.tableModels[i].connectLine.fieldList[j].sourceModel != null && $scope.dataSet.tableModels[i].connectLine.fieldList[j].sourceModel != ""
                      && $scope.dataSet.tableModels[i].connectLine.fieldList[j].targetModel != null && $scope.dataSet.tableModels[i].connectLine.fieldList[j].targetModel != "") {
                newflag = false;
              }
            }
          }
        }
      }
      if ($scope.dataSet.queryType = "1" && newflag) {
        $.messager.alert($.i18n.prop('ami.common.warning'), $.i18n.prop('ami.dataset.display.field01'), 'warning');
        return;
      }
      $(".easyui-form").form('enableValidation');
      if ($(".easyui-form").form('validate')) {
        if ($scope.dataSet.colTree) {
          var colLength = $scope.dataSet.colTree.length;
          for (var i = colLength - 1; i >= 0; i--) {
            var tree = $scope.dataSet.colTree[i];
            if (!tree.parentId) {
              var itemNew = {};
              itemNew.id = tree.id;
              itemNew.parentId = "";
              itemNew.name = tree.name;
              $scope.dataSet.colTree.remove(tree);
              $scope.dataSet.colTree.push(itemNew);
            }
          }
          if (!$scope.dataSet.colTree || $scope.dataSet.colTree.length == 0) {
            $.messager.alert($.i18n.prop('ami.common.warning'), $.i18n.prop('ami.dataset.display.field'), 'warning');
            return;
          }
          if (isrepeat($scope.dataSet.colTree)) {
            $.messager.alert($.i18n.prop('ami.common.warning'), $.i18n.prop('ami.dataset.field.repeat'), 'warning');
            return;
          }
        }
        if ($scope.dataSet && $scope.dataSet.queryId) {
          editDS();
        } else {
          addDS();
        }
      }
    }

    function isrepeat(list) {
      if (list && list.length > 1) {
        for (var i = 0; i < list.length; i++) {
          for (var j = i + 1; j < list.length; j++) {
            if (list[i].tableFiledAlias == list[j].tableFiledAlias) { return true; }
          }
        }

      }
      return false;
    }
    // 删除
    $scope.delDataSet = function(row) {

      $scope.dataSet = row;
      parent.$.messager.confirm('info', $.i18n.prop('ami.template.notice_message'), function(b) {
        if (b) {
          $http.post(basePath + "/customDataSet/delete", $scope.dataSet).success(function(result) {
            if (result.success) {
              $.messager.alert($.i18n.prop('ami.template.notice'), $.i18n.prop('ami.template.delete_success'), 'info');
              $("#dataSetTable").datagrid('reload');
            }
          })
        }
      })

    }

    $scope.tableUrl = basePath + '/customDataSet/query';
    $scope.$on("loadSuccess", function(e, data) {
      $compile($(data.target).find("td[field='operation'] > div"))($scope);// 手动编译表格最后一列，同步angularjs事件操作

      $permission.contains("/addSQL", function(data) {
        $scope.showDataSetAdd = data;
      });

      $permission.contains("/editSQL", function(data) {
        $scope.showDataSetEdit = data;
      });

      $permission.contains("/deleteSQL", function(data) {
        $scope.showDataSetDel = data;
      });

    });
  });

})(jQuery, app)