;(function($,app){
    "use strict";
    
    app.service("$permission",function($http,$q){
    	var deferred = $q.defer();//声明承诺
    	var promise = function(){
    		$http({
        	    method: 'post',
        	    url: basePath + '/permission/init'
        	}).success(function(data){
        		deferred.resolve(data);//请求成功
        	}).error(function(data) {  
                deferred.reject(data); //请求失败
            });
    		 return deferred.promise;
    	}()
    	
    	this.contains=function(key,callback){
    		promise.then(function(data) {  // 成功回调
    	       callback(!!data[key]);
    	    });
    	}
    	
    	// 在ctrl.js上注入$permission
    	// 通过调用
    	// $permission.contains(key,function(){});
    });
})(jQuery,app);
(function($, app) {
  "use strict";
  // 模板管理
  app.controller("dataSetCtrl", function($scope, $http, $timeout, $compile, $element, $permission) {
    $scope.tableHeader = [
        {
          field: 'queryId',
          title: 'queryId',
          align: 'left',
          hidden: 'true'
        },
        {
          field: 'queryName',
          title: $.i18n.prop('ami.dataset.name'),
          width: '20%',
          align: 'left'
        },
        {
          field: 'creatorName',
          title: $.i18n.prop('ami.dataset.creator'),
          width: '20%',
          align: 'left'
        },
        {
          field: 'createTime',
          title: $.i18n.prop('ami.dataset.createtime'),
          width: '20%',
          align: 'left'
        },
        {
          field: 'key',
          title: $.i18n.prop('ami.dataset.key'),
          width: '15%',
          align: 'left'
        },
        {
          field: 'queryType',
          title: $.i18n.prop('ami.dataset.querytype'),
          width: '10%',
          align: 'left',
          formatter: function(value, row, index) {
            if ("0" == value) { return $.i18n.prop('ami.dataSet.createSet'); }
            if ("1" == value) { return $.i18n.prop('ami.dataSet.multables'); }
          }
        },
        {
          field: 'operation',
          title: $.i18n.prop('ami.common.func'),
          width: '14%',
          align: 'left',
          formatter: function(value, row, index) {
            $scope['rowData_' + index] = row;
            return '<a href="javascript:void(0)" class="organization-easyui-linkbutton-edit" ng-if="showDataSetEdit" ng-click="gotoEditDataSet(rowData_' + index
                    + ')" data-options="plain:true,iconCls:\'icon-edit\'">' + $.i18n.prop('ami.common.edit')
                    + '</a> | <a href="javascript:void(0)" ng-id="showDataSetDel" class="organization-easyui-linkbutton-del" ng-click="delDataSet(rowData_' + index
                    + ')" data-options="plain:true,iconCls:\'icon-del\'">' + $.i18n.prop('ami.common.delete') + '</a>';
          }
        }];

    $scope.sqlOperateSelect = function(row) {
      $scope.dataSet = {};
      $.model($.i18n.prop('ami.dataSet.selMethod'), basePath + "/customDataSet/sqlOperateSelect", $scope.dataSet, function(result) {
        return $compile(result)($scope)
      }, function(m) {
      }, 600, 300);

    }
    // 新增
    $scope.gotoAddDataSet = function(dataSetType) {
      $(".dialog-s").dialog('destroy');
      $scope.sqlTestHeader = [];
      $scope.sqlTestUrl = "";
      $scope.dataSet = {};
      $scope.dataSet.tableModels = [];
      $scope.dataSet.colTree = [];
      $scope.dataSet.queryType = dataSetType;
      $.ajax({
        type: "POST",
        url: basePath + "/dataSource/getAllDataList",
        dataType: "html",
        contentType: "application/json",
        data: {},
        success: function(result) {
          if (result) {
            result = JSON.parse(result);
          }
          if (result.success) {
            $scope.$apply(function() {
              $scope.dataSet.dsList = eval(result.obj.dsList);
            });

          }
        }
      });
      $.ajax({
        type: "POST",
        url: basePath + "/objectTree/queryAll",
        dataType: "html",
        contentType: "application/json",
        data: {},
        success: function(result) {
          if (result) {
            result = JSON.parse(result);
          }
          if (result.success) {
            $scope.$apply(function() {
              $scope.dataSet.objectTreeList = eval(result.obj.objectTreeList);
            });

          }
        }
      });

      var addViewUrl = basePath + "/customDataSet/gotoDataSetAddView";
      if ('1' == dataSetType) {
        addViewUrl = basePath + "/customDataSet/jsPlumb";
      }
      if ($("#main").tabs("exists", $.i18n.prop('ami.dataset.add_dataset'))) {
        $("#main").tabs("close", $.i18n.prop('ami.dataset.add_dataset'));
      }
      if ($("#main").tabs("exists", $.i18n.prop('ami.dataset.edit_dataset'))) {
        $("#main").tabs("close", $.i18n.prop('ami.dataset.edit_dataset'));
      }

      $http.post(addViewUrl, $scope.dataSet).success(function(result) {
        $("#main").tabs('add', {
          title: $.i18n.prop('ami.dataset.add_dataset'),
          content: $compile(result)($scope.$new()),
          closable: true
        });
      })
    }
    $scope.addDataSet = function(row) {
      $(".easyui-form").form('enableValidation');
      if ($(".easyui-form").form('validate')) {
        addDS();
      }
    }

    function addDS() {
      $http.post(basePath + "/customDataSet/addDataSet", $scope.dataSet || {}).success(function(result) {
        if (result.success) {
          $("#main").tabs("close", $.i18n.prop('ami.dataset.add_dataset'));
          $.messager.alert($.i18n.prop('ami.template.notice'), $.i18n.prop('ami.dataset.add_success'), 'info');
          $("#dataSetTable").datagrid('reload');
        } else {
          if (result.msg) {
            $.messager.alert($.i18n.prop('ami.common.warning'), result.msg, 'warning');
          }
        }
      })
    }
    function editDS() {
      $http.post(basePath + "/customDataSet/editDataSet", $scope.dataSet || {}).success(function(result) {
        if (result.success) {
          $("#main").tabs("close", $.i18n.prop('ami.dataset.edit_dataset'));
          $.messager.alert($.i18n.prop('ami.template.notice'), $.i18n.prop('ami.dataset.edit_success'), 'info');
          $("#dataSetTable").datagrid('reload');
        } else {
          if (result.msg) {
            $.messager.alert($.i18n.prop('ami.common.warning'), result.msg, 'warning');
          }
        }
      })
    }
    $scope.gotoEditDataSet = function(row) {

      $scope.sqlTestHeader = [];
      $scope.sqlTestUrl = "";
      $scope.dataSet = angular.copy(row);
      $.ajax({
        type: "POST",
        url: basePath + "/dataSource/getAllDataList",
        dataType: "html",
        contentType: "application/json",
        data: {},
        success: function(result) {
          if (result) {
            result = JSON.parse(result);
          }
          if (result.success) {
            $scope.$apply(function() {
              $scope.dataSet.dsList = eval(result.obj.dsList);
            });

          }
        }
      });
      $.ajax({
        type: "POST",
        url: basePath + "/objectTree/queryAll",
        dataType: "html",
        contentType: "application/json",
        data: {},
        success: function(result) {
          if (result) {
            result = JSON.parse(result);
          }
          if (result.success) {
            $scope.$apply(function() {
              $scope.dataSet.objectTreeList = eval(result.obj.objectTreeList);
            });

          }
        }
      });

      var editViewUrl = basePath + "/customDataSet/gotoDataSetEditView";
      if ('1' == $scope.dataSet.queryType) {
        editViewUrl = basePath + "/customDataSet/jsPlumb";
      }
      if ($("#main").tabs("exists", $.i18n.prop('ami.dataset.edit_dataset'))) {
        $("#main").tabs("close", $.i18n.prop('ami.dataset.edit_dataset'));
      }
      if ($("#main").tabs("exists", $.i18n.prop('ami.dataset.add_dataset'))) {
        $("#main").tabs("close", $.i18n.prop('ami.dataset.add_dataset'));
      }

      $http.post(editViewUrl, $scope.dataSet).success(function(result) {
        $("#main").tabs('add', {
          title: $.i18n.prop('ami.dataset.edit_dataset'),
          content: $compile(result)($scope.$new()),
          closable: true
        });
      })

    }

    // 修改
    $scope.editDataSet = function(row) {
      var newflag = true;

      if ($scope.dataSet.tableModels && $scope.dataSet.tableModels.length > 1) {
        for (var i = 0; i < $scope.dataSet.tableModels.length; i++) {
          if ($scope.dataSet.tableModels[i].connectLine) {
            for (var j = 0; j < $scope.dataSet.tableModels[i].connectLine.fieldList.length; j++) {
              if ($scope.dataSet.tableModels[i].connectLine.fieldList[j].sourceModel != null && $scope.dataSet.tableModels[i].connectLine.fieldList[j].sourceModel != ""
                      && $scope.dataSet.tableModels[i].connectLine.fieldList[j].targetModel != null && $scope.dataSet.tableModels[i].connectLine.fieldList[j].targetModel != "") {
                newflag = false;
              }
            }
          }
        }
      }
      if ($scope.dataSet.queryType = "1" && newflag) {
        $.messager.alert($.i18n.prop('ami.common.warning'), $.i18n.prop('ami.dataset.display.field01'), 'warning');
        return;
      }
      $(".easyui-form").form('enableValidation');
      if ($(".easyui-form").form('validate')) {
        if ($scope.dataSet.colTree) {
          var colLength = $scope.dataSet.colTree.length;
          for (var i = colLength - 1; i >= 0; i--) {
            var tree = $scope.dataSet.colTree[i];
            if (!tree.parentId) {
              var itemNew = {};
              itemNew.id = tree.id;
              itemNew.parentId = "";
              itemNew.name = tree.name;
              $scope.dataSet.colTree.remove(tree);
              $scope.dataSet.colTree.push(itemNew);
            }
          }
          if (!$scope.dataSet.colTree || $scope.dataSet.colTree.length == 0) {
            $.messager.alert($.i18n.prop('ami.common.warning'), $.i18n.prop('ami.dataset.display.field'), 'warning');
            return;
          }
          if (isrepeat($scope.dataSet.colTree)) {
            $.messager.alert($.i18n.prop('ami.common.warning'), $.i18n.prop('ami.dataset.field.repeat'), 'warning');
            return;
          }
        }
        if ($scope.dataSet && $scope.dataSet.queryId) {
          editDS();
        } else {
          addDS();
        }
      }
    }

    function isrepeat(list) {
      if (list && list.length > 1) {
        for (var i = 0; i < list.length; i++) {
          for (var j = i + 1; j < list.length; j++) {
            if (list[i].tableFiledAlias == list[j].tableFiledAlias) { return true; }
          }
        }

      }
      return false;
    }
    // 删除
    $scope.delDataSet = function(row) {

      $scope.dataSet = row;
      parent.$.messager.confirm('info', $.i18n.prop('ami.template.notice_message'), function(b) {
        if (b) {
          $http.post(basePath + "/customDataSet/delete", $scope.dataSet).success(function(result) {
            if (result.success) {
              $.messager.alert($.i18n.prop('ami.template.notice'), $.i18n.prop('ami.template.delete_success'), 'info');
              $("#dataSetTable").datagrid('reload');
            }
          })
        }
      })

    }

    $scope.tableUrl = basePath + '/customDataSet/query';
    $scope.$on("loadSuccess", function(e, data) {
      $compile($(data.target).find("td[field='operation'] > div"))($scope);// 手动编译表格最后一列，同步angularjs事件操作

      $permission.contains("/addSQL", function(data) {
        $scope.showDataSetAdd = data;
      });

      $permission.contains("/editSQL", function(data) {
        $scope.showDataSetEdit = data;
      });

      $permission.contains("/deleteSQL", function(data) {
        $scope.showDataSetDel = data;
      });

    });
  });

})(jQuery, app);
(function($, app) {
  "use strict";
  // 模板管理
  app.controller("dataSetModalCtrl", function($scope, $http, $timeout, $compile, $element) {
    $scope.cube = {};
    $scope.cube.id = $scope.dataSet.cnnId;
    $scope.demo = {};

    function refreshCube(cnnId) {
      if (cnnId) {
        $scope.cube.id = cnnId;

        $.ajax({
          type: "POST",
          url: basePath + "/cube/getTreeListByDsId",
          dataType: "html",
          contentType: "application/json",
          data: JSON.stringify($scope.cube),
          success: function(result) {
            if (result) {
              result = JSON.parse(result);
            }
            if (result.success) {
              $timeout(function() {
                $scope.demo.tree = eval(result.obj.list);
              });

            } else {
              $.messager.alert($.i18n.prop('ami.common.warning'), $.i18n.prop('ami.role.waring_message'), 'warning');
            }
          }
        });

      }

    }
    refreshCube($scope.cube.id);
    $scope.fulshCube = function(cnnId) {
      $scope.treeSearch = "";
      refreshCube(cnnId);
    }
    $scope.dragOne = {};
    // 拖拽
    $scope.treeDrag = function(item) {
      $('#drag-tree-' + item.id).draggable({
        revert: true,
        deltaX: 0,
        deltaY: 0,
        proxy: function(source) {
          var p = $('<div class="drag-item"></div>');
          p.html($(source).text()).appendTo('body');
          return p;
        },
        onBeforeDrag: function(e) {
          $scope.dragOne = item;
          $("#querySql").droppable({
            accept: '#drag-tree-' + item.id,
            onDrop: function(e, source) {
              // 实现拖拽逻辑
              $scope.$apply(function() {
                if ($scope.dragOne.tableFiledSql) {
                  $("#querySql").insertContent($scope.dragOne.tableFiledSql);
                  $scope.dataSet.querySql = $("#querySql").val();
                }
                if ($scope.dragOne.tableSql) {
                  var tableSql = $scope.dragOne.tableSql;
                  if("target" == $scope.dragOne.tableType){
                    tableSql = " (" + $scope.dragOne.tableSql + ") " + $scope.dragOne.tableName;
                  }
                  
                  $("#querySql").insertContent(tableSql);
                  $scope.dataSet.querySql = $("#querySql").val();
                }
              })
            },
          });
        }
      });
    }

    $scope.testSql = function() {
      
      
      
      $http.post(basePath + "/customDataSet/testSql", $scope.dataSet).success(function(result) {
        if (result.success) {
          // 加载结果
          var str = assembleDatagrid(result.obj.colname);
          $scope.sqlTestHeader = eval(str);
          $scope.sqlTestUrl = basePath + '/customDataSet/sqlList';
          var param = {
            "querySql": result.obj.querySql,
            "cnnId": result.obj.cnnId
          };
          $("#mydatagrid").datagrid({
            url: basePath + '/customDataSet/sqlList',
            queryParams: param,
            columns: [$scope.sqlTestHeader],
            rownumbers: false,
            singleSelect: true,
            autoRowHeight: false,
            pagination: true,
            pageSize: 10,
            pageList: [10, 20, 50, 100]
          });
        } else {
          
          if(result.msg){
            
            $.messager.alert($.i18n.prop('ami.common.warning'), result.msg, 'warning');
          }else{
            
            $.messager.alert($.i18n.prop('ami.common.warning'), $.i18n.prop('ami.dataset.test.error'), 'warning');
          }
        }
      })
    }
    
    function checkSql(querySql){
      
    }
    
    
    $scope.functionToSql = function(myValue,type) {

      if (myValue) {
        if("date" == type){
          myValue = "TO_DATE('"+myValue+"','yyyy-MM-dd HH24:mi:ss')";
        }
        $("#querySql").insertContent(myValue);
        $scope.dataSet.querySql = $("#querySql").val();
      }
    }

    function assembleDatagrid(list) {
      var s = "[";
      if(list){
        // 循环处理
        var colWidth = "120px"; // 默认给10列
        
        for (var i = 0; i < list.length; i++) {
          if('R' == list[i]){
            continue;
          }
          var temp = "{field:'" + list[i] + "',title:'" + list[i] + "',width:'" + colWidth + "',align:'left'},"
          s = s + temp;
        }
        if (s && "" != s) {
          s = s.substr(0, s.length - 1);
        }
      }
      s = s + "]";
      return s;
    }

  });

  (function($) {
    $.fn.extend({
      insertContent: function(myValue, t) {
        var $t = $(this)[0];
        if (document.selection) { // ie
          this.focus();
          var sel = document.selection.createRange();
          sel.text = myValue;
          this.focus();
          sel.moveStart('character', -l);
          var wee = sel.text.length;
          if (arguments.length == 2) {
            var l = $t.value.length;
            sel.moveEnd("character", wee + t);
            t <= 0 ? sel.moveStart("character", wee - 2 * t - myValue.length) : sel.moveStart("character", wee - t - myValue.length);
            sel.select();
          }
        } else if ($t.selectionStart || $t.selectionStart == '0') {
          var startPos = $t.selectionStart;
          var endPos = $t.selectionEnd;
          var scrollTop = $t.scrollTop;
          $t.value = $t.value.substring(0, startPos) + myValue + $t.value.substring(endPos, $t.value.length);
          this.focus();
          $t.selectionStart = startPos + myValue.length;
          $t.selectionEnd = startPos + myValue.length;
          $t.scrollTop = scrollTop;
          if (arguments.length == 2) {
            $t.setSelectionRange(startPos - t, $t.selectionEnd + t);
            this.focus();
          }
        } else {
          this.value += myValue;
          this.focus();
        }
      }
    })
  })(jQuery);

})(jQuery, app);
(function($, app) {
  "use strict";

  // 跳转测试用。。。。======================================
  app.controller("dataSetPlumbCtrl", function($scope, $http, $timeout, $compile, $element) {
    // 页面初始化时生成流程图
    $scope.$watch('$viewContentLoaded',
            function() {
              var domId = "window";
              // 初始化画图工具
              var instance = $.jsplumb("canvas");
              jsPlumbUtil.logEnabled = false;
              instance.reset();// * 词句非常重要，进入ctrl方法必须将jsplumb内存重置（销毁）

              var popoverHTML = ['<form id="popoverForm" name="popoverForm">', '<div class="flowpopover">', '<div  class="row">', '<div class="form-group col-sm-12 ami-menu-group">',
                  '<label class="ami-float control-label">' + $.i18n.prop("ami.report.popover.label") + ': </label>', '<div class="ami-float">',
                  '<select class="form-control" ng-model="popover.relatedWays">', '<option ng-repeat="item in popover.relatedWaysOptions" value="{{item}}">{{item}}</option>', '</select>', '</div>',
                  '</div>', '</div>', '<div  class="row">', '<label class="control-label col-sm-6 ami-menu-group" ng-bind="popover.tableName1"></label>',
                  '<label class="control-label col-sm-6 ami-menu-group" ng-bind="popover.tableName2"></label>', '</div>', '<div  class="row" ng-repeat="field in popover.fieldList track by $index">',
                  '<div class="col-sm-5 ami-menu-group">', '<select class="form-control easyui-validatebox" validType="selectRequired[]" required="true" ng-model="field.sourceModel">',
                  '<option  value="">--' + $.i18n.prop("ami.common.pleaseSelect") + '--</option>', '<option ng-repeat="item in popover.fieldList1" value="{{item}}">{{item.tableFiledAlias}}</option>',
                  '</select>', '</div>', '<div class="col-sm-1 ami-menu-group ami-panel-header"><label class="control-label">=</label></div>', '<div class="col-sm-5 ami-menu-group">',
                  '<select class="form-control easyui-validatebox" validType="selectRequired[]" required="true"  ng-model="field.targetModel">',
                  '<option  value="">--' + $.i18n.prop("ami.common.pleaseSelect") + '--</option>', '<option ng-repeat="item in popover.fieldList2" value="{{item}}">{{item.tableFiledAlias}}</option>',
                  '</select>', '</div>', '<div ng-if="$index==0" class="col-sm-1 ami-menu-group ami-panel-header">', '<span class="glyphicon glyphicon-plus" ng-click="addItem()"></span>',
                  '<span class="glyphicon glyphicon-minus" ng-click="removeItem()"></span>', '</div>', '</div> ', '<div  class="row">', '<div class="col-sm-11 ami-menu-group btn-align">',
                  '<button type="button" class="btn btn-info ami-save" ng-click="saveConnection(connection,$event)">' + $.i18n.prop("ami.report.sure") + '</button>&nbsp;&nbsp;',
                  '<button type="button" class="btn btn-default ami-close" ng-click="popoverHide($event)">' + $.i18n.prop("ami.common.cancel") + '</button>', '</div>', '</div>', '</div>', '</form>']
                      .join("");
              $scope.popover = {};
              $scope.popover.relatedWaysOptions = ["left join", "right join", "inner join"];
              $scope.popoverHide = function($event) {
                $(".popover").remove();
              }
              $scope.saveConnection = function(conn, $event) {
                $.parser.parse($("#popoverForm").parent());
                if (!$("#popoverForm").form("validate")) return;
                conn.getOverlay("label").setLabel($scope.popover.relatedWays);
                if (!$(conn).data("serviceData")) {
                  createSingleConnection(conn);
                }// 如果不存在，则需要重新绑定连接数据
                $(conn).data("serviceData").label = $scope.popover.relatedWays;
                $(conn).data("serviceData").fieldList = $scope.popover.fieldList;
                // 入库保存。。。。。
                $scope.popoverHide($event);
              }

              $scope.addItem = function() {
                $scope.popover.fieldList.push({
                  sourceModel: "",
                  targetModel: ""
                });
              }

              $scope.removeItem = function() {
                if ($scope.popover.fieldList.length > 1) {
                  $scope.popover.fieldList.pop();
                }
              }

              // 连接label点击事件触发
              function popover(connection, event) {
                $scope.popover.tableName1 = connection.target.innerText;
                $scope.popover.tableName2 = connection.source.innerText;
                $scope.popover.relatedWays = connection.getOverlay("label").getLabel() || "";
                var oldfieldList = $(connection).data("serviceData") ? $(connection).data("serviceData").fieldList : [];
                var fieldList = [];
                angular.copy(oldfieldList, fieldList);
                $scope.popover.fieldList = fieldList && fieldList.length > 0 ? fieldList : [{
                  sourceModel: "",
                  targetModel: ""
                }];
                $scope.popover.fieldList1 = getFieldListByNodeName($scope.dataSourceTables, $scope.popover.tableName1);// 下拉框列表
                $scope.popover.fieldList2 = getFieldListByNodeName($scope.dataSourceTables, $scope.popover.tableName2);// 下拉框列表
                $scope.connection = connection;
                $(event.target).pop(popoverHTML, "#canvas", $compile, $scope);
                if (!$(event.target).next("div.popover").length) {
                  $(event.target).popover("show");
                }
              }
              // 修改页面加载数据
              $scope.dataSourceTables = [];
              $scope.colTree = [];
              // 页面元素保存的数据
              $scope.dataSourceItems = $scope.dataSet.tableModels;

              $scope.cube = {};
              $scope.cube.id = $scope.dataSet.cnnId;
              refreshCube($scope.cube.id);
              function refreshCube(cnnId) {
                if (cnnId) {
                  $scope.cube.id = cnnId;

                  $.ajax({
                    type: "POST",
                    url: basePath + "/cube/getJumbTreeByDsId",
                    dataType: "html",
                    contentType: "application/json",
                    data: JSON.stringify($scope.cube),
                    success: function(result) {
                      if (result) {
                        result = JSON.parse(result);
                      }
                      if (result.success) {
                        $timeout(function() {
                          $scope.dataSourceTables = eval(result.obj.list);

                          var flowIds = [];
                          // 渲染数据
                          if (($scope.colTree.length < 1) && $scope.dataSourceItems) {
                            // 组装colTree
                            angular.forEach($scope.dataSourceItems, function(item, i) {
                              flowIds.push(item.nodeId);
                              var table = getTableByNodeName($scope.dataSourceTables, item.nodeName);
                              var tableNew = {};
                              angular.copy(table, tableNew);
                              addCols(tableNew);
                              // TODO
                            });
                          }
                          if (flowIds && flowIds.length > 0) {
                            angular.forEach($scope.dataSourceTables, function(s, j) {
                              if ($scope.dataSet.cubeId && $scope.dataSet.cubeId == s.parentId) {
                                s.disabled = true;
                                s.draggable = false;
                              }
                              if (s.hasOwnProperty("draggable")) {
                                if ($.inArray(s.id, flowIds) > -1) {
                                  s.disabled = true;
                                  s.draggable = false;
                                }
                              }
                            });
                          }
                        });

                      } else {
                        $.messager.alert($.i18n.prop('ami.common.warning'), $.i18n.prop('ami.role.waring_message'), 'warning');
                      }
                    }
                  });

                }

              }
              
              
              $scope.dragThis = {};
              // 拖拽
              $scope.dragZD = function(item) {
                $('.coltreedrag #drag-tree-' + item.id).draggable({
                  revert: true,
                  deltaX: 0,
                  deltaY: 0,
                  proxy: function(source) {
                    var p = $('<div class="drag-item"></div>');
                    p.html($(source).text()).appendTo('body');
                    return p;
                  },
                  onBeforeDrag: function(e) {
                    $scope.dragThis = item;
                    $("#sqlWhere").droppable({
                      accept: '.coltreedrag #drag-tree-' + item.id,
                      onDrop: function(e, source) {
                        // 实现拖拽逻辑
                        $scope.$apply(function() {
                          if ($scope.dragThis.tableFiledSql) {
                            $("#sqlWhere").insertContent($scope.dragThis.tableFiledSql);
                            $scope.dataSet.sqlWhere = $("#sqlWhere").val();
                          }
                        })
                      },
                    });
                  }
                });
              }
              
              
              
              
              
              
              
              

              // 删除节点
              $scope.closeNode = function(item, $event) {
                $scope.dataSourceItems.remove(item);
                removeCols(item);
                $(".popover").remove();
                if (!$event) return;
                $scope.prevRemoveNode = item;
              }

              function getFieldListByNodeName(list, nodeName) {
                var fieldList = null;
                $.each(list, function(i, n) {
                  if (n.name === $.trim(nodeName)) {
                    fieldList = n.fieldList;
                    return false;
                  }
                });
                return fieldList || [];
              }

              function getTableByNodeName(list, nodeName) {
                var table = null;
                $.each(list, function(i, n) {
                  if (n.name === $.trim(nodeName)) {
                    table = n;
                    return false;
                  }
                });
                return table || [];
              }
              function createSingleConnection(conn) {
                $(conn).data("serviceData", {
                  target: conn.getUuids()[0],
                  source: conn.getUuids()[1],
                  label: conn.getOverlay("label").getLabel(),
                  fieldList: []
                });
              }

              // 监听流程图是否已经有当前节点，如果重复，则不允许拖拽
              $scope.$watch("dataSourceItems", function(n, o) {
                var flowIds = [];
                angular.forEach(n, function(v, i) {
                  flowIds.push(v.nodeId);
                });
                angular.forEach($scope.dataSourceTables, function(s, j) {
                  if (s.hasOwnProperty("draggable") && !s.hasOwnProperty("tableFiled")) {
                    s.draggable = $.inArray(s.id, flowIds) < 0;
                    s.disabled = !s.draggable;
                  }
                  $scope.treeDrag(s);
                });
                // 内部存在timeout延迟操作，这是必要的，否则js先执行而页面后加载，导致连接线不显示问题。后续有待优化
                $scope.completeCallback(domId);

              }, true);

              $scope.$watch("treeSearch", function(n, o) {
                if (n == undefined) return;
                $timeout(function() {
                  angular.forEach($scope.dataSourceTables, function(s, j) {
                    $scope.treeDrag(s);
                  });
                }, 50)
              })

              $scope.completeCallback = function(flowId) {
                $timeout(function() {
                  instance.reset();// * 词句非常重要，进入ctrl方法必须将jsplumb内存重置（销毁）
                  angular.forEach($scope.dataSourceItems, function(item, i) {
                    $.jsplumb.addPoint(instance, flowId + item.nodeId);
                    if (item.connectLine && !$.jsplumb.connect(instance, item.connectLine)) {
                      $scope.closeNode(item);// 如果连接失败，则删除当前节点
                    }
                    instance.unbind("click").bind("click", function(connection, event) {
                      if ($(event.target).hasClass("aLabel")) {
                        popover(connection, event);
                      }
                    })
                  });

                  angular.forEach($scope.retainItem, function(item, i) {
                    if (!item.parentId) return;
                    var jtkNode = $("#" + item.parentId);
                    // var left=jtkNode.position().left + jtkNode.width() + 200;
                    var p = jtkNode.position();
                    if (!p) return;
                    var top = p.top + i * (80 + jtkNode.height());
                    animateTop(item, top)
                    // 将此节点下的所有子节点按top偏移
                    angular.forEach($scope.childeNodes[domId + item.nodeId], function(child, index) {
                      animateTop(child, top)
                    })
                  })
                })
              }
              function animateTop(dom, top) {
                var $$dom = $("#" + domId + dom.nodeId);
                instance.animate($$dom[0], {
                  top: top
                }, {
                  complete: function() {
                    $scope.$apply(function() {
                      dom.style.top = top;
                    });
                  }
                });
              }

              $scope.fulshCube = function(cnnId) {
                $scope.treeSearch = "";
                refreshCube(cnnId);
              }

              // 判断删除节点时，对当前节点下所有的平级节点进行位置适应.
              $scope.$watch("prevRemoveNode", function(n, o) {
                if (n && n.connectLine) {
                  $scope.retainItem = [];
                  $scope.childeNodes = {};
                  var source = n.connectLine.source;// 指向同一个父节点的元素
                  angular.forEach($scope.dataSourceItems, function(item, i) {
                    if (item.connectLine && item.connectLine.source === source) {
                      $scope.retainItem.push(item);
                      $scope.childeNodes[domId + item.nodeId] = [];
                    }
                  });

                  angular.forEach($scope.retainItem, function(target, i) {
                    findeNodes(target, $scope.childeNodes)
                  });
                }
              });

              function findeNodes(target, childeNodes) {
                angular.forEach($scope.dataSourceItems, function(item, i) {
                  if ((domId + target.nodeId) === item.parentId) {
                    childeNodes[domId + target.nodeId].push(item);
                    findeNodes(item, childeNodes);
                  }
                });
              }

              // 拖拽生成表关联关系
              $scope.treeDrag = function(item) {
                var $$drag = $('#drag-tree-' + item.id);
                $$drag.draggable({
                  revert: true,
                  deltaX: 0,
                  deltaY: 0,
                  proxy: function(source) {
                    var p = $('<div class="drag-item"></div>');
                    p.html($(source).text()).appendTo('body');
                    return p;
                  },
                  onBeforeDrag: function(e) {
                    $("#flowchart_box").droppable({
                      accept: '#drag-tree-' + item.id,
                      onDrop: function(e, source) {
                        // 默认显示位置
                        var node = {
                          nodeId: item.id,
                          nodeName: item.name,
                          tableSql: item.tableSql,
                          tableType: item.tableType,
                          style: {
                            "left": event.pageX - $(e.target).offset().left,
                            "top": event.pageY - $(e.target).offset().top
                          }
                        }
                        // 判断鼠标落座的标签是否是在节点上
                        var jtkNode = $(event.target).closest("div.jtk-node");

                        // 判断放置区域内是否已经存在root节点，若存在则不允许重新拖拽新元素入放置区
                        if ($scope.dataSourceItems.length == 0 || jtkNode.length) {
                          $scope.$apply(function() {
                            node.parentId = undefined;
                            $scope.dataSourceItems.push(node);
                            addCols(item);/* 动态生成flow流程图item项 */
                          });
                        }

                        if (jtkNode.length) {
                          var target = $("#" + domId + node.nodeId);
                          var left, top;
                          var sourceId = jtkNode.attr("id"), targetId = target.attr("id");
                          var options = {
                            complete: function(el) {
                              // 自动连接时构造连接线对象
                              var conn = {
                                target: targetId + "-Left",
                                source: sourceId + "-Right",
                                label: $scope.popover.relatedWaysOptions[0],
                                fieldList: [{
                                  sourceModel: "",
                                  targetModel: ""
                                }]
                              };
                              $scope.$apply(function() {
                                node.style.left = $(el).position().left;
                                node.style.top = $(el).position().top;
                                node.parentId = sourceId;
                                node.connectLine = conn;
                              });
                            }
                          };

                          // 位置自适应动画
                          var targetItems = []
                          angular.forEach(instance.getAllConnections(), function(conn, i) {
                            if (sourceId === conn.targetId) targetItems.push(conn);
                          });
                          left = jtkNode.position().left + jtkNode.width() + 200;
                          top = jtkNode.position().top + (targetItems.length) * (80 + jtkNode.height());
                          instance.animate(target[0], {
                            left: left,
                            top: top
                          }, options);
                        }
                      }
                    });
                  }
                });
                $$drag.draggable(item.draggable ? "enable" : "disable");
              }

              function addCols(item) {
                var itemNew = angular.copy(item);
                var itemMain = {}
                itemMain.id = itemNew.id;
                itemMain.parentId = "";
                itemMain.name = itemNew.name;
                $scope.colTree.push(itemMain);
                angular.forEach(itemNew.fieldList, function(field, i) {
                  if ($scope.dataSet.colTree) {
                    angular.forEach($scope.dataSet.colTree, function(col, i) {
                      if (field.id == col.id) {
                        field.checked = true;
                      }
                    });
                  }
                  field.draggable=true;
                  $scope.colTree.push(field);
                });
              }
              function removeCols(item) {
                var colLength = $scope.colTree.length;
                for (var i = colLength - 1; i >= 0; i--) {
                  var tree = $scope.colTree[i];
                  if (tree.id == item.nodeId || tree.parentId == item.nodeId) {
                    $scope.colTree.remove(tree);
                  }
                }
              }
              $scope.testSql = function() {

                var newflag = true;

                if ($scope.dataSet.tableModels && $scope.dataSet.tableModels.length > 1) {
                  for (var i = 0; i < $scope.dataSet.tableModels.length; i++) {
                    if ($scope.dataSet.tableModels[i].connectLine) {
                      for (var j = 0; j < $scope.dataSet.tableModels[i].connectLine.fieldList.length; j++) {
                        if ($scope.dataSet.tableModels[i].connectLine.fieldList[j].sourceModel == "" || $scope.dataSet.tableModels[i].connectLine.fieldList[j].targetModel == "") {
                          newflag = false;
                        }
                      }
                    }
                  }
                }
                if (!newflag) {
                  $.messager.alert($.i18n.prop('ami.common.warning'), $.i18n.prop('ami.dataset.display.field01'), 'warning');
                  return;
                }

                var temp = [];
                angular.copy($scope.colTree, temp);
                $scope.dataSet.colTree = temp;
                if (temp) {
                  $scope.dataSet.colTree = [];
                  var colLength = temp.length;
                  for (var i = colLength - 1; i >= 0; i--) {
                    var tree = temp[i];
                    if (tree.checked && tree.parentId) {

                      $scope.dataSet.colTree.push(tree);
                    }
                  }
                }
                if (!$scope.dataSet.colTree || $scope.dataSet.colTree.length == 0) {
                  $.messager.alert($.i18n.prop('ami.common.warning'), $.i18n.prop('ami.dataset.display.field'), 'warning');
                  return;
                } else {
                  if (isrepeat($scope.dataSet.colTree)) {
                    $.messager.alert($.i18n.prop('ami.common.warning'), $.i18n.prop('ami.dataset.field.repeat'), 'warning');
                    return;
                  }
                }
                $http.post(basePath + "/customDataSet/testSql", $scope.dataSet).success(function(result) {
                  if (result.success) {
                    // 加载结果
                    var str = assembleDatagrid(result.obj.colname);
                    $scope.sqlTestHeader = eval(str);
                    $scope.sqlTestUrl = basePath + '/customDataSet/sqlList';
                    var param = {
                      "querySql": result.obj.querySql,
                      "cnnId": result.obj.cnnId
                    };
                    $("#mydatagrid").datagrid({
                      url: basePath + '/customDataSet/sqlList',
                      queryParams: param,
                      columns: [$scope.sqlTestHeader],
                      rownumbers: false,
                      singleSelect: true,
                      autoRowHeight: false,
                      pagination: true,
                      pageSize: 10,
                      pageList: [10, 20, 50, 100]
                    });
                  } else {
                    $.messager.alert($.i18n.prop('ami.common.warning'), $.i18n.prop('ami.dataset.model.test.error'), 'warning');
                  }
                })
              }
            $scope.previewSql = function() {previewSql();}
            
            function previewSql(){

              var temp = [];
              angular.copy($scope.colTree, temp);
              $scope.dataSet.colTree = temp;
              if (temp) {
                $scope.dataSet.colTree = [];
                var colLength = temp.length;
                for (var i = colLength - 1; i >= 0; i--) {
                  var tree = temp[i];
                  if (tree.checked && tree.parentId) {

                    $scope.dataSet.colTree.push(tree);
                  }
                }
              }
              $http.post(basePath + "/customDataSet/previewSql", $scope.dataSet).success(function(result) {
                if (result.success) {
                  $("#sqlPre").val(result.msg);
                } 
              })
              
            
            }
              
              function isrepeat(list) {
                if (list && list.length > 1) {
                  for (var i = 0; i < list.length; i++) {
                    for (var j = i + 1; j < list.length; j++) {
                      if (list[i].tableFiledAlias == list[j].tableFiledAlias) { return true; }
                    }
                  }

                }
                return false;
              }
              function assembleDatagrid(list) {
                var s = "[";
                if (list) {
                  // 循环处理
                  var colWidth = "120px"; // 默认给10列

                  for (var i = 0; i < list.length; i++) {
                    if ('R' == list[i]) {
                      continue;
                    }
                    var temp = "{field:'" + list[i] + "',title:'" + list[i] + "',width:'" + colWidth + "',align:'left'},"
                    s = s + temp;
                  }
                  if (s && "" != s) {
                    s = s.substr(0, s.length - 1);
                  }
                }
                s = s + "]";
                return s;
              }
              $scope.functionToSql = function(myValue,type) {

                if (myValue) {
                  if("date" == type){
                    myValue = "TO_DATE('"+myValue+"','yyyy-MM-dd HH24:mi:ss')";
                  }
                  $("#sqlWhere").insertContent(myValue);
                  $scope.dataSet.sqlWhere = $("#sqlWhere").val();
                }
              }

            });
  });
})(jQuery, app);(function($,app){
  "use strict";
  
  // 跳转测试用。。。。======================================
  app.controller("dataSetPlumbEditCtrl",function($scope,$http,$timeout,$compile,$element){
    // 页面初始化时生成流程图
    $scope.$watch('$viewContentLoaded', function() {
      var domId = "windowEdit";
      var canvasId = "canvasEdit";
    // 初始化画图工具
    var instance = $.jsplumb(canvasId);
    jsPlumbUtil.logEnabled=false;
    instance.reset();//* 词句非常重要，进入ctrl方法必须将jsplumb内存重置（销毁）
    
    var popoverHTML = [
                    '<div class="flowpopover">',
                    '<div  class="row">',
                      '<div class="form-group col-sm-12 ami-menu-group">',
                        '<label class="ami-float control-label">'+$.i18n.prop("ami.report.popover.label")+': </label>',
                        '<div class="ami-float">',
                            '<select class="form-control" ng-model="popover.relatedWays">',
                              '<option ng-repeat="item in popover.relatedWaysOptions" value="{{item}}">{{item}}</option>',
                            '</select>',
                        '</div>',
                      '</div>',
                    '</div>',
                    '<div  class="row">',
                        '<label class="control-label col-sm-6 ami-menu-group" ng-bind="popover.tableName1"></label>',
                        '<label class="control-label col-sm-6 ami-menu-group" ng-bind="popover.tableName2"></label>',
                    '</div>',
                    '<div  class="row" ng-repeat="field in popover.fieldList track by $index">',
                      '<div class="col-sm-5 ami-menu-group">',
                           '<select class="form-control"  ng-model="field.sourceModel">',
                              '<option ng-repeat="item in popover.fieldList1" value="{{item}}">{{item.tableFiledAlias}}</option>',
                            '</select>',
                        '</div>',       
                        '<div class="col-sm-1 ami-menu-group ami-panel-header"><label class="control-label">=</label></div>',
                      '<div class="col-sm-5 ami-menu-group">',
                           '<select class="form-control" ng-model="field.targetModel">',
                              '<option ng-repeat="item in popover.fieldList2" value="{{item}}">{{item.tableFiledAlias}}</option>',
                           '</select>',
                       '</div>',
                       '<div ng-if="$index==0" class="col-sm-1 ami-menu-group ami-panel-header">',
                          '<span class="glyphicon glyphicon-plus" ng-click="addItem()"></span>&nbsp;&nbsp;',
                          '<span class="glyphicon glyphicon-minus" ng-click="removeItem()"></span>',
                       '</div>',
                    '</div> ',
                    '<div  class="row">',
                      '<div class="col-sm-11 ami-menu-group btn-align">',
                        '<button type="button" class="btn btn-info ami-save" ng-click="saveConnection(connection,$event)">'+$.i18n.prop("ami.report.sure")+'</button>&nbsp;&nbsp;',
                        '<button type="button" class="btn btn-default ami-close" ng-click="popoverHide($event)">'+$.i18n.prop("ami.common.cancel")+'</button>',
                      '</div>',
                    '</div>',
                    '</div>'].join("");
    $scope.popover={};
    $scope.popover.relatedWaysOptions = ["left join","right join","inner join"];
    $scope.popoverHide=function($event){$(".popover").remove();}
    $scope.saveConnection=function(conn,$event){
      conn.getOverlay("label").setLabel($scope.popover.relatedWays);
      if(!$(conn).data("serviceData")) { createSingleConnection(conn); }// 如果不存在，则需要重新绑定连接数据
      $(conn).data("serviceData").label=$scope.popover.relatedWays;
      $(conn).data("serviceData").fieldList=$scope.popover.fieldList;
      // 入库保存。。。。。
      $scope.popoverHide($event);
    }
		
		$scope.addItem=function(){
      $scope.popover.fieldList.push({sourceModel:{},targetModel:{}});
    }
    
    $scope.removeItem=function(){
      if($scope.popover.fieldList.length > 1)
      {
        $scope.popover.fieldList.pop();
      } 
    }
		
    // 连接label点击事件触发
    function popover(connection,event){
      $scope.popover.tableName1 = connection.target.innerText;
      $scope.popover.tableName2 = connection.source.innerText;
      $scope.popover.relatedWays = connection.getOverlay("label").getLabel() || "";
      var oldfieldList = $(connection).data("serviceData") ?  $(connection).data("serviceData").fieldList : [];
      var fieldList = [];
      angular.copy(oldfieldList,fieldList);
      $scope.popover.fieldList = fieldList && fieldList.length > 0 ?  fieldList : [{sourceModel:{},targetModel:{}}];
      $scope.popover.fieldList1 = getFieldListByNodeName($scope.dataSourceTables,$scope.popover.tableName1);// 下拉框列表
      $scope.popover.fieldList2 = getFieldListByNodeName($scope.dataSourceTables,$scope.popover.tableName2);// 下拉框列表
      $scope.connection = connection;
      $(event.target).pop(popoverHTML,"#"+canvasId,$compile,$scope);
      if(!$(event.target).next("div.popover").length){$(event.target).popover("show");}
    }
 // 修改页面加载数据
		$scope.dataSourceTables = [];
		$scope.colTree = [];
		// 页面元素保存的数据
		$scope.dataSourceItems = $scope.dataSet.tableModels;
		
		$scope.cube = {};
    $scope.cube.id = $scope.dataSet.cnnId;
    refreshCube($scope.cube.id);
    function refreshCube(cnnId) {
      if (cnnId) {
        $scope.cube.id = cnnId;

        $.ajax({
          type: "POST",
          url: basePath + "/cube/getJumbTreeByDsId",
          dataType: "html",
          contentType: "application/json",
          data: JSON.stringify($scope.cube),
          success: function(result) {
            if (result) {
              result = JSON.parse(result);
            }
            if (result.success) {
              $timeout(function() {
                $scope.dataSourceTables = eval(result.obj.list);
                var flowIds = [];
                // 渲染数据
                if(($scope.colTree.length<1)&&$scope.dataSourceItems){
                  //组装colTree
                  angular.forEach($scope.dataSourceItems,function(item,i){
                    flowIds.push(item.nodeId);
                    var table =getTableByNodeName($scope.dataSourceTables,item.nodeName);
                    var tableNew={};
                    angular.copy(table,tableNew);
                    addCols(tableNew);
                    // TODO
                  });
                }
                if(flowIds && flowIds.length>0){
                  angular.forEach($scope.dataSourceTables,function(s,j){
                    if(s.hasOwnProperty("draggable")) { 
                      if($.inArray(s.id,flowIds) > -1){
                        s.disabled=true;
                        s.draggable=false;
                      }
                    }
                  });
                }
                
              });

            } else {
              $.messager.alert($.i18n.prop('ami.common.warning'), $.i18n.prop('ami.role.waring_message'), 'warning');
            }
          }
        });

      }

    }

    // 删除节点
    $scope.closeNode = function(item,$event){
      $scope.dataSourceItems.remove(item);
      removeCols(item);
      $(".popover").remove();
      if(!$event)return;
      $scope.prevRemoveNode = item;
    }
    
    function getFieldListByNodeName(list,nodeName)
    {
      var fieldList = null;
      $.each(list,function(i,n){ if(n.name===$.trim(nodeName)) { fieldList = n.fieldList; return false; } });
      return fieldList || [];
    }
		
		function getTableByNodeName(list,nodeName)
		{
		  var table = null;
		  $.each(list,function(i,n){ if(n.name===$.trim(nodeName)) { table = n; return false; } });
		  return table || [];
		}
		function createSingleConnection(conn)
    {
      $(conn).data("serviceData",{
        target:conn.getUuids()[0],
        source:conn.getUuids()[1],
              label:conn.getOverlay("label").getLabel(),
              fieldList:[]
      });
    }
		
		// 监听流程图是否已经有当前节点，如果重复，则不允许拖拽
    $scope.$watch("dataSourceItems",function(n,o){
      var flowIds = [];
      angular.forEach(n,function(v,i){ flowIds.push(v.nodeId); });
      angular.forEach($scope.dataSourceTables,function(s,j){
        if(s.hasOwnProperty("draggable") && !s.hasOwnProperty("tableFiled")) { s.draggable = $.inArray(s.id,flowIds) < 0;s.disabled=!s.draggable;}
        $scope.treeDrag(s);
      });
      // 内部存在timeout延迟操作，这是必要的，否则js先执行而页面后加载，导致连接线不显示问题。后续有待优化
      $scope.completeCallback(domId);
      
    },true);
    
    $scope.$watch("treeSearch",function(n,o){
      if(n==undefined)return;
      $timeout(function(){
        angular.forEach($scope.dataSourceTables,function(s,j){
          $scope.treeDrag(s);
        });
      },50)
    })
    
    $scope.completeCallback=function(flowId)
    {
      $timeout(function(){
        instance.reset();//* 词句非常重要，进入ctrl方法必须将jsplumb内存重置（销毁）
        angular.forEach($scope.dataSourceItems,function(item,i){
          $.jsplumb.addPoint(instance,flowId + item.nodeId);
          if(item.connectLine && !$.jsplumb.connect(instance,item.connectLine))
          {
            $scope.closeNode(item);// 如果连接失败，则删除当前节点
          }
          instance.unbind("click").bind("click",function(connection,event){
            if($(event.target).hasClass("aLabel"))
            {
              popover(connection,event);
            }
          })
        });
        
        angular.forEach($scope.retainItem,function(item,i){
          if(!item.parentId)return;
          var jtkNode = $("#" + item.parentId);
          //   var left=jtkNode.position().left + jtkNode.width() + 200;
          var p = jtkNode.position();
          if(!p)return;
          var top=p.top + i * (80 + jtkNode.height());
          animateTop(item,top)
          // 将此节点下的所有子节点按top偏移
          angular.forEach($scope.childeNodes[domId + item.nodeId],function(child,index){
            animateTop(child,top)
          })
        })
      })
    }
    function animateTop(dom,top)
    {
      var $$dom = $("#" + domId + dom.nodeId);
      instance.animate($$dom[0],{top:top},{complete:function(){
        $scope.$apply(function(){dom.style.top=top;});
      }});
    }
		
    $scope.fulshCube = function(cnnId) {
      $scope.treeSearch = "";
      refreshCube(cnnId);
    }
    
 // 判断删除节点时，对当前节点下所有的平级节点进行位置适应.
    $scope.$watch("prevRemoveNode",function(n,o){
      if(n && n.connectLine)
      {
        $scope.retainItem =[];
        $scope.childeNodes={};
        var source =  n.connectLine.source;// 指向同一个父节点的元素
        angular.forEach($scope.dataSourceItems,function(item,i){
          if(item.connectLine && item.connectLine.source === source)
          {
            $scope.retainItem.push(item);
            $scope.childeNodes[domId + item.nodeId] = [];
          }
        });
        
        angular.forEach($scope.retainItem,function(target,i){
          findeNodes(target,$scope.childeNodes)
        });
      } 
    });
    
    function findeNodes(target,childeNodes)
    {
      angular.forEach($scope.dataSourceItems,function(item,i){
        if((domId + target.nodeId) === item.parentId)
        {
          childeNodes[domId + target.nodeId].push(item);
          findeNodes(item,childeNodes);
        } 
      });
    }
    $scope.dragThis = {};
    // 拖拽
    $scope.dragZD = function(item) {
      $('.coltreedrag #drag-tree-' + item.id).draggable({
        revert: true,
        deltaX: 0,
        deltaY: 0,
        proxy: function(source) {
          var p = $('<div class="drag-item"></div>');
          p.html($(source).text()).appendTo('body');
          return p;
        },
        onBeforeDrag: function(e) {
          $scope.dragThis = item;
          $("#sqlWhere").droppable({
            accept: '.coltreedrag #drag-tree-' + item.id,
            onDrop: function(e, source) {
              // 实现拖拽逻辑
              $scope.$apply(function() {
                if ($scope.dragThis.tableFiledSql) {
                  $("#sqlWhere").insertContent($scope.dragThis.tableFiledSql);
                  $scope.dataSet.sqlWhere = $("#sqlWhere").val();
                }
              })
            },
          });
        }
      });
    }
    
    

    // 拖拽生成表关联关系
    $scope.treeDrag = function(item) {
      var $$drag = $('#drag-tree-' + item.id);
      $$drag.draggable({ revert : true, deltaX : 0, deltaY : 0,
                 proxy : function(source) {var p = $('<div class="drag-item"></div>'); p.html($(source).text()).appendTo('body'); return p; },
                onBeforeDrag : function(e) {
                  $("#flowchart_box").droppable({accept : '#drag-tree-' + item.id,
                    onDrop : function(e, source) {
                      // 默认显示位置
                      var node = {
                        nodeId:item.id,
                        nodeName:item.name,
                        tableSql:item.tableSql,
                        tableType:item.tableType,
                        style:{"left":event.pageX - $(e.target).offset().left,"top":event.pageY - $(e.target).offset().top}
                      }
                      // 判断鼠标落座的标签是否是在节点上
                      var jtkNode = $(event.target).closest("div.jtk-node");
                      
                      // 判断放置区域内是否已经存在root节点，若存在则不允许重新拖拽新元素入放置区
                      if($scope.dataSourceItems.length == 0 || jtkNode.length)
                      {
                        $scope.$apply(function(){node.parentId=undefined;$scope.dataSourceItems.push(node); addCols(item);/* 动态生成flow流程图item项*/});
                      } 
                      
                      if(jtkNode.length)
                      {
                        var target = $("#" + domId + node.nodeId);
                        var left,top;
                        var sourceId = jtkNode.attr("id"),targetId = target.attr("id");
                        var options ={complete:function(el){
                          // 自动连接时构造连接线对象
                          var conn = { target:targetId + "-Left", source:sourceId + "-Right", label:$scope.popover.relatedWaysOptions[0], fieldList:[{sourceModel:{},targetModel:{}}]}; 
                          $scope.$apply(function(){
                            node.style.left=$(el).position().left;
                            node.style.top=$(el).position().top;
                            node.parentId=sourceId;
                            node.connectLine=conn;
                          });
                        }};
                        
                        // 位置自适应动画
                        var targetItems=[]
                        angular.forEach(instance.getAllConnections(),function(conn,i){
                          if(sourceId === conn.targetId)targetItems.push(conn);
                        });
                        left=jtkNode.position().left + jtkNode.width() + 200;
                        top=jtkNode.position().top + (targetItems.length) * (80 + jtkNode.height());
                        instance.animate(target[0],{left:left,top:top},options);
                      } 
                    }
                  });
                }
               });
      $$drag.draggable(item.draggable ? "enable" : "disable");
      }
		
    function addCols(item){
      var itemNew =angular.copy(item);
      var itemMain={}
      itemMain.id=itemNew.id;
      itemMain.parentId="";
      itemMain.name=itemNew.name;
      $scope.colTree.push(itemMain);
      angular.forEach(itemNew.fieldList,function(field,i){
        if($scope.dataSet.colTree){
          angular.forEach($scope.dataSet.colTree,function(col,i){
            if(field.id==col.id){
              field.checked=true;
            }
          });
        }
        field.draggable=true;
        $scope.colTree.push(field);
      });
    }
    function removeCols(item){
      var colLength = $scope.colTree.length;
      for (var i=colLength-1;i>=0;i--){
        var tree = $scope.colTree[i];
        if(tree.id==item.nodeId || tree.parentId ==item.nodeId ){
          $scope.colTree.remove(tree);
        }
      }
    }
		$scope.testSql = function() {
		  
		 
		  var temp =[];
		  angular.copy($scope.colTree,temp);
		  $scope.dataSet.colTree=temp;
  		  if(temp){
  		    $scope.dataSet.colTree=[];
          var colLength = temp.length;
          for (var i=colLength-1;i>=0;i--){
            var tree = temp[i];
            if( tree.checked && tree.parentId){
             
              $scope.dataSet.colTree.push(tree);
            }
          }
      }
  		  if(!$scope.dataSet.colTree || $scope.dataSet.colTree.length==0){
          $.messager.alert($.i18n.prop('ami.common.warning'), '请设置查询字段!', 'warning');
          return;
        }
      $http.post(basePath + "/customDataSet/testSql", $scope.dataSet).success(function(result) {
        if (result.success) {
          // 加载结果
          var str = assembleDatagrid(result.obj.colname);
          $scope.sqlTestHeader = eval(str);
          $scope.sqlTestUrl = basePath + '/customDataSet/sqlList';
          var param = {
            "querySql": result.obj.querySql,
            "cnnId": result.obj.cnnId
          };
          $("#datagrid").datagrid({
            url: basePath + '/customDataSet/sqlList',
            queryParams: param,
            columns: [$scope.sqlTestHeader],
            rownumbers: false,
            singleSelect: true,
            autoRowHeight: false,
            pagination: true,
            pageSize: 10,
            pageList: [10, 20, 50, 100]
          });
        } else {
          var errorMsg = $.i18n.prop('ami.role.waring_message');
          if(result.msg){
            errorMsg=result.msg;
          }
          $.messager.alert($.i18n.prop('ami.common.warning'), errorMsg, 'warning');
        }
      })
    }
		function assembleDatagrid(list) {
      var s = "[";
		  if(list){
		    // 循环处理
		    var colWidth = 9.9; // 默认给10列
		    if (null != list && 0 != list.length) {
		      
		      colWidth = Math.ceil(0.99 / (list.length-1) * 100);
		    }
		    
		    for (var i = 0; i < list.length; i++) {
		      if('R' == list[i]){
		        continue;
		      }
		      var temp = "{field:'" + list[i] + "',title:'" + list[i] + "',width:'" + colWidth + "%',align:'left'},"
		      s = s + temp;
		    }
		    if (s && "" != s) {
		      s = s.substr(0, s.length - 1);
		    }
		  }
		  s = s + "]";
      return s;
    }
		$scope.functionToSql = function(myValue) {

      if (myValue) {
        $("#sqlWhere").insertContent(myValue);
        $scope.dataSet.sqlWhere = $("#sqlWhere").val();
      }
    }
		
		});
	});
})(jQuery,app);(function($,app){
	"use strict";
	// 模板管理
	app.controller("dataSourceCtrl",function($scope,$http,$timeout,$compile,$element){
//		$scope.tableHeader = [
//		                    {field:'id',title:'id',width:'20%',align:'left',hidden:true},
//	          				{field:'key',title:'名称',width:'20%',align:'left'},
//	          				{field:'dbType',title:'类型',width:'20%',align:'left',formatter:function(value,row,index){
//	          					if("01"==value){
//	          						return 'Oracle';
//	          					}if("02"==value){
//	          						return 'MySql';
//	          					}
//	          					
//	          				}},
//	          				{field:'url',title:'连接',width:'20%',align:'left'},
//	          				{field:'dbName',title:'用户名',width:'20%',align:'left'},
//	          				{field:'operation',title:'操作',width:'10%',align:'left',formatter:function(value, row, index){
//	          					$scope['rowData_'+index] = row;
//            					return '<a href="javascript:void(0)" class="organization-easyui-linkbutton-edit" ng-click="viewDataSource(rowData_'+index+')" data-options="plain:true,iconCls:\'icon-edit\'">查看</a> | <a href="javascript:void(0)" class="organization-easyui-linkbutton-edit" ng-click="modifyDataSource(rowData_'+index+')" data-options="plain:true,iconCls:\'icon-edit\'">修改</a>| <a href="javascript:void(0)" class="organization-easyui-linkbutton-del" ng-click="delDataSource(rowData_'+index+')" data-options="plain:true,iconCls:\'icon-del\'">删除</a>';
//            				}},
//	          			  ];
//		
//		// 查看
//		$scope.viewDataSource = function(row){
//			
//			$scope.dataSource =row;
//			$.model("查看数据源",basePath + "/dataSource/viewPage",$scope.dataSource,function(result){return $compile(result)($scope)});
//		}
//		
//		// 新增
//		$scope.addDataSource = function(row){
//			$scope.dataSource ={};
//			$.model("新增数据源",basePath + "/dataSource/addPage",$scope.dataSource,function(result){return $compile(result)($scope)},function(m){
//				$http.post(basePath + "/dataSource/save", $scope.dataSource || {})
//				.success( function(result) 
//						{
//						if(result.success){
//							$.model.close(m);
//							$.messager.alert('提示', '添加成功', 'info');
//							$("#dataSourceTable").datagrid('reload');
//						}
//					} 
//				)
//			});
//		}
//		
//		// 修改
//		$scope.modifyDataSource = function(row){
//			$scope.dataSource = row;
//			$.model("修改数据源",basePath + "/dataSource/editPage",$scope.dataSource,function(result){return $compile(result)($scope)},function(m){
//				$http.post(basePath + "/dataSource/edit", $scope.dataSource || {})
//				.success( function(result) 
//						{
//						if(result.success){
//							$.model.close(m);
//							$.messager.alert('提示', '修改成功', 'info');
//							$("#dataSourceTable").datagrid('reload');
//						}
//					} 
//				)
//			});
//		}
//		
//		// 删除
//		$scope.delDataSource = function(row){
//			
//			$scope.dataSource = row;
//			parent.$.messager.confirm('info','是否删除该条记录',function(b){
//				if(b){
//					$http.post(basePath + "/dataSource/delete", $scope.dataSource)
//					.success( function(result) 
//							{
//						
//								if(result.success){
//									$.messager.alert('提示', '删除成功', 'info');
//									$("#dataSourceTable").datagrid('reload');
//								}
//							} 
//					)
//				}
//			})
//			
//		}
//		
//		$scope.updateDataSourceTable = function(row){
//			$scope.dataSource = row;
//			parent.$.messager.confirm('info','是否更新数据源中所有表及表结构',function(b){
//				if(b){
//					$http.post(basePath + "/dataSource/updateTable", $scope.dataSource)
//					.success( function(result) 
//							{
//						
//								if(result.success){
//									$.messager.alert('提示', '更新需要时间,请稍候', 'info');
//								}
//							} 
//					)
//				}
//			})
//		}
		
		$scope.testConnection = function(){
			$http.post(basePath + "/dataSource/testConnection", $scope.dataSource)
			.success( function(result) 
					{
						if(result.success){
							//ami.dataSource.TestConnection.success
							$.messager.alert($.i18n.prop('ami.common.info'), $.i18n.prop('ami.dataSource.TestConnection.success'), 'info');
						}else{
							$.messager.alert($.i18n.prop('ami.common.warning'), $.i18n.prop('ami.dataSource.TestConnection.fail'), 'warning');
						}
					} 
			)
			
		}
		
		
//		$scope.tableUrl = basePath + '/dataSource/query';
//		
//		// 表格加载数据完成后，执行
//		$scope.$on("loadSuccess",function(e,data){
//			$compile($(data.target).find("td[field='operation'] > div"))($scope);// 手动编译表格最后一列，同步angularjs事件操作
//		});
	});
})(jQuery,app);
(function($, app) {
  "use strict";
  // 连接管理
  app.controller("dataSourceManagerCtrl", function($scope, $http, $timeout, $compile, $element, $permission) {
    // 权限按钮控制
    $permission.contains("/reflushDataSource", function(data) {
      $scope.showDataSourceRef = data;
    });

    $permission.contains("/editDataSource", function(data) {
      $scope.showDataSourceEdit = data;
    });

    $permission.contains("/deleteDataSource", function(data) {
      $scope.showDataSourceDel = data;
    });

    $permission.contains("/addDataSource", function(data) {
      $scope.showDataSourceAdd = data;
    });

    $permission.contains("/addCube", function(data) {
      if (!data) {
        $("#cubeAdd + div.panel .panel-tool").remove();
      }
    });

    $permission.contains("/editCube", function(data) {
      $scope.showCubeEdit = data;
    });

    $permission.contains("/deleteCube", function(data) {
      $scope.showCubeDel = data;
    });

    $permission.contains("/renameTableFiled", function(data) {
      $scope.showObjectEdit = data;
    });

    // 请求所有数据源
    $.ajax({
      type: "POST",
      url: basePath + "/dataSource/getAllDataList",
      dataType: "html",
      contentType: "application/json",
      data: {},
      success: function(result) {
        if (result) {
          result = JSON.parse(result);
        }
        if (result.success) {
          $scope.$apply(function() {
            $scope.dsList = eval(result.obj.dsList);
          });

        } else {
          $.messager.alert($.i18n.prop('ami.common.warning'), $.i18n.prop('ami.dataSource.getFailed'), 'warning');
        }
      }
    });

    refreshCubeList();
    
    $scope.urlMessChange = function(value){
    	if(undefined==value||''==value){
    		$("#urlMess").attr("placeholder","");
    	}
    	if('01'==value){
    		$("#urlMess").attr("placeholder","jdbc:oracle:thin:@127.0.0.1:1521:devdb");
    	}
    	if('02'==value){
    		$("#urlMess").attr("placeholder","jdbc:mysql://127.0.0.1:3306/mysql");
    	}
    }
    
    
    
    // 新增数据源
    $scope.addDataSourceNew = function() {

      $scope.dataSource = {};

      $.model($.i18n.prop('ami.dataSource.add'), basePath + "/dataSource/addPage", $scope.dataSource, function(result) {
        return $compile(result)($scope)
      }, function(m) {
        if ($(".easyui-form").form('enableValidation').form('validate')) {
          $.ajax({
            type: "POST",
            url: basePath + "/dataSource/genertateDsId",
            dataType: "html",
            contentType: "application/json",
            data: {},
            success: function(result) {
              if (result) {
                result = JSON.parse(result);
              }
              if (result.success) {
                $scope.$apply(function() {
                  $scope.dataSource.id = eval(result.obj.id);
                });

                $http.post(basePath + "/dataSource/save", $scope.dataSource || {}).success(function(result) {
                  if (result.success) {
                    $scope.dsList.unshift($scope.dataSource);
                    $.model.close(m);
                    $.messager.alert($.i18n.prop('ami.common.info'), $.i18n.prop('ami.common.save.success'), 'info');
                  }else{
                	  $.messager.alert($.i18n.prop('ami.common.warning'), result.msg, 'warning');
                  }
                })

              } else {
                $.messager.alert($.i18n.prop('ami.common.warning'), $.i18n.prop('ami.common.id.fail'), 'warning');
              }
            }
          });
        }

      });
    }
    // 请求所有立方
    function refreshCubeList() {
      $.ajax({
        type: "POST",
        url: basePath + "/cube/getAllCubeList",
        dataType: "html",
        contentType: "application/json",
        data: {},
        success: function(result) {
          if (result) {
            result = JSON.parse(result);
          }
          if (result.success) {
            $scope.$apply(function() {
              $scope.cubeList = eval(result.obj.cubeList);
            });
            if ($scope.cubeList.length > 0) {
              // 初始化调用生成树
              $scope.cube = $scope.cubeList[0];
              $scope.viewTree(null, $scope.cube);
            }else{
            	$scope.viewTree(null, null);
            }
          } else {
            $.messager.alert($.i18n.prop('ami.common.warning'), $.i18n.prop('ami.cube.get.fail'), 'warning');
          }
        }
      });
    }

    // 点击每个item，刷新下方立方区
    $scope.reflushItem = function($event, row) {
      $event.stopPropagation();// 阻止事件冒泡

      $scope.cube = {};
      $scope.cube.id = row.id;

      $.ajax({
        type: "POST",
        url: basePath + "/cube/getCubeListByDsId",
        dataType: "html",
        contentType: "application/json",
        data: JSON.stringify($scope.cube),
        success: function(result) {
          if (result) {
            result = JSON.parse(result);
          }
          if (result.success) {
            $scope.$apply(function() {
              $scope.cubeList = eval(result.obj.cubeList);
            });
            if ($scope.cubeList.length > 0) {
                // 初始化调用生成树
                $scope.cube = $scope.cubeList[0];
                $scope.viewTree(null, $scope.cube);
              }else{
            	  $scope.viewTree(null, null);
            }

          } else {
            $.messager.alert($.i18n.prop('ami.common.warning'), $.i18n.prop('ami.cube.refresh.fail'), 'warning');
          }
        }
      });

    }

    // 点击删除
    $scope.closeItem = function($event, row, index) {
      $event.stopPropagation();// 阻止事件冒泡
      $scope.dataSource = row;
      parent.$.messager.confirm($.i18n.prop('ami.common.info'), $.i18n.prop('ami.template.notice_message'), function(b) {
        if (b) {
          $http.post(basePath + "/dataSource/delete", JSON.stringify($scope.dataSource)).success(function(result) {
            if (result.success) {
              $scope.dsList.splice(index, 1);
              $.messager.alert($.i18n.prop('ami.common.info'), $.i18n.prop('ami.common.del.success'), 'info');
              // $("#dataSourceTable").datagrid('reload');

              refreshCubeList();
            }
          })
        }
      })

    }

    $scope.modifyItem = function($event, row, index) {
      $event.stopPropagation();// 阻止事件冒泡
      $scope.dataSource = angular.copy(row);
      $.model($.i18n.prop('ami.dataSource.edit'), basePath + "/dataSource/editPage", $scope.dataSource, function(result) {
        return $compile(result)($scope)
      }, function(m) {
        if ($(".easyui-form").form('enableValidation').form('validate')) {
          $http.post(basePath + "/dataSource/edit", $scope.dataSource || {}).success(function(result) {
            if (result.success) {
              $.model.close(m);
              $.messager.alert($.i18n.prop('ami.common.info'), $.i18n.prop('ami.common.edit.success'), 'info');
              angular.extend(row,$scope.dataSource);
              // $("#dataSourceTable").datagrid('reload');
            }
          })
        }
      });
    }
    $scope.refreshItem = function($event, row, index) {
      $event.stopPropagation();// 阻止事件冒泡
      $scope.dataSource = angular.copy(row);
      parent.$.messager.confirm($.i18n.prop('ami.common.info'), '是否更新数据源中所有表及表结构', function(b) {
        if (b) {
          $http.post(basePath + "/dataSource/updateTable", $scope.dataSource).success(function(result) {
            if (result.success) {
              $.messager.alert($.i18n.prop('ami.common.info'), '更新需要时间,请稍候查看', 'info');
            }
          })
        }
      })
    }

    // 点击删除
    $scope.closeCubeItem = function($event, row, index) {
      $event.stopPropagation();// 阻止事件冒泡
      $scope.cube = angular.copy(row);
      parent.$.messager.confirm($.i18n.prop('ami.common.info'), $.i18n.prop('ami.template.notice_message'), function(b) {
        if (b) {
          $http.post(basePath + "/cube/delete", JSON.stringify($scope.cube)).success(function(result) {
            if (result.success) {
              $scope.cubeList.splice(index, 1);
              $.messager.alert($.i18n.prop('ami.common.info'), $.i18n.prop('ami.common.del.success'), 'info');
              // $("#dataSourceTable").datagrid('reload');
            }
          })
        }
      })
    }

    // 点击添加立方
    $scope.addCubeItem = function(obj) {
      if (!obj) {
        // ami.cube.seldatasource
        $.messager.alert($.i18n.prop('ami.common.info'), $.i18n.prop('ami.cube.seldatasource'), 'info');
        return;
      } else {
        $scope.cube = {};
        $scope.cube.id = obj.id;

        $scope.tableList = [];
        $scope.selTableList = [];

        $.ajax({
          type: "POST",
          url: basePath + "/cube/genertateCubeId",
          dataType: "html",
          contentType: "application/json",
          data: {},
          success: function(result) {
            if (result) {
              result = JSON.parse(result);
            }
            if (result.success) {
              $scope.$apply(function() {
                $scope.cube.cubeId = eval(result.obj.id);
              });

              // 请求表列表
              $.ajax({
                type: "POST",
                url: basePath + "/cube/getTableListByDSId",
                dataType: "html",
                contentType: "application/json",
                data: JSON.stringify($scope.cube),
                success: function(result) {
                  if (result) {
                    result = JSON.parse(result);
                  }
                  if (result.success) {
                    $timeout(function() {
                      $scope.tableList = eval(result.obj.tableList);
                    }, 100);

                  } else {
                    $.messager.alert($.i18n.prop('ami.common.warning'), '获取数据源表列表失败', 'warning');
                  }
                }
              });

              $scope.cube.tableList = $scope.selTableList;
              $.model($.i18n.prop('ami.cube.add'), basePath + "/cube/addPage", $scope.cube || {}, function(result) {
                return $compile(result)($scope)
              }, function(m) {
                if ($(".easyui-form").form('enableValidation').form('validate')) {
                  $http.post(basePath + "/cube/save", $scope.cube || {}).success(function(result) {
                    if (result.success) {
                      $.model.close(m);
                      $.messager.alert($.i18n.prop('ami.common.info'), $.i18n.prop('ami.common.save.success'), 'info');
                      $scope.cubeList.unshift($scope.cube);

                      // $("#dataSourceTable").datagrid('reload');
                    }
                  })
                }

              });

            }

          }
        })
      }
    }
    $scope.addCubeTable = function($event, row, index) {
	  delete $scope.cube['leftIndex'];
      delete $scope.cube['leftCacheRow'];
      for (var i = 0; i < $scope.selTableList.length; i++) {
        var item = $scope.selTableList[i];
        if (item.tableName == row.tableName) { return; }
      }
      $scope.selTableList.push(row);
    }

    $scope.delCubeTable = function($event, row, index) {
      $scope.selTableList.remove(row);
      delete $scope.cube['rightIndex'];
      delete $scope.cube['rightCacheRow'];
    }

    $scope.selectedRow=function(row,direction){
    	$scope.cube[direction+'CacheRow']=row;
    }
    
    $scope.toTarget=function(direction){
    	var $$row = $scope.cube[direction+'CacheRow'];
    	if(!$$row)
    	{
    		$.messager.alert($.i18n.prop('ami.common.info'),$.i18n.prop('ami.cube.messager.cube'),"info");
    		return;
    	}
    	
    	if(direction==='left') { $scope.addCubeTable(null,$$row,null); }	else { $scope.delCubeTable(null,$$row,null); }
    }
    
    // 修改立方
    $scope.modifyCubeNew = function($event, row, index) {
      $event.stopPropagation();// 阻止事件冒泡

      $scope.cube = {};
      $scope.cube = angular.copy(row);;

      $scope.tableList = [];
      $scope.selTableList = [];

      // 请求表列表
      $.ajax({
        type: "POST",
        url: basePath + "/cube/getTableListByDSId",
        dataType: "html",
        contentType: "application/json",
        data: JSON.stringify($scope.cube),
        success: function(result) {
          if (result) {
            result = JSON.parse(result);
          }
          if (result.success) {
            $scope.$apply(function() {
              $scope.tableList = eval(result.obj.tableList);
            });

          } else {
            $.messager.alert($.i18n.prop('ami.common.warning'), '获取数据源表列表失败', 'warning');
          }
        }
      });

      // 请求已添加表列表
      $.ajax({
        type: "POST",
        url: basePath + "/cube/getTableListByCubeId",
        dataType: "html",
        contentType: "application/json",
        data: JSON.stringify($scope.cube),
        success: function(result) {
          if (result) {
            result = JSON.parse(result);
          }
          if (result.success) {
            $scope.$apply(function() {
              $scope.selTableList = eval(result.obj.selTableList);
            });

          } else {
            $.messager.alert($.i18n.prop('ami.common.warning'), '获取已添加表列表失败', 'warning');
          }
        }
      });

      $.model($.i18n.prop('ami.cube.edit'), basePath + "/cube/editPage", $scope.cube, function(result) {
        return $compile(result)($scope)
      }, function(m) {
        if ($(".easyui-form").form('enableValidation').form('validate')) {
          $scope.cube.tableList = $scope.selTableList;
          $http.post(basePath + "/cube/edit", $scope.cube || {}).success(function(result) {
            if (result.success) {
              $.model.close(m);
              $.messager.alert($.i18n.prop('ami.common.info'), $.i18n.prop('ami.common.edit.success'), 'info');
              angular.extend(row,$scope.cube);
              // $("#dataSourceTable").datagrid('reload');
            }
          })
        }
      });
    }
    // 树
    $scope.demo = {};
    $scope.viewTree = function($event, c) {
      $scope.treeSearch = "";
      var e = $event || window.event;
      e.stopPropagation();// 阻止事件冒泡
      
      if(null==c || undefined == c){
    	  $scope.$apply(function() {
              $scope.demo.tree = [];
    	  })
      }else{
    	  $.ajax({
    	        type: "POST",
    	        url: basePath + "/cube/getTableTreeByCubeId",
    	        dataType: "html",
    	        contentType: "application/json",
    	        data: JSON.stringify(c),
    	        success: function(result) {
    	          if (result) {
    	            result = JSON.parse(result);
    	          }
    	          if (result.success) {
    	            $scope.$apply(function() {
    	              $scope.demo.tree = eval(result.obj.list);
    	              $scope.demo.tree.push({
    	                "id": c.id,
    	                "dsId": c.id,
    	                "name": c.cubeName,
    	                parentId: "",
    	                treeId: c.cubeId,
    	                editable: false
    	              });
    	            });

    	          } else {
    	            $.messager.alert($.i18n.prop('ami.common.warning'), '获取失败', 'warning');
    	          }
    	        }
    	      });
      }
      
    }

    // 重命名
    $scope.rename = function($item) {
      // 重命名 字段别名
      // alert($item.name);
    	
    	if($item.name==""){
    		$item.name = $item.tableFiled;
    		return;
    	}

      $scope.tableFiled = {};
      $scope.tableFiled.id = $item.id;
      $scope.tableFiled.tableName = $item.tableName;
      $scope.tableFiled.tableFiled = $item.tableFiled;
      $scope.tableFiled.tableFiledAlias = $item.name;
      $.ajax({
        type: "POST",
        url: basePath + "/cube/reNameTableFiledAlias",
        dataType: "html",
        contentType: "application/json",
        data: JSON.stringify($scope.tableFiled),
        success: function(result) {
          if (result) {
            result = JSON.parse(result);
          }
          if (result.success) {

          } else {
            $.messager.alert($.i18n.prop('ami.common.warning'), '字段别名修改失败', 'warning');
          }
        }
      });
    }

    $scope.sure = function() {
      var checkedData = $.tree($scope.demo.tree).checked;
      var content = [];
      angular.forEach(checkedData, function(data, index) {
        content.push(data.name);
      });
      $scope.content = content.join(",");
    }
  });
})(jQuery, app);(function($,app){
	"use strict";
	
	// 跳转测试用。。。。======================================
	app.controller("jsPlumbCtrl",function($scope,$http,$timeout,$compile,$element){
		// 页面初始化时生成流程图
		$scope.$watch('$viewContentLoaded', function() {
		var domId = "window";	
		// 初始化画图工具
		var instance = $.jsplumb("canvas");
		jsPlumbUtil.logEnabled=false;
		instance.reset();//* 词句非常重要，进入ctrl方法必须将jsplumb内存重置（销毁）
		
		var popoverHTML = [
										'<div class="flowpopover">',
										'<div  class="row">',
											'<div class="form-group col-sm-12 ami-menu-group">',
												'<label class="ami-float control-label">'+$.i18n.prop("ami.report.popover.label")+': </label>',
												'<div class="ami-float">',
												    '<select class="form-control" ng-model="popover.relatedWays">',
												    	'<option ng-repeat="item in popover.relatedWaysOptions" value="{{item}}">{{item}}</option>',
												    '</select>',
												'</div>',
											'</div>',
										'</div>',
										'<div  class="row">',
												'<label class="control-label col-sm-6 ami-menu-group" ng-bind="popover.tableName1"></label>',
												'<label class="control-label col-sm-6 ami-menu-group" ng-bind="popover.tableName2"></label>',
										'</div>',
										'<div  class="row" ng-repeat="field in popover.fieldList track by $index">',
											'<div class="col-sm-5 ami-menu-group">',
												   '<select class="form-control"  ng-model="field.sourceModel">',
												   		'<option ng-repeat="item in popover.fieldList1" value="{{item}}">{{item}}</option>',
												    '</select>',
										    '</div>',		    
										    '<div class="col-sm-1 ami-menu-group ami-panel-header"><label class="control-label">=</label></div>',
											'<div class="col-sm-5 ami-menu-group">',
											     '<select class="form-control" ng-model="field.targetModel">',
											     		'<option ng-repeat="item in popover.fieldList2" value="{{item}}">{{item}}</option>',
											     '</select>',
										   '</div>',
										   '<div ng-if="$index==0" class="col-sm-1 ami-menu-group ami-panel-header">',
													'<span class="glyphicon glyphicon-plus" ng-click="addItem()"></span>&nbsp;&nbsp;',
													'<span class="glyphicon glyphicon-minus" ng-click="removeItem()"></span>',
										   '</div>',
										'</div>	',
										'<div  class="row">',
											'<div class="col-sm-11 ami-menu-group btn-align">',
												'<button type="button" class="btn btn-info ami-save" ng-click="saveConnection(connection,$event)">'+$.i18n.prop("ami.report.sure")+'</button>&nbsp;&nbsp;',
												'<button type="button" class="btn btn-default ami-close" ng-click="popoverHide($event)">'+$.i18n.prop("ami.common.cancel")+'</button>',
											'</div>',
										'</div>',
										'</div>'].join("");
		
		
		$scope.popover={};
		$scope.popover.relatedWaysOptions = ["left join","right join","inner join"];
		$scope.popoverHide=function($event){$(".popover").remove();}
		$scope.saveConnection=function(conn,$event){
			conn.getOverlay("label").setLabel($scope.popover.relatedWays);
			if(!$(conn).data("serviceData")) { createSingleConnection(conn); }// 如果不存在，则需要重新绑定连接数据
			$(conn).data("serviceData").label=$scope.popover.relatedWays;
			$(conn).data("serviceData").fieldList=$scope.popover.fieldList;
			// 入库保存。。。。。
			$scope.popoverHide($event);
		}
		$scope.addItem=function(){
			$scope.popover.fieldList.push({sourceModel:"",targetModel:""});
		}
		
		$scope.removeItem=function(){
			if($scope.popover.fieldList.length > 1)
			{
				$scope.popover.fieldList.pop();
			}	
		}
		
		// 连接label点击事件触发
		function popover(connection,event){
			$scope.popover.tableName1 = connection.target.innerText;
			$scope.popover.tableName2 = connection.source.innerText;
			$scope.popover.relatedWays = connection.getOverlay("label").getLabel() || "";
			var oldfieldList = $(connection).data("serviceData") ?  $(connection).data("serviceData").fieldList : [];
			var fieldList = [];
			angular.copy(oldfieldList,fieldList);
			$scope.popover.fieldList = fieldList && fieldList.length > 0 ?  fieldList : [{sourceModel:"",targetModel:""}];
			$scope.popover.fieldList1 = getFieldListByNodeName($scope.dataSourceTables,$scope.popover.tableName1);// 下拉框列表
			$scope.popover.fieldList2 = getFieldListByNodeName($scope.dataSourceTables,$scope.popover.tableName2);// 下拉框列表
			$scope.connection = connection;
			$(event.target).pop(popoverHTML,"#canvas",$compile,$scope);
			if(!$(event.target).next("div.popover").length){$(event.target).popover("show");}
		}
		
		$scope.dataSourceTables = [];
		// 页面元素保存的数据
		$scope.dataSourceItems = [];
		
		// 左边表形成对象树
		$http({
		    method: 'post',
		    url: ''
		}).success(function(data){
			// 构造表结构数据
			data = [
			        {id:0,name:'表结构',parentId:-1},
			        {id:1,name:'T_SYS_USER',parentId:0,draggable:true,fieldList:["字段1","字段2","字段3"]},
			        {id:2,name:'T_REPORT_DATASOURCE',parentId:0,draggable:true,fieldList:["字段11","字段22","字段33"]},
			        {id:3,name:'T_SYS_ROLE',parentId:0,draggable:true,fieldList:["字段111","字段222","字段333"]},
			        {id:4,name:'T_SYS_CUSTOMER',parentId:0,draggable:true,fieldList:["字段1111","字段2222","字段3333"]}
			        ];
			
			$scope.dataSourceTables = data;
			// 需要查询数据库获取数据,也是需要入库持久化的数据
			// 页面画图布局
			$scope.dataSourceItems =  [
							{
								nodeId:1,
								nodeName:'T_SYS_USER',
								parentId:undefined,
								style:{"left":117.156,"top":215},
							},
							{
								nodeId:2,
								nodeName:'T_REPORT_DATASOURCE',
								parentId:'window1',
								style:{"left":400.283,"top":215},
								connectLine:{
					            	  target:"window2-Left",
					            	  source:"window1-Right",
					            	  label:"right join",
					            	  fieldList:[{sourceModel:"字段2",targetModel:'字段33'},{sourceModel:"字段3",targetModel:'字段22'}]
					              }
							}
			            ];
			});
		
		// 删除节点
		$scope.closeNode = function(item,$event){
			$scope.dataSourceItems.remove(item);
			$(".popover").remove();
			if(!$event)return;
			$scope.prevRemoveNode = item;
		}
		
		function getFieldListByNodeName(list,nodeName)
		{
			var fieldList = null;
			$.each(list,function(i,n){ if(n.name===$.trim(nodeName)) { fieldList = n.fieldList; return false; } });
			return fieldList || [];
		}
		
		function createSingleConnection(conn)
		{
			$(conn).data("serviceData",{
				target:conn.getUuids()[0],
				source:conn.getUuids()[1],
            	label:conn.getOverlay("label").getLabel(),
            	fieldList:[]
			});
		}
		
		// 监听流程图是否已经有当前节点，如果重复，则不允许拖拽
		$scope.$watch("dataSourceItems",function(n,o){
			var flowIds = [];
			angular.forEach(n,function(v,i){ flowIds.push(v.nodeId); });
			angular.forEach($scope.dataSourceTables,function(s,j){
				if(s.hasOwnProperty("draggable")) { s.draggable = $.inArray(s.id,flowIds) < 0;s.disabled=!s.draggable;}
				$scope.treeDrag(s);
			});
			// 内部存在timeout延迟操作，这是必要的，否则js先执行而页面后加载，导致连接线不显示问题。后续有待优化
			$scope.completeCallback(domId);
		},true);
		
		$scope.$watch("treeSearch",function(n,o){
			if(n==undefined)return;
			$timeout(function(){
				angular.forEach($scope.dataSourceTables,function(s,j){
					$scope.treeDrag(s);
				});
			},50)
		})
		
		$scope.completeCallback=function(flowId)
		{
			$timeout(function(){
				instance.reset();//* 词句非常重要，进入ctrl方法必须将jsplumb内存重置（销毁）
				angular.forEach($scope.dataSourceItems,function(item,i){
					$.jsplumb.addPoint(instance,flowId + item.nodeId);
					if(item.connectLine && !$.jsplumb.connect(instance,item.connectLine))
					{
						$scope.closeNode(item);// 如果连接失败，则删除当前节点
					}	
					instance.unbind("click").bind("click",function(connection,event){
						if($(event.target).hasClass("aLabel"))
						{
							popover(connection,event);
						}
					})
				});
				
				angular.forEach($scope.retainItem,function(item,i){
					if(!item.parentId)return;
					var jtkNode = $("#" + item.parentId);
					//	 var left=jtkNode.position().left + jtkNode.width() + 200;
					var p = jtkNode.position();
					if(!p)return;
					var top=p.top + i * (80 + jtkNode.height());
					animateTop(item,top)
					// 将此节点下的所有子节点按top偏移
					angular.forEach($scope.childeNodes[domId + item.nodeId],function(child,index){
						animateTop(child,top)
					})
				})
			})
		}
		
		function animateTop(dom,top)
		{
			var $$dom = $("#" + domId + dom.nodeId);
			instance.animate($$dom[0],{top:top},{complete:function(){
				$scope.$apply(function(){dom.style.top=top;});
			}});
		}
		
		// 判断删除节点时，对当前节点下所有的平级节点进行位置适应.
		$scope.$watch("prevRemoveNode",function(n,o){
			if(n && n.connectLine)
			{
				$scope.retainItem =[];
				$scope.childeNodes={};
				var source =  n.connectLine.source;// 指向同一个父节点的元素
				angular.forEach($scope.dataSourceItems,function(item,i){
					if(item.connectLine && item.connectLine.source === source)
					{
						$scope.retainItem.push(item);
						$scope.childeNodes[domId + item.nodeId] = [];
					}
				});
				
				angular.forEach($scope.retainItem,function(target,i){
					findeNodes(target,$scope.childeNodes)
				});
			}	
		});
		
		function findeNodes(target,childeNodes)
		{
			angular.forEach($scope.dataSourceItems,function(item,i){
				if((domId + target.nodeId) === item.parentId)
				{
					childeNodes[domId + target.nodeId].push(item);
					findeNodes(item,childeNodes);
				}	
			});
		}
		
		// 拖拽生成表关联关系
		$scope.treeDrag = function(item) {
			var $$drag = $('#drag-tree-' + item.id);
			$$drag.draggable({ revert : true, deltaX : 0, deltaY : 0,
							   proxy : function(source) {var p = $('<div class="drag-item"></div>'); p.html($(source).text()).appendTo('body'); return p; },
								onBeforeDrag : function(e) {
									$("#flowchart_box").droppable({accept : '#drag-tree-' + item.id,
										onDrop : function(e, source) {
											// 默认显示位置
											var node = {
												nodeId:item.id,
												nodeName:item.name,
												style:{"left":event.pageX - $(e.target).offset().left,"top":event.pageY - $(e.target).offset().top}
											}
											// 判断鼠标落座的标签是否是在节点上
											var jtkNode = $(event.target).closest("div.jtk-node");
											
											// 判断放置区域内是否已经存在root节点，若存在则不允许重新拖拽新元素入放置区
											if($scope.dataSourceItems.length == 0 || jtkNode.length)
											{
												$scope.$apply(function(){node.parentId=undefined;$scope.dataSourceItems.push(node);/* 动态生成flow流程图item项*/});
											}	
											
											if(jtkNode.length)
											{
												var target = $("#" + domId + node.nodeId);
												var left,top;
												var sourceId = jtkNode.attr("id"),targetId = target.attr("id");
												var options ={complete:function(el){
													// 自动连接时构造连接线对象
													var conn = { target:targetId + "-Left", source:sourceId + "-Right", label:$scope.popover.relatedWaysOptions[0], fieldList:[{sourceModel:"",targetModel:""}]}; 
													$scope.$apply(function(){
														node.style.left=$(el).position().left;
														node.style.top=$(el).position().top;
														node.parentId=sourceId;
														node.connectLine=conn;
													});
												}};
												
												// 位置自适应动画
												var targetItems=[]
												angular.forEach(instance.getAllConnections(),function(conn,i){
													if(sourceId === conn.targetId)targetItems.push(conn);
												});
												left=jtkNode.position().left + jtkNode.width() + 200;
												top=jtkNode.position().top + (targetItems.length) * (80 + jtkNode.height());
												instance.animate(target[0],{left:left,top:top},options);
											}	
										}
									});
								}
							 });
			$$drag.draggable(item.draggable ? "enable" : "disable");
			}
		});
	});
})(jQuery,app);
(function ($, app) {
    "use strict";
    // 模板管理
    app.controller("chooseObjectTreeCtrl", function ($scope, $http, $timeout, $compile, $element) {

        $scope.objectTreeData = {};

        function pushData() {
            $scope.objectTree;
            $.ajax({
                type: "POST",
                url: basePath + "/objectTree/getObjectTreeForChoose",
                dataType: "html",
                contentType: "application/json",
                data: JSON.stringify($scope.objectTree),
                success: function (result) {
                    if (result) {
                        result = JSON.parse(result);
                    }
                    if (result.success) {
                        $timeout(function () {
                            $scope.objectTreeData = eval(result.obj.list);
                        });
                        // $scope.$apply(function(){
                        // $scope.objectTreeData = eval(result.obj.list);
                        // });

                    } else {
                        $.messager.alert($.i18n.prop('ami.common.warning'), $.i18n.prop('ami.role.waring_message'), 'warning');
                    }
                }
            });
        }

        pushData();

        // 双击回填input
        $scope.choose = function (item) {
            var $$treeId = $scope.$parent.objectTree.id;
            $("input[id^='" + $$treeId + "_treeName_" + "']").searchbox("setValue", item.treeName);
            parent.$("#objectTreeTable").datagrid("getSelected").treeCode = item.treeCode;
            parent.$("#objectTreeTable").datagrid("getSelected").treeId = item.treeId;
            parent.$("#objectTreeTable").datagrid("getSelected").treeName = item.treeName;
            $("#objectTreeCloseBtn").trigger("click");
        }
    });
})(jQuery, app)
;
(function($, app) {
  "use strict";
  // 模板管理
  app.controller("objectTreeCtrl", function($scope, $http, $timeout, $compile, $element, $permission) {

    $scope.tableHeader = [{
      field: 'id',
      title: 'ID',
      width: '10%',
      align: 'left',
      hidden: 'true'
    }, {
      field: 'name',
      title: $.i18n.prop('ami.object.name'),
      width: '30%',
      align: 'left'
    }, {
      field: 'desc',
      title: $.i18n.prop('ami.object.desc'),
      width: '40%',
      align: 'left',
    }, {
      field: 'operation',
      title: $.i18n.prop('ami.common.func'),
      width: '20%',
      align: 'left',
      formatter: function(value, row, index) {
        $scope['rowData_' + index] = row;
        var str = '';
        str += ' <shiro:hasPermission name="assetInfo/query">';
        str += '<a href="javascript:void(0)" ng-if="showEdit" ng-click="editObjectFn(rowData_' + index + ')">' + $.i18n.prop('ami.common.edit') + '</a>';
        str += '</shiro:hasPermission>';
        str += ' | ';
        str += '<a href="javascript:void(0)" ng-if="showMaintain" ng-click="maintainObjectFn(rowData_' + index + ')">' + $.i18n.prop('ami.common.maintain') + '</a>';
        str += ' | ';
        str += '<a href="javascript:void(0)" ng-if="showDelete" ng-click="deleteObjectFn(rowData_' + index + ')">' + $.i18n.prop('ami.common.delete') + '</a>';
        return str;
      }
    }];

    $scope.tableUrl = basePath + '/objectTree/query';

    // 新增
    $scope.addObjectTree = function(row) {
      $scope.objectTree = {};
      $.model($.i18n.prop('ami.common.add'), basePath + "/objectTree/addPage", $scope.objectTree, function(result) {
        return $compile(result)($scope)
      }, function(m) {
        $http.post(basePath + "/objectTree/save", $scope.objectTree || {}).success(function(result) {
          if (result.success) {
            $.model.close(m);
            $.messager.alert($.i18n.prop('ami.common.info'), $.i18n.prop('ami.common.save.success'), 'info');
            $("#objectTreeTableSet").datagrid('reload');
          }
        })
      });
    }

    $scope.editObjectFn = function(row) {
      $scope.objectTree = row;
      $.model($.i18n.prop('ami.common.edit'), basePath + "/objectTree/editPage", $scope.objectTree, function(result) {
        return $compile(result)($scope)
      }, function(m) {
        $http.post(basePath + "/objectTree/edit", $scope.objectTree || {}).success(function(result) {
          if (result.success) {
            $.model.close(m);
            $.messager.alert($.i18n.prop('ami.common.info'), result.msg, 'success');
            $("#objectTreeTableSet").datagrid('reload');
          } else {
            $.messager.alert($.i18n.prop('ami.common.info'), result.msg, 'error');
          }
        })
      });
    }

    $scope.maintainObjectFn = function(row) {
      $scope.objectTree = row;

      var treeObjectUrl = basePath + "/objectTree/maintainPage";
      if ($("#main").tabs("exists", $.i18n.prop('ami.object.maintain'))) {
        $("#main").tabs('select', $.i18n.prop('ami.object.maintain'));
        updateTab($("#main"), treeObjectUrl, $scope.objectTree);
        return;
      }

      $http.post(treeObjectUrl, $scope.objectTree).success(function(result) {
        $("#main").tabs('add', {
          title: $.i18n.prop('ami.object.maintain'),
          content: $compile(result)($scope.$new()),
          closable: true
        });
      })

    }

    function updateTab($tab, url, obj) {

      $http.post(url, obj).success(function(result) {
        var tab = $tab.tabs("getSelected");
        $tab.tabs('update', {
          tab: tab,
          options: {
            content: $compile(result)($scope.$new())
          }
        });
      })

      // $.post(url,angular.toJson(obj),function(result){
      // var tab = $tab.tabs("getSelected");
      // $tab.tabs('update', { tab: tab, options: {
      // content: $compile(result)($scope.$new()) } });
      // });
    }

    $scope.deleteObjectFn = function(row) {
      $scope.objectTree = row;
      parent.$.messager.confirm('info', $.i18n.prop('ami.template.notice_message'), function(b) {
        if (b) {
          $http.post(basePath + "/objectTree/delete", $scope.objectTree || {}).success(function(result) {
            if (result.success) {
              $.messager.alert($.i18n.prop('ami.common.info'), result.msg, 'success');
              $("#objectTreeTableSet").datagrid('reload');
            } else {
              $.messager.alert($.i18n.prop('ami.common.info'), result.msg, 'error');
            }
          })
        }
      })
    }

    // 表格加载数据完成后，执行
    $scope.$on("loadSuccess", function(e, data) {
      $compile($(data.target).find("td[field='operation'] > div"))($scope);// 手动编译表格最后一列，同步angularjs事件操作

      $permission.contains("/addObjTree", function(data) {
        $scope.showAdd = data;
      });
      $permission.contains("/editObjTree", function(data) {
        $scope.showEdit = data;
      });
      $permission.contains("/maintainObjTree", function(data) {
        $scope.showMaintain = data;
      });
      $permission.contains("/deleteObjTree", function(data) {
        $scope.showDelete = data;
      });
    });
  });
})(jQuery, app)
;
(function($, app) {
  "use strict";
  // 模板管理
  app.controller("objectTreeNodeCtrl", function($scope, $http, $timeout, $compile, $element) {

    $scope.objectTreeData = {};
    function pushData() {
      $scope.objectTree;
      $.ajax({
        type: "POST",
        url: basePath + "/objectTree/getObjectTreeByObjectId",
        dataType: "html",
        contentType: "application/json",
        data: JSON.stringify($scope.objectTree),
        success: function(result) {
          if (result) {
            result = JSON.parse(result);
          }
          if (result.success) {
            $timeout(function() {
              $scope.objectTreeData = eval(result.obj.list);
            });
            // $scope.$apply(function(){
            // $scope.objectTreeData = eval(result.obj.list);
            // });

          } else {
            $.messager.alert($.i18n.prop('ami.common.warning'), $.i18n.prop('ami.role.waring_message'), 'warning');
          }
        }
      });
    }
    pushData();

    // 获取生成id
    $scope.addObjectTreeRoot = function() {
      var id = $scope.objectTree.id;
      $scope.objectTreeNode = {};
      $scope.objectTreeNode.objectTreeId = id;
      $scope.objectTreeNode.level = 1;

      // 先生成节点id
      $.ajax({
        type: "POST",
        url: basePath + "/objectTree/genertateId?date=" + new Date(),
        dataType: "html",
        contentType: "application/json",
        data: {},
        async: false,
        success: function(result) {
          if (result) {
            result = JSON.parse(result);
          }
          if (result.success) {
            $scope.objectTreeNode.treeId = eval(result.obj.id);

          } else {
            $.messager.alert($.i18n.prop('ami.common.warning'), $.i18n.prop('ami.object.id_fail'), 'warning');
          }
        }
      });

      $.model($.i18n.prop('ami.object.add_node'), basePath + "/objectTree/addRootNodePage", $scope.objectTreeNode, function(result) {
        return $compile(result)($scope)
      }, function(m) {

        if ($scope.objectTreeData.length == 0) {
        	if ($(".easyui-form").form('enableValidation').form('validate')) {
	          $http.post(basePath + "/objectTree/saveRootNode", $scope.objectTreeNode || {}).success(function(result) {
	            if (result.success) {
	              $scope.objectTreeNode.level = 1;
	              $scope.objectTreeData.push($scope.objectTreeNode);
	              $.model.close(m);
	              $.messager.alert($.i18n.prop('ami.common.info'), result.msg, 'success');
	            } else {
	              $.messager.alert($.i18n.prop('ami.common.info'), result.msg, 'error');
	            }
	          })
        	}
        } else {
          $.model.close(m);
          $.messager.alert($.i18n.prop('ami.common.info'), $.i18n.prop('ami.object.add_message'), 'info');
        }

      });

    }

    $scope.addTreeNode = function(v) {
      var id = $scope.objectTree.id;
      $scope.objectTreeNode = {};
      $scope.objectTreeNode.objectTreeId = id;
      $scope.objectTreeNode.level = v.level++;
      $scope.objectTreeNode.treePid = v.treeId;

      // 先生成节点id
      $.ajax({
        type: "POST",
        url: basePath + "/objectTree/genertateId?date=" + new Date(),
        dataType: "html",
        contentType: "application/json",
        data: {},
        async: false,
        success: function(result) {
          if (result) {
            result = JSON.parse(result);
          }
          if (result.success) {
            $scope.objectTreeNode.treeId = eval(result.obj.id);
          } else {
            $.messager.alert($.i18n.prop('ami.common.warning'), $.i18n.prop('ami.object.id_fail'), 'warning');
          }
        }
      });

      $.model($.i18n.prop('ami.object.add'), basePath + "/objectTree/addNodePage", $scope.objectTreeNode, function(result) {
        return $compile(result)($scope)
      }, function(m) {
    	  if ($(".easyui-form").form('enableValidation').form('validate')) {
	        $http.post(basePath + "/objectTree/saveNode", $scope.objectTreeNode || {}).success(function(result) {
	          if (result.success) {
	            $.model.close(m);
	            $.messager.alert($.i18n.prop('ami.common.info'), result.msg, 'success');
	            $scope.objectTreeData.push($scope.objectTreeNode);
	          } else {
	            $.messager.alert($.i18n.prop('ami.common.info'), result.msg, 'error');
	          }
	        })
    	  }
      });
    }
    $scope.eidtTreeNode = function(v) {
      var id = $scope.objectTree.id;
      $scope.objectTreeNode = {};
      $scope.objectTreeNode.objectTreeId = id;
      $scope.objectTreeNode = angular.copy(v);
      $.model($.i18n.prop('ami.object.edit'), basePath + "/objectTree/editNodePage", $scope.objectTreeNode, function(result) {
        return $compile(result)($scope)
      }, function(m) {
    	  if ($(".easyui-form").form('enableValidation').form('validate')) {
	        $http.post(basePath + "/objectTree/editNode", $scope.objectTreeNode || {}).success(function(result) {
	          if (result.success) {
	            $.model.close(m);
	            $.messager.alert($.i18n.prop('ami.common.info'), result.msg, 'success', function() {
	              $scope.$apply(function() {
	                angular.extend(v, $scope.objectTreeNode);
	              })
	            });
	          } else {
	            $.messager.alert($.i18n.prop('ami.common.info'), result.msg, 'error');
	          }
	        })
    	  }
      });
    }

    $scope.removeTreeNode = function(v) {
      var id = $scope.objectTree.id;
      $scope.objectTreeNode = {};
      $scope.objectTreeNode.objectTreeId = id;
      $scope.objectTreeNode.treeId = v.treeId;

      if (v.children) {
        $.messager.alert($.i18n.prop('ami.common.info'), $.i18n.prop('ami.object.delete_message'), 'info');
      } else {
        $http.post(basePath + "/objectTree/delNode", $scope.objectTreeNode || {}).success(function(result) {
          if (result.success) {

            // 删除节点
            var _arr = $scope.objectTreeData;
            var _obj = $scope.objectTreeNode;
            var length = _arr.length;
            for (var i = 0; i < length; i++) {
              if (_arr[i].treeId == _obj.treeId) {
                if (i == 0) {
                  _arr.shift(); // 删除并返回数组的第一个元素
                  return;
                } else if (i == length - 1) {
                  _arr.pop(); // 删除并返回数组的最后一个元素
                  return;
                } else {
                  _arr.splice(i, 1); // 删除下标为i的元素
                  return;
                }
              }
            }

            $.messager.alert($.i18n.prop('ami.common.info'), result.msg, 'success');
          } else {
            $.messager.alert($.i18n.prop('ami.common.info'), result.msg, 'error');
          }
        })
      }

    }

    // 双击回填input
    $scope.choose = function(item) {
      var $$treeId = $scope.$parent.objectTree.id;
      $("input[id^='" + $$treeId + "_treeName_" + "']").searchbox("setValue", item.treeName);
      $("#objectTreeTable").datagrid("getSelected").treeCode = item.treeCode;
      $("#objectTreeCloseBtn").trigger("click");
    }
  });
})(jQuery, app)
;
(function ($, app) {
    "use strict";
    // 模板管理
    app.controller("reportFileCtrl", function ($scope, $http, $timeout, $compile, $element, $permission) {
        $scope.tableHeader = [{
            field: 'reportName',
            title: $.i18n.prop('ami.file.name'),
            width: '15%',
            align: 'left',
            formatter: function (value) {
                return value && "<span title='" + value + "'>" + value + "</span>";
            }
        }, {
            field: 'reportType',
            title: $.i18n.prop('ami.file.type'),
            width: '6%',
            align: 'left',
            formatter: function (value) {
                switch (value) {
                    case "0":
                        return "<span title='" + $.i18n.prop('ami.common.daily') + "'>" + $.i18n.prop('ami.common.daily') + "</span>";
                    case "1":
                        return "<span title='" + $.i18n.prop('ami.common.monthly') + "'>" + $.i18n.prop('ami.common.monthly') + "</span>";
                    default:
                        return value;
                }
            }
        }, {
            field: 'tempName',
            title: $.i18n.prop('ami.file.tmpName'),
            width: '10%',
            align: 'left',
            formatter: function (value) {
                return value && "<span title='" + value + "'>" + value + "</span>";
            }
        }, {
            field: 'tmpKey',
            title: $.i18n.prop('ami.file.tmpKey'),
            width: '8%',
            align: 'left',
            formatter: function (value) {
                return value && "<span title='" + value + "'>" + value + "</span>";
            }
        }, {
            field: 'reportStatus',
            title: $.i18n.prop('ami.file.status'),
            width: '6%',
            align: 'left',
            formatter: function (value) {
                return value && "<span title='" + value + "'>" + value + "</span>";
            }
        }, {
            field: 'reportDesc',
            title: $.i18n.prop('ami.file.reportDesc'),
            width: '13%',
            align: 'left',
            formatter: function (value) {
                return value && "<span title='" + value + "'>" + value + "</span>";
            }
        }, {
            field: 'reportPath',
            title: $.i18n.prop('ami.file.reportPath'),
            width: '10%',
            align: 'left',
            formatter: function (value) {
                return value && "<span title='" + value + "'>" + value + "</span>";
            }
        }, {
            field: 'userName',
            title: $.i18n.prop('ami.file.user'),
            width: '10%',
            align: 'left',
            formatter: function (value) {
                return value && "<span title='" + value + "'>" + value + "</span>";
            }
        }, {
            field: 'createTime',
            title: $.i18n.prop('ami.file.createTime'),
            width: '10%',
            align: 'left'
        }, {
            field: 'operation',
            title: $.i18n.prop('ami.common.func'),
            width: '12%',
            align: 'left',
            formatter: function (value, row, index) {
                $scope['rowData_' + index] = row;
                var str = '';
                str += '<a href="javascript:void(0)" ng-if="showSee" ng-click="viewFn(rowData_' + index + ')">' + $.i18n.prop("ami.file.view") + '</a>';
                str += ' | ';
                str += '<a href="javascript:void(0)" ng-if="showDown" ng-click="downloadFn(rowData_' + index + ')">' + $.i18n.prop("ami.file.download") + '</a>';
                str += ' | ';
                str += '<a href="javascript:void(0)" ng-if="showEdit" ng-click="editFn(rowData_' + index + ')">' + $.i18n.prop("ami.common.edit") + '</a>';
                str += ' | ';
                str += '<a href="javascript:void(0)" ng-if="showDelete" ng-click="deleteFn(rowData_' + index + ')">' + $.i18n.prop("ami.common.delete") + '</a>';
                return str;
            }
        }];

        $scope.tableUrl = basePath + '/reportFile/datagrid';

        $scope.submit = function () {
            $.reload('reportFileTable', null, serializeObject($("#reportFileFrom")));
        };

        $scope.downloadFn = function (row) {
            window.location.href = basePath + "/reportFile/download?id=" + row.reportId;
        };

        $scope.editFn = function (row) {
            $scope.reportFile = angular.copy(row) || {};
            $.model($.i18n.prop("ami.file.editReport"), basePath + "/reportFile/editPage", $scope.reportFile, function (result) {
                return $compile(result)($scope)
            }, function (m) {
                if ($(".easyui-form").form('enableValidation').form('validate')) {
                    $http.post(basePath + "/reportFile/edit", $scope.reportFile || {}).success(function (result) {
                        if (result.success) {
                            $.model.close(m);
                            $.messager.alert($.i18n.prop("ami.common.prompt"), result.msg, 'success');
                            $("#reportFileTable").datagrid('reload');
                        } else {
                            $.messager.alert($.i18n.prop("ami.common.prompt"), result.msg, 'error');
                        }
                    })
                }

            });
        };

        $scope.deleteFn = function (row) {
            $scope.reportFile = row;
            parent.$.messager.confirm('info', $.i18n.prop("ami.common.isDel"), function (b) {
                if (b) {
                    $http.post(basePath + "/reportFile/delete", $scope.reportFile || {}).success(function (result) {
                        if (result.success) {
                            $.messager.alert($.i18n.prop("ami.common.prompt"), result.msg, 'success');
                            $("#reportFileTable").datagrid('reload');
                        } else {
                            $.messager.alert($.i18n.prop("ami.common.prompt"), result.msg, 'error');
                        }
                    })
                }
            })
        };

        $scope.viewFn = function (row) {
            $scope.reportId = row.reportId;


            $http.get(basePath + "/reportFile/viewPage?id=" + row.reportId).success(function (result) {
                var main = $("#main");
                var title = $.i18n.prop("ami.file.viewReport");
                if(!main.tabs("exists", title)){
                    main.tabs("add", {
                        title: title,
                        content: $compile(result)($scope.$new()),
                        closable: true
                    });
                } else {
                    main.tabs("update",{
                        tab: main.tabs("getTab", title),
                        options: {
                            content: $compile(result)($scope.$new()),
                        }
                    }
                );
                }

                main.tabs("select", title);
            })
        };

        $scope.noteName = function (e) {
            $scope.lastReportName = e.target.value;
        };

        $scope.checkName = function () {
            var suffix = $scope.reportFile.reportName.slice($scope.reportFile.reportName.lastIndexOf("."));
            var lastSuffix = $scope.lastReportName.slice($scope.lastReportName.lastIndexOf("."));
            if (suffix !== lastSuffix) {
                $.messager.alert($.i18n.prop("ami.common.prompt"), $.i18n.prop("ami.file.sameSuffix"), 'error');
                $scope.reportFile.reportName = $scope.lastReportName;
            }
        };

        // 表格加载数据完成后，执行
        $scope.$on("loadSuccess", function (e, data) {
            $compile($(data.target).find("td[field='operation'] > div"))($scope);// 手动编译表格最后一列，同步angularjs事件操作

            $permission.contains("/searchReportFile", function (data) {
                $scope.showSearch = data;
            });

            $permission.contains("/seeReportFile", function (data) {
                $scope.showSee = data;
            });
            $permission.contains("/downReportFile", function (data) {
                $scope.showDown = data;
            });
            $permission.contains("/editReportFile", function (data) {
                $scope.showEdit = data;
            });
            $permission.contains("/deleteReportFile", function (data) {
                $scope.showDelete = data;
            });

        });
    });
})(jQuery, app)
;(function($,app){
    "use strict";
    // 模板管理
    app.controller("reportHtmlCtrl",function($scope,$http,$timeout,$compile,$element){
        $scope.tableHeader = [
            {field:'sheetName',title:$.i18n.prop("ami.file.sheetName"),width:'30%',align:'left'},
            {field:'htmlName',title:$.i18n.prop("ami.file.pageName"),width:'50%',align:'left'},
            {field:'operation',title:$.i18n.prop('ami.common.func'),width:'20%',align:'left',formatter:function(value, row, index){
                $scope['rowData_'+index] = row;
                return '<a href="javascript:void(0)" ng-click="showHtml(rowData_'+index+')">'+$.i18n.prop("ami.file.view")+'</a>';
            }}
        ];

        $scope.tableUrl = basePath + '/reportFile/htmlDatagrid';

        $scope.param = {"id" : $scope.reportId};

        $scope.showHtml = function(row){
            window.open(basePath + row.downPath+"?timeStasp="+new Date());
        }

        // 表格加载数据完成后，执行
        $scope.$on("loadSuccess",function(e,data){
            $compile($(data.target).find("td[field='operation'] > div"))($scope);// 手动编译表格最后一列，同步angularjs事件操作
        });
    });
})(jQuery,app)



;
(function($, app) {
  "use strict";
  // 模板管理
  app.controller("reportCtrl", function($scope, $http, $timeout, $compile, $element, $permission) {
    $scope.tableHeader = [
        {
          field: 'tmpid',
          title: 'id',
          width: '20%',
          align: 'left',
          hidden: 'true'
        },
        {
          field: 'tmpname',
          title: $.i18n.prop('ami.template.name'),
          width: '20%',
          align: 'left'
        },
        {
          field: 'tmpfile',
          title: 'tmpfile',
          width: '20%',
          align: 'left',
          hidden: 'true'
        },
        {
          field: 'tmpkey',
          title: $.i18n.prop('ami.template.key'),
          width: '20%',
          align: 'left'
        },
        {
          field: 'reporttype',
          title: $.i18n.prop('ami.template.type'),
          width: '20%',
          align: 'left',
          formatter: function(value) {
            switch (value) {
            case "0":
              return $.i18n.prop('ami.template.day');
            case "1":
              return $.i18n.prop('ami.template.month');
            }
          }
        },
        {
          field: 'tmpdesc',
          title: $.i18n.prop('ami.template.desc'),
          width: '20%',
          align: 'left'
        },
        {
          field: 'operation',
          title: $.i18n.prop('ami.common.func'),
          width: '10%',
          align: 'left',
          formatter: function(value, row, index) {
            $scope['rowData_' + index] = row;
            return '<a href="javascript:void(0)" class="organization-easyui-linkbutton-edit" ng-if="showBuild" ng-click="generateReport(rowData_' + index + ')" data-options="plain:true">'
                    + $.i18n.prop('ami.report.report_build') + '</a> ';
          }
        }];

    // 修改
    $scope.generateReport = function(row) {
      $scope.template = row;
      $.model($.i18n.prop('ami.report.report_build'), basePath + "/report/gotoGenerateReport", row, function(result) {
        return $compile(result)($scope)
      }, function(m) {
        if ($(".easyui-form").form('enableValidation').form('validate')) {
          $scope.template.currentTime = $("#currentTime").val();
          $scope.template.startTime = $("#startTime").val();
          $scope.template.endTime = $("#endTime").val();
          var dataList = $("#objectTreeTable").datagrid("getData").rows;
          var ids = "";
          for ( var i in dataList) {
            if (dataList[i].treeCode) {
              ids += dataList[i].name;
              ids += ",";
              ids += dataList[i].treeCode;
              ids += ",";
              ids += dataList[i].treeId;
              ids += ";"
            }
          }
          $scope.template.treeMap = ids;
          $http.post(basePath + "/report/generateReport", $scope.template || {}).success(function(result) {
            if (result.success) {
            	$.model.close(m);
            	$.messager.alert($.i18n.prop('ami.common.info'), $.i18n.prop('ami.report.message'), 'info');
            } else {
            	$.messager.alert($.i18n.prop('ami.common.info'), $.i18n.prop('ami.report.false_message'), 'info');
            }
          })
        }

      });
    }

    /*
     * $scope.geneteReport = function(row){ $scope.template = row
     * $http.post(basePath + "/report/generateReport", $scope.template || {})
     * .success( function(result) { if(result.success){ $.messager.alert('提示',
     * '生成成功', 'info'); }else{ $.messager.alert('提示', '生成失败', 'info'); } } ) }
     */

    $scope.tableUrl = basePath + '/report/query';
    $scope.$on("loadSuccess", function(e, data) {
      $compile($(data.target).find("td[field='operation'] > div"))($scope);// 手动编译表格最后一列，同步angularjs事件操作

      $permission.contains("/buildReport", function(data) {
        $scope.showBuild = data;
      });
    });

  });

})(jQuery, app);
(function($, app) {
	"use strict";
	// 模板管理
	app
			.controller(
					"reportGenerateCtrl",
					function($scope, $http, $timeout, $compile, $element) {
						$scope.tableHeader = [
								{
									field : 'id',
									title : 'ID',
									width : '10%',
									align : 'left',
									hidden : true
								},
								{
									field : 'name',
									title : $.i18n.prop('ami.object.name'),
									width : '40%',
									align : 'left'
								},
								{
									field : 'treeName',
									title : $.i18n.prop('ami.report.objectkey'),
									width : '58%',
									align : 'left',
									formatter : function(value, row, index) {
										var objectId = row.id;
										return '<input id="'
												+ objectId
												+ '_treeName_'
												+ index
												+ '" value="'
												+ value
												+ '"  data-options="editable:false" class="treeNameClass" style="width:80%"/>';
										/*
										 * 
										 * return '<select-tree
										 * select-btn-ok="sure()"
										 * input-text="content"> '+ '<epms-tree
										 * tree-data="objTreeList"
										 * parent-id="treePid"
										 * text-field="treeName"
										 * value-field="treeId"
										 * search-filter="treeSearch1" '+
										 * 'item-edit="true"
										 * item-checkbox="true"></epms-tree> '+ '</select-tree> ';
										 */

									}
								},
								{
									field : 'treeCode',
									formatter : function(value, row, index) {
										return '<input id="treeCode' + index
												+ '" value="' + value
												+ '" style="width:80%"/>';
									},
									hidden : true
								},
								{
									field : 'treeId',
									formatter : function(value, row, index) {
										return '<input id="treeId' + index
												+ '" value="' + value
												+ '" style="width:80%"/>';
									},
									hidden : true
								} ];

						$scope.tableUrl = basePath
								+ '/objectTree/queryForReport?tmpId='
								+ $scope.template.tmpid;
						$scope
								.$on(
										"loadSuccess",
										function(e, data) {
											$(".treeNameClass")
													.searchbox(
															{
																width : 203,
																height : 24,
																searcher : function(
																		value,
																		name) {
																	var treeCodeId = "";
																	var treeNameId = $(
																			this)
																			.attr(
																					"id");
																	var treeCode = "";
																	var objectId = "";
																	if (treeNameId) {
																		var index = treeNameId
																				.split("_");
																		objectId = index[0];
																		treeCodeId = ("treeCode" + index[2]);
																		treeCode = $(
																				"#"
																						+ treeCodeId)
																				.val();
																	}
																	choseTree(
																			objectId,
																			treeNameId,
																			treeCodeId,
																			treeCode);
																},
																prompt : $.i18n
																		.prop('ami.report.key_message')
															});

											$compile(
													$(data.target)
															.find(
																	"td[field='operation'] > div"))
													($scope);// 手动编译表格最后一列，同步angularjs事件操作
										});

						function choseTree(objectId, treeNameId, treeCodeId,
								treeCode) {
							$scope.objectTree = {};
							$scope.objectTree.id = objectId;

							$.model($.i18n.prop('ami.report.object'), basePath
									+ "/objectTree/choosePage",
									$scope.objectTree, function(result) {
										return $compile(result)($scope)
									}, function(m) {

									}, 600, 400);

						}
					});

})(jQuery, app);
(function($, app) {
	"use strict";
	// 模板管理
	app
			.controller(
					"roleCtrl",
					function($scope, $http, $timeout, $compile, $element,
							$permission) {
						$scope.searchrole = {};

						$scope.tableHeader = [
								{
									field : 'name',
									title : $.i18n.prop('ami.role.name'),
									width : '17%',
									align : 'left'
								},
								{
									field : 'description',
									title : $.i18n.prop('ami.template.desc'),
									width : '26%',
									align : 'left'
								},
								{
									field : 'status',
									title : $.i18n.prop('ami.common.status'),
									width : '8%',
									align : 'left',
									formatter : function(value) {
										switch (value) {
										case 0:
											return $.i18n
													.prop('ami.common.normal');
										case 1:
											return $.i18n
													.prop('ami.common.disable');
										}
									}
								},
								{
									field : 'operation',
									title : $.i18n.prop('ami.common.func'),
									width : '30%',
									formatter : function(value, row, index) {
										$scope['rowData_' + index] = row;
										var str = '';

										str += '<a href="javascript:void(0)" ng-if="showRoleGrant" ng-click="grantFun(rowData_'
												+ index
												+ ')">'
												+ $.i18n.prop('ami.role.grant')
												+ '</a>';
										str += ' | ';
										str += '<a href="javascript:void(0)" ng-if="showRoleEdit" ng-click="editFun(rowData_'
												+ index
												+ ')">'
												+ $.i18n
														.prop('ami.common.edit')
												+ '</a>';
										str += ' | ';
										str += '<a href="javascript:void(0)" ng-if="showRoleDel" ng-click="deleteFun(rowData_'
												+ index
												+ ')">'
												+ $.i18n
														.prop('ami.common.delete')
												+ '</a>';
										return str;
									}
								} ];
						$scope.tableUrl = basePath + '/role/query';
						$scope.tableparam = $scope.searchrole;
						$scope.submit = function() {
							$scope.tableparam = $scope.searchrole;
							$("#roleTable").datagrid('reload');
						}

						$scope.grantFun = function(row) {
							// 如果是新增
							var url = basePath + "/role/grant";
							if (row) {
								row.status += "";
							}
							$scope.role = row;
							$
									.model(
											$.i18n.prop('ami.role.grant'),
											url,
											$scope.role,
											function(result) {
												return $compile(result)($scope)
											},
											function(m) {
												// 点击保存后回调
												$scope.ids = "";
												var modalScope = angular
														.element(m)
														.find(
																"div[ng-controller]")
														.scope();
												for (var i = 0; i < modalScope.demo.tree.length; i++) {
													if (modalScope.demo.tree[i].checked) {
														$scope.ids += modalScope.demo.tree[i].id;
														$scope.ids += ','
													}
												}
												$scope.role.resourceId = $scope.ids;
												$http
														.post(
																basePath
																		+ "/role/saveTree",
																$scope.role)
														.success(
																function(result) {
																	if (result.success) {
																		$.model
																				.close(m);
																		$.messager
																				.alert(
																						$.i18n
																								.prop('ami.template.notice'),
																						$.i18n
																								.prop('ami.role.save_success'),
																						'info');
																		$(
																				"#roleTable")
																				.datagrid(
																						'reload');
																	}
																})
											});
						}

						$scope.editFun = function(row) {
							// 如果是新增
							var url = basePath + "/role/model";
							if (row) {
								row.status += "";
							}
							$scope.role = row;
							$
									.model(
											row ? $.i18n
													.prop('ami.role.editrole')
													: $.i18n
															.prop('ami.role.addrole'),
											url,
											$scope.role,
											function(result) {
												return $compile(result)($scope)
											},
											function(m) {
												// 点击保存后回调
												$http
														.post(
																basePath
																		+ "/role/editRole",
																$scope.role
																		|| {})
														.success(
																function(result) {
																	if (result.success) {
																		$.model
																				.close(m);
																		$.messager
																				.alert(
																						$.i18n
																								.prop('ami.template.notice'),
																						$.i18n
																								.prop('ami.role.save_success'),
																						'info');
																		$(
																				"#roleTable")
																				.datagrid(
																						'reload');
																	}
																})
											});
						}

						// 删除
						$scope.deleteFun = function(row) {

							$scope.role = row;
							parent.$.messager
									.confirm(
											'info',
											$.i18n
													.prop('ami.template.notice_message'),
											function(b) {
												if (b) {
													$http
															.post(
																	basePath
																			+ "/role/delete",
																	$scope.role)
															.success(
																	function(
																			result) {
																		if (result.success) {
																			$.messager
																					.alert(
																							$.i18n
																									.prop('ami.template.notice'),
																							$.i18n
																									.prop('ami.template.delete_success'),
																							'info');
																			$(
																					"#roleTable")
																					.datagrid(
																							'reload');
																		} else {
																			$.messager
																					.alert(
																							$.i18n
																									.prop('ami.template.notice'),
																							$.i18n
																									.prop('ami.template.delete_failed'),
																							'warning');
																		}
																	})
												}
											})

						}

						// 表格加载数据完成后，执行
						$scope.$on("loadSuccess", function(e, data) {
							$compile(
									$(data.target).find(
											"td[field='operation'] > div"))(
									$scope);// 手动编译表格最后一列，同步angularjs事件操作
							$permission.contains("/addRole", function(data) {
								$scope.showAdd = data;
							});

							$permission.contains("/searchRole", function(data) {
								$scope.showSee = data;
							});

							$permission.contains("/roleGrant", function(data) {
								$scope.showRoleGrant = data;
							});

							$permission.contains("/editRole", function(data) {
								$scope.showRoleEdit = data;
							});

							$permission.contains("/deleteRole", function(data) {
								$scope.showRoleDel = data;
							});
						});
					});
})(jQuery, app);
(function($, app) {
  "use strict";
  // 模板管理
  app.controller("roleGrantCtrl", function($scope, $http, $timeout, $compile, $element) {
    $scope.demo = {};

    $.ajax({
      type: "POST",
      url: basePath + "/role/getTreeListByRoleId",
      dataType: "html",
      contentType: "application/json",
      data: JSON.stringify($scope.role),
      success: function(result) {
        if (result) {
          result = JSON.parse(result);
        }
        if (result.success) {
          $timeout(function() {
            for (var i = 0; i < result.obj.list.length; i++) {
              result.obj.list[i].name = $.i18n.prop(result.obj.list[i].id);
            }
            $scope.demo.tree = eval(result.obj.list);
          });

        } else {
          $.messager.alert($.i18n.prop('ami.common.warning'), $.i18n.prop('ami.role.waring_message'), 'warning');
        }
      }
    });

    $scope.checkAll = function() {
      for (var i = 0; i < $scope.demo.tree.length; i++) {
        $scope.demo.tree[i].checked = true;
      }
    }

    $scope.checkInverse = function() {
      for (var i = 0; i < $scope.demo.tree.length; i++) {
        if ($scope.demo.tree[i].checked) {
          $scope.demo.tree[i].checked = false;
        } else {
          $scope.demo.tree[i].checked = true;
        }
      }
    }

    $scope.uncheckAll = function() {
      for (var i = 0; i < $scope.demo.tree.length; i++) {
        $scope.demo.tree[i].checked = false;
      }
    }
    //		
    // $scope.saveTree = function(){
    //			
    // }

  });

})(jQuery, app);
(function($, app) {
  "use strict";
  // 模板管理
  app.controller("syslogCtrl", function($scope, $http, $timeout, $compile, $element, $permission) {
    $scope.sysLogBean = {};
    $scope.tableHeader = [{
      width: '12%',
      title: $.i18n.prop('ami.syslog.createTime'),
      align: 'center',
      sortable: true,
      field: 'createTime'
    }, {
      width: '10%',
      title: $.i18n.prop('ami.syslog.loginName'),
      field: 'loginName',
      align: 'center'
    }, {
      width: '10%',
      title: $.i18n.prop('ami.syslog.roleName'),
      align: 'center',
      field: 'roleName'
    }, {
      width: '10%',
      title: $.i18n.prop('ami.syslog.clientIp'),
      field: 'clientIp',
      align: 'center'
    }, {
      width: '8%',
      title: $.i18n.prop('ami.syslog.logType'),
      field: 'logType',
      align: 'center',
      formatter: function(value, row, index) {
        if (value == '01') {
          return $.i18n.prop('ami.syslog.czrz');
        } else if (value == '02') {
          // return '<spring:message code="charge_charge_czrz" />';
          return $.i18n.prop('ami.syslog.ywrz');
        } else {
          return value;
        }
      }
    }, {
      width: '11%',
      title: $.i18n.prop('ami.syslog.sessionId'),
      field: 'sessionId',
      align: 'center',
      hidden: true
    }, {
      width: '24%',
      title: $.i18n.prop('ami.syslog.optContent'),
      field: 'optContent',
      formatter: function(value) {
        if (value != null) { return "<span title='" + value + "'>" + value + "</span>"; }
        return "";
      }
    }, {
      width: '25%',
      title: $.i18n.prop('ami.syslog.optDetail'),
      field: 'optDetail',
      formatter: function(value) {
        if (value != null) { return "<span title='" + value + "'>" + value + "</span>"; }
        return "";
      }
    }];
    $scope.tableUrl = basePath + '/syslog/dataGrid';
    $scope.submit = function() {
      $.reload('syslogTable', null, $scope.sysLogBean);
    }

    $scope.reset = function() {
      // $("#startTime").datetimebox('setValue', "");
      // $("#endTime").datetimebox('setValue', "");
      // $("#logType").val("");
      // $("#loginName").val("");
      // $("#roleName").val("");
      // $("#optContent").val("");
      $scope.sysLogBean = {};
    }

    // 表格加载数据完成后，执行
    $scope.$on("loadSuccess", function(e, data) {
      $compile($(data.target).find("td[field='operation'] > div"))($scope);// 手动编译表格最后一列，同步angularjs事件操作
    });
  });
})(jQuery, app);
(function ($, app) {
    "use strict";
    // 模板管理
    app.controller("systemParameterCtrl", function ($scope, $http, $timeout, $compile, $element, $permission) {
        $scope.tableHeader = [{
            field: 'name',
            title: $.i18n.prop('ami.sysParameter.name'),
            width: '20%',
            align: 'left'
        }, {
            field: 'value',
            title: $.i18n.prop('ami.sysParameter.value'),
            width: '20%',
            align: 'left',
            formatter: function (value, row) {
                return row.isPassword ? '********' : value;
            }
        }, {
            field: 'remark',
            title: $.i18n.prop('ami.sysParameter.remark'),
            width: '40%',
            align: 'left'
        }, {
            field: 'operation',
            title: $.i18n.prop('ami.common.func'),
            width: '20%',
            align: 'left',
            formatter: function (value, row, index) {
                $scope['rowData_' + index] = row;
                var str = '';
                str += '<a href="javascript:void(0)" ng-if="showEdit" ng-click="editFn(rowData_' + index + ')">' + $.i18n.prop('ami.common.edit'), +'</a>';
                return str;
            }
        }];

        $scope.tableUrl = basePath + '/systemParameter/datagrid';

        $scope.editFn = function (row) {
            $scope.systemParameter = angular.copy(row) || {};
            $.model($.i18n.prop('ami.sysParameter.editParameter'), basePath + "/systemParameter/editPage", $scope.systemParameter, function (result) {
                return $compile(result)($scope)
            }, function (m) {
                if ($(".easyui-form").form('enableValidation').form('validate')) {
                    $http.post(basePath + "/systemParameter/edit", $scope.systemParameter || {}).success(function (result) {
                        if (result.success) {
                            $.model.close(m);
                            $.messager.alert($.i18n.prop("ami.common.prompt"), result.msg, 'success');
                            $("#systemParameterTable").datagrid('reload');
                        } else {
                            $.messager.alert($.i18n.prop("ami.common.prompt"), result.msg, 'error');
                        }
                    })
                }

            });
        }

        // 表格加载数据完成后，执行
        $scope.$on("loadSuccess", function (e, data) {
            $compile($(data.target).find("td[field='operation'] > div"))($scope);// 手动编译表格最后一列，同步angularjs事件操作

            $permission.contains("/editSystemParameter", function (data) {
                $scope.showEdit = data;
            });
        });
    });
})(jQuery, app)
;(function ($, app) {
    "use strict";
    // 模板管理
    app.controller("reportTaskCtrl",function ($scope, $http, $timeout, $compile, $element, $permission) {
        $scope.tableHeader = [{
            field: 'id',
            title: 'ID',
            width: '10%',
            align: 'left',
            formatter: function (value) {
                return value && "<span title='" + value + "'>" + value + "</span>";
            }
        }, {
            field: 'name',
            title: $.i18n.prop("ami.task.name"),
            width: '10%',
            align: 'left',
            formatter: function (value) {
                return value && "<span title='" + value + "'>" + value + "</span>";
            }
        }, {
            field: 'startTime',
            title: $.i18n.prop("ami.task.startTime"),
            width: '10%',
            align: 'left',
            formatter: function (value) {
                return value && "<span title='" + value + "'>" + value + "</span>";
            }
        }, {
            field: 'endTime',
            title: $.i18n.prop("ami.task.endTime"),
            width: '10%',
            align: 'left',
            formatter: function (value) {
                return value && "<span title='" + value + "'>" + value + "</span>";
            }
        }, {
            field: 'offset',
            title: $.i18n.prop("ami.task.offset"),
            width: '10%',
            align: 'left',
            formatter: function (value) {
                return value && "<span title='" + value + "'>" + value + "</span>";
            }
        }, {
            field: 'type',
            title: $.i18n.prop("ami.task.type"),
            width: '10%',
            align: 'left',
            formatter: function (value) {
                switch (value) {
                    case "0":
                        return "<span title='" + $.i18n.prop('ami.common.daily') + "'>" + $.i18n.prop('ami.common.daily') + "</span>";
                    case "1":
                        return "<span title='" + $.i18n.prop('ami.common.monthly') + "'>" + $.i18n.prop('ami.common.monthly') + "</span>";
                    default:
                        return value;
                }
            }
        }, {
            field: 'status',
            title: $.i18n.prop("ami.task.status"),
            width: '10%',
            align: 'left',
            formatter: function (value) {
                switch (value) {
                    case "01":
                        return "<span title='" + $.i18n.prop('ami.task.suspend') + "'>" + $.i18n.prop('ami.task.suspend') + "</span>";
                    case "02":
                        return "<span title='" + $.i18n.prop('ami.task.running') + "'>" + $.i18n.prop('ami.task.running') + "</span>";
                    default:
                        return value;
                }
            }
        }, {
            field: 'remark',
            title: $.i18n.prop("ami.task.remark"),
            width: '12%',
            align: 'left',
            formatter: function (value) {
                return value && "<span title='" + value + "'>" + value + "</span>";
            }
        }, {
            field: 'operation',
            title: $.i18n.prop('ami.common.func'),
            width: '18%',
            align: 'left',
            formatter: function (value, row, index) {
                $scope['rowData_' + index] = row;
                var str = '';
                str += '<a href="javascript:void(0)" ng-if="showEdit" ng-click="detailFn(\'' + $.i18n.prop("ami.task.editTask") + '\',rowData_' + index + ')">' + $.i18n.prop('ami.common.edit') + '</a>';
                str += ' | ';
                str += '<a href="javascript:void(0)" ng-if="showDelete" ng-click="deleteFn(rowData_' + index + ')">' + $.i18n.prop('ami.common.delete') + '</a>';
                str += ' | ';
                str += '<a href="javascript:void(0)" ng-if="showTempConf" ng-click="tempConfig(rowData_' + index + ')">' + $.i18n.prop('ami.task.tempConfig') + '</a>';
                str += ' | ';
                str += '<a href="javascript:void(0)" ng-if="showObjConf" ng-click="objConfig(rowData_' + index + ')">' + $.i18n.prop('ami.task.objConfig') + '</a>';
                str += ' | ';
                str += '<a href="javascript:void(0)" ng-if="showDo" ng-click="doTask(rowData_' + index + ')">' + $.i18n.prop('ami.task.doTask') + '</a>';
                return str;
            }
        }];

        $scope.tableUrl = basePath + '/reportTask/datagrid';
        $scope.reportTask={};
        $scope.detailFn = function (title, row) {
            $scope.reportTask = angular.copy(row) || {"status":"01","type":"0"};
            $.model(title,basePath + "/reportTask/detailPage",$scope.reportTask,
                function (result) {
                    return $compile(result)($scope);
                },
                function (m) {
                    if ($(".easyui-form").form('enableValidation').form('validate')) {
                        $http.post(basePath + "/reportTask/update",$scope.reportTask || {}).success(function (result) {
                            if (result.success) {
                                $.model.close(m);
                                $.messager.alert($.i18n.prop("ami.common.prompt"),result.msg,'success');
                                $("#taskTable").datagrid('reload');
                            } else {
                                $.messager.alert($.i18n.prop("ami.common.prompt"),result.msg,'error');
                            }
                        })
                    }
                });
        };
        

        $scope.objConfig = function (row) {
            $scope.reportTask = angular.copy(row) || {};
            $scope.objectTreeParam = {"tmpIds":$scope.reportTask.tmpIds};
            selfModel($.i18n.prop("ami.task.configTask"),basePath + "/reportTask/objConfPage",$scope.reportTask,
                function () {
                    $("#objectTreeTable").datagrid({
                        idField : "id"
                    });
                    document.querySelector("#treeMaps").value = $scope.reportTask.objTreeMaps;
                },
                function (m) {
                    var rows = $("#objectTreeTable").datagrid("getData").rows;

                    var o = "";
                    rows.forEach(function (item) {
                        if(item.treeCode){
                            o += item.id;
                            o += ",";
                            o += item.name;
                            o += ",";
                            o += item.treeCode;
                            o += ",";
                            o += item.treeName;
                            o += ",";
                            o += item.treeId;
                            o += ";"
                        }
                    });
                    $scope.reportTask.objTreeMaps = o;

                    $http.post(basePath + "/reportTask/objConfig",$scope.reportTask || {}).success(function (result) {
                        if (result.success) {
                            $.model.close(m);
                            $.messager.alert($.i18n.prop("ami.common.prompt"),result.msg,'success');
                            $("#taskTable").datagrid('reload');
                        } else {
                            $.messager.alert($.i18n.prop("ami.common.prompt"),result.msg,'error');
                        }
                    })
                });
        };

        $scope.deleteFn = function (row) {
            $scope.reportTask = row;
            parent.$.messager.confirm('info',$.i18n.prop("ami.common.isDel"),function (b) {
                if (b) {
                    $http.post(basePath + "/reportTask/delete", $scope.reportTask || {}).success(function (result) {
                        if (result.success) {
                            $.messager.alert($.i18n.prop("ami.common.prompt"),result.msg,'success');
                            $("#taskTable").datagrid('reload');
                        } else {
                            $.messager.alert($.i18n.prop("ami.common.prompt"),result.msg,'error');
                        }
                    })
                }
            })
        };

        $scope.doTask = function (row) {
            $http.post(basePath + "/reportTask/doTask",{"id":row.id || ""}).success(function (result) {
                if (result.success) {
                    $.messager.alert($.i18n.prop("ami.common.prompt"),result.msg,'success');
                } else {
                    $.messager.alert($.i18n.prop("ami.common.prompt"),result.msg,'error');
                }
            })
        };

        $scope.objectTreeHeader =[ {
            field : 'name',
            title : $.i18n.prop('ami.object.name'),
            width : '40%',
            align : 'left'
        },
        {
            field : 'treeName',
            title : $.i18n.prop('ami.report.objectkey'),
            width : '58%',
            align : 'left',
            formatter : function(value, row, index) {
                var objectId = row.id;
                return '<input id="' + objectId + '_treeName_' + index + '" value="' + value + '"  data-options="editable:false" class="treeNameClass" style="width:80%"/>';
            }
        }];

        $scope.objectTreeUrl = basePath + '/reportTask/queryObject';

        // 表格加载数据完成后，执行
        $scope.$on("loadSuccess", function (e, data) {
            $compile($(data.target).find("td[field='operation'] > div"))($scope);// 手动编译表格最后一列，同步angularjs事件操作

            $(".treeNameClass").searchbox({
                width: 203,
                height: 24,
                searcher: function() {
                    var treeCodeId = "";
                    var treeNameId = $(this).attr("id");
                    var treeCode = "";
                    var objectId = "";
                    if (treeNameId) {
                        var index = treeNameId.split("_");
                        objectId = index[0];
                        treeCodeId = ("treeCode" + index[2]);
                        treeCode = $("#" + treeCodeId).val();
                    }
                    choseTree(objectId,treeNameId,treeCodeId,treeCode);
                },
                prompt: $.i18n.prop('ami.report.key_message')
            });

            // 对象树回选
            feedback("#treeMaps",function (value) {
                var v = value.split(";");
                var treeTable = $("#objectTreeTable");

                treeTable.datagrid('updateRow',{
                    index: treeTable.datagrid("getRowIndex",v[0]),
                    row: {
                        treeId: v[3],
                        treeCode: v[2],
                        treeName: v[1]
                    }
                });
            });

            $permission.contains("/addTask", function (data) {
                $scope.showAdd = data;
            });
            $permission.contains("/editTask", function (data) {
                $scope.showEdit = data;
            });
            $permission.contains("/deleteTask", function (data) {
                $scope.showDelete = data;
            });
            $permission.contains("/tempConf", function (data) {
                $scope.showTempConf = data;
            });
            $permission.contains("/objConf", function (data) {
                $scope.showObjConf = data;
            });
            $permission.contains("/doTask", function (data) {
                $scope.showDo = data;
            });
        });

        function changeIdsField (id,isUnSelect) {
            var target = document.querySelector("#tempIds");
            var ids = target.value ? target.value.split(",") : [];
            ids.indexOf(id) === -1 && ids.push(id);
            ids.splice(ids.indexOf(id),isUnSelect);
            target.value = ids.join(",");
        }

        function choseTree(objectId) {
            $scope.objectTree = {};
            $scope.objectTree.id = objectId;

            $.model($.i18n.prop('ami.report.object'), basePath + "/objectTree/choosePage", $scope.objectTree,
                function(result) {
                    return $compile(result)($scope)
                },
                function(m) {
                },600, 400
            );
        }

        function feedback(id,fn) {
            var dom = document.querySelector(id);
            var value = dom && dom.value;
            var list = value ? value.split(",") : [];
            list.forEach(fn);
        }

        function selfModel(title,url,param,onOpen,callback) {
            $.ajax({
                type:"POST",
                url:url,
                dataType:"html",
                contentType:"application/json",
                data:angular.toJson(param),
                success:function(result){
                    var d = $('<div class="dialog-s"/>').dialog({
                        title: title,
                        width: 750,
                        height: 600,
                        content: $compile(result)($scope),
                        modal: true,
                        onOpen : onOpen,
                        onClose: function () { $(d).dialog('destroy'); }
                    }).hide().fadeIn(50);
                    d.find(".ami-close").on("click",function(){
                        $(d).dialog('destroy');
                    });
                    d.find(".ami-save").on("click",function(){
                        callback(d);
                    });
                }
            });
        }

        // 点击添加模板
        $scope.tempConfig = function(row) {
            $scope.reportTask = angular.copy(row) || {};
            $scope.taskTempList = [];
            $scope.selTaskTempList = [];

            $.ajax({
                type: "POST",
                url: basePath + '/templateManagement/queryList?timestamp=' + (new Date()).valueOf(),
                dataType: "html",
                contentType: "application/json",
                data: JSON.stringify(row),
                success: function(result) {
                    if (result) {
                        result = JSON.parse(result);
                    }
                    if (result.success) {
                        var taskTempList = result.obj;
                        var selTaskTempList = [];
                        if(taskTempList && taskTempList.length){
                            if(row.tmpIds){
                                var ids = row.tmpIds.split(",");
                                ids.forEach(function(id){
                                    for (var i = 0; i < taskTempList.length; i++) {
                                        var item = taskTempList[i];
                                        if(id === item.tmpid){
                                            selTaskTempList.push(item);
                                            break;
                                        }
                                    }
                                })
                            }
                        }
                        $scope.$apply(function() {
                            $scope.taskTempList = taskTempList;
                            $scope.selTaskTempList = selTaskTempList;
                        });

                        $.model($.i18n.prop('ami.task.configTask'), basePath + "/reportTask/tempConfPage", $scope.reportTask || {}, function(result) {
                            return $compile(result)($scope)
                        }, function(m) {
                            delete $scope.reportTask['leftIndex'];
                            delete $scope.reportTask['leftCacheRow'];
                            delete $scope.reportTask['rightIndex'];
                            delete $scope.reportTask['rightCacheRow'];

                            var ids = "";
                            var len = $scope.selTaskTempList.length;
                            for (var i = 0; i < len; i++) {
                                ids += $scope.selTaskTempList[i].tmpid + (i === len - 1 ? "" : ",");
                            }
                            $scope.reportTask.tmpIds = ids;
                            $http.post(basePath + "/reportTask/tempConfig",$scope.reportTask || {}).success(function (result) {
                                if (result.success) {
                                    $.model.close(m);
                                    $.messager.alert($.i18n.prop("ami.common.prompt"),result.msg,'success');
                                    $("#taskTable").datagrid('reload');
                                } else {
                                    $.messager.alert($.i18n.prop("ami.common.prompt"),result.msg,'error');
                                }
                            })
                        });
                    } else {
                        $.messager.alert($.i18n.prop('ami.common.warning'), $.i18n.prop('ami.task.tempTableErr'), 'warning');
                    }
                }
            })
        };

        $scope.addTempTable = function($event, row, index) {
            delete $scope.reportTask['leftIndex'];
            delete $scope.reportTask['leftCacheRow'];
            for (var i = 0; i < $scope.selTaskTempList.length; i++) {
                var item = $scope.selTaskTempList[i];
                if (item.tmpname === row.tmpname) { return; }
            }
            $scope.selTaskTempList.push(row);
        };

        $scope.delTempTable = function($event, row, index) {
            $scope.selTaskTempList.remove(row);
            delete $scope.reportTask['rightIndex'];
            delete $scope.reportTask['rightCacheRow'];
        };

        $scope.selectedTempRow=function(row,direction){
            $scope.reportTask[direction+'CacheRow']=row;
        };

        $scope.toTargetTable=function(direction){
            var $$row = $scope.reportTask[direction+'CacheRow'];
            if(!$$row)
            {
                return;
            }
            if(direction==='left') { $scope.addTempTable(null,$$row,null); }	else { $scope.delTempTable(null,$$row,null); }
        };
        
        $scope.generateCron=function(){
          $scope.cron={};
          $.model($.i18n.prop('ami.report.Cron'), basePath + "/reportTask/generateCron", $scope.cron, function(result) {
                    return $compile(result)($scope)
                  }, function(m) {
                    debugger
                    var cronStr = "* * * * * ?";
                    if ($("#cronForm").form('enableValidation').form('validate')) {
                      if($scope.cron.periodTime){
                        if("month" == $scope.cron.periodType){
                          cronStr= "0 0 0 0 1/"+$scope.cron.periodTime+" ? ";
                        }else if("week" == $scope.cron.periodType){
                          cronStr= "0 0 0 0 0 1#"+$scope.cron.periodTime;
                        }else if("day" == $scope.cron.periodType){
                          cronStr= "0 0 0 1/"+$scope.cron.periodTime+" * ? ";
                        }else if("hour" == $scope.cron.periodType){
                          cronStr= "0 0 0/"+$scope.cron.periodTime+" * * ? ";
                        }else if("minute" == $scope.cron.periodType){
                          cronStr= "0 0/"+$scope.cron.periodTime+" * * * ? ";
                        }
                      }else{
                        var month="*";
                        var week="?";
                        var day="*";
                        var hour="*";
                        var minute="*";
                        if($scope.cron.month){
                          month=$scope.cron.month;
                        }
                        if($scope.cron.week){
                          week=$scope.cron.week;
                        }
                        if($scope.cron.day){
                          day=$scope.cron.day;
                        }
                        if($scope.cron.hour){
                          hour=$scope.cron.hour;
                        }
                        if($scope.cron.minute){
                          minute=$scope.cron.minute;
                        }
                        
                        cronStr="* "+minute+" "+hour+" "+day+" "+month+" "+week;
                      }
                      
                      $scope.reportTask.handle=cronStr;
                      $("#reportTaskhandle").val(cronStr);
                      $("#reportTaskhandle").attr("value",cronStr);
                      $.model.close(m);
                    }
                  }, 600, 300);
        };
        
    });
})(jQuery, app)
;
(function($, app) {
  "use strict";
  // 模板管理
  app.controller("templateDesignCtrl", function($scope, $http, $timeout, $compile, $element) {

    function extendDeep(parent) {
      var i, proxy;
      proxy = JSON.stringify(parent); // 把parent对象转换成字符串
      proxy = JSON.parse(proxy) // 把字符串转换成对象，这是parent的一个副本
      var child = [];
      for (i in proxy) {
        if (proxy.hasOwnProperty(i)) {
          child[i] = proxy[i];
        }
      }
      proxy = null; // 因为proxy是中间对象，可以将它回收掉
      return child;
    }

    var leng = 0;
    var nindex = null;
    var template = $scope.template;
    var datalist = [];
    var oldlength = 0;
    $.post(basePath + "/templateManagement/getData?date=" + new Date(), {
      tmpid: template.tmpid
    }, function(result) {
      var odatalist = [];
      if (result) {
        result = JSON.parse(result);
      }
      var dataList = result.list;
      $scope.dataList = dataList;
      oldlength = dataList.length;
      for (var k = 0; k < oldlength; k++) {
        var obj = {
          insertPosition: dataList[k].position,
          positionName: dataList[k].sheetname + '->' + dataList[k].dataname
        };
        odatalist.push(obj);
      }
      $http.get(basePath + '/customDataSet/queryAll?date=' + new Date()).success(function(result) {
        datalist = extendDeep(result);
        $scope.dataCollection = extendDeep(result);
        $.post(basePath + "/templateManagement/getDesgin?date=" + new Date(), {
          tmpid: template.tmpid
        }, function(result) {
          if (result) {
            result = JSON.parse(result);
          }
          var deslist = result.list;
          // $scope.dataGrid
          // =
          // result.list;
          var len = $scope.dataCollection.length;
          for (var i = 0; i < len; i++) {
            var ret = 0;
            var ret2 = 0;
            for (var j = 0; j < deslist.length; j++) {
              if ($scope.dataCollection[i].queryId == deslist[j].queryid) {
                var jj = 0;
                for (var m = 0; m < odatalist.length; m++) {
                  if (deslist[j].toexcel == odatalist[m].insertPosition) {
                    jj++;
                    odatalist[m].queryId = $scope.dataCollection[i].queryId;
                    odatalist[m].queryName = $scope.dataCollection[i].queryName;
                  }
                }
                ret++;
                if (jj == 0) {
                  var ttt = extendDeep($scope.dataCollection);
                  ttt[i].insertPosition = deslist[j].toexcel;
                  odatalist.push(ttt[i]);
                }
              }
            }
          }
          for (var u = 0; u < odatalist.length; u++) {
            odatalist[u].index = u;
          }
          $scope.$apply(function() {
            $scope.dataCollection = extendDeep(datalist);
            $scope.dataGrid = extendDeep(odatalist);
          })
        });
      });

    });

    var dragid = "";

    $scope.currentContainer = "";
    $scope.currentD = "";
    $scope.dropContainer = function(event) {
      $scope.currentContainer = event.target.parentElement;
      var i = $scope.currentContainer.children[0].innerHTML;
      nindex = i - 1;
      $scope.currentD = $scope.dataGrid[nindex];
    }
    // $scope.dataGrid = [];
    $scope.drag = function(o, index) {
      $('#drag_' + index).draggable({
        handle: '#item_' + (index - leng),
        revert: true,
        deltaX: 0,
        deltaY: 0,
        proxy: function(source) {
          var p = $('<div class="drag-item"></div>');
          p.html($(source).html().replace("drag-div", "")).appendTo('body');
          return p;
        },
        onBeforeDrag: function() {
          $(".drag-table").droppable({
            accept: '#drag_' + (index - leng),
            onDrop: function(e, source) {
              dragid = source.id;
              $scope.$apply(function() {
                if ($scope.currentContainer.className.indexOf("drag-table") != -1) {
                  $scope.dataGrid.push(o);
                } else {
                  $scope.dataGrid[nindex].queryId = o.queryId;
                  $scope.dataGrid[nindex].queryName = o.queryName;
                }
              });
              $(source).css("left", "0px");
              $(source).css("top", "0px");
            },
          });
        },
        onStopDrag: function() {
          $("#" + dragid).css("left", "0px");
          $("#" + dragid).css("top", "0px");
          $scope.$apply(function() {
            $scope.dataCollection = extendDeep(datalist);
          })
        }
      });
    }
    $scope.saveDesgin = function() {
      $.parser.parse($("#designForm").parent());
      if (!$("#designForm").form('enableValidation').form("validate")) return;
      var list = $scope.dataGrid;
      var designList = [];
      var hangList = [];
      for (var dataset = 0; dataset < list.length; dataset++) {
        var design = new Object();
        design.reportid = template.tmpid;
        design.queryid = list[dataset].queryId;
        design.toexcel = list[dataset].insertPosition;
        hangList.push(list[dataset].insertPosition.substring(list[dataset].insertPosition.lastIndexOf('$') + 1, list[dataset].insertPosition.length));
        designList.push(design);
      }

      var nary = hangList.sort();
      for (var y = 0; y < nary.length - 1; y++) {
        if (nary[y] == nary[y + 1]) {
          $.messager.alert($.i18n.prop('ami.common.warning'), $.i18n.prop('ami.template.hangrepeat'), 'warning');
          return;
        }
      }

      $.ajax({
        type: "post",
        data: {
          designList: JSON.stringify(designList),
          tmpid: template.tmpid
        },
        url: basePath + "/templateManagement/saveDesgin",
        beforeSend: function() {
          $("#save").attr("disabled", "disabled");
        },
        success: function(result) {
          if (result) {
            result = JSON.parse(result);
          }
          if (result.success) {
            $.messager.alert($.i18n.prop('ami.template.notice'), $.i18n.prop('ami.template.bind_success'), 'warning');
            $("#main").tabs("close", $scope.template.tmpname + $.i18n.prop('ami.template.bind'));
          } else {
            $.messager.alert($.i18n.prop('ami.template.notice'), $.i18n.prop('ami.template.bind_failed'), 'warning');
          }
        },
        complete: function() {
          $("#save").removeAttr("disabled");
        },
        error: function(data) {
          console.info("error: " + data.responseText);
        }
      });
    }

    $scope.deleteDesign = function(index) {
      if (oldlength > index) {
        $scope.dataGrid[index] = {
          insertPosition: $scope.dataGrid[index].insertPosition,
          positionName: $scope.dataGrid[index].positionName
        };
      } else {
        $scope.dataGrid.splice(index, 1);
      }
      $scope.dataGrid = extendDeep($scope.dataGrid);
    }

  });
})(jQuery, app);
(function($, app) {
  "use strict";
  // 模板管理
  app.controller("templateManagementCtrl", function($scope, $http, $timeout, $compile, $element, $permission) {
    $scope.tableHeader = [
        {
          field: 'tmpid',
          title: 'id',
          width: '20%',
          align: 'left',
          hidden: 'true'
        },
        {
          field: 'tmpname',
          title: $.i18n.prop('ami.template.name'),
          width: '20%',
          align: 'left'
        },
        {
          field: 'tmpfile',
          title: 'tmpfile',
          width: '20%',
          align: 'left',
          hidden: 'true'
        },
        {
          field: 'tmpkey',
          title: $.i18n.prop('ami.template.key'),
          width: '20%',
          align: 'left'
        },
        {
          field: 'reporttype',
          title: $.i18n.prop('ami.template.type'),
          width: '20%',
          align: 'left',
          formatter: function(value) {
            switch (value) {
            case "0":
              return $.i18n.prop('ami.template.day');
            case "1":
              return $.i18n.prop('ami.template.month');
            }
          }
        },
        {
          field: 'tmpdesc',
          title: $.i18n.prop('ami.template.desc'),
          width: '20%',
          align: 'left'
        },
        {
          field: 'operation',
          title: $.i18n.prop('ami.common.func'),
          width: '10%',
          align: 'left',
          formatter: function(value, row, index) {
            $scope['rowData_' + index] = row;
            return '<a href="javascript:void(0)" ng-if="showTmpSee" class="organization-easyui-linkbutton-edit" ng-click="view(rowData_' + index + ')" data-options="plain:true">'
                    + $.i18n.prop('ami.template.preview') + '</a> | <a href="javascript:void(0)" ng-if="showTmpEdit" class="organization-easyui-linkbutton-edit" ng-click="operationTemplate(rowData_'
                    + index + ')" data-options="plain:true">' + $.i18n.prop('ami.common.edit')
                    + '</a> | <a href="javascript:void(0)" ng-if="showTmpDel" class="organization-easyui-linkbutton-edit" ng-click="del(rowData_' + index + ')" data-options="plain:true">'
                    + $.i18n.prop('ami.common.delete') + '</a>';
          }
        },
        {
          field: 'design',
          title: $.i18n.prop('ami.template.design'),
          width: '10%',
          align: 'left',
          formatter: function(value, row, index) {
            $scope['rowData_' + index] = row;
            return '<a href="javascript:void(0)" ng-if="showTmpDesgin" class="organization-easyui-linkbutton-edit" ng-click="design(rowData_' + index + ')" data-options="plain:true">'
                    + $.i18n.prop('ami.template.bind') + '</a>';
          }
        }, ];

    $scope.htmlList = [];

    // 数据绑定
    $scope.design = function(row) {
      $scope.template = row;
      var designurl = basePath + "/templateDesign";
      if ($("#main").tabs("exists", $.i18n.prop('ami.template.bind'))) {
        $("#main").tabs('select', $.i18n.prop('ami.template.bind'));
        updateTab($("#main"), designurl, $scope.template);
        return;
      }

      $http.post(designurl, $scope.template).success(function(result) {
        $("#main").tabs('add', {
          title: $.i18n.prop('ami.template.bind'),
          content: $compile(result)($scope.$new()),
          closable: true
        });
      })
    }

    // 删除
    $scope.del = function(row) {
      parent.$.messager.confirm($.i18n.prop('ami.template.notice'), $.i18n.prop('ami.template.notice_message'), function(b) {
        if (b) {
          $.post(basePath + "/templateManagement/delete?date=" + new Date(), {
            tmpid: row.tmpid
          }, function(result) {
            if (result) {
              result = JSON.parse(result);
            }
            if (result.success) {
              $('#templateManagementTable').datagrid('load');
              $.messager.alert($.i18n.prop('ami.template.notice'), $.i18n.prop('ami.template.delete_success'), 'info');
            } else {
              $.messager.alert($.i18n.prop('ami.template.notice'), $.i18n.prop('ami.template.delete_failed') + ":" + result.messgae, 'warning');
            }

          });
        }
      })
    }

    // 新增 | 修改
    $scope.operationTemplate = function(row) {
      // 如果是新增
      var url = basePath + "/templateModel";
      $scope.template = angular.copy(row);
      // $scope.template = row;
      $.model(row ? $.i18n.prop('ami.template.edit_template') : $.i18n.prop('ami.template.add_template'), url, $scope.template, function(result) {
        return $compile(result)($scope)
      }, function(m) {
        $(".easyui-form").form('enableValidation');
        if (($("#excelFile").filebox('isValid') || !!$scope.linkbuttonshow) && $("#tmpname").validatebox('isValid') && $("#reporttype").validatebox('isValid')) {
          // 点击保存后回调
          var fileboxId = $(m).find("#excelFile").filebox("options").fileboxId;
          var url = basePath + '/templateManagement/uploadFile';
          if (($("#" + fileboxId).val() != "" && ($("#" + fileboxId).val().indexOf(".xlsx") > 0 || $("#" + fileboxId).val().indexOf(".xls") > 0)) || $("#" + fileboxId).val() == "") {
            $("#save").attr("disabled", "disabled");
            $.fileUpload(fileboxId, url, $scope.template || {}, function(data) {
              if (data.success) {
                $.messager.confirm($.i18n.prop('ami.template.confirm'), $.i18n.prop('ami.template.upload_confirm'), function(r) {
                  if (r) {
                    $scope.design(data.template);
                  }
                });
                $.model.close(m);
                $('#templateManagementTable').datagrid('load');
              } else {
                $.messager.alert($.i18n.prop('ami.template.notice'), $.i18n.prop('ami.template.upload_failed') + data.error, 'warning');
              }

            });
          } else {
            $.messager.alert($.i18n.prop('ami.template.notice'), $.i18n.prop('ami.template.upload_notice'), 'warning');
          }
        }

      });
    }

    $scope.tableUrl = basePath + '/templateManagement/query';

    // 表格加载数据完成后，执行
    $scope.$on("loadSuccess", function(e, data) {
      $compile($(data.target).find("td[field='operation'] > div"))($scope);// 手动编译表格最后一列，同步angularjs事件操作
      $compile($(data.target).find("td[field='design'] > div"))($scope);// 手动编译表格最后一列，同步angularjs事件操作

      // 菜单权限
      $permission.contains("/addTemplate", function(data) {
        $scope.showTmpAdd = data;
      });

      $permission.contains("/seeTemplate", function(data) {
        $scope.showTmpSee = data;
      });

      $permission.contains("/editTemplate", function(data) {
        $scope.showTmpEdit = data;
      });

      $permission.contains("/deleteTemplate", function(data) {
        $scope.showTmpDel = data;
      });

      $permission.contains("/seeTemplateDesgin", function(data) {
        $scope.showTmpDesgin = data;
      });

      $permission.contains("/saveTemplateDesgin", function(data) {
        $scope.saveTemplateDesgin = data;
      });
    });

    $scope.view = function(row) {
      $scope.htmlParam = {
        tmpid: row.tmpid
      };
      var viewurl = basePath + "/templateManagement/view"

      if ($("#main").tabs("exists", $.i18n.prop('ami.template.select'))) {
        $("#main").tabs('select', $.i18n.prop('ami.template.select'));
        updateTab($("#main"), viewurl, $scope.htmlParam);
        return;
      }

      $.ajax({
        url: viewurl + "?timeStasp=" + new Date(),
        type: 'post',
        data: {
          tmpid: row.tmpid
        },
        async: false,
        success: function(result) {
          $("#main").tabs('add', {
            title: $.i18n.prop('ami.template.select'),
            content: $compile(result)($scope.$new()),
            closable: true
          });
        }
      });

    }

    function updateTab($tab, url, obj) {
      $.ajax({
        url: url + "?timeStasp=" + new Date(),
        type: 'post',
        data: obj,
        async: false,
        success: function(result) {
          var tab = $tab.tabs("getSelected");
          $tab.tabs('update', {
            tab: tab,
            options: {
              content: $compile(result)($scope.$new())
            }
          });
        }
      });

    }

  });
})(jQuery, app);
(function($, app) {
  "use strict";
  // 模板管理
  app.controller("templatePrrviewCtrl", function($scope, $http, $timeout, $compile, $element) {

    $.post(basePath + '/templateManagement/htmlDatagrid?date=' + new Date(), $scope.htmlParam, function(result) {
      var htmlList = JSON.parse(result).rows;
      for (var i = 0; i < htmlList.length; i++) {
        /*
         * $("#tab").tabs('add', { title: htmlList[i].sheetName, : basePath +
         * htmlList[i].downPath + "?timeStasp=" + new Date(), closable: false,
         * cache: false });
         */
        $.ajax({
          url: basePath + htmlList[i].downPath + "?timeStasp=" + new Date(),
          type: 'get',
          async: false,
          success: function(data) {
            $("#tab").tabs('add', {
              title: htmlList[i].sheetName,
              content: $compile(data)($scope.$new()),
              closable: false,
              cache: false
            });
          }
        });

      }
      $('#tab').tabs({
        onSelect: function(title, index) {
          var tab = $('#tab').tabs('getSelected'); // 获取选择的面板
          $('#tab').tabs('update', {
            tab: tab
          });
        }
      });

      $("#tab").tabs('select', 0);
    });
  });
})(jQuery, app);(function($,app){
	"use strict";
	
	// 跳转测试用。。。。======================================
	app.controller("testCtrl",function($scope,$http,$timeout,$compile,$element){
		$scope.select=['0','1'];
		$scope.changeSelect=function(){
			$scope.select=['1'];
		}
		
		$scope.setSelect=function(){
			alert($scope.select);
		}
		
		$scope.resetSelect=function(){
			$scope.selectList =[{label:'苹果',value:'0'},{label:'哈密瓜',value:'1'},{label:'西瓜',value:'2'}];
		}
		
		$scope.selectList =[{label:'苹果',value:'0'},{label:'哈密瓜',value:'1'}];
		
		$scope.datestr = '2017-10-18';
		$scope.itemList = [{ label: 'java', value: '1' },{ label: 'perl', value: '2' },{ label: 'ruby', value: '3' }];
		$scope.selectedItem = '3';
		$scope.tableData = getData();
		$scope.submit = function(){
			var valid = $("form").form('enableValidation').form('validate');
			if(valid)return;
			$scope.tableData = getData();
			 $("#dg").datagrid("loadData",$scope.tableData);
		}
		
		// 假数据。。。。
		function getData(){var d=[];for(var b=1;b<=800;b++){var a=Math.floor(Math.random()*1000);var c=Math.floor(Math.random()*1000);d.push({inv:"Inv No "+b,date:$.fn.datebox.defaults.formatter(new Date()),name:"Name "+b,amount:a,price:c,cost:a*c,note:"Note "+b})}return d};
		var operation = '<a href="javascript:void(0)" class="organization-easyui-linkbutton-edit sycn-easyui" data-options="plain:true,iconCls:\'icon-edit\'">修改</a>';
		$scope.tableHeader = [
	            				//	 {field:'ck',checkbox:true },
	            				{field:'inv',title:'序列',width:80,align:'left'},
	            				{field:'date',title:'时间',width:100,align:'left'},
	            				{field:'name',title:'姓名',width:80,align:'left'},
	            				{field:'amount',title:'金额',width:80,align:'left'},
	            				{field:'price',title:'价格',width:80,align:'left'},
	            				{field:'cost',title:'总价',width:100,align:'left'},
	            				{field:'note',title:'记录',width:110,align:'left'},
	            				{field:'operation',title:'操作',width:110,align:'left',formatter:function(value, row, index){
	            					return operation;
	            				}}
	            			  ];
		
		$scope.model=function(){
			$.model("弹出框","",function(model){$.model.close(model)}); 
		}
		
		$scope.messager=function(){
			$.messager.alert("提示","<span style='position:relative;top:10px;'>请至少选择一项进行操作！</span>","warning")
		}
		
		// 树
		$scope.demo={};
		$scope.demo.tree=
			[
		       {"id":"tree_01",name:"配置管理",children:[{"id":"tree_0101",name:"数据源配置",children:[{"id":"tree_010101",name:"Oracle数据库"},{"id":"tree_010102",name:"MySQL数据库"}]}]}
		    ] 
		$scope.demo.itemClicked=function($item)
		{
			alert(1);
		}
		
		
		$scope.$on("tree.menu.Item",function(e,v){
			$scope.addTree=function()
			{
				alert(v.name);
			}
			
			$scope.removeTree=function($item)
			{
				alert(2);
			}
		})
		
		$scope.$watch('$viewContentLoaded', function() {
			$("#select").combobox({data:$scope.itemList});
		});
	});
})(jQuery,app);
(function($, app) {
  "use strict";
  app.controller("editFirstPwdCtrl", function($scope, $http, $timeout, $compile, $element) {

    $scope.userPassword = {};

    $scope.editFirstPwd = function() {
      if ($(".easyui-form").form('enableValidation').form('validate')) {
        $http.post(basePath + "/user/editUserPwd", $scope.userPassword).success(function(result) {
          if (result.success) {
            // 加载结果
            setTimeout(function() {
              reLogin();
            }, 500);
          } else {
            $.messager.alert($.i18n.prop('ami.common.warning'), result.msg, 'warning');
          }
        })
      }

    }

    function reLogin() {
      $http.post(basePath + "/logout", {}).success(function(result) {
        window.location.href = basePath;
      })
    }

  });

})(jQuery, app);
(function($, app) {
  "use strict";
  // 模板管理
  app.controller("userCtrl", function($scope, $http, $timeout, $compile, $element, $permission) {

    $scope.tableHeader = [
        {
          width: '10%',
          title: "id",
          field: 'id',
          hidden: 'true'
        },
        {
          width: '10%',
          title: $.i18n.prop('ami.user.loginname'),
          field: "loginname"
        },
        {
          width: '10%',
          title: $.i18n.prop('ami.user.name'),
          field: "name"
        },
        {
          width: '15%',
          title: $.i18n.prop('ami.dataset.createtime'),
          field: "createdate",
          sortable: true
        },
        {
          width: '5%',
          title: $.i18n.prop('ami.user.sex'),
          field: "sex",
          formatter: function(value) {
            switch (value) {
            case 0:
              return $.i18n.prop('ami.user.man');
            case 1:
              return $.i18n.prop('ami.user.woman');
            }
          }
        },
        {
          width: '10%',
          title: $.i18n.prop('ami.user.tel'),
          field: 'phone'
        },
        {
          width: '20%',
          title: $.i18n.prop('ami.user.role'),
          field: 'roleName',
          formatter: function(value) {
            if (null != value) { return "<span title='" + value + "'>" + value + "</span>"; }
          }
        },
        {
          width: '9%',
          title: $.i18n.prop('ami.common.status'),
          field: 'status',
          formatter: function(value) {
            switch (value) {
            case 0:
              return $.i18n.prop('ami.common.normal');
            case 1:
              return $.i18n.prop('ami.common.disable');
            }
          }
        },
        {
          field: 'operation',
          title: $.i18n.prop('ami.common.func'),
          width: '10%',
          formatter: function(value, row, index) {
            $scope['rowData_' + index] = row;
            return '<a href="javascript:void(0)" class="organization-easyui-linkbutton-edit" ng-if="showEdit" ng-click="editUser(rowData_' + index
                    + ')" data-options="plain:true,iconCls:\'icon-edit\'">' + $.i18n.prop('ami.common.edit')
                    + '</a> | <a href="javascript:void(0)" class="organization-easyui-linkbutton-del" ng-if="showDelete" ng-click="delUser(rowData_' + index
                    + ')" data-options="plain:true,iconCls:\'icon-del\'">' + $.i18n.prop('ami.common.delete')
                    + '</a> | <a href="javascript:void(0)" class="organization-easyui-linkbutton-del" ng-if="showGrant" ng-click="grantUser(rowData_' + index
                    + ')" data-options="plain:true,iconCls:\'icon-del\'">' + $.i18n.prop('ami.role.grant') + '</a>';
          }
        }];

    $scope.grantUser = function(row) {
      var url = basePath + "/user/grant";
      $scope.treeuser = angular.copy(row);
      $.model($.i18n.prop('ami.role.grant'), url, $scope.treeuser, function(result) {
        return $compile(result)($scope)
      }, function(m) {
        if ($(".easyui-form").form('enableValidation').form('validate')) {
          // 点击保存后回调
          $scope.cubeids = "";
          $scope.dataids = "";
          $scope.tmpids = "";
          $scope.objids = "";
          var modalScope = angular.element(m).find("div[ng-controller]").scope();
          for (var i = 0; i < modalScope.demo.tree.length; i++) {
            if (modalScope.demo.tree[i].checked) {
              if (modalScope.demo.tree[i].cubeId) {
                $scope.cubeids += modalScope.demo.tree[i].id;
                $scope.cubeids += ','
              } else {
                $scope.dataids += modalScope.demo.tree[i].id;
                $scope.dataids += ','
              }
            }
          }
          for (var j = 0; j < modalScope.selectTmpList.length; j++) {
            $scope.tmpids += modalScope.selectTmpList[j].tmpid;
            $scope.tmpids += ','
          }
          for (var t = 0; t < modalScope.demo.objtree.length; t++) {
            if (modalScope.demo.objtree[t].checked && !modalScope.demo.objtree[t].$$state) {
              $scope.objids += modalScope.demo.objtree[t].treeId;
              $scope.objids += ','
            }
          }

          $scope.userGrant = {};
          $scope.userGrant.userid = $scope.treeuser.id;
          $scope.userGrant.cubeid = $scope.cubeids;
          $scope.userGrant.cnnid = $scope.dataids;
          $scope.userGrant.tmpid = $scope.tmpids;
          $scope.userGrant.objid = $scope.objids;
          $http.post(basePath + "/user/saveTree", $scope.userGrant).success(function(result) {
            if (result.success) {
              $.model.close(m);
              $.messager.alert($.i18n.prop('ami.common.info'), $.i18n.prop('ami.role.save_success'), 'info');
              $("#roleTable").datagrid('reload');
            }
          })
        }

      });
    }

    // 新增
    $scope.addUser = function(row) {
      $scope.user = {};
      $.model($.i18n.prop('ami.user.adduser'), basePath + "/user/addPage", $scope.user, function(result) {
        return $compile(result)($scope)
      }, function(m) {
        if ($(".easyui-form").form('enableValidation').form('validate')) {
          // $scope.user.roleIds=$("#roleIds").val();
          $http.post(basePath + "/user/add", $scope.user || {}).success(function(result) {
            if (result.success) {
              $.model.close(m);
              $.messager.alert($.i18n.prop('ami.common.info'), $.i18n.prop('ami.role.save_success'), 'info');
              $("#userTable").datagrid('reload');
            }else{
              $.messager.alert($.i18n.prop('ami.common.warning'), result.msg, 'warning');
            }
          })
        }

      });

    }
    // 修改
    $scope.editUser = function(row) {
      if (row) {
        row.status += "";
        row.sex += "";
      }
      $scope.user = angular.copy(row);
      $scope.user.password = $("#password").val();
      $.model($.i18n.prop('ami.user.edituser'), basePath + "/user/editPage", $scope.user, function(result) {
        return $compile(result)($scope)
      }, function(m) {
        if ($(".easyui-form").form('enableValidation').form('validate')) {
          $scope.user.password = $("#password").val();
          $http.post(basePath + "/user/edit", $scope.user || {}).success(function(result) {
            if (result.success) {
              $.model.close(m);
              $.messager.alert($.i18n.prop('ami.common.info'), $.i18n.prop('ami.role.save_success'), 'info');
              $("#userTable").datagrid('reload');
            }
            else{
              $.messager.alert($.i18n.prop('ami.common.warning'), result.msg, 'warning');
            }
          })
        }
      });
    }

    // 删除
    $scope.delUser = function(row) {

      $scope.user = row;
      parent.$.messager.confirm('info', $.i18n.prop('ami.template.notice_message'), function(b) {
        if (b) {
          $http.post(basePath + "/user/delete", $scope.user).success(function(result) {
            if (result.success) {
              $.messager.alert($.i18n.prop('ami.common.info'), $.i18n.prop('ami.template.delete_success'), 'info');
              $("#userTable").datagrid('reload');
            }
          })
        }
      })

    }

    $scope.tableUrl = basePath + '/user/dataGrid';
    $scope.$on("loadSuccess", function(e, data) {
      $compile($(data.target).find("td[field='operation'] > div"))($scope);// 手动编译表格最后一列，同步angularjs事件操作

      $permission.contains("/addUser", function(data) {
        $scope.showAdd = data;
      });

      $permission.contains("/userGrant", function(data) {
        $scope.showGrant = data;
      });

      $permission.contains("/editUser", function(data) {
        $scope.showEdit = data;
      });

      $permission.contains("/deleteUser", function(data) {
        $scope.showDelete = data;
      });

    });
  });

})(jQuery, app);
(function($, app) {
	"use strict";
	// 模板管理
	app.controller("userGrantCtrl", function($scope, $http, $timeout, $compile,
			$element) {
		$scope.demo = {};

		$scope.tmpList = [];
		$scope.selectTmpList = [];

		$.post(basePath + "/user/getTreeListByUserId", {
			id : $scope.treeuser.id
		}, function(result) {
			if (result) {
				result = JSON.parse(result);
			}
			if (result.success) {
				$timeout(function() {
					$scope.demo.tree = eval(result.obj.list);
					$scope.tmpList = eval(result.obj.tmpList);
					$scope.selectTmpList = eval(result.obj.selectTmpList);
					$scope.demo.objtree = eval(result.obj.objlist);
				});

			} else {
				$.messager.alert($.i18n.prop('ami.common.warning'), $.i18n
						.prop('ami.role.waring_message'), 'warning');
			}
		});

		$scope.selectTmp = function($event, row, index) {
			$scope.selectTmpList.push(row);
			$scope.tmpList.splice(index, 1);
		}

		$scope.unselectTmp = function($event, row, index) {
			$scope.tmpList.push(row);
			$scope.selectTmpList.splice(index, 1);
		}

		$scope.checkAll = function(tree) {
			for (var i = 0; i < tree.length; i++) {
				tree[i].checked = true;
			}
		}

		$scope.checkInverse = function(tree) {
			for (var i = 0; i < tree.length; i++) {
				if (tree[i].checked) {
					tree[i].checked = false;
				} else {
					tree[i].checked = true;
				}
			}
		}

		$scope.uncheckAll = function(tree) {
			for (var i = 0; i < tree.length; i++) {
				tree[i].checked = false;
			}
		}
		//		
		// $scope.saveTree = function(){
		//			
		// }

	});

})(jQuery, app);
(function($, app) {
	"use strict";
	// 模板管理
	app.controller("userModelCtrl", function($scope, $http, $timeout, $compile,
			$element) {

		// 树
		$scope.demo = {};

		$.ajax({
			type : "POST",
			url : basePath + '/role/tree',
			dataType : "html",
			contentType : "application/json",
			data : JSON.stringify($scope.user),
			async : true,
			success : function(result) {
				if (result) {
					result = JSON.parse(result);
				}
				if (result.success) {
					$timeout(function() {
						$scope.$apply(function() {
							$scope.demo.tree = eval(result.obj.list);
							var checkedData = $.tree($scope.demo.tree).checked;
							var content = [];
							angular.forEach(checkedData, function(data, index) {
								content.push(data.text);
							});
							$scope.content = content.join(",");
						});
					});

				} else {
					$.messager.alert($.i18n.prop('ami.common.warning'), $.i18n
							.prop('ami.role.waring_message'), 'warning');
				}
			}
		});

		$scope.sure = function() {
			var checkedData = $.tree($scope.demo.tree).checked;
			var content = [];
			var roleId = [];
			angular.forEach(checkedData, function(data, index) {
				content.push(data.text);
				roleId.push(data.id);
			});
			$scope.content = content.join(",");
			$scope.user.roleIds = roleId.join(",");

		}

	});

})(jQuery, app)