;
(function($, app) {
  "use strict";
  // 模板管理
  app.controller("userCtrl", function($scope, $http, $timeout, $compile, $element, $permission) {

    $scope.tableHeader = [
        {
          width: '10%',
          title: "id",
          field: 'id',
          hidden: 'true'
        },
        {
          width: '10%',
          title: $.i18n.prop('ami.user.loginname'),
          field: "loginname"
        },
        {
          width: '10%',
          title: $.i18n.prop('ami.user.name'),
          field: "name"
        },
        {
          width: '15%',
          title: $.i18n.prop('ami.dataset.createtime'),
          field: "createdate",
          sortable: true
        },
        {
          width: '5%',
          title: $.i18n.prop('ami.user.sex'),
          field: "sex",
          formatter: function(value) {
            switch (value) {
            case 0:
              return $.i18n.prop('ami.user.man');
            case 1:
              return $.i18n.prop('ami.user.woman');
            }
          }
        },
        {
          width: '10%',
          title: $.i18n.prop('ami.user.tel'),
          field: 'phone'
        },
        {
          width: '20%',
          title: $.i18n.prop('ami.user.role'),
          field: 'roleName',
          formatter: function(value) {
            if (null != value) { return "<span title='" + value + "'>" + value + "</span>"; }
          }
        },
        {
          width: '9%',
          title: $.i18n.prop('ami.common.status'),
          field: 'status',
          formatter: function(value) {
            switch (value) {
            case 0:
              return $.i18n.prop('ami.common.normal');
            case 1:
              return $.i18n.prop('ami.common.disable');
            }
          }
        },
        {
          field: 'operation',
          title: $.i18n.prop('ami.common.func'),
          width: '10%',
          formatter: function(value, row, index) {
            $scope['rowData_' + index] = row;
            return '<a href="javascript:void(0)" class="organization-easyui-linkbutton-edit" ng-if="showEdit" ng-click="editUser(rowData_' + index
                    + ')" data-options="plain:true,iconCls:\'icon-edit\'">' + $.i18n.prop('ami.common.edit')
                    + '</a> | <a href="javascript:void(0)" class="organization-easyui-linkbutton-del" ng-if="showDelete" ng-click="delUser(rowData_' + index
                    + ')" data-options="plain:true,iconCls:\'icon-del\'">' + $.i18n.prop('ami.common.delete')
                    + '</a> | <a href="javascript:void(0)" class="organization-easyui-linkbutton-del" ng-if="showGrant" ng-click="grantUser(rowData_' + index
                    + ')" data-options="plain:true,iconCls:\'icon-del\'">' + $.i18n.prop('ami.role.grant') + '</a>';
          }
        }];

    $scope.grantUser = function(row) {
      var url = basePath + "/user/grant";
      $scope.treeuser = angular.copy(row);
      $.model($.i18n.prop('ami.role.grant'), url, $scope.treeuser, function(result) {
        return $compile(result)($scope)
      }, function(m) {
        if ($(".easyui-form").form('enableValidation').form('validate')) {
          // 点击保存后回调
          $scope.cubeids = "";
          $scope.dataids = "";
          $scope.tmpids = "";
          $scope.objids = "";
          var modalScope = angular.element(m).find("div[ng-controller]").scope();
          for (var i = 0; i < modalScope.demo.tree.length; i++) {
            if (modalScope.demo.tree[i].checked) {
              if (modalScope.demo.tree[i].cubeId) {
                $scope.cubeids += modalScope.demo.tree[i].id;
                $scope.cubeids += ','
              } else {
                $scope.dataids += modalScope.demo.tree[i].id;
                $scope.dataids += ','
              }
            }
          }
          for (var j = 0; j < modalScope.selectTmpList.length; j++) {
            $scope.tmpids += modalScope.selectTmpList[j].tmpid;
            $scope.tmpids += ','
          }
          for (var t = 0; t < modalScope.demo.objtree.length; t++) {
            if (modalScope.demo.objtree[t].checked && !modalScope.demo.objtree[t].$$state) {
              $scope.objids += modalScope.demo.objtree[t].treeId;
              $scope.objids += ','
            }
          }

          $scope.userGrant = {};
          $scope.userGrant.userid = $scope.treeuser.id;
          $scope.userGrant.cubeid = $scope.cubeids;
          $scope.userGrant.cnnid = $scope.dataids;
          $scope.userGrant.tmpid = $scope.tmpids;
          $scope.userGrant.objid = $scope.objids;
          $http.post(basePath + "/user/saveTree", $scope.userGrant).success(function(result) {
            if (result.success) {
              $.model.close(m);
              $.messager.alert($.i18n.prop('ami.common.info'), $.i18n.prop('ami.role.save_success'), 'info');
              $("#roleTable").datagrid('reload');
            }
          })
        }

      });
    }

    // 新增
    $scope.addUser = function(row) {
      $scope.user = {};
      $.model($.i18n.prop('ami.user.adduser'), basePath + "/user/addPage", $scope.user, function(result) {
        return $compile(result)($scope)
      }, function(m) {
        if ($(".easyui-form").form('enableValidation').form('validate')) {
          // $scope.user.roleIds=$("#roleIds").val();
          $http.post(basePath + "/user/add", $scope.user || {}).success(function(result) {
            if (result.success) {
              $.model.close(m);
              $.messager.alert($.i18n.prop('ami.common.info'), $.i18n.prop('ami.role.save_success'), 'info');
              $("#userTable").datagrid('reload');
            }else{
              $.messager.alert($.i18n.prop('ami.common.warning'), result.msg, 'warning');
            }
          })
        }

      });

    }
    // 修改
    $scope.editUser = function(row) {
      if (row) {
        row.status += "";
        row.sex += "";
      }
      $scope.user = angular.copy(row);
      $scope.user.password = $("#password").val();
      $.model($.i18n.prop('ami.user.edituser'), basePath + "/user/editPage", $scope.user, function(result) {
        return $compile(result)($scope)
      }, function(m) {
        if ($(".easyui-form").form('enableValidation').form('validate')) {
          $scope.user.password = $("#password").val();
          $http.post(basePath + "/user/edit", $scope.user || {}).success(function(result) {
            if (result.success) {
              $.model.close(m);
              $.messager.alert($.i18n.prop('ami.common.info'), $.i18n.prop('ami.role.save_success'), 'info');
              $("#userTable").datagrid('reload');
            }
            else{
              $.messager.alert($.i18n.prop('ami.common.warning'), result.msg, 'warning');
            }
          })
        }
      });
    }

    // 删除
    $scope.delUser = function(row) {

      $scope.user = row;
      parent.$.messager.confirm('info', $.i18n.prop('ami.template.notice_message'), function(b) {
        if (b) {
          $http.post(basePath + "/user/delete", $scope.user).success(function(result) {
            if (result.success) {
              $.messager.alert($.i18n.prop('ami.common.info'), $.i18n.prop('ami.template.delete_success'), 'info');
              $("#userTable").datagrid('reload');
            }
          })
        }
      })

    }

    $scope.tableUrl = basePath + '/user/dataGrid';
    $scope.$on("loadSuccess", function(e, data) {
      $compile($(data.target).find("td[field='operation'] > div"))($scope);// 手动编译表格最后一列，同步angularjs事件操作

      $permission.contains("/addUser", function(data) {
        $scope.showAdd = data;
      });

      $permission.contains("/userGrant", function(data) {
        $scope.showGrant = data;
      });

      $permission.contains("/editUser", function(data) {
        $scope.showEdit = data;
      });

      $permission.contains("/deleteUser", function(data) {
        $scope.showDelete = data;
      });

    });
  });

})(jQuery, app)