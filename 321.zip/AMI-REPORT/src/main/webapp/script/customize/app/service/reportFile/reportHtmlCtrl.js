;(function($,app){
    "use strict";
    // 模板管理
    app.controller("reportHtmlCtrl",function($scope,$http,$timeout,$compile,$element){
        $scope.tableHeader = [
            {field:'sheetName',title:$.i18n.prop("ami.file.sheetName"),width:'30%',align:'left'},
            {field:'htmlName',title:$.i18n.prop("ami.file.pageName"),width:'50%',align:'left'},
            {field:'operation',title:$.i18n.prop('ami.common.func'),width:'20%',align:'left',formatter:function(value, row, index){
                $scope['rowData_'+index] = row;
                return '<a href="javascript:void(0)" ng-click="showHtml(rowData_'+index+')">'+$.i18n.prop("ami.file.view")+'</a>';
            }}
        ];

        $scope.tableUrl = basePath + '/reportFile/htmlDatagrid';

        $scope.param = {"id" : $scope.reportId};

        $scope.showHtml = function(row){
            window.open(basePath + row.downPath+"?timeStasp="+new Date());
        }

        // 表格加载数据完成后，执行
        $scope.$on("loadSuccess",function(e,data){
            $compile($(data.target).find("td[field='operation'] > div"))($scope);// 手动编译表格最后一列，同步angularjs事件操作
        });
    });
})(jQuery,app)



