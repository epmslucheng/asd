;(function($,app){
	"use strict";
	// 模板管理
	app.controller("dataSourceCtrl",function($scope,$http,$timeout,$compile,$element){
//		$scope.tableHeader = [
//		                    {field:'id',title:'id',width:'20%',align:'left',hidden:true},
//	          				{field:'key',title:'名称',width:'20%',align:'left'},
//	          				{field:'dbType',title:'类型',width:'20%',align:'left',formatter:function(value,row,index){
//	          					if("01"==value){
//	          						return 'Oracle';
//	          					}if("02"==value){
//	          						return 'MySql';
//	          					}
//	          					
//	          				}},
//	          				{field:'url',title:'连接',width:'20%',align:'left'},
//	          				{field:'dbName',title:'用户名',width:'20%',align:'left'},
//	          				{field:'operation',title:'操作',width:'10%',align:'left',formatter:function(value, row, index){
//	          					$scope['rowData_'+index] = row;
//            					return '<a href="javascript:void(0)" class="organization-easyui-linkbutton-edit" ng-click="viewDataSource(rowData_'+index+')" data-options="plain:true,iconCls:\'icon-edit\'">查看</a> | <a href="javascript:void(0)" class="organization-easyui-linkbutton-edit" ng-click="modifyDataSource(rowData_'+index+')" data-options="plain:true,iconCls:\'icon-edit\'">修改</a>| <a href="javascript:void(0)" class="organization-easyui-linkbutton-del" ng-click="delDataSource(rowData_'+index+')" data-options="plain:true,iconCls:\'icon-del\'">删除</a>';
//            				}},
//	          			  ];
//		
//		// 查看
//		$scope.viewDataSource = function(row){
//			
//			$scope.dataSource =row;
//			$.model("查看数据源",basePath + "/dataSource/viewPage",$scope.dataSource,function(result){return $compile(result)($scope)});
//		}
//		
//		// 新增
//		$scope.addDataSource = function(row){
//			$scope.dataSource ={};
//			$.model("新增数据源",basePath + "/dataSource/addPage",$scope.dataSource,function(result){return $compile(result)($scope)},function(m){
//				$http.post(basePath + "/dataSource/save", $scope.dataSource || {})
//				.success( function(result) 
//						{
//						if(result.success){
//							$.model.close(m);
//							$.messager.alert('提示', '添加成功', 'info');
//							$("#dataSourceTable").datagrid('reload');
//						}
//					} 
//				)
//			});
//		}
//		
//		// 修改
//		$scope.modifyDataSource = function(row){
//			$scope.dataSource = row;
//			$.model("修改数据源",basePath + "/dataSource/editPage",$scope.dataSource,function(result){return $compile(result)($scope)},function(m){
//				$http.post(basePath + "/dataSource/edit", $scope.dataSource || {})
//				.success( function(result) 
//						{
//						if(result.success){
//							$.model.close(m);
//							$.messager.alert('提示', '修改成功', 'info');
//							$("#dataSourceTable").datagrid('reload');
//						}
//					} 
//				)
//			});
//		}
//		
//		// 删除
//		$scope.delDataSource = function(row){
//			
//			$scope.dataSource = row;
//			parent.$.messager.confirm('info','是否删除该条记录',function(b){
//				if(b){
//					$http.post(basePath + "/dataSource/delete", $scope.dataSource)
//					.success( function(result) 
//							{
//						
//								if(result.success){
//									$.messager.alert('提示', '删除成功', 'info');
//									$("#dataSourceTable").datagrid('reload');
//								}
//							} 
//					)
//				}
//			})
//			
//		}
//		
//		$scope.updateDataSourceTable = function(row){
//			$scope.dataSource = row;
//			parent.$.messager.confirm('info','是否更新数据源中所有表及表结构',function(b){
//				if(b){
//					$http.post(basePath + "/dataSource/updateTable", $scope.dataSource)
//					.success( function(result) 
//							{
//						
//								if(result.success){
//									$.messager.alert('提示', '更新需要时间,请稍候', 'info');
//								}
//							} 
//					)
//				}
//			})
//		}
		
		$scope.testConnection = function(){
			$http.post(basePath + "/dataSource/testConnection", $scope.dataSource)
			.success( function(result) 
					{
						if(result.success){
							//ami.dataSource.TestConnection.success
							$.messager.alert($.i18n.prop('ami.common.info'), $.i18n.prop('ami.dataSource.TestConnection.success'), 'info');
						}else{
							$.messager.alert($.i18n.prop('ami.common.warning'), $.i18n.prop('ami.dataSource.TestConnection.fail'), 'warning');
						}
					} 
			)
			
		}
		
		
//		$scope.tableUrl = basePath + '/dataSource/query';
//		
//		// 表格加载数据完成后，执行
//		$scope.$on("loadSuccess",function(e,data){
//			$compile($(data.target).find("td[field='operation'] > div"))($scope);// 手动编译表格最后一列，同步angularjs事件操作
//		});
	});
})(jQuery,app)