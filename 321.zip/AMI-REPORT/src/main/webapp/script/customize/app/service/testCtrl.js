;(function($,app){
	"use strict";
	
	// 跳转测试用。。。。======================================
	app.controller("testCtrl",function($scope,$http,$timeout,$compile,$element){
		$scope.select=['0','1'];
		$scope.changeSelect=function(){
			$scope.select=['1'];
		}
		
		$scope.setSelect=function(){
			alert($scope.select);
		}
		
		$scope.resetSelect=function(){
			$scope.selectList =[{label:'苹果',value:'0'},{label:'哈密瓜',value:'1'},{label:'西瓜',value:'2'}];
		}
		
		$scope.selectList =[{label:'苹果',value:'0'},{label:'哈密瓜',value:'1'}];
		
		$scope.datestr = '2017-10-18';
		$scope.itemList = [{ label: 'java', value: '1' },{ label: 'perl', value: '2' },{ label: 'ruby', value: '3' }];
		$scope.selectedItem = '3';
		$scope.tableData = getData();
		$scope.submit = function(){
			var valid = $("form").form('enableValidation').form('validate');
			if(valid)return;
			$scope.tableData = getData();
			 $("#dg").datagrid("loadData",$scope.tableData);
		}
		
		// 假数据。。。。
		function getData(){var d=[];for(var b=1;b<=800;b++){var a=Math.floor(Math.random()*1000);var c=Math.floor(Math.random()*1000);d.push({inv:"Inv No "+b,date:$.fn.datebox.defaults.formatter(new Date()),name:"Name "+b,amount:a,price:c,cost:a*c,note:"Note "+b})}return d};
		var operation = '<a href="javascript:void(0)" class="organization-easyui-linkbutton-edit sycn-easyui" data-options="plain:true,iconCls:\'icon-edit\'">修改</a>';
		$scope.tableHeader = [
	            				//	 {field:'ck',checkbox:true },
	            				{field:'inv',title:'序列',width:80,align:'left'},
	            				{field:'date',title:'时间',width:100,align:'left'},
	            				{field:'name',title:'姓名',width:80,align:'left'},
	            				{field:'amount',title:'金额',width:80,align:'left'},
	            				{field:'price',title:'价格',width:80,align:'left'},
	            				{field:'cost',title:'总价',width:100,align:'left'},
	            				{field:'note',title:'记录',width:110,align:'left'},
	            				{field:'operation',title:'操作',width:110,align:'left',formatter:function(value, row, index){
	            					return operation;
	            				}}
	            			  ];
		
		$scope.model=function(){
			$.model("弹出框","",function(model){$.model.close(model)}); 
		}
		
		$scope.messager=function(){
			$.messager.alert("提示","<span style='position:relative;top:10px;'>请至少选择一项进行操作！</span>","warning")
		}
		
		// 树
		$scope.demo={};
		$scope.demo.tree=
			[
		       {"id":"tree_01",name:"配置管理",children:[{"id":"tree_0101",name:"数据源配置",children:[{"id":"tree_010101",name:"Oracle数据库"},{"id":"tree_010102",name:"MySQL数据库"}]}]}
		    ] 
		$scope.demo.itemClicked=function($item)
		{
			alert(1);
		}
		
		
		$scope.$on("tree.menu.Item",function(e,v){
			$scope.addTree=function()
			{
				alert(v.name);
			}
			
			$scope.removeTree=function($item)
			{
				alert(2);
			}
		})
		
		$scope.$watch('$viewContentLoaded', function() {
			$("#select").combobox({data:$scope.itemList});
		});
	});
})(jQuery,app)