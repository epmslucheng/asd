(function($) {
  $.extend($.fn.validatebox.defaults.rules, {
    selectRequired: {
      validator: function(value) {
        return !!value;
      },
      message: $.fn.validatebox.defaults.missingMessage
    },
    fileRequired: {
      validator: function(value) {
        return !!value.match(/.xls$/) || !!value.match(/.xlsx$/);
      },
      message: $.i18n.prop('Exception_file')
    },
    sheetRequired: {
      validator: function(value) {
        return !!value.match(/^[^\!\$\：:]+\!\$[A-Z]\$\d+$/)
      },
      message: $.i18n.prop('Exception_sheet')
    },
    sqlValidation: {
      validator: function(value) {

        return !/[@#\$\^&\*]+/i.test(value);
      },
      message: $.i18n.prop('sql_validation')
    },
    keyValidation: {
      validator: function(value) {

        return /^[a-zA-Z][a-zA-Z0-9_]{5,15}$/i.test(value);
      },
      message: $.i18n.prop('key_validation')
    },
    globalPhone: {
      validator: function(value) {
        if (/^[\d+\-\s]+$/.test(value) && value.length >= 0 && value.length <= 18) { return true; }
        return false;
      },
      message: $.i18n.prop('phone_message')
    },
    eqPwd: {
      validator: function(value, param) {
        return value == $(param[0]).val();
      },
      message: $.i18n.prop('pwd_message')
    },
    loginName: {
      validator: function(value) {
        return /^[a-zA-Z]{1}([a-zA-Z0-9_\s]){4,15}$/.test(value);
      },
      message: $.i18n.prop('loginName_message')
    },
    commonEnglish: {// 验证英语
      validator: function(value) {
        if (/^[a-zA-Z0-9\u4E00-\u9FA5\.\s\#\_\,\@\:\/\*\-\(\)]+$/.test(value)) {
          return true;
        } else {
          return false;
        }
      },
      message: $.i18n.prop('commonEnglish_message')
    },
    nameCN: {
      validator: function(value, param) {
        value = value.replace(/[\u4e00-\u9fa5]/g, 'xxxx');
        var len = $.trim(value).length;
        return len >= param[0] && len <= param[1];
      },
      message: $.i18n.prop('nameCN_message')
    },
    numberCompare: {
      validator: function (value, param) {
        if(!(/^([+]?[0-9])+$/.test(value))){
            return false;
        }else{
          return value >= param[0] && value <= param[1];
        }
      },
      message:  $.i18n.prop('numberCompare_message')
    },
    integer: {// 验证整数 可正负数
      validator: function (value) {
        //return /^[+]?[1-9]+\d*$/i.test(value);
        return /^([+]?[0-9])+$/.test(value);
    },
    message:  $.i18n.prop('ami.cron.validate.integer')
}
  });
})(jQuery);