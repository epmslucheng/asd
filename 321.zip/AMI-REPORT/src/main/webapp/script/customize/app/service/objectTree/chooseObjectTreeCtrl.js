;
(function ($, app) {
    "use strict";
    // 模板管理
    app.controller("chooseObjectTreeCtrl", function ($scope, $http, $timeout, $compile, $element) {

        $scope.objectTreeData = {};

        function pushData() {
            $scope.objectTree;
            $.ajax({
                type: "POST",
                url: basePath + "/objectTree/getObjectTreeForChoose",
                dataType: "html",
                contentType: "application/json",
                data: JSON.stringify($scope.objectTree),
                success: function (result) {
                    if (result) {
                        result = JSON.parse(result);
                    }
                    if (result.success) {
                        $timeout(function () {
                            $scope.objectTreeData = eval(result.obj.list);
                        });
                        // $scope.$apply(function(){
                        // $scope.objectTreeData = eval(result.obj.list);
                        // });

                    } else {
                        $.messager.alert($.i18n.prop('ami.common.warning'), $.i18n.prop('ami.role.waring_message'), 'warning');
                    }
                }
            });
        }

        pushData();

        // 双击回填input
        $scope.choose = function (item) {
            var $$treeId = $scope.$parent.objectTree.id;
            $("input[id^='" + $$treeId + "_treeName_" + "']").searchbox("setValue", item.treeName);
            parent.$("#objectTreeTable").datagrid("getSelected").treeCode = item.treeCode;
            parent.$("#objectTreeTable").datagrid("getSelected").treeId = item.treeId;
            parent.$("#objectTreeTable").datagrid("getSelected").treeName = item.treeName;
            $("#objectTreeCloseBtn").trigger("click");
        }
    });
})(jQuery, app)
