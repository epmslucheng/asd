;(function($,app){
    "use strict";
    
    app.service("$permission",function($http,$q){
    	var deferred = $q.defer();//声明承诺
    	var promise = function(){
    		$http({
        	    method: 'post',
        	    url: basePath + '/permission/init'
        	}).success(function(data){
        		deferred.resolve(data);//请求成功
        	}).error(function(data) {  
                deferred.reject(data); //请求失败
            });
    		 return deferred.promise;
    	}()
    	
    	this.contains=function(key,callback){
    		promise.then(function(data) {  // 成功回调
    	       callback(!!data[key]);
    	    });
    	}
    	
    	// 在ctrl.js上注入$permission
    	// 通过调用
    	// $permission.contains(key,function(){});
    });
})(jQuery,app)