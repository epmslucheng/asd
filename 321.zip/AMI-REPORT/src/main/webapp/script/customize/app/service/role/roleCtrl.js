;
(function($, app) {
	"use strict";
	// 模板管理
	app
			.controller(
					"roleCtrl",
					function($scope, $http, $timeout, $compile, $element,
							$permission) {
						$scope.searchrole = {};

						$scope.tableHeader = [
								{
									field : 'name',
									title : $.i18n.prop('ami.role.name'),
									width : '17%',
									align : 'left'
								},
								{
									field : 'description',
									title : $.i18n.prop('ami.template.desc'),
									width : '26%',
									align : 'left'
								},
								{
									field : 'status',
									title : $.i18n.prop('ami.common.status'),
									width : '8%',
									align : 'left',
									formatter : function(value) {
										switch (value) {
										case 0:
											return $.i18n
													.prop('ami.common.normal');
										case 1:
											return $.i18n
													.prop('ami.common.disable');
										}
									}
								},
								{
									field : 'operation',
									title : $.i18n.prop('ami.common.func'),
									width : '30%',
									formatter : function(value, row, index) {
										$scope['rowData_' + index] = row;
										var str = '';

										str += '<a href="javascript:void(0)" ng-if="showRoleGrant" ng-click="grantFun(rowData_'
												+ index
												+ ')">'
												+ $.i18n.prop('ami.role.grant')
												+ '</a>';
										str += ' | ';
										str += '<a href="javascript:void(0)" ng-if="showRoleEdit" ng-click="editFun(rowData_'
												+ index
												+ ')">'
												+ $.i18n
														.prop('ami.common.edit')
												+ '</a>';
										str += ' | ';
										str += '<a href="javascript:void(0)" ng-if="showRoleDel" ng-click="deleteFun(rowData_'
												+ index
												+ ')">'
												+ $.i18n
														.prop('ami.common.delete')
												+ '</a>';
										return str;
									}
								} ];
						$scope.tableUrl = basePath + '/role/query';
						$scope.tableparam = $scope.searchrole;
						$scope.submit = function() {
							$scope.tableparam = $scope.searchrole;
							$("#roleTable").datagrid('reload');
						}

						$scope.grantFun = function(row) {
							// 如果是新增
							var url = basePath + "/role/grant";
							if (row) {
								row.status += "";
							}
							$scope.role = row;
							$
									.model(
											$.i18n.prop('ami.role.grant'),
											url,
											$scope.role,
											function(result) {
												return $compile(result)($scope)
											},
											function(m) {
												// 点击保存后回调
												$scope.ids = "";
												var modalScope = angular
														.element(m)
														.find(
																"div[ng-controller]")
														.scope();
												for (var i = 0; i < modalScope.demo.tree.length; i++) {
													if (modalScope.demo.tree[i].checked) {
														$scope.ids += modalScope.demo.tree[i].id;
														$scope.ids += ','
													}
												}
												$scope.role.resourceId = $scope.ids;
												$http
														.post(
																basePath
																		+ "/role/saveTree",
																$scope.role)
														.success(
																function(result) {
																	if (result.success) {
																		$.model
																				.close(m);
																		$.messager
																				.alert(
																						$.i18n
																								.prop('ami.template.notice'),
																						$.i18n
																								.prop('ami.role.save_success'),
																						'info');
																		$(
																				"#roleTable")
																				.datagrid(
																						'reload');
																	}
																})
											});
						}

						$scope.editFun = function(row) {
							// 如果是新增
							var url = basePath + "/role/model";
							if (row) {
								row.status += "";
							}
							$scope.role = row;
							$
									.model(
											row ? $.i18n
													.prop('ami.role.editrole')
													: $.i18n
															.prop('ami.role.addrole'),
											url,
											$scope.role,
											function(result) {
												return $compile(result)($scope)
											},
											function(m) {
												// 点击保存后回调
												$http
														.post(
																basePath
																		+ "/role/editRole",
																$scope.role
																		|| {})
														.success(
																function(result) {
																	if (result.success) {
																		$.model
																				.close(m);
																		$.messager
																				.alert(
																						$.i18n
																								.prop('ami.template.notice'),
																						$.i18n
																								.prop('ami.role.save_success'),
																						'info');
																		$(
																				"#roleTable")
																				.datagrid(
																						'reload');
																	}
																})
											});
						}

						// 删除
						$scope.deleteFun = function(row) {

							$scope.role = row;
							parent.$.messager
									.confirm(
											'info',
											$.i18n
													.prop('ami.template.notice_message'),
											function(b) {
												if (b) {
													$http
															.post(
																	basePath
																			+ "/role/delete",
																	$scope.role)
															.success(
																	function(
																			result) {
																		if (result.success) {
																			$.messager
																					.alert(
																							$.i18n
																									.prop('ami.template.notice'),
																							$.i18n
																									.prop('ami.template.delete_success'),
																							'info');
																			$(
																					"#roleTable")
																					.datagrid(
																							'reload');
																		} else {
																			$.messager
																					.alert(
																							$.i18n
																									.prop('ami.template.notice'),
																							$.i18n
																									.prop('ami.template.delete_failed'),
																							'warning');
																		}
																	})
												}
											})

						}

						// 表格加载数据完成后，执行
						$scope.$on("loadSuccess", function(e, data) {
							$compile(
									$(data.target).find(
											"td[field='operation'] > div"))(
									$scope);// 手动编译表格最后一列，同步angularjs事件操作
							$permission.contains("/addRole", function(data) {
								$scope.showAdd = data;
							});

							$permission.contains("/searchRole", function(data) {
								$scope.showSee = data;
							});

							$permission.contains("/roleGrant", function(data) {
								$scope.showRoleGrant = data;
							});

							$permission.contains("/editRole", function(data) {
								$scope.showRoleEdit = data;
							});

							$permission.contains("/deleteRole", function(data) {
								$scope.showRoleDel = data;
							});
						});
					});
})(jQuery, app)