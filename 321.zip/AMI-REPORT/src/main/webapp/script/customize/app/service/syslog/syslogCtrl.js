;
(function($, app) {
  "use strict";
  // 模板管理
  app.controller("syslogCtrl", function($scope, $http, $timeout, $compile, $element, $permission) {
    $scope.sysLogBean = {};
    $scope.tableHeader = [{
      width: '12%',
      title: $.i18n.prop('ami.syslog.createTime'),
      align: 'center',
      sortable: true,
      field: 'createTime'
    }, {
      width: '10%',
      title: $.i18n.prop('ami.syslog.loginName'),
      field: 'loginName',
      align: 'center'
    }, {
      width: '10%',
      title: $.i18n.prop('ami.syslog.roleName'),
      align: 'center',
      field: 'roleName'
    }, {
      width: '10%',
      title: $.i18n.prop('ami.syslog.clientIp'),
      field: 'clientIp',
      align: 'center'
    }, {
      width: '8%',
      title: $.i18n.prop('ami.syslog.logType'),
      field: 'logType',
      align: 'center',
      formatter: function(value, row, index) {
        if (value == '01') {
          return $.i18n.prop('ami.syslog.czrz');
        } else if (value == '02') {
          // return '<spring:message code="charge_charge_czrz" />';
          return $.i18n.prop('ami.syslog.ywrz');
        } else {
          return value;
        }
      }
    }, {
      width: '11%',
      title: $.i18n.prop('ami.syslog.sessionId'),
      field: 'sessionId',
      align: 'center',
      hidden: true
    }, {
      width: '24%',
      title: $.i18n.prop('ami.syslog.optContent'),
      field: 'optContent',
      formatter: function(value) {
        if (value != null) { return "<span title='" + value + "'>" + value + "</span>"; }
        return "";
      }
    }, {
      width: '25%',
      title: $.i18n.prop('ami.syslog.optDetail'),
      field: 'optDetail',
      formatter: function(value) {
        if (value != null) { return "<span title='" + value + "'>" + value + "</span>"; }
        return "";
      }
    }];
    $scope.tableUrl = basePath + '/syslog/dataGrid';
    $scope.submit = function() {
      $.reload('syslogTable', null, $scope.sysLogBean);
    }

    $scope.reset = function() {
      // $("#startTime").datetimebox('setValue', "");
      // $("#endTime").datetimebox('setValue', "");
      // $("#logType").val("");
      // $("#loginName").val("");
      // $("#roleName").val("");
      // $("#optContent").val("");
      $scope.sysLogBean = {};
    }

    // 表格加载数据完成后，执行
    $scope.$on("loadSuccess", function(e, data) {
      $compile($(data.target).find("td[field='operation'] > div"))($scope);// 手动编译表格最后一列，同步angularjs事件操作
    });
  });
})(jQuery, app)