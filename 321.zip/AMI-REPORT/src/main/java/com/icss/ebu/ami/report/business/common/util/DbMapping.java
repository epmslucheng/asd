package com.icss.ebu.ami.report.business.common.util;

import java.lang.reflect.Field;
import java.util.LinkedHashMap;
import java.util.Map;

public class DbMapping
{
    private static Map <Class, Map <String, String>> wholeMap = new LinkedHashMap <Class, Map <String, String>> ();
    static
    {/*
        Map <String, String> usermapping = new HashMap <String, String> ();
        usermapping.put ("User", "t_sys_user");
        usermapping.put ("loginName", "login_name");
        usermapping.put ("orgId", "org_id");
        usermapping.put ("phone", "phone");
        usermapping.put ("foreignKey", "orgId");
        usermapping.put ("primaryKey", "");
        
        Map <String, String> orgmapping = new HashMap <String, String> ();
        orgmapping.put ("Orgination", "t_sys_organization");
        orgmapping.put ("id", "id");
        orgmapping.put ("type", "type");
        orgmapping.put ("orgName", "org_name");
        orgmapping.put ("foreignKey", "");
        orgmapping.put ("primaryKey", "id");
        
        wholeMap.put (User.class, usermapping);
        wholeMap.put (Orgination.class, orgmapping);
     */
    }
    
    private Class clazz;
    
    private DbMapping (Class clazz)
    {
        this.clazz = clazz;
    }
    
    public String getForeignKey ()
    {
        return getMapping ().get ("foreignKey");
    }
    
    public String getPrimaryKey ()
    {
        return getMapping ().get ("primaryKey");
    }
    
    public Map <String, String> getMapping ()
    {
        return wholeMap.get (clazz);
    }
    
    public String getTableName ()
    {
        return wholeMap.get (clazz).get (clazz.getSimpleName ());
    }
    
    public String getColumnMapping (Field field)
    {
        return wholeMap.get (clazz).get (field.getName ());
    }
    
    public static DbMapping obtain (Class clazz)
    {
        return new DbMapping (clazz);
    }
}
