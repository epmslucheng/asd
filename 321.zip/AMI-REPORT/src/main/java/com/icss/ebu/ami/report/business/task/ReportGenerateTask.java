package com.icss.ebu.ami.report.business.task;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;

import com.icss.ebu.ami.report.business.common.constant.ReportConstant;
import com.icss.ebu.ami.report.business.common.util.ConfigHolder;
import com.icss.ebu.ami.report.business.common.util.ExcelWrite;
import com.icss.ebu.ami.report.business.common.util.JDBCTemplateUtil;
import com.icss.ebu.ami.report.business.common.util.SqlUtils;
import com.icss.ebu.ami.report.business.mapper.CustomDataSetMapper;
import com.icss.ebu.ami.report.business.mapper.DataSourceMapper;
import com.icss.ebu.ami.report.business.mapper.ObjectTreeMapper;
import com.icss.ebu.ami.report.business.mapper.ReportFileMapper;
import com.icss.ebu.ami.report.business.mapper.ReportMapper;
import com.icss.ebu.ami.report.business.model.DataSourceBean;
import com.icss.ebu.ami.report.business.model.Function;
import com.icss.ebu.ami.report.business.model.ObjectTreeBean;
import com.icss.ebu.ami.report.business.model.ReportDesign;
import com.icss.ebu.ami.report.business.model.ReportFile;
import com.icss.ebu.ami.report.business.model.Template;

/**
 * 生成报表
 * @author lvzhengtao
 *
 */
public class ReportGenerateTask implements Callable <Boolean>
{
    private Logger LOGGER = LoggerFactory.getLogger (ReportGenerateTask.class);
    
    private ReportMapper reportMapper;
    
    private CustomDataSetMapper customDataSetMapper;
    
    private ReportFileMapper reportFileMapper;
    
    private DataSourceMapper dataSourceMapper;
    
    private ObjectTreeMapper objectTreeMapper;
    
    private Template template;
    
    private String date_formatter;
    
    private static final int PAGE_SIAE = 5000;
    
    private static final ThreadPoolExecutor htmlPools = new ThreadPoolExecutor (15, 30, 5, TimeUnit.SECONDS,
        new LinkedBlockingQueue <Runnable> (800));
    
    public ReportGenerateTask (ReportMapper reportMapper, CustomDataSetMapper customDataSetMapper,
        ReportFileMapper reportFileMapper, DataSourceMapper dataSourceMapper, Template template,
        ObjectTreeMapper objectTreeMapper, String date_formatter)
    {
        this.reportMapper = reportMapper;
        this.customDataSetMapper = customDataSetMapper;
        this.reportFileMapper = reportFileMapper;
        this.template = template;
        this.dataSourceMapper = dataSourceMapper;
        this.objectTreeMapper = objectTreeMapper;
        this.date_formatter = date_formatter;
    }
    
    @Override
    public Boolean call ()
    {
        String reportId = template.getReportId ();
        String startTime = template.getStartTime ();
        String endTime = template.getEndTime ();
        String currentTime = template.getCurrentTime ();
        String tempPath = template.getTempPath ();
        String treeMap = template.getTreeMap ();
        ReportFile reportFile = new ReportFile ();
        reportFile.setReportId (reportId);
        
        Map <String, String> map = new HashMap <String, String> ();
        try
        {
            if (StringUtils.isNotBlank (treeMap))
            {
                
                String[] treeList = treeMap.split (";");
                for (String tree : treeList)
                {
                    String[] split = tree.split (",");
                    map.put (split[0], split[1]);
                }
            }
        }
        catch (Exception e)
        {
            recordReportStatus (reportFile, ReportConstant.REPORT_FAILURE, "Cause : Wrong Object Tree Parameter");
            LOGGER.error ("String split fail.", e);
            return false;
        }
        
        List <ReportDesign> list = null;
        List <Function> func = null;
        List <ObjectTreeBean> objectTreeList = null;
        
        try
        {
            list = reportMapper.queryReportDesignById (template.getTmpid ());
            func = customDataSetMapper.findAllFunction ();
            objectTreeList = objectTreeMapper.queryAllObjectTree (new ObjectTreeBean ());
        }
        catch (Exception e)
        {
            recordReportStatus (reportFile, ReportConstant.REPORT_FAILURE, "Cause : Query Template Design Information Exception");
            LOGGER.error ("Query Report Info from DB - error", e);
            return false;
        }
        
        if (list == null)
        {
            LOGGER.error ("Report designs is null, please check it.");
            return true;
        }
        
        /**
         * ftp上传路径
         */
        String targetDir =
            ConfigHolder.getCfg (ReportConstant.FTP_CATALOG) + ConfigHolder.getCfg (ReportConstant.REPORT_FTP_PATH_DAY);
        if (ReportConstant.REPORT_TYPE_MONTH.equals (template.getReporttype ()))
        {
            targetDir =
                ConfigHolder.getCfg (ReportConstant.FTP_CATALOG) + ConfigHolder.getCfg (ReportConstant.REPORT_FTP_PATH_MONTH);
        }
        
        /**
         * 下载模板处理report_date
         */
        String tmpFile = template.getTmpfile ();
        String tmpfilename = template.getTmpfilename ();
        String repTempPath = ConfigHolder.getCfg (ReportConstant.REPORT_TEMP_PATH);
        try
        {
            ExcelWrite.createTempExcel (tmpFile, tmpfilename, repTempPath, tempPath, date_formatter);
        }
        catch (Exception e)
        {
            recordReportStatus (reportFile, ReportConstant.REPORT_FAILURE, "Cause : Download Template Failure");
            LOGGER.error ("ExcelWrite createTempExcel fail", e);
            return false;
        }
        
        /**
         * 循环数据集
         */
        String querySql = "";
        
        FileOutputStream out = null;
        List <Map <String, Object>> datas = null;
        try
        {
            Workbook workBook = createWorkBook (tempPath);
            if (workBook == null)
            {
                recordReportStatus (reportFile, ReportConstant.REPORT_FAILURE, "Cause : Reading Template Exception");
                return false;
            }
            for (ReportDesign rd : list)
            {
                rd.setTmpFile (tmpFile);
                rd.setTmpFileName (tmpfilename);
                // 循环生成数据集插入报表
                //SQL 语句处理
                querySql = rd.getQuerySql ().replace (ReportConstant.REPORT_ENTER, ReportConstant.REPORT_SPACE);
                querySql = SqlUtils.assembleSqlFunction (querySql, currentTime, startTime, endTime, func);
                querySql = SqlUtils.assembleTreeSqlFunction (querySql, map, objectTreeList);
                
                //查询总记录数
                DataSourceBean ds = dataSourceMapper.getDataSourceById (rd.getCnnId ());
                rd.setDbType (ds.getDbType ());
                JdbcTemplate jdbcTemplate = JDBCTemplateUtil.getJDBC (rd.getCnnId ());
                int count = jdbcTemplate.queryForObject (SqlUtils.getCountSql (querySql), Integer.class);
                
                Map <String, Object> position = ExcelWrite.excelColStrToNum (rd.getToexcel ());
                
                int page = count % PAGE_SIAE == 0 ? count / PAGE_SIAE : count / PAGE_SIAE + 1;
                String[] title = null;
                for (int i = 1; i <= page; i++)
                {
                    LOGGER.info ("sql: " + SqlUtils.getPageSql (i, PAGE_SIAE, querySql, ds.getDbType ()));
                    LOGGER.info ("position: " + position);
                    datas = jdbcTemplate.queryForList (SqlUtils.getPageSql (i, PAGE_SIAE, querySql, ds.getDbType ()));
                    if (null != datas && 0 != datas.size ())
                    {
                        title = (String[]) (datas.get (0).keySet ().toArray (new String[0]));
                    }
                    ExcelWrite.writeToExcel (workBook, tempPath, datas, position, title);
                    position.put (ReportConstant.REPORT_SHEET_ROW, (int) position.get (ReportConstant.REPORT_SHEET_ROW)
                        + PAGE_SIAE);
                    datas.clear ();
                }
            }
            out = new FileOutputStream (tempPath);
            workBook.setForceFormulaRecalculation (true);
            workBook.write (out);
            out.flush ();
            out.close ();
        }
        catch (Exception e)
        {
            recordReportStatus (reportFile, ReportConstant.REPORT_FAILURE, "Cause : Generate File Failure");
            LOGGER.error ("generate report - query sql error", e);
            return false;
        }
        finally
        {
            
            IOUtils.closeQuietly (out);
        }
        
        try
        {
            ExcelWrite.uploadFileToFtp (tempPath, targetDir);
            ExcelWrite.deleteExcel (tempPath);
            htmlPools.submit (new HtmlGenerateTask (reportFileMapper, template, list, func, objectTreeMapper, date_formatter));
            
        }
        catch (Exception e)
        {
            recordReportStatus (reportFile, ReportConstant.REPORT_FAILURE, "Cause : Upload File Failure");
            LOGGER.error ("generate report - error", e);
            return false;
        }
        return true;
    }
    
    private void recordReportStatus (ReportFile reportFile, String status, String desc)
    {
        reportFile.setReportStatus (status);
        reportFile.setReportDesc (desc);
        reportFileMapper.editReportFile (reportFile);
        reportFileMapper.editReportLog (reportFile);
    }
    
    /**
     * 创建Workbook
     * @return
     */
    private Workbook createWorkBook (String tempPath)
    {
        Workbook workBook = null;
        try
        {
            FileInputStream in = new FileInputStream (new File (tempPath));
            if (tempPath.endsWith (ReportConstant.REPORT_SUFFIX_XLS))
            {
                workBook = new HSSFWorkbook (in);
            }
            else
            {
                XSSFWorkbook xwork = new XSSFWorkbook (in);
                workBook = new SXSSFWorkbook (xwork, 1000);
            }
        }
        catch (Exception e)
        {
            LOGGER.error ("createWorkBook fail.", e);
        }
        
        return workBook;
    }
    
}
