package com.icss.ebu.ami.report.business.mapper;

import java.util.List;

import com.icss.ebu.ami.commons.pagePlugin.Page;
import com.icss.ebu.ami.report.business.model.DataSourceBean;
import com.icss.ebu.ami.report.business.model.DataSourceTable;
import com.icss.ebu.ami.report.business.model.DataSourceTableFiled;

public interface DataSourceMapper
{
    List <DataSourceBean> getAllDataSource ();
    
    List <DataSourceBean> getAllDataSourceByUserId (String userId);
    
    List <DataSourceBean> getDataSourceList (Page <DataSourceBean> page);
    
    DataSourceBean getDataSourceById (String id);
    
    DataSourceBean getDataSourceByKey (String key);
    
    Integer delDataSourceById (String id);
    
    Integer addDataSource (DataSourceBean ds);
    
    Integer updateDataSource (DataSourceBean ds);
    
    Integer addDataSourceTable (List <DataSourceTable> dstList);
    
    Integer addDataSourceTableFiled (List <DataSourceTableFiled> dstfList);
    
    //获取数据源下所有表
    List <DataSourceTable> getDataSourceTable (String dsId);
    
    //删除数据源表字段
    Integer delDataSourceTableFiledById (String id);
    
    //删除数据源表
    Integer delDataSourceTableById (String id);
    
    //删除具体表
    Integer delTableByTableNameAndDsId (DataSourceTable dataSourceTable);
    
    //删除具体表关联字段
    Integer delTableFiledByTableNameAndDsId (DataSourceTable dataSourceTable);
    
    int getTableCount (DataSourceTable dataSourceTable);
    
}