package com.icss.ebu.ami.report.system.shiro;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.shiro.SecurityUtils;

public class AuthFilter implements Filter
{
    public void doFilter (ServletRequest request, ServletResponse response, FilterChain chain)
        throws IOException, ServletException
    {
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse rep = (HttpServletResponse) response;
        //获取登录用户的Session --基础权限检查，用户没有登陆，被拦截或者session超时请重新登录
        if (!SecurityUtils.getSubject ().isAuthenticated ())
        {
            if (req.getHeader ("x-requested-with") != null
                && req.getHeader ("x-requested-with").equalsIgnoreCase ("XMLHttpRequest"))
            {
                rep.setHeader ("sessionstatus", "timeout");//在响应头设置session状态
                return;
            }
        }
        chain.doFilter (request, response);//跳转页面
    }
    
    @Override
    public void destroy ()
    {
        // TODO Auto-generated method stub
    }
    
    @Override
    public void init (FilterConfig arg0) throws ServletException
    {
        // TODO Auto-generated method stub
    }
}
