package com.icss.ebu.ami.report.business.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.icss.ebu.ami.commons.pagePlugin.Page;
import com.icss.ebu.ami.report.business.common.constant.CommonConstant;
import com.icss.ebu.ami.report.business.common.constant.ReportConstant;
import com.icss.ebu.ami.report.business.model.ReportTask;
import com.icss.ebu.ami.report.business.model.ReportTaskObj;
import com.icss.ebu.ami.report.business.model.ReportTaskTemp;
import com.icss.ebu.ami.report.business.model.ReportTaskTempObjs;
import com.icss.ebu.ami.report.business.service.ObjectTreeService;
import com.icss.ebu.ami.report.business.service.ReportTaskService;
import com.icss.ebu.ami.report.system.model.User;

@Controller
@RequestMapping ("/reportTask")
public class ReportTaskController extends BaseController
{
    private static final Logger LOGGER = LoggerFactory.getLogger(ReportController.class);
    
    @Autowired
    private ReportTaskService reportTaskService;
    
    @Autowired
    private ObjectTreeService objectTreeService;
    
    @RequestMapping ("")
    public String index()
    {
        return "/service/task/reportTask";
    }
    
    @RequestMapping ("/detailPage")
    public String detailPage()
    {
        return "/service/task/reportTaskDetails";
    }
    
    @RequestMapping ("/tempConfPage")
    public String tempConfPage()
    {
        return "/service/task/taskTempConfig";
    }
    
    @RequestMapping ("/objConfPage")
    public String objConfPage()
    {
        return "/service/task/taskObjConfig";
    }
    
    @RequestMapping ("/datagrid")
    @ResponseBody
    public Map<String, Object> datagrid(ReportTask reportTask, HttpServletRequest request)
    {
        Map<String, Object> map = new HashMap<String, Object>();
        Page<ReportTask> page = new Page<ReportTask>(reportTask);
        page.setPageNo(NumberUtils.toInt(request.getParameter(CommonConstant.PAGE_PARAM_PAGE)));
        page.setPageSize(NumberUtils.toInt(request.getParameter(CommonConstant.PAGE_PARAM_ROWS)));
        
        page = reportTaskService.queryReportTaskByPage(page);
        map.put(CommonConstant.PAGE_RESULT_ROWS, page.getResults());
        map.put(CommonConstant.PAGE_RESULT_TOTAL, page.getTotalRecord());
        return map;
    }
    
    @RequestMapping ("/update")
    @ResponseBody
    public Object update(@RequestBody ReportTask reportTask)
    {
        int rt = 0;
        String id = reportTask.getId();
        try
        {
            if(StringUtils.isBlank(id))
            {
                reportTask.setCode("01");
                rt = reportTaskService.addReportTask(reportTask);
            }
            else
            {
                ReportTask r = reportTaskService.queryReportTaskById(id);
                if(!r.getType().equals(reportTask.getType()))
                {
                    reportTaskService.delTaskReportsByTaskId(id);
                    reportTaskService.delTaskObjectsByTaskId(id);
                }
                rt = reportTaskService.editReportTask(reportTask);
            }
        }
        catch (Exception e)
        {
            LOGGER.error("update reportTask error.", e);
        }
        if(rt == 1)
        {
            return renderSuccess(super.getProperty("ami.common.optSuccess"));
        }
        else
        {
            return renderError(super.getProperty("ami.common.optFail"));
        }
    }
    
    @RequestMapping ("/tempConfig")
    @ResponseBody
    public Object tempConfig(@RequestBody ReportTask reportTask)
    {
        String id = reportTask.getId();
        
        try
        {
            String[] tmpIds = reportTask.getTmpIds().split(",");
            reportTaskService.delTaskReportsByTaskId(id);
            reportTaskService.delTaskObjectsByTaskId(id);
            if(tmpIds.length > 0)
            {
                ReportTaskTemp r = new ReportTaskTemp();
                r.setTaskId(id);
                for(String tmpId : tmpIds)
                {
                    if(StringUtils.isNotBlank(tmpId))
                    {
                        r.setTmpId(tmpId);
                        reportTaskService.addTaskReports(r);
                    }
                }
            }
            return renderSuccess(super.getProperty("ami.common.optSuccess"));
        }
        catch (Exception e)
        {
            LOGGER.error("tempConfig error.", e);
            return renderError(super.getProperty("ami.common.optFail"));
        }
    }
    
    @RequestMapping ("/objConfig")
    @ResponseBody
    public Object objConfig(@RequestBody ReportTask reportTask)
    {
        String id = reportTask.getId();
        
        try
        {
            String[] objTreeMaps = reportTask.getObjTreeMaps().split(";");
            reportTaskService.delTaskObjectsByTaskId(id);
            if(objTreeMaps.length > 0)
            {
                ReportTaskObj r = new ReportTaskObj();
                r.setTaskId(id);
                for(String o : objTreeMaps)
                {
                    if(StringUtils.isNotBlank(o))
                    {
                        String[] s = o.split(",");
                        if(StringUtils.isNotBlank(s[2]))
                        {
                            r.setObjId(s[0]);
                            r.setObjName(s[1]);
                            r.setTreeCode(s[2]);
                            r.setTreeName(s[3]);
                            r.setTreeId(s[4]);
                            reportTaskService.addTaskObjects(r);
                        }
                    }
                }
            }
            return renderSuccess(super.getProperty("ami.common.optSuccess"));
        }
        catch (Exception e)
        {
            LOGGER.error("objConfig error.", e);
            return renderError(super.getProperty("ami.common.optFail"));
        }
    }
    
    @RequestMapping ("/delete")
    @ResponseBody
    public Object delete(@RequestBody ReportTask reportTask)
    {
        int rt = 0;
        String id = reportTask.getId();
        try
        {
            rt = reportTaskService.delReportTaskById(id);
        }
        catch (Exception e)
        {
            LOGGER.error("delete reportTask error.", e);
        }
        if(rt == 1)
        {
            try
            {
                reportTaskService.delTaskReportsByTaskId(id);
            }
            catch (Exception e)
            {
                LOGGER.error("delete reportTask error.", e);
            }
            return renderSuccess(super.getProperty("ami.common.optSuccess"));
        }
        else
        {
            return renderError(super.getProperty("ami.common.optFail"));
        }
    }
    
    /**
     * 报表生成页面根据报表模板绑定的对象树类型展示列表
     * @param request
     * @return
     */
    @RequestMapping ("/queryObject")
    @ResponseBody
    public Object queryForReport(HttpServletRequest request)
    {
        ReportTaskTempObjs reportTaskTempObjs = new ReportTaskTempObjs();
        User currentUser = getCurrentUser();
        if(!ReportConstant.REPORT_USERID_ROOT.equals(currentUser.getId()))
        {
            reportTaskTempObjs.setUserId(currentUser.getId());
        }
        String tmpIds = request.getParameter("tmpIds");
        if(StringUtils.isNotBlank(tmpIds))
        {
            reportTaskTempObjs.setIds(tmpIds.split(","));
        }
        
        return objectTreeService.queryObjectTreesListByTempIds(reportTaskTempObjs);
    }
    
    /**
     * 立即执行
     * @param reportTask
     *
     */
    @RequestMapping ("/doTask")
    @ResponseBody
    public Object doTask(@RequestBody ReportTask reportTask)
    {
        String id = reportTask.getId();
        if(StringUtils.isNotBlank(id))
        {
            try
            {
                reportTaskService.taskGenerateReport(id);
                return renderSuccess(super.getProperty("ami.common.optSuccess"));
            }
            catch (Exception e)
            {
                return renderError(super.getProperty("ami.common.optFail"));
            }
        }
        return renderError(super.getProperty("ami.common.optFail"));
    }
    
    /**
     * 立即执行
     * @param reportTask
     *
     */
    @RequestMapping ("/generateCron")
    public Object generateCron(HttpServletRequest request)
    {
        return "/service/task/generateCron";
    }
    
}
