package com.icss.ebu.ami.report.business.mapper;

import com.icss.ebu.ami.auth.domain.oauth.AccessToken;
import com.icss.ebu.ami.auth.domain.oauth.ClientDetails;

public interface OauthMapper
{
    public AccessToken findAccessTokenByTokenId (String tokenId);
    
    public ClientDetails findClientDetailsByClientIdAndResourceIds (ClientDetails clientDetails);
}
