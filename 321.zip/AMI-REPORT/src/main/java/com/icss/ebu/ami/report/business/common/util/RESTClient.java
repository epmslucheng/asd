package com.icss.ebu.ami.report.business.common.util;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.List;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.client.HttpClient;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.DefaultHttpRequestRetryHandler;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.ssl.TrustStrategy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.alibaba.fastjson.JSON;
import com.icss.ebu.ami.commons.aspect.RedisCacheUtil;

/**
 * restful接口调用方法
 * @author luis
 *
 */
public class RESTClient
{
    private static final Logger LOGGER = LoggerFactory.getLogger (RESTClient.class);
    
    private static RedisCacheUtil redisCacheUtil = new RedisCacheUtil ();
    
    //单例获取RESTClient类 
    private static class restClientHolder
    {
        private static final RESTClient restClient = new RESTClient ();
    }
    
    private RESTClient ()
    {
    }
    
    public static final RESTClient getInstance ()
    {
        return restClientHolder.restClient;
    }
    
    //单例获取RestTemplate类      
    private static class restTemplateHolder
    {
        private static final RestTemplate restTemplate = new RestTemplate ();
    }
    
    private static final RestTemplate getRestTemplateInstance ()
    {
        return restTemplateHolder.restTemplate;
    }
    
    /**
     * 接口调用
     * ssl
     * @param modelBaseUrl  服务接口URL
     * @param postDataJsonStr  接口请求参数
     * @return
     */
    public String callBack (String modelBaseUrl, String postDataJsonStr)
    {
        
        // RestTemplate restTemplate = RESTClient.getRestTemplateInstance ();
        HttpEntity <String> entity = new HttpEntity <String> (postDataJsonStr, getHttpHeaders (""));
        try
        {
            //trustAllHttpsCertificates ();
            RestTemplate restTemplate = new RestTemplate (clientHttpRequestFactory ());
            return restTemplate.postForObject (modelBaseUrl, entity, String.class);
        }
        catch (Exception e)
        {
            LOGGER.error (e.getMessage (), e);
            return null;
        }
    }
    
    public HttpComponentsClientHttpRequestFactory clientHttpRequestFactory ()
    {
        try
        {
            HttpClientBuilder httpClientBuilder = HttpClientBuilder.create ();
            SSLContext sslContext = new SSLContextBuilder ().loadTrustMaterial (null, new TrustStrategy ()
            {
                public boolean isTrusted (X509Certificate[] arg0, String arg1) throws CertificateException
                {
                    return true;
                }
            }).build ();
            httpClientBuilder.setSSLContext (sslContext);
            HostnameVerifier hostnameVerifier = NoopHostnameVerifier.INSTANCE;
            SSLConnectionSocketFactory sslConnectionSocketFactory = new SSLConnectionSocketFactory (sslContext, hostnameVerifier);
            Registry <ConnectionSocketFactory> socketFactoryRegistry =
                RegistryBuilder.<ConnectionSocketFactory> create ()
                    .register ("http", PlainConnectionSocketFactory.getSocketFactory ())
                    .register ("https", sslConnectionSocketFactory).build ();// 注册http和https请求
            PoolingHttpClientConnectionManager poolingHttpClientConnectionManager =
                new PoolingHttpClientConnectionManager (socketFactoryRegistry);// 开始设置连接池
            poolingHttpClientConnectionManager.setMaxTotal (200); // 最大连接数200
            poolingHttpClientConnectionManager.setDefaultMaxPerRoute (20); // 同路由并发数20
            httpClientBuilder.setConnectionManager (poolingHttpClientConnectionManager);
            httpClientBuilder.setRetryHandler (new DefaultHttpRequestRetryHandler (2, true));// 重试次数
            HttpClient httpClient = httpClientBuilder.build ();
            HttpComponentsClientHttpRequestFactory clientHttpRequestFactory =
                new HttpComponentsClientHttpRequestFactory (httpClient);// httpClient连接配置
            clientHttpRequestFactory.setConnectTimeout (20000);// 连接超时
            clientHttpRequestFactory.setReadTimeout (20000);// 数据读取超时时间
            clientHttpRequestFactory.setConnectionRequestTimeout (200);// 连接不够用的等待时间
            return clientHttpRequestFactory;
        }
        catch (KeyManagementException | NoSuchAlgorithmException | KeyStoreException e)
        {
            LOGGER.error (e.getMessage ());
        }
        return null;
    }
    
    public String postMethodCall (String modelBaseUrl, String postDataJsonStr)
    {
        
        RestTemplate restTemplate = RESTClient.getRestTemplateInstance ();
        HttpEntity <String> entity = new HttpEntity <String> (postDataJsonStr, getHttpHeaders (""));
        try
        {
            trustAllHttpsCertificates ();
            LOGGER.info ("[Request Url:] " + modelBaseUrl);
            LOGGER.info ("[Request Data:] \n" + postDataJsonStr);
            String returnStr = restTemplate.postForObject (modelBaseUrl, entity, String.class);
            LOGGER.info ("[Response Data:] \n" + returnStr);
            return returnStr == null ? StringUtils.EMPTY : returnStr;
        }
        catch (Exception e)
        {
            LOGGER.error (e.getMessage (), e);
            return StringUtils.EMPTY;
        }
    }
    
    /**
     * 文件上传
     * @param <T>
     * @param curveDataUrl 调用URL接口
     * @param zipPath 文件路径
     * @return
     * @throws Exception
     */
    @SuppressWarnings ("rawtypes")
    public <T> T postUploadCall (String modelBaseUrl, String zipPath, String fileName, String taskId, Class <T> clazz)
    {
        
        RestTemplate restTemplate = RESTClient.getRestTemplateInstance ();
        FileSystemResource resource = new FileSystemResource (new File (zipPath));
        MultiValueMap <String, Object> param = new LinkedMultiValueMap <> ();
        param.add ("file", resource);
        param.add ("fileName", fileName);
        param.add ("taskId", taskId);
        
        HttpHeaders headers = new HttpHeaders ();
        headers.add ("Accept", MediaType.APPLICATION_JSON_VALUE);
        headers.add ("X-ACCESS-TOKEN", "");
        
        HttpEntity <MultiValueMap> entity = new HttpEntity <MultiValueMap> (param, headers);
        
        try
        {
            trustAllHttpsCertificates ();
            return restTemplate.postForObject (modelBaseUrl, entity, clazz);
        }
        catch (Exception e)
        {
            LOGGER.error (e.getMessage (), e);
            return null;
        }
    }
    
    /**
     * 使用spring RestTemplate调用cxf REST web服务
     * 
     * @param requestParams
     * 参数对象体
     * @param modelBaseUrl
     * 模块的基础url地址
     * @param serviceUri
     * 请求具体服务的uri地址
     * @return
     */
    public String getMethodCall (String modelBaseUrl, String serviceUri, String... requestParams)
    {
        HttpHeaders headers = new HttpHeaders ();
        headers.add ("Content-Type", MediaType.APPLICATION_JSON_VALUE);
        headers.add ("Accept", MediaType.APPLICATION_JSON_VALUE);
        HttpEntity <String> entity = new HttpEntity <String> ("", headers);
        RestTemplate restTemplate = RESTClient.getRestTemplateInstance ();
        //解决中文乱码问题
        resetCnMessageConverter (restTemplate);
        ResponseEntity <Object> response = null;
        String jsonResult = null;
        if (requestParams.length == 0)
        {
            response = restTemplate.exchange (modelBaseUrl + serviceUri, HttpMethod.GET, entity, Object.class);
        }
        else
        {
            response = restTemplate.exchange (modelBaseUrl + serviceUri, HttpMethod.GET, entity, Object.class, requestParams);
        }
        if (response.getStatusCode () == HttpStatus.OK)
        {
            jsonResult = JSON.toJSONString (response.getBody ());
        }
        return jsonResult;
    }
    
    /**
     * 生成接口请求头
     * @return
     * @throws Exception 
     */
    private HttpHeaders getHttpHeaders (String token_id)
    {
        HttpHeaders headers = new HttpHeaders ();
        headers.add ("Content-Type", MediaType.APPLICATION_FORM_URLENCODED_VALUE);
        headers.add ("Accept", MediaType.APPLICATION_JSON_VALUE);
        headers.add ("X-ACCESS-TOKEN", token_id);
        return headers;
    }
    
    /**
     * 信任所有SSL连接
     * @throws NoSuchAlgorithmException 
     * @throws KeyManagementException 
     * @throws Exception
     */
    private void trustAllHttpsCertificates () throws NoSuchAlgorithmException, KeyManagementException
    {
        javax.net.ssl.TrustManager[] trustAllCerts = new javax.net.ssl.TrustManager[1];
        javax.net.ssl.TrustManager tm = new miTM ();
        trustAllCerts[0] = tm;
        javax.net.ssl.SSLContext sc = javax.net.ssl.SSLContext.getInstance ("SSL");
        sc.init (null, trustAllCerts, null);
        javax.net.ssl.HttpsURLConnection.setDefaultSSLSocketFactory (sc.getSocketFactory ());
    }
    
    static class miTM implements javax.net.ssl.TrustManager, javax.net.ssl.X509TrustManager
    {
        public java.security.cert.X509Certificate[] getAcceptedIssuers ()
        {
            return null;
        }
        
        public boolean isServerTrusted (java.security.cert.X509Certificate[] certs)
        {
            return true;
        }
        
        public boolean isClientTrusted (java.security.cert.X509Certificate[] certs)
        {
            return true;
        }
        
        public void checkServerTrusted (java.security.cert.X509Certificate[] certs, String authType)
            throws java.security.cert.CertificateException
        {
            return;
        }
        
        public void checkClientTrusted (java.security.cert.X509Certificate[] certs, String authType)
            throws java.security.cert.CertificateException
        {
            return;
        }
    }
    
    /*
     * 初始化RestTemplate，RestTemplate会默认添加HttpMessageConverter
     * 添加的StringHttpMessageConverter非UTF-8 所以先要移除原有的StringHttpMessageConverter，
     * 再添加一个字符集为UTF-8的StringHttpMessageConvert
     */
    private void resetCnMessageConverter (RestTemplate restTemplate)
    {
        List <HttpMessageConverter <?>> converterList = restTemplate.getMessageConverters ();
        HttpMessageConverter <?> converterTarget = null;
        for (HttpMessageConverter <?> item : converterList)
        {
            if (item.getClass () == StringHttpMessageConverter.class)
            {
                converterTarget = item;
                break;
            }
        }
        
        if (converterTarget != null)
        {
            converterList.remove (converterTarget);
        }
        HttpMessageConverter <?> converter = new StringHttpMessageConverter (StandardCharsets.UTF_8);
        converterList.add (converter);
    }
    
}
