package com.icss.ebu.ami.report.business.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.icss.ebu.ami.report.system.model.User;

public class UserRowMapper implements RowMapper <User>
{
    
    @Override
    public User mapRow (ResultSet rs, int rowNum) throws SQLException
    {
        User user = new User ();
        user.setId (rs.getString ("ID"));
        user.setLoginname (rs.getString ("LOGINNAME"));
        user.setName (rs.getString ("NAME"));
        user.setPassword (rs.getString ("PASSWORD"));
        
        return user;
    }
    
}
