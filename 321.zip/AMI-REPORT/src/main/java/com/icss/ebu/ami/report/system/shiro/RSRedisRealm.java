/*
 * Copyright (c) 2015 MONKEYK Information Technology Co. Ltd
 * www.monkeyk.com
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * MONKEYK Information Technology Co. Ltd ("Confidential Information").
 * You shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement you
 * entered into with MONKEYK Information Technology Co. Ltd.
 */
package com.icss.ebu.ami.report.system.shiro;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.shiro.authc.AccountException;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.SimpleAuthenticationInfo;
import org.apache.shiro.authz.AuthorizationException;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.Assert;
import org.springframework.util.StringUtils;

import com.icss.ebu.ami.auth.domain.oauth.AccessToken;
import com.icss.ebu.ami.auth.domain.oauth.ClientDetails;
import com.icss.ebu.ami.auth.exception.OAuth2AuthenticationException;
import com.icss.ebu.ami.auth.oauth.shiro.OAuth2Token;
import com.icss.ebu.ami.commons.aspect.RedisCacheUtil;
import com.icss.ebu.ami.report.business.service.OAuthRSService;
import com.icss.ebu.ami.report.business.service.UserService;
import com.icss.ebu.ami.report.system.common.shiro.ShiroUser;
import com.icss.ebu.ami.report.system.model.User;
import com.icss.ebu.ami.report.system.service.RoleService;

/**
 * 2015/10/27
 *
 * @author Shengzhao Li
 */
public class RSRedisRealm extends AuthorizingRealm implements InitializingBean
{
    
    private static final Logger LOG = LoggerFactory.getLogger (RSRedisRealm.class);
    
    @Autowired
    private OAuthRSService rsService;
    
    @Autowired
    private UserService userService;
    
    @Autowired
    private RoleService roleService;
    
    private RedisCacheUtil redisCacheUtil = new RedisCacheUtil ();
    
    public RSRedisRealm ()
    {
        super ();
        setAuthenticationTokenClass (OAuth2Token.class);
        LOG.debug ("Initial Resources-Realm: {}, set authenticationTokenClass = {}", this, getAuthenticationTokenClass ());
    }
    
    @Override
    public AuthenticationInfo doGetAuthenticationInfo (AuthenticationToken token) throws AuthenticationException
    {
        
        OAuth2Token upToken = (OAuth2Token) token;
        final String accessToken = (String) upToken.getCredentials ();
        
        if (StringUtils.isEmpty (accessToken))
        {
            throw new OAuth2AuthenticationException ("Invalid access_token: " + accessToken);
        }
        //Validate access token
        AccessToken aToken = rsService.loadAccessTokenByTokenId (accessToken);
        validateToken (accessToken, aToken);
        
        //Validate client details by resource-id
        final ClientDetails clientDetails = rsService.loadClientDetails (aToken.clientId (), upToken.getResourceId ());
        validateClientDetails (accessToken, aToken, clientDetails);
        
        String username = aToken.username ();
        
        // Null username is invalid
        if (username == null)
        {
            throw new AccountException ("Null usernames are not allowed by this realm.");
        }
        
        User user = userService.findUserByLoginName (username);
        // 账号不存在
        if (user == null)
        {
            return null;
        }
        // 账号未启用
        if (user.getStatus () == 1)
        {
            return null;
        }
        if (StringUtils.isEmpty (user.getPwdFirstUpdate ()))
        {
            user.setPwdFirstUpdate ("0");
        }
        List <Long> roleList = roleService.findRoleIdListByUserId (user.getId ());
        
        ShiroUser shiroUser = new ShiroUser (user.getId (), user.getLoginname (), user.getName (), roleList);
        
        // 认证缓存信息
        return new SimpleAuthenticationInfo (shiroUser, accessToken, getName ());
        // return new SimpleAuthenticationInfo (username, accessToken, getName ());
    }
    
    private void validateToken (String token, AccessToken accessToken) throws OAuth2AuthenticationException
    {
        if (accessToken == null)
        {
            LOG.info ("Invalid access_token: {}, because it is null", token);
            throw new OAuth2AuthenticationException ("Invalid access_token: " + token);
        }
        if (accessToken.tokenExpired ())
        {
            LOG.info ("Invalid access_token: {}, because it is expired", token);
            throw new OAuth2AuthenticationException ("Invalid access_token: " + token);
        }
    }
    
    private void validateClientDetails (String token, AccessToken accessToken, ClientDetails clientDetails)
        throws OAuth2AuthenticationException
    {
        if (clientDetails == null || clientDetails.archived ())
        {
            LOG.debug ("Invalid ClientDetails: {} by client_id: {}, it is null or archived", clientDetails,
                accessToken.clientId ());
            throw new OAuth2AuthenticationException ("Invalid client by token: " + token);
        }
    }
    
    public void setRsService (OAuthRSService rsService)
    {
        this.rsService = rsService;
    }
    
    @Override
    protected AuthorizationInfo doGetAuthorizationInfo (PrincipalCollection principals)
    {
        
        /*final String username = getUsername (principals);
        
        List <Roles> roles = roleService.findRoleIdListByUserId (username);
        LOG.debug ("Load Roles[{}] by username: {}", roles, username);
        
        SimpleAuthorizationInfo info = new SimpleAuthorizationInfo ();
        
        for (Roles role : roles)
        {
            info.addRole (role.roleName ());
            for (RolesPermissions permissions : role.permissions ())
            {
                info.addStringPermission (permissions.permission ());
            }
        }
        
        return info;*/
        
        clearCachedAuthenticationInfo (principals);
        ShiroUser shiroUser = (ShiroUser) principals.getPrimaryPrincipal ();
        List <Long> roleList = shiroUser.getRoleList ();
        
        Set <String> urlSet = new HashSet <String> ();
        for (Long roleId : roleList)
        {
            List <String> roleResourceList = roleService.findResourcesByRoleId (roleId);
            if (CollectionUtils.isNotEmpty (roleResourceList))
            {
                urlSet.addAll (roleResourceList);
            }
        }
        SimpleAuthorizationInfo info = new SimpleAuthorizationInfo ();
        info.addStringPermissions (urlSet);
        //redis
        redisCacheUtil.saveDataInRedis (shiroUser.loginName, urlSet, -1);
        return info;
        
    }
    
    protected String getUsername (PrincipalCollection principals)
    {
        //null usernames are invalid
        if (principals == null)
        {
            throw new AuthorizationException ("PrincipalCollection method argument cannot be null.");
        }
        
        return (String) getAvailablePrincipal (principals);
    }
    
    @Override
    public void afterPropertiesSet () throws Exception
    {
        Assert.notNull (userService, "usersRepository is null");
    }
}
