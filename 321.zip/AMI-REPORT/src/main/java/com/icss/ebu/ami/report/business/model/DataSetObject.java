package com.icss.ebu.ami.report.business.model;

import java.io.Serializable;

public class DataSetObject implements Serializable
{
    
    /**
     * 
     */
    private static final long serialVersionUID = 7860986212283858195L;
    
    private String id;
    
    private String queryId;
    
    private String objectId;
    
    public String getId ()
    {
        return id;
    }
    
    public void setId (String id)
    {
        this.id = id;
    }
    
    public String getQueryId ()
    {
        return queryId;
    }
    
    public void setQueryId (String queryId)
    {
        this.queryId = queryId;
    }
    
    public String getObjectId ()
    {
        return objectId;
    }
    
    public void setObjectId (String objectId)
    {
        this.objectId = objectId;
    }
    
}
