package com.icss.ebu.ami.report.system.core.task;

import java.util.*;

/**
 * @author tfl
 * @version [版本号]
 * @since [产品/模块版本]
 * @see [相关类/方法]
 */
public class CronExpreUtil
{
    
    /**
     * 获得定期任务时间间隔
     * 
     * @param priodNum
     *            采集周期
     * @param timeUnit
     *            周期單位
     * @return 返回秒数
     */
    public static int getIntervalSecond(int priodNum, String timeUnit)
    {
        return priodNum * getTimeUnitSecond (timeUnit);
    }
    
    /**
     * 获得定期任务时间间隔
     * 
     * @param timeUnit
     * @return 返回秒数
     */
    public static int getTimeUnitSecond(String timeUnit)
    {
        int rev = 0;
        if ("1".equals (timeUnit))
        {
            // 秒
            rev = 1;
        }
        else if ("2".equals (timeUnit))
        {
            // 分
            rev = 60;
        }
        else if ("3".equals (timeUnit))
        {
            // 时
            rev = 3600;
        }
        else if ("4".equals (timeUnit))
        {
            // 天 24*3600
            rev = 86400;
        }
        else if ("5".equals (timeUnit))
        {
            // 周 7*24*3600
            rev = 604800;
        }
        else if ("6".equals (timeUnit))
        {
            // 旬 10*24*3600
            rev = 864000;
        }
        else if ("7".equals (timeUnit))
        {
            // 月 默认 30天，其实应该使用表达式来确定30*24*3600
            rev = 2592000;
        }
        else if ("8".equals (timeUnit))
        {
            // 季默认90天，应该使用表达式来确定90*24*3600
            rev = 7776000;
        }
        else if ("9".equals (timeUnit))
        {
            // 年默认365天 ，应该使用表达式来确定365*24*3600
            rev = 31104000;
        }
        return rev;
    }
    
    /**
     * 定時任務时间表达式
     * 
     * @param date
     * @return
     */
    public static String generateCronExpre(Date date)
    {
        if (date == null)
            return null;
        Calendar calr = Calendar.getInstance ();
        calr.setTime (date);
        
        StringBuilder sb = new StringBuilder ().append (calr.get (Calendar.SECOND)).append (" ");
        sb.append (calr.get (Calendar.MINUTE)).append (" ");
        sb.append (calr.get (Calendar.HOUR_OF_DAY)).append (" ");
        sb.append (calr.get (Calendar.DAY_OF_MONTH)).append (" ");
        sb.append (calr.get (Calendar.MONTH) + 1).append (" ");
        sb.append (calr.get (Calendar.DAY_OF_WEEK)).append (" ");
        sb.append (calr.get (Calendar.YEAR));
        return sb.toString ();
    }
    
    /**
     * 定時任務时间表达式 (间隔月数 1,2,3,4,6,12)
     * 
     * @param date
     * @param priodNum
     * @param timeUnit
     * @return
     */
    public static String generateCronExpre(Date date, int priodNum, String timeUnit)
    {
        if (date == null)
            return null;
        Calendar calr = Calendar.getInstance ();
        calr.setTime (date);
        StringBuilder sb = new StringBuilder ().append (calr.get (Calendar.SECOND)).append (" ");
        sb.append (calr.get (Calendar.MINUTE)).append (" ");
        sb.append (calr.get (Calendar.HOUR_OF_DAY)).append (" ");
        sb.append (calr.get (Calendar.DAY_OF_MONTH)).append (" ");
        int curMonth = calr.get (Calendar.MONTH) + 1;
        int intervalMonth = getIntervalMonth (priodNum, timeUnit);
        if (intervalMonth == 1)
        {
            sb.append ("*");
        }
        else
        {
            sb.append (getExpreMonth (curMonth, intervalMonth));
        }
        sb.append (" ? *");
        return sb.toString ();
    }
    
    /**
     * 获得定期任务时间间隔
     * 
     * @param priodNum
     *            采集周期
     * @param timeUnit
     *            周期單位
     * @return 返回月数
     */
    public static int getIntervalMonth(int priodNum, String timeUnit)
    {
        return priodNum * getTimeUnitMonth (timeUnit);
    }
    
    /**
     * 获得定期任务时间间隔
     * 
     * @param timeUnit
     * @return 返回月数
     */
    public static int getTimeUnitMonth(String timeUnit)
    {
        int rev = 0;
        if ("7".equals (timeUnit))
        {
            // 月 默认 30天，其实应该使用表达式来确定30*24*3600
            rev = 1;
        }
        else if ("8".equals (timeUnit))
        {
            // 季默认90天，应该使用表达式来确定90*24*3600
            rev = 3;
        }
        else if ("9".equals (timeUnit))
        {
            // 年默认365天 ，应该使用表达式来确定365*24*3600
            rev = 12;
        }
        return rev;
    }
    
    /**
     * 判断是否使用表达式
     * 
     * @param priodNum
     *            周期数
     * @param timeUnit
     *            周期单位
     * @return true:使用表达式 ，false:不使用
     */
    public static boolean isCronExpre(int priodNum, String timeUnit)
    {
        int num = getIntervalMonth (priodNum, timeUnit);
        if (num == 1 || num == 2 || num == 3 || num == 4 || num == 6 || num == 12)
        {
            return true;
        }
        return false;
    }
    
    /**
     * 计算定期任务调用次数
     * 
     * @param spaceTime
     *            调用间隔时间
     * @param bgnTime
     *            开始时间
     * @param endTime
     *            结束时间
     * @return 返回调用次数
     */
    public static int calcRepeatCount(long spaceTime, Date bgnTime, Date endTime)
    {
        if (null == endTime || spaceTime == 0)
        {
            return Integer.MAX_VALUE;
        }
        if (null == bgnTime)
        {
            return Integer.MIN_VALUE;
        }
        long times = (endTime.getTime () - bgnTime.getTime ()) / spaceTime;
        if (times > 2147483647)
        {
            return Integer.MAX_VALUE;
        }
        else if (times < 1)
        {
            return 0;
        }
        return Integer.parseInt (String.valueOf (times));
    }
    
    /**
     * 验证任务调度时间是否有效
     * 
     * 
     * @param startTime
     *            开始时间
     * @param endTime
     *            结束时间
     * @param curTime
     *            当前时间
     * @return 返回true:有效，false:无效
     */
    public static boolean checkTaskTime(Date startTime, Date endTime, Date curTime)
    {
        boolean isValid = true;
        if (startTime == null)
        {
            isValid = false;
        }
        else if (endTime != null && startTime.getTime () > endTime.getTime ())
        {
            isValid = false;
        }
        else if (curTime != null && startTime.getTime () > curTime.getTime ())
        {
            isValid = false;
        }
        else if (endTime != null && curTime != null && curTime.getTime () > endTime.getTime ())
        {
            isValid = false;
        }
        return isValid;
    }
    
    /**
     * 验证任务时间间隔是否有效
     * 
     * 
     * @param bgnTime
     *            开始时间
     * @param endTime
     *            结束时间
     * @param spaceTime
     *            调用间隔时间
     * @return 返回true:有效，false:无效
     */
    public static boolean checkIntervalTime(Integer priodNum, String timeUnit)
    {
        boolean valid = true;
        if (priodNum == null)
        {
            valid = false;
        }
        else if (getIntervalSecond (priodNum, timeUnit) < 1)
        {
            valid = false;
        }
        return valid;
    }
    
    public static Date getNextMonth(Date date)
    {
        Calendar calendar = Calendar.getInstance ();
        calendar.setTime (date); // 设置为当前时间
        calendar.set (Calendar.MONTH, calendar.get (Calendar.MONTH) + 1); // 设置为下一个月
        return calendar.getTime ();
    }
    
    /**
     * 获得异常信息
     * 
     * @param e
     *            异常对象
     * @param len
     *            长度
     * @return String
     */
    public static String getExceptionInfo(Throwable e, int len)
    {
        StringBuilder sb = new StringBuilder ();
        if (null == e)
        {
            return null;
        }
        sb.append ("message:").append (e.getMessage ()).append ("\n\r");
        for (StackTraceElement st : e.getStackTrace ())
        {
            sb.append (st.toString ()).append ("\n\r");
        }
        if (sb.length () > len)
        {
            sb.setLength (len);
        }
        return sb.toString ();
    }
    
    /**
     * 获得表达式中月份内容
     * 
     * @param curMonth
     *            当前月
     * @param intervalMonth
     *            间隔的月数
     * @return String
     */
    private static String getExpreMonth(int curMonth, int intervalMonth)
    {
        List <Integer> months = new ArrayList <Integer> ();
        months.add (curMonth);
        int size = 12 / intervalMonth;
        for (int i = 1; i < size; i++)
        {
            int temp = curMonth + i * intervalMonth;
            if (temp > 12)
            {
                temp -= 12;
            }
            months.add (temp);
        }
        Collections.sort (months);
        StringBuilder monthSb = new StringBuilder ();
        for (Integer month : months)
        {
            monthSb.append (month).append (",");
        }
        monthSb.setLength (monthSb.length () - 1);
        return monthSb.toString ();
    }
    
}
