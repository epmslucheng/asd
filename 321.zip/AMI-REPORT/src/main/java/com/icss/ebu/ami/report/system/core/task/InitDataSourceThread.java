package com.icss.ebu.ami.report.system.core.task;

import java.util.List;
import java.util.TimerTask;


import org.springframework.beans.factory.annotation.Autowired;

import com.alibaba.druid.pool.DruidDataSource;
import com.icss.ebu.ami.report.business.common.util.JDBCTemplateUtil;
import com.icss.ebu.ami.report.business.model.DataSourceBean;
import com.icss.ebu.ami.report.business.service.DataSourceService;

public class InitDataSourceThread extends TimerTask
{

    @Autowired
    private DataSourceService dbSerivce;
    
    @Override
    public void run()
    {
        //初始化数据到cache缓存中
        List<DataSourceBean> dbList = dbSerivce.getAllDataSource();
        
        //清理缓存
        DataSourceThreadCache.clear();
        
        DruidDataSource ds = null;
        DataSourceBean dsBean = null;
        
        for(int i = 0; i < dbList.size(); i++)
        {
            if( null != dbList.get(i)){
                dsBean = dbList.get(i);
                /**
                 * 封装数据
                 */
                ds = JDBCTemplateUtil.pacakageDataSource(dsBean);
                //加入缓存中
                DataSourceThreadCache.setCache(dsBean.getId(), ds);
            }
            
        }
    }
    
}
