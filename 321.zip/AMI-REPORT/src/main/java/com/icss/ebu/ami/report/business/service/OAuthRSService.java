/*
 * Copyright (c) 2013 Andaily Information Technology Co. Ltd
 * www.andaily.com
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Andaily Information Technology Co. Ltd ("Confidential Information").
 * You shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement you
 * entered into with Andaily Information Technology Co. Ltd.
 */
package com.icss.ebu.ami.report.business.service;

import java.util.List;

import com.icss.ebu.ami.auth.domain.oauth.AccessToken;
import com.icss.ebu.ami.auth.domain.oauth.ClientDetails;
import com.icss.ebu.ami.report.system.model.Role;
import com.icss.ebu.ami.report.system.model.User;

/**
 * 2015/7/8
 *
 * @author Shengzhao Li
 */

public interface OAuthRSService
{
    
    AccessToken loadAccessTokenByTokenId (String tokenId);
    
    ClientDetails loadClientDetails (String clientId, String resourceIds);
    
    List <Role> queryRolesByUserId (String userId);
    
    User findUserById (String id);
    
}