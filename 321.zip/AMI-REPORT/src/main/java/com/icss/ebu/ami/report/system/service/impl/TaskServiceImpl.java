package com.icss.ebu.ami.report.system.service.impl;

import com.alibaba.dubbo.config.annotation.Service;
import com.icss.ebu.ami.report.system.core.task.Task;
import com.icss.ebu.ami.report.system.mapper.TaskMapper;
import com.icss.ebu.ami.report.system.service.TaskService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Service ()
@Component ("taskService")
public class TaskServiceImpl implements TaskService
{
    
    @Autowired
    private TaskMapper taskMapper;
    
    @Override
    public List<Task> getAllTask (String taskType)
    {
        Task t = new Task ();
        t.setTaskType (taskType);
        return taskMapper.getAllTask (t);
    }
    
    @Override
    public void updateTaskStatus (Long taskId, Long status)
    {
        Task task = new Task ();
        task.setTaskId (taskId);
        task.setStatus (status);
        taskMapper.updateTaskStatus (task);
    }
    
    @Override
    public Task getTaskById (Long taskId)
    {
        if ((taskId == null) || (taskId <= 0l))
        {
            return null;
        }
        return taskMapper.getTaskById (taskId);
    }
}
