package com.icss.ebu.ami.report.system.core.task;

import com.icss.ebu.ami.commons.context.ContextHelper;
import com.icss.ebu.ami.commons.exception.ServiceException;
import com.icss.ebu.ami.commons.util.GeneralUtils;
import com.icss.ebu.ami.report.system.service.TaskParamService;
import com.icss.ebu.ami.report.system.service.TaskService;
import org.apache.commons.lang3.StringUtils;
import org.quartz.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.SchedulerFactoryBean;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * 任务调度管理器 负责启动初始化所有的任务
 *
 * @author Administrator
 *
 */
@Service ("taskScheduleManager")
public class TaskScheduleManager
{
    
    private Logger logger = LoggerFactory.getLogger (getClass ());
    
    @Autowired
    private TaskService taskService;
    
    @Autowired
    private SchedulerFactoryBean taskSchedulerFactory;
    
    @Autowired
    private TaskParamService taskParamService;
    
    private Map <Long, Task> cachedTaskMap = null;
    
    public TaskScheduleManager ()
    {
        super ();
        cachedTaskMap = Collections.synchronizedMap (new LinkedHashMap <Long, Task> ());
    }
    
    public void init ()
    {
        try
        {
            initTaskScheduler ();
        }
        catch (Exception e)
        {
            logger.error ("TaskScheduleManager init error:", e);
        }
    }
    
    /*
     * 检查任务是否存在
     * */
    public boolean checkTaskExist (Task task)
    {
        return cachedTaskMap.containsKey (task.getTaskId ());
    }
    
    /*
    * 检查任务是否变更
    * */
    public boolean checkTaskModify (Task task)
    {
        return cachedTaskMap.containsKey (task.getTaskId ()) && !cachedTaskMap.get (task.getTaskId ()).compareEquals (task);
    }
    
    /**
     * 增加一个任务到调度计划中
     *
     * @param task
     */
    public void runningTriggerByTask (Task task)
    {
        Trigger t = getTriggerByTask (task);
        if (t == null)
        {
            return;
        }
        try
        {
            Class job = ContextHelper.getContext ().getBean (task.getHandler ()).getClass ();
            JobBuilder jobBuilder = JobBuilder.newJob (job);
            jobBuilder.withIdentity (task.getTaskId ().toString (), TaskConstant.SCAN_TASK);
            jobBuilder.storeDurably (true);
            jobBuilder.withDescription (TaskConstant.SCAN_TASK + task.getName ());
            JobDetail jobDetail = jobBuilder.build ();
            if (t instanceof SimpleTrigger)
            {
                schedulerJob (jobDetail, t);
            }
            else
            {
                CronTrigger cronTrigger = (CronTrigger) t;
                schedulerJob (jobDetail, cronTrigger);
            }
            
            startScheduler ();
        }
        catch (Exception e)
        {
            logger.error ("Start Task:" + task.getName () + " fail [" + e + "]", e);
        }
    }
    
    /**
     * 从任务调度计划中删除一条计划任务
     *
     * @param taskName
     */
    public void removeTask (String taskName, String group)
    {
        try
        {
            pauseTrigger (taskName, group);
            unscheduleJob (taskName, group);
            deleteJob (taskName, group);
        }
        catch (SchedulerException e)
        {
            logger.error ("removeTask name[" + taskName + "],group[" + group + "] failed", e);
            throw new ServiceException (e);
        }
    }
    
    public void addOrUpdateTaskToCached (Task task)
    {
        if (cachedTaskMap.get (task.getTaskId ()) == null)
        {
            cachedTaskMap.put (task.getTaskId (), task);
        }
        else
        {
            cachedTaskMap.get (task.getTaskId ()).copy (task);
        }
        
    }
    
    public void startScheduler () throws SchedulerException
    {
        if (taskSchedulerFactory.getScheduler ().isShutdown ())
        {
            taskSchedulerFactory.getScheduler ().start ();
        }
    }
    
    public void schedulerJob (JobDetail jobDetail, Trigger trigger) throws SchedulerException
    {
        
        try
        {
            taskSchedulerFactory.getScheduler ().scheduleJob (jobDetail, trigger);
        }
        catch (ObjectAlreadyExistsException e)
        {
            logger.info ("Store Task:{} fail, because one already exists with this identification", trigger.getKey ().getName ());
            rescheduleJob (trigger.getKey (), trigger);
        }
    }
    
    public void unscheduleJob (String name, String group) throws SchedulerException
    {
        taskSchedulerFactory.getScheduler ().unscheduleJob (TriggerKey.triggerKey (name, group));
    }
    
    public void deleteJob (String name, String group) throws SchedulerException
    {
        taskSchedulerFactory.getScheduler ().deleteJob (JobKey.jobKey (name, group));
    }
    
    public void pauseTrigger (String name, String group) throws SchedulerException
    {
        taskSchedulerFactory.getScheduler ().pauseTrigger (TriggerKey.triggerKey (name, group));
    }
    
    public Date rescheduleJob (TriggerKey triggerKey, Trigger trigger) throws SchedulerException
    {
        return taskSchedulerFactory.getScheduler ().rescheduleJob (triggerKey, trigger);
    }
    
    /*
    * 检查任务是否有效
    * */
    public boolean checkTaskValid (Task task, Date curDate)
    {
        boolean temp;
        if (Task.REPEAT_MODE_SIMPLE.equals (task.getRepeatMode ()))
        {
            // 定时任务
            temp = (task.getRepeatInterval () != null && task.getRepeatInterval ().longValue () > 0)
                && CronExpreUtil.checkTaskTime (task.getValidTime (), task.getInvalidTime (), curDate);
        }
        else
        {
            // 表达式
            temp = StringUtils.isNotBlank (task.getCronExpre ())
                && CronExpreUtil.checkTaskTime (task.getValidTime (), task.getInvalidTime (), curDate);
        }
        
        return temp && Task.TASK_ISVALID.equals (task.getIsValid ()) && Task.STATUS_RUNNING == task.getStatus ();
    }
    
    /*
    * 初始化所有任务
    * */
    private void initTaskScheduler () throws BeansException
    {
        List <Task> allTaskList = taskService.getAllTask (null);
        Date curDate = new Date ();
        if (GeneralUtils.isNotNullOrZeroSize (allTaskList) && isScheduleRun (allTaskList, curDate))
        {
            
            for (Task task : allTaskList)
            {
                logger.info ("begin to init task(id={},name={})", task.getTaskId (), task.getName ());
                // 判断任务是否有效
                if (checkTaskValid (task, curDate))
                {
                    cachedTaskMap.put (task.getTaskId (), task);
                    runningTriggerByTask (task);
                }
                else
                {
                    taskService.updateTaskStatus (task.getTaskId (), 2L);
                }
            }
        }
        
        if (!taskSchedulerFactory.isRunning ())
        {
            taskSchedulerFactory.start ();
        }
    }
    
    private boolean isScheduleRun (List <Task> allTaskList, Date curDate)
    {
        boolean rev = false;
        for (Task t : allTaskList)
        {
            if (!"02".equals (t.getTaskType ()))
            {
                if (checkTaskValid (t, curDate))
                {
                    return true;
                }
            }
        }
        return rev;
    }
    
    /*
    * 根据Task对象生成Trigger对象
    * */
    private Trigger getTriggerByTask (Task task)
    {
        String handeBeanName = task.getHandler ();
        Object bean = ContextHelper.getContext ().getBean (handeBeanName);
        if (!(bean instanceof AbstractTask))
        {
            logger.warn ("Start Task:{} fail,Can't receive bean by task handler name ", task.getName ());
            return null; // 配置的Bean并不是一个真正的任务对象
        }
        
        return TriggerGeneratFactory.getInstance ().getTrigger (task, bean.getClass (), generateJobExecParamMap (task));
    }
    
    private Map <String, Object> generateJobExecParamMap (Task task)
    {
        List <TaskParam> taskParamList = taskParamService.getTaskParamsByTaskId (task.getTaskId ());
        Map <String, Object> jobExecParamAsMap = new HashMap <String, Object> ();
        jobExecParamAsMap.put ("taskId", task.getTaskId ());
        jobExecParamAsMap.put ("taskName", task.getName ());
        jobExecParamAsMap.put ("taskCode", task.getTaskCode ());
        jobExecParamAsMap.put ("taskNameAlias", task.getAlias ());
        jobExecParamAsMap.put ("paramList", taskParamList);
        jobExecParamAsMap.put ("startStatus", Task.STATUS_PAUSE != task.getStatus ());
        return jobExecParamAsMap;
    }
}
