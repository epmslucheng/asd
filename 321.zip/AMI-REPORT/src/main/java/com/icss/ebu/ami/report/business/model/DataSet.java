package com.icss.ebu.ami.report.business.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * 数据集
 * @author 芦成
 *
 */
public class DataSet implements Serializable
{
    
    /**
     * 
     */
    private static final long serialVersionUID = -3371246948863226518L;
    
    private String queryId;
    
    private String cnnId;
    
    private String cubeId;
    
    private String queryName;
    
    //数据集关键字 -生成指标用
    private String key;
    
    private String queryOption;
    
    private int maxRow;
    
    private String queryDesc;
    
    /**
     * 0-自定义sql；1-多表关联
     */
    private String queryType;
    
    private String creatorId;
    
    private String creatorName;
    
    /**
     * 是否发布：0-否，1-是
     */
    private int isPublish;
    
    private String needDept;
    
    private String querySql;
    
    private Date createTime;
    
    private Date updateTime;
    
    private String sqlJson;
    
    private String dateFunction;
    
    private List <DataSourceBean> dsList;
    
    private String objectTreeId;
    
    private List <ObjectTreeBean> objectTreeList;
    
    private List <TableModel> tableModels;
    
    private List <TableField> colTree;
    
    private String sqlWhere;
    
    public String getQueryId ()
    {
        return queryId;
    }
    
    public void setQueryId (String queryId)
    {
        this.queryId = queryId;
    }
    
    public String getCnnId ()
    {
        return cnnId;
    }
    
    public void setCnnId (String cnnId)
    {
        this.cnnId = cnnId;
    }
    
    public String getQueryName ()
    {
        return queryName;
    }
    
    public void setQueryName (String queryName)
    {
        this.queryName = queryName;
    }
    
    public String getQueryOption ()
    {
        return queryOption;
    }
    
    public void setQueryOption (String queryOption)
    {
        this.queryOption = queryOption;
    }
    
    public int getMaxRow ()
    {
        return maxRow;
    }
    
    public void setMaxRow (int maxRow)
    {
        this.maxRow = maxRow;
    }
    
    public String getQueryDesc ()
    {
        return queryDesc;
    }
    
    public void setQueryDesc (String queryDesc)
    {
        this.queryDesc = queryDesc;
    }
    
    public String getQueryType ()
    {
        return queryType;
    }
    
    public void setQueryType (String queryType)
    {
        this.queryType = queryType;
    }
    
    public String getCreatorId ()
    {
        return creatorId;
    }
    
    public void setCreatorId (String creatorId)
    {
        this.creatorId = creatorId;
    }
    
    public String getCreatorName ()
    {
        return creatorName;
    }
    
    public void setCreatorName (String creatorName)
    {
        this.creatorName = creatorName;
    }
    
    public int getIsPublish ()
    {
        return isPublish;
    }
    
    public void setIsPublish (int isPublish)
    {
        this.isPublish = isPublish;
    }
    
    public String getNeedDept ()
    {
        return needDept;
    }
    
    public void setNeedDept (String needDept)
    {
        this.needDept = needDept;
    }
    
    public String getQuerySql ()
    {
        return querySql;
    }
    
    public void setQuerySql (String querySql)
    {
        this.querySql = querySql;
    }
    
    public Date getCreateTime ()
    {
        return createTime;
    }
    
    public void setCreateTime (Date createTime)
    {
        this.createTime = createTime;
    }
    
    public Date getUpdateTime ()
    {
        return updateTime;
    }
    
    public void setUpdateTime (Date updateTime)
    {
        this.updateTime = updateTime;
    }
    
    public String getDateFunction ()
    {
        return dateFunction;
    }
    
    public void setDateFunction (String dateFunction)
    {
        this.dateFunction = dateFunction;
    }
    
    public List <DataSourceBean> getDsList ()
    {
        return dsList;
    }
    
    public void setDsList (List <DataSourceBean> dsList)
    {
        this.dsList = dsList;
    }
    
    public List <ObjectTreeBean> getObjectTreeList ()
    {
        return objectTreeList;
    }
    
    public void setObjectTreeList (List <ObjectTreeBean> objectTreeList)
    {
        this.objectTreeList = objectTreeList;
    }
    
    public String getObjectTreeId ()
    {
        return objectTreeId;
    }
    
    public void setObjectTreeId (String objectTreeId)
    {
        this.objectTreeId = objectTreeId;
    }
    
    public String getKey ()
    {
        return key;
    }
    
    public void setKey (String key)
    {
        this.key = key;
    }
    
    public String getSqlJson ()
    {
        return sqlJson;
    }
    
    public void setSqlJson (String sqlJson)
    {
        this.sqlJson = sqlJson;
    }
    
    public String getCubeId ()
    {
        return cubeId;
    }
    
    public void setCubeId (String cubeId)
    {
        this.cubeId = cubeId;
    }
    
    public List <TableModel> getTableModels ()
    {
        return tableModels;
    }
    
    public void setTableModels (List <TableModel> tableModels)
    {
        this.tableModels = tableModels;
    }
    
    public List <TableField> getColTree ()
    {
        return colTree;
    }
    
    public void setColTree (List <TableField> colTree)
    {
        this.colTree = colTree;
    }
    
    public String getSqlWhere ()
    {
        return sqlWhere;
    }
    
    public void setSqlWhere (String sqlWhere)
    {
        this.sqlWhere = sqlWhere;
    }
    
}
