package com.icss.ebu.ami.report.business.service;

import java.util.List;

import com.icss.ebu.ami.report.system.model.Resource;
import com.icss.ebu.ami.report.system.model.ResourceTree;
import com.icss.ebu.ami.report.system.model.User;

public interface ResourceService
{
    
    /**
     * 查询菜单列表
     *
     * @return
     */
    List <ResourceTree> queryResourceTree (User user);
    
    List <Resource> allResource ();
    
}
