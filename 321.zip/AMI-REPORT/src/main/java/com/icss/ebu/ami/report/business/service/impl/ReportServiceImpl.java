package com.icss.ebu.ami.report.business.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.dubbo.common.utils.StringUtils;
import com.icss.ebu.ami.commons.pagePlugin.Page;
import com.icss.ebu.ami.commons.util.DateUtils;
import com.icss.ebu.ami.commons.util.I18nUtils;
import com.icss.ebu.ami.commons.util.ServiceUtils;
import com.icss.ebu.ami.commons.util.UUIDUtils;
import com.icss.ebu.ami.report.business.common.constant.ReportConstant;
import com.icss.ebu.ami.report.business.common.util.ConfigHolder;
import com.icss.ebu.ami.report.business.mapper.CustomDataSetMapper;
import com.icss.ebu.ami.report.business.mapper.DataSourceMapper;
import com.icss.ebu.ami.report.business.mapper.ObjectTreeMapper;
import com.icss.ebu.ami.report.business.mapper.ReportFileMapper;
import com.icss.ebu.ami.report.business.mapper.ReportMapper;
import com.icss.ebu.ami.report.business.model.ReportDesign;
import com.icss.ebu.ami.report.business.model.ReportFile;
import com.icss.ebu.ami.report.business.model.ReportFileTree;
import com.icss.ebu.ami.report.business.model.ReportLog;
import com.icss.ebu.ami.report.business.model.Template;
import com.icss.ebu.ami.report.business.service.ReportService;
import com.icss.ebu.ami.report.business.service.SystemParameterService;
import com.icss.ebu.ami.report.business.task.ReportGenerateTask;
import com.icss.ebu.ami.report.system.model.SystemParameter;

@Service
public class ReportServiceImpl implements ReportService
{
    @Autowired
    private ReportMapper reportMapper;
    
    @Autowired
    private CustomDataSetMapper customDataSetMapper;
    
    @Autowired
    private ReportFileMapper reportFileMapper;
    
    @Autowired
    private DataSourceMapper dataSourceMapper;
    
    @Autowired
    private ObjectTreeMapper objectTreeMapper;
    
    @Autowired
    private SystemParameterService systemParameterService;
    
    private static final ThreadPoolExecutor reportPools = new ThreadPoolExecutor (10, 20, 5, TimeUnit.SECONDS,
        new LinkedBlockingQueue <Runnable> (800));
    
    private static Logger LOGGER = LoggerFactory.getLogger (ReportServiceImpl.class);
    
    @Override
    public Page <ReportDesign> queryReportDesignList (Page <ReportDesign> page)
    {
        
        List <ReportDesign> list = reportMapper.queryReportDesignList (page);
        page.setResults (list);
        return page;
    }
    
    @Override
    public List <ReportDesign> queryReportDesignById (String id)
    {
        return reportMapper.queryReportDesignById (id);
    }
    
    @Override
    public String generateReport (Template template)
    {
        ReportFile reportFile = new ReportFile ();
        try
        {
            SystemParameter datesystemParameter = systemParameterService.querySystemParameterById ("10005");
            String targetDir =
                ConfigHolder.getCfg (ReportConstant.FTP_CATALOG)
                    + ConfigHolder.getCfg (ReportConstant.REPORT_FTP_PATH_DAY);
            if (ReportConstant.REPORT_TYPE_MONTH.equals (template.getReporttype ()))
            {
                targetDir =
                    ConfigHolder.getCfg (ReportConstant.FTP_CATALOG)
                        + ConfigHolder.getCfg (ReportConstant.REPORT_FTP_PATH_MONTH);
            }
            String tempPath = "";
            StringBuffer sb = new StringBuffer ();
            String templateFileName = template.getTmpfilename ();
            sb.append (templateFileName.substring (0, templateFileName.lastIndexOf (ReportConstant.REPORT_SPOT))).append ("_")
                .append (DateUtils.date2String (new Date (), DateUtils.DATE_PATTERN_YMDHMS))
                .append (templateFileName.substring (templateFileName.lastIndexOf (ReportConstant.REPORT_SPOT)));
            
            tempPath = ConfigHolder.getCfg (ReportConstant.REPORT_TEMP_PATH) + sb.toString ();
            template.setTempPath (tempPath);
            String reportId = UUIDUtils.generate16Str ();
            template.setReportId (reportId);
            reportPools.submit (new ReportGenerateTask (reportMapper, customDataSetMapper, reportFileMapper, dataSourceMapper,
                template, objectTreeMapper, datesystemParameter.getValue ()));
            reportFile.setReportId (reportId);
            reportFile.setReportName (sb.toString ());
            reportFile.setReportPath (targetDir);
            reportFile.setReportType (template.getReporttype ());
            reportFile.setTempId (template.getTmpid ());
            reportFile.setTmpKey (template.getTmpkey ());
            reportFile.setReportStatus (ReportConstant.REPORT_PROCESSING);
            reportFile.setReportDesc (template.getTmpdesc ());
            reportFile.setUserId (template.getUserId ());
            reportFileMapper.addReportFile (reportFile);
            
            saveReportObjectTree (template);
            recordReportLog (template);
            
        }
        catch (RejectedExecutionException e)
        {
            reportFile.setReportStatus (ReportConstant.REPORT_FAILURE);
            reportFile.setReportDesc ("Cause : System Busy");
            reportFileMapper.editReportFile (reportFile);
            LOGGER.error ("generateReport RejectedExecutionException :", e);
            return ReportConstant.REPORT_FAILURE;
        }
        catch (Exception e)
        {
            reportFile.setReportStatus (ReportConstant.REPORT_FAILURE);
            reportFile.setReportDesc ("Cause : System Exception");
            reportFileMapper.editReportFile (reportFile);
            LOGGER.error ("generateReport Exception :", e);
            return ReportConstant.REPORT_FAILURE;
        }
        return ReportConstant.REPORT_SUCCESS;
    }
    
    /**
     * 记录生成的报表与对象树的关联关系
     * @param template
     * @param reportId
     */
    private void saveReportObjectTree (Template template)
    {
        try
        {
            String treeMap = template.getTreeMap ();
            List <ReportFileTree> reportFileTrees = null;
            ReportFileTree reportFileTree = null;
            String[] split = null;
            if (StringUtils.isNotEmpty (treeMap))
            {
                reportFileTrees = new ArrayList <ReportFileTree> ();
                String[] treeList = treeMap.split (";");
                for (String tree : treeList)
                {
                    reportFileTree = new ReportFileTree ();
                    split = tree.split (",");
                    reportFileTree.setTreeId (split[2]);
                    reportFileTree.setReportId (template.getReportId ());
                    reportFileTree.setId (UUIDUtils.generate16Str ());
                    reportFileTrees.add (reportFileTree);
                }
                
                if (!reportFileTrees.isEmpty ())
                {
                    reportFileMapper.insertReportFileTree (reportFileTrees);
                }
            }
        }
        catch (Exception e)
        {
            LOGGER.error ("insert report file tree error.", e);
        }
    }
    
    /**
     * 记录报表生成记录
     * @param template
     */
    private void recordReportLog (Template template)
    {
        try
        {
            ReportLog reportLog = new ReportLog ();
            reportLog.setReportId (template.getReportId ());
            reportLog.setCurrentTime (template.getCurrentTime ());
            reportLog.setStartTime (template.getStartTime ());
            reportLog.setEndTime (template.getEndTime ());
            reportLog.setTreeParam (template.getTreeMap () == null ? "" : template.getTreeMap ().toString ());
            reportLog.setCreateTime (new Date ());
            reportLog.setCreatorId (template.getUserId ());
            reportLog.setStatus (ReportConstant.REPORT_PROCESSING);
            reportFileMapper.insertReportLog (reportLog);
            
        }
        catch (Exception e)
        {
            LOGGER.error ("record report log Exception :", e);
        }
    }
    
    @Override
    public String analyseGenerateContent (Template template)
    {
        if (template == null)
        {
            return "template is empty";
        }
        StringBuilder delSb = new StringBuilder ();
        ServiceUtils.addPropContent (I18nUtils.getI18nMsg ("ami.report.name"), template.getTmpname (), delSb);
        ServiceUtils.addPropContent (I18nUtils.getI18nMsg ("ami.report.current_time"), template.getCurrentTime (), delSb);
        ServiceUtils.addPropContent (I18nUtils.getI18nMsg ("ami.task.startTime"), template.getStartTime (), delSb);
        ServiceUtils.addPropContent (I18nUtils.getI18nMsg ("ami.task.endTime"), template.getEndTime (), delSb);
        ServiceUtils.addPropContent (I18nUtils.getI18nMsg ("ami.report.select_objecttree"), template.getTreeMap (), delSb);
        if (delSb.length () > 1)
        {
            delSb.setLength (delSb.length () - 1);
        }
        return delSb.toString ();
    }
}
