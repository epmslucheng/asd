package com.icss.ebu.ami.report.business.common.util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

import org.apache.commons.io.IOUtils;
import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;
import org.apache.commons.net.ftp.FTPReply;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.icss.ebu.ami.commons.util.AesKeyUtils;
import com.icss.ebu.ami.report.business.common.constant.ReportConstant;

/** 
* @author  zhangkaining 
* @date 2017年11月2日 下午4:24:15 
* @version 1.0   
*/
public class FileUtils
{
    
    private static final Logger LOGGER = LoggerFactory.getLogger (FileUtils.class);
    
    private final static int FILE_BUFFER_SIZE = 1024 * 1024;

    public static String downloadFile (String pathname, String filename, String localpath, String newname)
    {
        String downPath = "";
        FTPClient ftpClient = new FTPClient ();
        OutputStream os = null;
        try
        {
            if (!ftpLogin (ftpClient))
            {
                return downPath;
            }
            ftpClient.setControlEncoding ("UTF-8"); // 设置字符编码
            //切换FTP目录
            ftpClient.changeWorkingDirectory (pathname);
            ftpClient.setFileType (FTP.BINARY_FILE_TYPE);
            ftpClient.enterLocalPassiveMode ();
            FTPFile[] ftpFiles = ftpClient.listFiles ();
            for (FTPFile file : ftpFiles)
            {
                if (filename.equalsIgnoreCase (file.getName ()))
                {
                    downPath = localpath + File.separator + newname;
                    File localFile = new File (downPath);
                    if (!localFile.getParentFile ().mkdir ())
                    {
                        if (!localFile.exists ())
                        {
                            localFile.createNewFile ();
                        }
                    }
                    os = new FileOutputStream (localFile);
                    ftpClient.retrieveFile (new String (file.getName ().getBytes ("utf-8"), "iso-8859-1"), os);
                }
            }
        }
        catch (Exception e)
        {
            LOGGER.error ("downloadFile error : ", e);
        }
        finally
        {
            ftpQuit (ftpClient);
            IOUtils.closeQuietly (os);
        }
        return downPath;
    }

    private static boolean ftpLogin (FTPClient ftpClient)
    {
        String hostname = ConfigHolder.getCfg (ReportConstant.FTPHOST);
        int port = Integer.valueOf (ConfigHolder.getCfg (ReportConstant.FTPPORT));
        String username = ConfigHolder.getCfg (ReportConstant.FTPUSERNAME);
        String password = ConfigHolder.getCfg (ReportConstant.FTPPASSWORD);
        return ftpLogin(ftpClient,hostname,port,username,password);
    }

    private static boolean ftpLogin (FTPClient ftpClient, String hostname, int port, String username, String password)
    {
        boolean revFlag = true;
        try
        {
            //连接FTP服务器
            ftpClient.connect (hostname, port);
            //登录FTP服务器
            ftpClient.login (username, AesKeyUtils.decrypt (password, PropertiesReader.getUserPwdKey ()));
            //是否成功登录FTP服务器
            int replyCode = ftpClient.getReplyCode ();
            if (!FTPReply.isPositiveCompletion (replyCode))
            {
                revFlag = false;
            }
        }
        catch (Exception e)
        {
            revFlag = false;
            LOGGER.error ("ftpLogin error : ", e);
        }
        return revFlag;
    }
    
    private static void ftpQuit (FTPClient ftpClient)
    {
        if (ftpClient.isConnected ())
        {
            try
            {
                ftpClient.logout ();
            }
            catch (Exception e)
            {
                LOGGER.error ("ftpQuit logout error  : ", e);
            }
            try
            {
                ftpClient.disconnect ();
            }
            catch (Exception e)
            {
                LOGGER.error ("ftpQuit disconnect error  : ", e);
            }
        }
    }
    
    public static String reportTmpPath ()
    {
        String currPath = FileUtils.class.getResource ("").getPath ();
        
        return "";
    }
}
