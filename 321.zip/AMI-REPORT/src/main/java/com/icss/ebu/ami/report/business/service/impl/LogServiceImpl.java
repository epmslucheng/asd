package com.icss.ebu.ami.report.business.service.impl;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.icss.ebu.ami.commons.bean.vo.Organization;
import com.icss.ebu.ami.commons.constants.GeneralConstant;
import com.icss.ebu.ami.commons.pagePlugin.Page;
import com.icss.ebu.ami.commons.util.AesKeyUtils;
import com.icss.ebu.ami.commons.util.ServiceUtils;
import com.icss.ebu.ami.commons.util.UUIDUtils;
import com.icss.ebu.ami.report.business.controller.BaseController;
import com.icss.ebu.ami.report.business.mapper.SysLogMapper;
import com.icss.ebu.ami.report.business.service.LogService;
import com.icss.ebu.ami.report.business.service.OrganizationService;
import com.icss.ebu.ami.report.system.model.SysLog;
import com.icss.ebu.ami.report.system.model.SysLogBean;
import com.icss.ebu.ami.report.system.model.User;

/**
 * @description：
 * 
 * @author：zhixuan.wang @date：2015/10/30 10:40
 */
@Service
public class LogServiceImpl extends BaseController implements LogService
{
    @Autowired
    private SysLogMapper sysLogMapper;
    
    @Autowired
    private OrganizationService organizationService;
    
    private static final ArrayBlockingQueue <SysLog> queue = new ArrayBlockingQueue <SysLog> (GeneralConstant.NUM_3000);
    
    private Thread workingThread;
    
    @Override
    public void insertLog (SysLog sysLog)
    {
        sysLog.setId (UUIDUtils.generate16Long ());
        //        sysLogMapper.insert (sysLog);
        try
        {
            queue.put (sysLog);
        }
        catch (InterruptedException e)
        {
            logger.error ("queue add syslog error:", e);
        }
    }
    
    @Override
    public Page <SysLogBean> findSysLogByPage (Page <SysLogBean> page)
    {
        List <SysLogBean> logList = sysLogMapper.findSysLogByPage (page);
        if (logList != null && logList.size () > 0)
        {
            for (SysLogBean log : logList)
            {
                log.setClientIp (AesKeyUtils.decryptCookieURL (log.getClientIp ()));
            }
        }
        page.setResults (logList);
        return page;
    }
    
    private String getOrgName (List <Organization> orgList, String pOrgNo)
    {
        if (orgList == null)
        {
            return "";
        }
        for (Organization org : orgList)
        {
            if (org.getId ().equals (pOrgNo))
            {
                return org.getName ();
            }
        }
        return "";
    }
    
    @Override
    public void insertLog (String pOrgNo, String funDesc, String operDetail, String paramsOld, String paramsNew)
    {
        HttpServletRequest request = getRequest ();
        StringBuilder sb = new StringBuilder ();
        SysLog sysLog = new SysLog ();
        User user = getCurrentUser ();
        sysLog.setUserId (user.getId ());
        sysLog.setLoginName (user.getLoginname ());
        sysLog.setRoleName (user.getName ());
        sysLog.setClientIp (AesKeyUtils.encryptCookieURL (ServiceUtils.getClientIp (request)));
        sysLog.setSessionId (pOrgNo);
        sysLog.setLogType ("02");
        sb.append (funDesc);
        try
        {
            sysLog.setOptContent (ServiceUtils.getSubString (sb.toString (), "UTF-8", 256));
            //            if (StringUtils.isNotBlank (paramsOld) || StringUtils.isNotBlank (paramsNew))
            //            {
            //                sb.setLength (0);
            //                sb.append ("[before]:").append (paramsOld == null ? "" : paramsOld).append (",[after]:")
            //                    .append (paramsNew == null ? "" : paramsNew);
            //                sysLog.setParams (ServiceUtils.getSubString (sb.toString (), "UTF-8", 2800));
            //            }
            sysLog.setOptDetail (ServiceUtils.getSubString (operDetail, "UTF-8", 2800));
            sb.setLength (0);
        }
        catch (UnsupportedEncodingException e)
        {
            logger.error ("Unsupported the charset [ UTF-8 ] : ", e);
        }
        sysLog.setCreateTime (new Date ());
        insertLog (sysLog);
    }
    
    @Override
    public void insertSysLog (User user, String logType, String client, String funDesc, String operDetail, String paramsOld,
        String paramsNew)
    {
        if (null != funDesc && "login".equals (funDesc))
        {
            SysLog sysLog = new SysLog ();
            sysLog.setUserId (user.getId ());
            sysLog.setLoginName (user.getLoginname ());
            sysLog.setRoleName (user.getName ());
            sysLog.setClientIp (AesKeyUtils.encryptCookieURL (client));
            sysLog.setSessionId (user.getpOrganizationId ());
            sysLog.setLogType (logType);
            sysLog.setOptContent (funDesc);
            sysLog.setCreateTime (new Date ());
            //        sysLogMapper.insert (sysLog);
            insertLog (sysLog);
        }
        else
        {
            if (StringUtils.isNotBlank (operDetail))
            {
                SysLog sysLog = new SysLog ();
                sysLog.setUserId (user.getId ());
                sysLog.setLoginName (user.getLoginname ());
                sysLog.setRoleName (user.getName ());
                sysLog.setClientIp (AesKeyUtils.encryptCookieURL (client));
                sysLog.setSessionId (user.getpOrganizationId ());
                sysLog.setLogType (logType);
                try
                {
                    sysLog.setOptContent (ServiceUtils.getSubString (funDesc, "UTF-8", 256));
                    //                    if (StringUtils.isNotBlank (paramsOld) || StringUtils.isNotBlank (paramsNew))
                    //                    {
                    //                        StringBuilder sb = new StringBuilder ();
                    //                        sb.append ("[before]:").append (paramsOld == null ? "" : paramsOld).append (",[after]:")
                    //                        .append (paramsNew == null ? "" : paramsNew);
                    //                        sysLog.setParams (ServiceUtils.getSubString (sb.toString (), "UTF-8", 2800));
                    //                        sb.setLength (0);
                    //                    }
                    sysLog.setOptDetail (ServiceUtils.getSubString (operDetail, "UTF-8", 2800));
                }
                catch (UnsupportedEncodingException e)
                {
                    logger.error ("Unsupported the charset [ UTF-8 ] : ", e);
                }
                sysLog.setCreateTime (new Date ());
                //        sysLogMapper.insert (sysLog);
                insertLog (sysLog);
            }
        }
        
    }
    
    @Override
    public int deleteSysLogByMaxId (Long sysLogId)
    {
        return sysLogMapper.deleteByHisLogByKey (sysLogId);
    }
    
    public void initLogTask ()
    {
        if (workingThread == null)
        {
            workingThread = new Thread (new Runnable ()
            {
                public void run ()
                {
                    doInsertLogs ();
                }
            });
            workingThread.setName ("InsertLog-WorkingThread");
            workingThread.start ();
        }
    }
    
    private void doInsertLogs ()
    {
        ArrayList <SysLog> list = new ArrayList <SysLog> (GeneralConstant.MAX_LENGTH_50);
        try
        {
            while (true)
            {
                try
                {
                    SysLog log = queue.poll (GeneralConstant.NUM_5000, TimeUnit.MILLISECONDS);
                    if (log != null)
                    {
                        list.add (log);
                        if (list.size () >= GeneralConstant.MAX_LENGTH_50)
                        {
                            sysLogMapper.insertList (list);
                            list.clear ();
                        }
                    }
                    else if (list.size () > 0)
                    {
                        sysLogMapper.insertList (list);
                        list.clear ();
                    }
                }
                catch (InterruptedException e)
                {
                    logger.error ("insert syslog InterruptedException : ", e);
                }
                catch (Exception e)
                {
                    logger.error ("insert syslog Exception : " + changeSysLogs (list), e);
                    list.clear ();
                }
            }
        }
        finally
        {
            list.clear ();
        }
    }
    
    private String changeSysLogs (List <SysLog> list)
    {
        StringBuffer sb = new StringBuffer ();
        sb.append ("battch insert syslogs error [");
        int size = list.size ();
        SysLog log;
        for (int i = 0; i < size; i++)
        {
            log = list.get (i);
            if (i < size - 1)
            {
                sb.append (log.toString ()).append (",");
            }
            else
            {
                sb.append (log.toString ());
            }
        }
        sb.append ("]");
        return sb.toString ();
    }
}
