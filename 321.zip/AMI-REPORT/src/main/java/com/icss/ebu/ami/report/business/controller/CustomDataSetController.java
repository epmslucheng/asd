package com.icss.ebu.ami.report.business.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.jdbc.support.rowset.SqlRowSetMetaData;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.icss.ebu.ami.commons.constants.ConstantCode;
import com.icss.ebu.ami.commons.constants.GeneralConstant;
import com.icss.ebu.ami.commons.pagePlugin.Page;
import com.icss.ebu.ami.commons.util.UUIDUtils;
import com.icss.ebu.ami.report.business.common.constant.CommonConstant;
import com.icss.ebu.ami.report.business.common.constant.SqlConstant;
import com.icss.ebu.ami.report.business.common.util.JDBCTemplateUtil;
import com.icss.ebu.ami.report.business.common.util.LogRenderUtils;
import com.icss.ebu.ami.report.business.common.util.SqlUtils;
import com.icss.ebu.ami.report.business.model.CubeBean;
import com.icss.ebu.ami.report.business.model.DataSet;
import com.icss.ebu.ami.report.business.model.DataSetObject;
import com.icss.ebu.ami.report.business.model.DataSourceBean;
import com.icss.ebu.ami.report.business.model.DataSourceTable;
import com.icss.ebu.ami.report.business.model.DataSourceTableFiled;
import com.icss.ebu.ami.report.business.model.Function;
import com.icss.ebu.ami.report.business.model.ObjectTreeBean;
import com.icss.ebu.ami.report.business.model.SqlObject;
import com.icss.ebu.ami.report.business.model.TableField;
import com.icss.ebu.ami.report.business.service.CubeService;
import com.icss.ebu.ami.report.business.service.CustomDataSetService;
import com.icss.ebu.ami.report.business.service.DataSourceService;
import com.icss.ebu.ami.report.business.service.LogService;
import com.icss.ebu.ami.report.business.service.ObjectTreeService;
import com.icss.ebu.ami.report.system.model.User;

@Controller
@RequestMapping ("/customDataSet")
public class CustomDataSetController extends BaseController
{
    
    private static Logger LOGGER = LoggerFactory.getLogger (CustomDataSetController.class);
    
    @Autowired
    private CustomDataSetService customDataSetService;
    
    @Autowired
    private DataSourceService dataSourceService;
    
    @Autowired
    private ObjectTreeService objectTreeService;
    
    @Autowired
    private CubeService cubeService;
    
    @Autowired
    private LogService logService;
    
    @RequestMapping ("/dataSetList")
    public String dataSetList (HttpServletRequest req)
    {
        return "/service/dataSet/dataSet";
    }
    
    @RequestMapping ("/query")
    @ResponseBody
    public Object query (HttpServletRequest request)
    {
        
        DataSet dataSet = new DataSet ();
        Page <DataSet> page = new Page <DataSet> (dataSet);
        String sortCol = request.getParameter (CommonConstant.PAGE_PARAM_ORDER_COL);
        String order = request.getParameter (CommonConstant.PAGE_PARAM_ORDER);
        if (StringUtils.isNotEmpty (sortCol) && StringUtils.isNotEmpty (order))
        {
            if ("createTime".equals (sortCol))
            {
                sortCol = "CREATE_TIME";
            }
            if ("sendTime".equals (sortCol))
            {
                sortCol = "SEND_TIME";
            }
            
            Map <String, Object> params = new HashMap <String, Object> ();
            params.put ("order", sortCol + GeneralConstant.SPACE + order);
            page.setConditions (params);
        }
        page.setPageNo (NumberUtils.toInt (request.getParameter (CommonConstant.PAGE_PARAM_PAGE)));
        page.setPageSize (NumberUtils.toInt (request.getParameter (CommonConstant.PAGE_PARAM_ROWS)));
        page = customDataSetService.findCustomDataSets (page);
        Map <String, Object> map = new HashMap <String, Object> ();
        map.put (CommonConstant.PAGE_RESULT_ROWS, page.getResults ());
        map.put (CommonConstant.PAGE_RESULT_TOTAL, page.getTotalRecord ());
        return map;
        
    }
    
    /**
     * 查询所有数据集
     * 
     * @param request
     * @return
     * by zhangkaining
     */
    @RequestMapping ("/queryAll")
    @ResponseBody
    public Object queryAll (HttpServletRequest request)
    {
        
        return customDataSetService.queryAll ();
        
    }
    
    @RequestMapping ("/sqlOperateSelect")
    public String sqlOperateSelect (HttpServletRequest request)
    {
        
        return "/service/dataSet/sqlOperateSelect";
    }
    
    @RequestMapping ("/gotoDataSetAddView")
    public String gotoDataSetAddView (Model model, HttpServletRequest request, @RequestBody DataSet dataSet)
    {
        return "/service/dataSet/dataSetAdd";
    }
    
    @RequestMapping ("/addDataSet")
    @ResponseBody
    public Object addDataSet (HttpServletRequest request, @RequestBody DataSet dataSet)
    {
        //规则校验
        
        try
        {
            User currentUser = getCurrentUser ();
            if (null != dataSet)
            {
                
                /**
                 * 校验key是否重复
                 */
                if (checkDataSetKeyRepeat (dataSet))
                {
                    LOGGER.info ("data set key repeat, key: " + dataSet.getKey ());
                    return renderError (super.getProperty ("ami.dataset.tablename.repeat"));
                }
                if (checkDataSetQuerySql (dataSet))
                {
                    LOGGER.info ("data set key repeat, key: " + dataSet.getKey ());
                    return renderError (super.getProperty ("ami.dataset.querysql.empty"));
                }
                
                String queryId = UUIDUtils.generate16Str ();
                List <DataSetObject> dataSetObjs = null;
                Set <String> objectIds = null;
                DataSetObject dataSetObject = null;
                dataSet.setQueryId (queryId);
                assembleDataSet (dataSet);
                String querySql = dataSet.getQuerySql ();
                
                /**
                 * 检查sql的合法
                 */
                try
                {
                    DataSourceBean ds = dataSourceService.getDataSourceById (dataSet.getCnnId ());
                    boolean badSql = SqlUtils.badSqlValidate (querySql);
                    if (badSql)
                    {
                        LOGGER.error ("sql cann't contains keywords: insert|delete|update|drop|truncate|*, bad sql: " + badSql);
                        return renderError (getProperty ("ami.dataset.test.sqlvalid"));
                    }
                    List <Function> func = customDataSetService.findAllFunction ();
                    String testSql = querySql;
                    testSql = SqlUtils.assembleSqlFunction (testSql, null, null, null, func);
                    JdbcTemplate jdbcTemplate = JDBCTemplateUtil.getJDBC (dataSet.getCnnId ());
                    SqlRowSet rs = jdbcTemplate.queryForRowSet (testSql);
                    
                }
                catch (Exception e)
                {
                    
                    LOGGER.error ("test sql error,sql : " + querySql, e);
                    return renderError (super.getProperty ("ami.dataset.model.test.error"));
                }
                
                dataSet.setQuerySql (querySql);
                dataSet.setCreatorId (currentUser.getId ());
                dataSet.setCreatorName (currentUser.getName ());
                dataSet.setCubeId (UUIDUtils.generate16Str ());
                customDataSetService.addDataSet (dataSet);
                if (querySql.indexOf ("%") > -1)
                {
                    // 处理数据集与对象树关系
                    
                    objectIds = new HashSet <String> ();
                    List <ObjectTreeBean> objectTreeList = objectTreeService.queryAllObjectTree (new ObjectTreeBean ());
                    for (ObjectTreeBean objectTreeBean : objectTreeList)
                    {
                        if (querySql.indexOf (objectTreeBean.getName ()) > 0)
                        {
                            objectIds.add (objectTreeBean.getId ());
                            
                        }
                    }
                }
                
                if (null != objectIds && !objectIds.isEmpty ())
                {
                    dataSetObjs = new ArrayList <DataSetObject> ();
                    // 插入关联关系
                    for (String objectId : objectIds)
                    {
                        dataSetObject = new DataSetObject ();
                        dataSetObject.setId (UUIDUtils.generate16Str ());
                        dataSetObject.setQueryId (queryId);
                        dataSetObject.setObjectId (objectId);
                        dataSetObjs.add (dataSetObject);
                        
                    }
                    
                    objectTreeService.insertDataSetObject (dataSetObjs);
                    
                }
                
                //生成自定义数据集   ->  指标
                generateTarget (dataSet);
            }
            
            //获取当前登录用户
            User curUser = getCurrentUser ();
            //获取操作描述 key = 类名+"_"+方法名 
            String funDesc = LogRenderUtils.getLogReqMap ("CustomDataSetController_addDataSet");
            try
            {
                //分析删除对象的的关键内容
                String operDetail = customDataSetService.analyseAddContent (dataSet);
                if (StringUtils.isNotBlank (operDetail))
                {
                    //插入日志
                    logService.insertSysLog (curUser, ConstantCode.STRING_02, getRemoteAddr (), funDesc, operDetail, null, null);
                }
            }
            catch (Exception ex)
            {
                logger.error (funDesc + "  bussness log insert error", ex);
            }
        }
        catch (Exception e)
        {
            LOGGER.error ("add data set error.", e);
            return renderError ("error");
        }
        return renderSuccess ("success");
        
    }
    
    /**
     * 检查key是否重复
     * @param dataSet
     * @return
     */
    private boolean checkDataSetKeyRepeat (DataSet dataSet)
    {
        boolean flag = false;
        if (StringUtils.isNotBlank (dataSet.getKey ()))
        {
            DataSourceTable dataSourceTable = new DataSourceTable ();
            dataSourceTable.setId (dataSet.getCnnId ());
            dataSourceTable.setTableName (dataSet.getKey ().toUpperCase ());
            int count = dataSourceService.getTableCount (dataSourceTable);
            if (count > 0)
            {
                flag = true;
            }
        }
        return flag;
    }
    
    private boolean checkDataSetQuerySql (DataSet dataSet)
    {
        boolean flag = false;
        
        if (SqlConstant.DATASET_USER_DEFINED.equals (dataSet.getQueryType ()))
        {
            if (StringUtils.isBlank (dataSet.getQuerySql ()))
            {
                flag = true;
            }
        }
        else if (SqlConstant.DATASET_MULTI_TABLE_ASSOCIATION.equals (dataSet.getQueryType ()))
        {
            if (null == dataSet.getColTree () || dataSet.getColTree ().isEmpty ())
            {
                flag = true;
            }
        }
        
        return flag;
    }
    
    /**
     * 生成指标
     */
    private void generateTarget (DataSet dataSet)
    {
        
        //查询出结果集  封装成 指标、立方 入对应的数据集
        List <String> colname = new ArrayList <String> ();
        String querySql = "";
        
        if (null != dataSet && StringUtils.isNotBlank (dataSet.getQuerySql ()))
        {
            querySql = dataSet.getQuerySql ();
            querySql.replace ("\n", " ");
            
            DataSourceBean ds = dataSourceService.getDataSourceById (dataSet.getCnnId ());
            assembleDataSet (dataSet);
            querySql = dataSet.getQuerySql ();
            boolean badSql = SqlUtils.badSqlValidate (querySql);
            if (badSql)
            {
                LOGGER.error ("sql cann't contains keywords: insert|delete|update|drop|truncate|*, bad sql: " + badSql);
            }
            List <Function> func = customDataSetService.findAllFunction ();
            querySql = SqlUtils.assembleSqlFunction (querySql, null, null, null, func);
            //            String sql = SqlUtils.getPageSql (1, 1, querySql, ds.getDbType ());
            JdbcTemplate jdbcTemplate = JDBCTemplateUtil.getJDBC (dataSet.getCnnId ());
            SqlRowSet rs = jdbcTemplate.queryForRowSet (querySql);
            if (null != rs)
            {
                
                SqlRowSetMetaData metaData = rs.getMetaData ();
                int columnCount = metaData.getColumnCount ();
                for (int i = 1; i <= columnCount; i++)
                {
                    colname.add (metaData.getColumnName (i));
                }
                
            }
            
            //            //截取sql  
            //            //规则
            //            querySql = querySql.toUpperCase ();
            //            //1.截取  select 到 第一个from 中间的字段集合
            //            querySql = querySql.substring (querySql.indexOf ("SELECT") + 6, querySql.indexOf ("FROM")).trim ();
            //            
            //            String[] filedList = querySql.split (",");
            //            
            //            if (filedList.length > 0)
            //            {
            //                for (String filed : filedList)
            //                {
            //                    //2.去除"号
            //                    filed = filed.replaceAll ("\"", "");
            //                    //3.是否包含  as 关键字
            //                    if (filed.contains (" AS "))
            //                    {
            //                        filed = filed.substring (filed.indexOf (" AS ") + 4, filed.length ()).trim ();
            //                        //                        System.out.println ("filed==" + filed);
            //                    }
            //                    //4. 是否表名.字段名
            //                    if (filed.contains ("."))
            //                    {
            //                        filed = filed.substring (filed.indexOf (".") + 1, filed.length ()).trim ();
            //                        //                        System.out.println ("filed...=" + filed);
            //                    }
            //                    colname.add (filed);
            //                }
            //            }
            
            //            List <Function> func = customDataSetService.findAllFunction ();
            //            querySql = SqlUtils.assembleSqlFunction (querySql, null, null, null, func);
            //            String sql = SqlUtils.getPageSql (1, 1, querySql, ds.getDbType ());
            //            JdbcTemplate jdbcTemplate = JDBCTemplateUtil.getJDBC (dataSet.getCnnId ());
            //            objs = jdbcTemplate.queryForList (sql);
            //            if (null != objs && 0 != objs.size ())
            //            {
            //                Map <String, Object> map = objs.get (0);
            //                colname = new ArrayList <String> (map.keySet ());
            //                
            //            }
            
        }
        
        if (CollectionUtils.isNotEmpty (colname))
        {
            String cubeName = dataSet.getKey ().toUpperCase ();
            String tableName = dataSet.getKey ().toUpperCase ();
            
            //封装立方对象
            CubeBean cube = new CubeBean ();
            cube.setCubeId (dataSet.getCubeId ());
            cube.setId (dataSet.getCnnId ());
            cube.setCubeName (cubeName);
            List <DataSourceTable> dstList = new ArrayList <> ();
            
            //封装指标对象
            String tableId = UUIDUtils.generate16Str ();
            DataSourceTable dsb = new DataSourceTable ();
            dsb.setQueryId (dataSet.getQueryId ());
            dsb.setId (dataSet.getCnnId ());
            dsb.setTableId (tableId);
            dsb.setTableName (tableName);
            dsb.setTableType ("target");
            
            //立方所选表
            dstList.add (dsb);
            cube.setTableList (dstList);
            
            List <DataSourceTableFiled> dsTableFiledList = new ArrayList <> ();
            DataSourceTableFiled dstf = null;
            
            for (int i = 0; i < colname.size (); i++)
            {
                dstf = new DataSourceTableFiled ();
                dstf.setQueryId (dataSet.getQueryId ());
                dstf.setId (dataSet.getCnnId ());
                dstf.setFiledId (UUIDUtils.generate16Str ());
                dstf.setTableName (tableName);
                dstf.setTableType ("target");
                dstf.setTableFiled (colname.get (i));
                dstf.setTableFiledSql (tableName + "." + colname.get (i));
                dstf.setTableFiledAlias (colname.get (i));
                dstf.setTableId (tableId);
                dsTableFiledList.add (dstf);
            }
            //删除数据源中表 和 字段
            dataSourceService.delTableByTableNameAndDsId (dsb);
            customDataSetService.deleteDataSetCols (dsb);
            //删除立方和立方关联
            CubeBean oldCube = new CubeBean ();
            oldCube.setId (dataSet.getCnnId ());
            oldCube.setCubeName (cubeName);
            oldCube.setCubeId (dataSet.getCubeId ());
            oldCube = cubeService.getCubeById (dataSet.getCubeId ());
            if (null != oldCube)
            {
                cubeService.delCubeById (oldCube.getCubeId ());
            }
            
            //插入数据库
            //1.将数据集转换成 表 插入对应的数据库所有表中
            dataSourceService.addDataSourceTable (dstList);
            //2.立方
            cubeService.addCube (cube);
            //3.指标
            dataSourceService.addDataSourceTableFiled (dsTableFiledList);
            //4.数据集字段
            customDataSetService.insetDataSetCols (dsTableFiledList);
        }
        
    }
    
    @RequestMapping ("/gotoDataSetEditView")
    public String gotoDataSetEditView (Model model, HttpServletRequest request, @RequestBody DataSet dataSet)
    {
        return "/service/dataSet/dataSetEdit";
    }
    
    @RequestMapping ("/editDataSet")
    @ResponseBody
    public Object editDataSet (HttpServletRequest request, @RequestBody DataSet dataSet)
    {
        //规则校验
        
        try
        {
            
            DataSet oldDataSet = null;
            if (null != dataSet)
            {
                if (checkDataSetQuerySql (dataSet))
                {
                    LOGGER.info ("data set key repeat, key: " + dataSet.getKey ());
                    return renderError (super.getProperty ("ami.dataset.querysql.empty"));
                }
                
                assembleDataSet (dataSet);
                String queryId = dataSet.getQueryId ();
                
                oldDataSet = customDataSetService.findCustomDataSetById (queryId);
                List <DataSetObject> dataSetObjs = null;
                Set <String> objectIds = null;
                DataSetObject dataSetObject = null;
                String querySql = dataSet.getQuerySql ();
                
                /**
                 * 检查sql的合法
                 */
                try
                {
                    DataSourceBean ds = dataSourceService.getDataSourceById (dataSet.getCnnId ());
                    boolean badSql = SqlUtils.badSqlValidate (querySql);
                    if (badSql)
                    {
                        LOGGER.error ("sql cann't contains keywords: insert|delete|update|drop|truncate|*, bad sql: " + badSql);
                        return renderError (getProperty ("ami.dataset.test.sqlvalid"));
                    }
                    List <Function> func = customDataSetService.findAllFunction ();
                    String testSql = querySql;
                    testSql = SqlUtils.assembleSqlFunction (testSql, null, null, null, func);
                    JdbcTemplate jdbcTemplate = JDBCTemplateUtil.getJDBC (dataSet.getCnnId ());
                    SqlRowSet rs = jdbcTemplate.queryForRowSet (testSql);
                    
                }
                catch (Exception e)
                {
                    
                    LOGGER.error ("test sql error,sql : " + querySql, e);
                    return renderError (super.getProperty ("ami.dataset.model.test.error"));
                }
                
                customDataSetService.editDataSet (dataSet);
                
                if (querySql.indexOf ("%") > -1)
                {
                    // 处理数据集与对象树关系
                    
                    objectIds = new HashSet <String> ();
                    List <ObjectTreeBean> objectTreeList = objectTreeService.queryAllObjectTree (new ObjectTreeBean ());
                    for (ObjectTreeBean objectTreeBean : objectTreeList)
                    {
                        if (querySql.indexOf (objectTreeBean.getName ()) > 0)
                        {
                            objectIds.add (objectTreeBean.getId ());
                            
                        }
                    }
                }
                
                if (null != objectIds && !objectIds.isEmpty ())
                {
                    objectTreeService.deleteDataSetObjectByQueryId (queryId);
                    
                    dataSetObjs = new ArrayList <DataSetObject> ();
                    // 插入关联关系
                    for (String objectId : objectIds)
                    {
                        dataSetObject = new DataSetObject ();
                        dataSetObject.setId (UUIDUtils.generate16Str ());
                        dataSetObject.setQueryId (queryId);
                        dataSetObject.setObjectId (objectId);
                        dataSetObjs.add (dataSetObject);
                        
                    }
                    
                    objectTreeService.insertDataSetObject (dataSetObjs);
                    
                }
                else
                {
                    objectTreeService.deleteDataSetObjectByQueryId (queryId);
                }
                
            }
            
            //生成立方-指标
            generateTarget (dataSet);
            
            //获取当前登录用户
            User curUser = getCurrentUser ();
            //获取操作描述 key = 类名+"_"+方法名 
            String funDesc = LogRenderUtils.getLogReqMap ("CustomDataSetController_editDataSet");
            try
            {
                //分析删除对象的的关键内容
                String operDetail = customDataSetService.analyseEditContent (oldDataSet, dataSet);
                if (StringUtils.isNotBlank (operDetail))
                {
                    //插入日志
                    logService.insertSysLog (curUser, ConstantCode.STRING_02, getRemoteAddr (), funDesc, operDetail, null, null);
                }
            }
            catch (Exception ex)
            {
                logger.error (funDesc + "  bussness log insert error", ex);
            }
            
        }
        catch (Exception e)
        {
            LOGGER.error ("edit data set error.", e);
            return renderError ("error");
        }
        return renderSuccess ("success");
        
    }
    
    @RequestMapping ("/delete")
    @ResponseBody
    public Object delete (HttpServletRequest request, @RequestBody DataSet dataSet)
    {
        //规则校验
        
        try
        {
            customDataSetService.delete (dataSet);
            objectTreeService.deleteDataSetObjectByQueryId (dataSet.getQueryId ());
            
            //删除生成的立方和指标
            String cubeName = dataSet.getKey ().toUpperCase ();
            String tableName = dataSet.getKey ().toUpperCase ();
            
            //封装指标对象
            DataSourceTable dsb = new DataSourceTable ();
            dsb.setQueryId (dataSet.getQueryId ());
            dsb.setId (dataSet.getCnnId ());
            dsb.setTableName (tableName);
            dsb.setTableType ("target");
            //删除数据源中表 和 字段
            dataSourceService.delTableByTableNameAndDsId (dsb);
            customDataSetService.deleteDataSetCols (dsb);
            //删除立方和立方关联
            CubeBean oldCube = new CubeBean ();
            oldCube.setId (dataSet.getCnnId ());
            oldCube.setCubeName (cubeName);
            oldCube = cubeService.getCubeByDsIdAndCubeName (oldCube);
            if (null != oldCube)
            {
                cubeService.delCubeById (oldCube.getCubeId ());
            }
            //获取当前登录用户
            User curUser = getCurrentUser ();
            String funDesc = LogRenderUtils.getLogReqMap ("CustomDataSetController_delete");
            try
            {
                //分析删除对象的的关键内容
                String operDetail = customDataSetService.analyseDelContent (dataSet);
                if (StringUtils.isNotBlank (operDetail))
                {
                    //插入日志
                    logService.insertSysLog (curUser, ConstantCode.STRING_02, getRemoteAddr (), funDesc, operDetail, null, null);
                }
            }
            catch (Exception ex)
            {
                logger.error (funDesc + "  bussness log insert error", ex);
            }
        }
        catch (Exception e)
        {
            LOGGER.error ("edit data set error.", e);
            return renderError ("error");
        }
        return renderSuccess ("success");
        
    }
    
    @RequestMapping ("/testSql")
    @ResponseBody
    public Object testSql (HttpServletRequest request, @RequestBody DataSet dataSet)
    {
        Map <String, Object> result = new HashMap <String, Object> ();
        List <Map <String, Object>> objs = null;
        List <String> colname = null;
        String querySql = "";
        try
        {
            
            if (null != dataSet)
            {
                DataSourceBean ds = dataSourceService.getDataSourceById (dataSet.getCnnId ());
                assembleDataSet (dataSet);
                querySql = dataSet.getQuerySql ();
                boolean badSql = SqlUtils.badSqlValidate (querySql);
                if (badSql)
                {
                    LOGGER.error ("sql cann't contains keywords: insert|delete|update|drop|truncate|*, bad sql: " + badSql);
                    return renderError (getProperty ("ami.dataset.test.sqlvalid"));
                }
                List <Function> func = customDataSetService.findAllFunction ();
                querySql = SqlUtils.assembleSqlFunction (querySql, null, null, null, func);
                String sql = SqlUtils.getPageSql (1, 1, querySql, ds.getDbType ());
                JdbcTemplate jdbcTemplate = JDBCTemplateUtil.getJDBC (dataSet.getCnnId ());
                objs = jdbcTemplate.queryForList (sql);
                if (null != objs && 0 != objs.size ())
                {
                    Map <String, Object> map = objs.get (0);
                    colname = new ArrayList <String> (map.keySet ());
                    
                }
                
            }
            result.put ("list", objs);
            result.put ("colname", colname);
            result.put ("querySql", querySql);
            result.put ("cnnId", dataSet.getCnnId ());
            
            //获取当前登录用户
            User curUser = getCurrentUser ();
            //获取操作描述 key = 类名+"_"+方法名 
            String funDesc = LogRenderUtils.getLogReqMap ("CustomDataSetController_testSql");
            try
            {
                //分析删除对象的的关键内容
                String operDetail = customDataSetService.analyseTestContent (dataSet);
                if (StringUtils.isNotBlank (operDetail))
                {
                    //插入日志
                    logService.insertSysLog (curUser, ConstantCode.STRING_02, getRemoteAddr (), funDesc, operDetail, null, null);
                }
            }
            catch (Exception ex)
            {
                logger.error (funDesc + "  bussness log insert error", ex);
            }
            
        }
        catch (Exception e)
        {
            LOGGER.error ("test sql error.", e);
            return renderError (super.getProperty ("ami.dataset.test.error"));
            
        }
        return renderSuccess (result);
    }
    
    @RequestMapping ("/previewSql")
    @ResponseBody
    public Object previewSql (HttpServletRequest request, @RequestBody DataSet dataSet)
    {
        String querySql = "";
        if (null != dataSet)
        {
            assembleDataSet (dataSet);
            querySql = dataSet.getQuerySql ();
        }
        
        return renderSuccess (querySql);
    }
    
    private void assembleDataSet (DataSet dataSet)
    {
        String querySql = "";
        String sqlJson = "";
        if (SqlConstant.DATASET_USER_DEFINED.equals (dataSet.getQueryType ()))
        {
            // 自定义sql取sql
            if (StringUtils.isNotBlank (dataSet.getQuerySql ()))
            {
                
                querySql = dataSet.getQuerySql ().trim ();
                querySql.replace ("\n", " ");
            }
        }
        else if (SqlConstant.DATASET_MULTI_TABLE_ASSOCIATION.equals (dataSet.getQueryType ()))
        {
            // 多表关联sql树处理
            SqlObject sqlObject = new SqlObject ();
            sqlObject.setSqlSelect (SqlConstant.SQL_SELECT);
            sqlObject.setSqlFrom (SqlConstant.SQL_FROM);
            if (StringUtils.isNotBlank (dataSet.getSqlWhere ()))
            {
                sqlObject.setSqlWhere (dataSet.getSqlWhere ().trim ());
            }
            sqlObject.setTableModels (dataSet.getTableModels ());
            
            List <TableField> colTree = dataSet.getColTree ();
            sqlObject.setSqlColumns (colTree);
            querySql = SqlUtils.generateSqlBySqlObject (sqlObject);
            sqlJson = SqlUtils.generateSqlJson (sqlObject);
        }
        dataSet.setQuerySql (querySql);
        dataSet.setSqlJson (sqlJson);
    }
    
    @RequestMapping ("/sqlList")
    @ResponseBody
    public Object sqlList (HttpServletRequest request/*, @RequestBody DataSet dataSet*/)
    {
        List <Map <String, Object>> objs = null;
        Map <String, Object> map = new HashMap <String, Object> ();
        String querySql = request.getParameter ("querySql");
        String cnnId = request.getParameter ("cnnId");
        int total = 0;
        try
        {
            List <Function> func = customDataSetService.findAllFunction ();
            if (StringUtils.isNotBlank (querySql))
            {
                querySql = SqlUtils.assembleSqlFunction (querySql, null, null, null, func);
                DataSourceBean ds = dataSourceService.getDataSourceById (cnnId);
                querySql.replace ("\n", " ");
                JdbcTemplate jdbcTemplate = JDBCTemplateUtil.getJDBC (cnnId);
                total = jdbcTemplate.queryForObject (SqlUtils.getCountSql (querySql), Integer.class);
                
                int pageNo = NumberUtils.toInt (request.getParameter (CommonConstant.PAGE_PARAM_PAGE));
                int pageSize = NumberUtils.toInt (request.getParameter (CommonConstant.PAGE_PARAM_ROWS));
                objs = jdbcTemplate.queryForList (SqlUtils.getPageSql (pageNo, pageSize, querySql, ds.getDbType ()));
                
                map.put (CommonConstant.PAGE_RESULT_ROWS, objs);
                map.put (CommonConstant.PAGE_RESULT_TOTAL, total);
            }
        }
        catch (Exception e)
        {
            LOGGER.error ("test sql error.", e);
            return null;
            
        }
        return map;
    }
    
    /**
     * 数据集流程图页面
     * @param request 请求
     * @param response 响应
     * @return 主页
     */
    @RequestMapping (value = "/jsPlumb")
    public String jsPlumb (HttpServletRequest request, HttpServletResponse response)
    {
        return "service/dataSet/dataSetPlumb";
    }
    
    /**
     * 数据集流程图页面
     * @param request 请求
     * @param response 响应
     * @return 主页
     */
    @RequestMapping (value = "/jsPlumbEdit")
    public String jsPlumbEdit (HttpServletRequest request, HttpServletResponse response)
    {
        return "service/dataSet/dataSetPlumbEdit";
    }
}
