package com.icss.ebu.ami.report.business.service;

import java.util.List;

import com.icss.ebu.ami.commons.pagePlugin.Page;
import com.icss.ebu.ami.report.business.model.Template;
import com.icss.ebu.ami.report.system.model.User;

/** 
* @author  zhangkaining 
* @date 2017年10月23日 下午3:29:33 
* @version 1.0   
*/
public interface TemplateManagementService
{
    
    /**
     * 分页获取模板列表
     * @return
     */
    Page <Template> queryTemplateList (Page <Template> page);
    
    /**
     * 根据ID获取模板
     * @param tmpid
     * @return
     */
    Template selectTemplateById (String tmpid);
    
    /**
     * 根据名称获取模板
     * @param tmpname
     * @return
     */
    Template selectTemplateByName (String tmpname);
    
    /**
     * 根据路径获取模板
     * @param tmpname
     * @return
     */
    Template selectTemplateByFile (String tmpfile);
    
    /**
     * 添加模板
     * @param template
     * @return
     */
    int insert (Template template);
    
    /**
     * 获取模板列表
     * @return
     */
    List <Template> queryTemplateList (User user);
    
    /**
     * 删除模板
     * @param tmpid
     * @return
     */
    int delete (String tmpid);
    
    /**
     * 更新模板信息
     * @param template
     */
    void update (Template template);
    
    Page <Template> queryTempDesignListByPage (Page <Template> page);
    
    List <Template> findAll ();
    
    List <String> selectFileIdByTmpid (String tmpid);
    
    List <String> selectTaskIdByTmpid (String tmpid);
    
    Template selectTemplateByKey (String tmpkey);
    
    String analyseAddContent (Template template);
    
    String analyseEditContent (Template oldtemplate, Template template);
    
    String analyseDelContent (Template oldtemplate);

    List <Template> queryListByVo (Template template);
}
