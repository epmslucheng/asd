package com.icss.ebu.ami.report.system.shiro;

import java.util.List;

import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.oltu.oauth2.common.OAuth;
import org.apache.oltu.oauth2.common.error.OAuthError;
import org.apache.oltu.oauth2.common.exception.OAuthSystemException;
import org.apache.oltu.oauth2.common.message.OAuthResponse;
import org.apache.oltu.oauth2.rs.response.OAuthRSResponse;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.subject.Subject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;

import com.icss.ebu.ami.auth.domain.oauth.AccessToken;
import com.icss.ebu.ami.auth.infrastructure.WebUtils;
import com.icss.ebu.ami.auth.oauth.shiro.OAuth2Token;
import com.icss.ebu.ami.commons.constants.DictConstant;
import com.icss.ebu.ami.commons.util.I18nUtils;
import com.icss.ebu.ami.report.business.common.constant.CommonConstant;
import com.icss.ebu.ami.report.system.common.shiro.ShiroUser;
import com.icss.ebu.ami.report.system.model.Role;
import com.icss.ebu.ami.report.system.model.User;

public class OAuth2Filter extends SessionFilter implements InitializingBean
{
    
    private static Logger logger = LoggerFactory.getLogger(OAuth2Filter.class);
    
    @Override
    protected AuthenticationToken createToken(ServletRequest request, ServletResponse response) throws Exception
    {
        
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        
        String accessToken = getToken(request);
        AccessToken token = getAccessToken(accessToken);
        
        String username = null;
        if(token != null)
        {
            username = token.username();
            logger.debug("Set username[{}] and clientId[{}] to request that from AccessToken: {}", username, token.clientId(),
                token);
            httpRequest.setAttribute(OAuth.OAUTH_CLIENT_ID, token.clientId());
        }
        else
        {
            logger.debug("Not found AccessToken by access_token: {}", accessToken);
        }
        
        return new OAuth2Token("", accessToken, "os-resource").setUserId(username);
    }
    
    protected boolean isAccessAllowed(ServletRequest request, ServletResponse response, Object mappedValue)
    {
        return false;
    }
    
    @Override
    protected boolean onLoginFailure(AuthenticationToken token, AuthenticationException ae, ServletRequest request,
        ServletResponse response)
    {
        OAuthResponse oAuthResponse = null;
        try
        {
            oAuthResponse =
                OAuthRSResponse.errorResponse(401).setError(OAuthError.ResourceResponse.INVALID_TOKEN)
                    .setErrorDescription(ae.getMessage()).buildJSONMessage();
            
            WebUtils.writeOAuthJsonResponse((HttpServletResponse) response, oAuthResponse);
            
        }
        catch (OAuthSystemException e)
        {
            logger.error("Build JSON message error", e);
            throw new IllegalStateException(e);
        }
        
        return false;
    }
    
    @Override
    protected boolean onLoginSuccess(AuthenticationToken token, Subject subject, ServletRequest request, ServletResponse response)
        throws Exception
    {
        
        ShiroUser shiroUser = (ShiroUser) subject.getPrincipal();
        
        // 判断用户所属角色是否有被锁定的，有被锁定的，登录失败
        // 判断用户所属角色是否所有都被锁定，都被被锁定的，登录失败 20170406xiugai
        List<Role> roles = queryRolesByUserId(shiroUser.id);
        int roleLimited = 0;
        int roleSize = roles.size();
        for(Role role : roles)
        {
            if(Role.STATUS_DISABLED.equals(role.getStatus()))
            {
                // 移除限制的角色id
                shiroUser.getRoleList().remove(role.getId());
                roleLimited++;
            }
        }
        if(roleSize == roleLimited)
        {
            subject.logout();
        }
        
        //显示调用shiro 权限验证。保证每次登陆后的url权限正确    等于调用doGetAuthorizationInfo()
        SecurityUtils.getSubject().isPermitted("/index");
        
        // 登录校验成功后，将用户存到session中
        User currentUser = findUserById(shiroUser.id);
        subject.getSession().setAttribute(CommonConstant.CURRENT_LOGIN_USER, currentUser);
        subject.getSession().setAttribute(CommonConstant.SESSION_LOCALE, I18nUtils.getCurrentLocale());
        Object vale = redisCacheUtil.getDataFromRedis(DictConstant.MONETARY_UNIT);
        subject.getSession().setAttribute(CommonConstant.MONETARY_UNIT, (String) vale);
        return true;
    }
    
    @Override
    public void afterPropertiesSet() throws Exception
    {
        
    }
    
}
