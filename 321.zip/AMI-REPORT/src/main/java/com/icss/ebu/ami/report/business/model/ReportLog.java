package com.icss.ebu.ami.report.business.model;

import java.io.Serializable;
import java.util.Date;

/**
 * 
 * 记录报表生成参数,
 * @author lucheng
 *
 */
public class ReportLog implements Serializable
{
    
    /**
     * 序列化
     */
    private static final long serialVersionUID = -3994184743316923091L;
    
    private String reportId;
    
    private String creatorId;
    
    private String startTime;
    
    private String endTime;
    
    private String currentTime;
    
    private String status;
    
    private Date createTime;
    
    private String treeParam;
    
    public String getReportId ()
    {
        return reportId;
    }
    
    public void setReportId (String reportId)
    {
        this.reportId = reportId;
    }
    
    public String getStatus ()
    {
        return status;
    }
    
    public void setStatus (String status)
    {
        this.status = status;
    }
    
    public String getTreeParam ()
    {
        return treeParam;
    }
    
    public void setTreeParam (String treeParam)
    {
        this.treeParam = treeParam;
    }
    
    public String getCreatorId ()
    {
        return creatorId;
    }
    
    public void setCreatorId (String creatorId)
    {
        this.creatorId = creatorId;
    }
    
    public Date getCreateTime ()
    {
        return createTime;
    }
    
    public void setCreateTime (Date createTime)
    {
        this.createTime = createTime;
    }
    
    public String getStartTime ()
    {
        return startTime;
    }
    
    public void setStartTime (String startTime)
    {
        this.startTime = startTime;
    }
    
    public String getEndTime ()
    {
        return endTime;
    }
    
    public void setEndTime (String endTime)
    {
        this.endTime = endTime;
    }
    
    public String getCurrentTime ()
    {
        return currentTime;
    }
    
    public void setCurrentTime (String currentTime)
    {
        this.currentTime = currentTime;
    }
    
}
