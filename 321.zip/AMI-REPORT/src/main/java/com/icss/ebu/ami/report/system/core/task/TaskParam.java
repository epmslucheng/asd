package com.icss.ebu.ami.report.system.core.task;

import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;

/**
 * 任务相关运行参数表
 * 
 * @author Administrator
 *
 */
@XmlRootElement
public class TaskParam implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * 运行任务参数标识 PARA_ID
	 */
	private Long paramId;
	/**
	 * 运行任务标识 task_id
	 */
	private Long taskId;
	/**
	 * 参数名称 NAME
	 */
	private String name;
	/**
	 * 参数类型 TYPE_CODE
	 */
	private String type;
	/**
	 * 参数说明 PARA_DESC
	 */
	private String desc;
	/**
	 * 参数内容 CONTENT
	 */
	private String content;

	public Long getParamId() {
		return paramId;
	}

	public void setParamId(Long paramId) {
		this.paramId = paramId;
	}

	public Long getTaskId() {
		return taskId;
	}

	public void setTaskId(Long taskId) {
		this.taskId = taskId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

}
