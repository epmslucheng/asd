package com.icss.ebu.ami.report.system.core.task;

import com.fasterxml.jackson.annotation.JsonFormat;

import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.util.Date;

/**
 * 任务运行日志记录
 * 
 * @author Administrator
 *
 */
@XmlRootElement
public class TaskLog implements Serializable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -2426070584552378802L;
	/**
	 * 任务运行日志标识 TASK_LOG_ID
	 */
	private Long taskLogId;
	/**
	 * 运行任务标识 TASK_ID
	 */
	private Long taskId;
	/**
	 * 任务名称 name
	 */
	private String taskName;

	private String taskNameAlias;

	/**
	 * 任务运行结果 RUN_RSLT s:成功,f:失败
	 */
	private String runResult;
	/**
	 * 任务运行信息 RUN_DESC
	 */
	private String runDesc;
	/**
	 * 任务实际运行时间 ACCTUAL_RUN_TIME
	 */
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
	private Date acctualRunTime;
	/**
	 * 任务开始执行时间 START_RUN_TIME
	 */
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
	private Date startRunTime;
	/**
	 * 任务执行结束时间 END_RUN_TIME
	 */
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
	private Date endRunTime;
	/**
	 * 耗时
	 */
	private Long consTime;

	public Long getTaskLogId() {
		return taskLogId;
	}

	public void setTaskLogId(Long taskLogId) {
		this.taskLogId = taskLogId;
	}

	public Long getTaskId() {
		return taskId;
	}

	public void setTaskId(Long taskId) {
		this.taskId = taskId;
	}

	public String getTaskName() {
		return taskName;
	}

	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}

	public String getRunResult() {
		return runResult;
	}

	public void setRunResult(String runResult) {
		this.runResult = runResult;
	}

	public String getRunDesc() {
		return runDesc;
	}

	public void setRunDesc(String runDesc) {
		this.runDesc = runDesc;
	}

	public Date getAcctualRunTime() {
		if (acctualRunTime == null) {
			return null;
		}
		return (Date) acctualRunTime.clone();
	}

	public void setAcctualRunTime(Date acctualRunTime) {
		if (acctualRunTime == null) {
			this.acctualRunTime = null;
		} else {
			this.acctualRunTime = (Date) acctualRunTime.clone();
		}
	}

	public Date getStartRunTime() {
		if (startRunTime == null) {
			return null;
		}
		return (Date) startRunTime.clone();
	}

	public void setStartRunTime(Date startRunTime) {
		if (startRunTime == null) {
			this.startRunTime = null;
		} else {
			this.startRunTime = (Date) startRunTime.clone();
		}
	}

	public Date getEndRunTime() {
		if (endRunTime == null) {
			return null;
		}
		return (Date) endRunTime.clone();
	}

	public void setEndRunTime(Date endRunTime) {
		if (endRunTime == null) {
			this.endRunTime = null;
		} else {
			this.endRunTime = (Date) endRunTime.clone();
		}
	}

	public String getTaskNameAlias() {
		return taskNameAlias;
	}

	public void setTaskNameAlias(String taskNameAlias) {
		this.taskNameAlias = taskNameAlias;
	}

	public Long getConsTime() {
		return consTime;
	}

	public void setConsTime(Long consTime) {
		this.consTime = consTime;
	}

}
