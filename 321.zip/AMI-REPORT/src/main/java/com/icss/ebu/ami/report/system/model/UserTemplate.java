package com.icss.ebu.ami.report.system.model;

import java.io.Serializable;

/** 
* @author  zhangkaining 
* @date 2017年11月16日 上午10:40:27 
* @version 1.0   
*/
public class UserTemplate implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8142719253181055901L;
	
	private Long id;
	
	private String userId;
	
	private String reportId;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getReportId() {
		return reportId;
	}

	public void setReportId(String reportId) {
		this.reportId = reportId;
	}
	
	
}
