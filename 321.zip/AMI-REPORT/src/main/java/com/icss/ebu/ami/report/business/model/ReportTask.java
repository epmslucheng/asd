package com.icss.ebu.ami.report.business.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;

import java.io.Serializable;
import java.util.Date;

public class ReportTask implements Serializable
{
    
    private static final long serialVersionUID = 6621267910573753985L;
    
    //任务状态:暂停
    public static final String STATUS_PAUSE = "01";
    
    //任务状态:运行
    public static final String STATUS_RUNNING = "02";
    
    private String id;
    
    private String code;
    
    private String name;
    
    @JsonFormat (pattern = "yyyy-MM-dd", timezone = "GMT+8")
    private Date startTime;
    
    @JsonFormat (pattern = "yyyy-MM-dd", timezone = "GMT+8")
    private Date endTime;
    
    private String type;
    
    private String status;
    
    private Date createTime;
    
    private String remark;
    
    private String handle;
    
    private int offset;
    
    private String tmpIds;
    
    private String objTreeMaps;
    
    public String getId ()
    {
        return id;
    }
    
    @JsonIgnore
    public Long getLongId ()
    {
        return Long.valueOf (id);
    }
    
    public void setId (String id)
    {
        this.id = id;
    }
    
    public String getName ()
    {
        return name;
    }
    
    public void setName (String name)
    {
        this.name = name;
    }
    
    public String getCode ()
    {
        return code;
    }
    
    public void setCode (String code)
    {
        this.code = code;
    }
    
    public Date getStartTime ()
    {
        return startTime;
    }
    
    public void setStartTime (Date startTime)
    {
        this.startTime = startTime;
    }
    
    public Date getEndTime ()
    {
        return endTime;
    }
    
    public void setEndTime (Date endTime)
    {
        this.endTime = endTime;
    }
    
    public String getType ()
    {
        return type;
    }
    
    public void setType (String type)
    {
        this.type = type;
    }
    
    public String getStatus ()
    {
        return status;
    }
    
    public void setStatus (String status)
    {
        this.status = status;
    }

    public String getRemark ()
    {
        return remark;
    }
    
    public void setRemark (String remark)
    {
        this.remark = remark;
    }
    
    public String getHandle ()
    {
        return handle;
    }
    
    public void setHandle (String handle)
    {
        this.handle = handle;
    }
    
    public int getOffset ()
    {
        return offset;
    }
    
    public void setOffset (int offset)
    {
        this.offset = offset;
    }
    
    public boolean compareEquals (Object obj)
    {
        boolean isFlag = true;
        if (obj instanceof ReportTask)
        {
            ReportTask task = (ReportTask) obj;
            if (this.handle != null && !this.handle.equals (task.getHandle ()))
            {
                isFlag = false;
            }
            else if (this.handle == null && task.getHandle () != null)
            {
                isFlag = false;
            }
            else if (this.status != null && !this.status.equals (task.getStatus ()))
            {
                isFlag = false;
            }
            else if (this.status == null && task.getStatus () != null)
            {
                isFlag = false;
            }
            else if (this.startTime != null && task.getStartTime () != null
                && this.startTime.getTime () != task.getStartTime ().getTime ())
            {
                isFlag = false;
            }
            else if (this.endTime != null && task.getEndTime () != null
                && this.endTime.getTime () != task.getEndTime ().getTime ())
            {
                isFlag = false;
            }
            else if (this.name != null && !this.name.equals (task.getName ()))
            {
                isFlag = false;
            }
            else if (this.name == null && task.getName () != null)
            {
                isFlag = false;
            }
        }
        else
        {
            isFlag = false;
        }
        return isFlag;
    }
    
    public String getTmpIds ()
    {
        return tmpIds;
    }
    
    public void setTmpIds (String tmpIds)
    {
        this.tmpIds = tmpIds;
    }
    
    public String getObjTreeMaps ()
    {
        return objTreeMaps;
    }
    
    public void setObjTreeMaps (String objTreeMaps)
    {
        this.objTreeMaps = objTreeMaps;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }
}
