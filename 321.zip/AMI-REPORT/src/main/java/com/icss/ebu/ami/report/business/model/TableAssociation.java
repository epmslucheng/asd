package com.icss.ebu.ami.report.business.model;

import java.io.Serializable;

/**
 * 表关联模型图
 * @author lucheng
 *
 */
public class TableAssociation implements Serializable
{
    /**
     * 序列化
     */
    private static final long serialVersionUID = 4272582948039971823L;
    
    private String sourceModel;
    
    private String targetModel;
    
    public String getSourceModel ()
    {
        return sourceModel;
    }
    
    public void setSourceModel (String sourceModel)
    {
        this.sourceModel = sourceModel;
    }
    
    public String getTargetModel ()
    {
        return targetModel;
    }
    
    public void setTargetModel (String targetModel)
    {
        this.targetModel = targetModel;
    }
    
    /* private TableField sourceModel;
     
     private TableField targetModel;
     
     public TableField getSourceModel ()
     {
         return sourceModel;
     }
     
     public void setSourceModel (TableField sourceModel)
     {
         this.sourceModel = sourceModel;
     }
     
     public TableField getTargetModel ()
     {
         return targetModel;
     }
     
     public void setTargetModel (TableField targetModel)
     {
         this.targetModel = targetModel;
     }*/
    
}
