package com.icss.ebu.ami.report.system.shiro;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.subject.Subject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.icss.ebu.ami.auth.domain.oauth.AccessToken;
import com.icss.ebu.ami.auth.infrastructure.cache.CacheKeyGenerator;
import com.icss.ebu.ami.commons.aspect.RedisCacheUtil;
import com.icss.ebu.ami.commons.util.GeneralUtils;
import com.icss.ebu.ami.report.business.common.util.ConfigHolder;
import com.icss.ebu.ami.report.business.service.OAuthRSService;
import com.icss.ebu.ami.report.system.model.Role;
import com.icss.ebu.ami.report.system.model.User;

/**
 * 监控session问题
 * 包含：
 * 1、单账号登陆，一账号异地登陆踢下线功能
 * 2、统计在线人数
 * 3、后续需要优化，可能服务器压力过大
 * @author lucheng
 *
 */
public abstract class SessionFilter implements Filter
{
    
    private static final Logger LOGGER = LoggerFactory.getLogger(SessionFilter.class);
    
    private Set<String> excludesPattern;
    
    private String exclusions;
    
    private String SINGLE_ACCOUNT_ON = "SINGLE_ACCOUNT_ON";
    
    private long SESSION_ACTIVE_TIME = 120000;
    
    private static final int TOKEN_EXP_1800 = 1800;
    
    private OAuthRSService oAuthRSService;
    
    protected RedisCacheUtil redisCacheUtil = new RedisCacheUtil();
    
    @Override
    public void init(FilterConfig filterConfig) throws ServletException
    {
    }
    
    /**
     * 单账号踢下线
     */
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException,
        ServletException
    {
        try
        {
            
            HttpServletRequest httpRequest = (HttpServletRequest) request;
            String requestURI = httpRequest.getRequestURI();
            String tokenId = getToken(request);
            
            HttpSession httpSession = httpRequest.getSession();
            User user = (User) httpSession.getAttribute("currentUser");
            if(null == user && StringUtils.isNotBlank(tokenId))
            {
                //这一步做踢下线提示
                AccessToken accessToken = getAccessToken(tokenId);
                if(null == accessToken || (!tokenId.equals(accessToken.tokenId())))
                {
                    LOGGER.info("offline , accessToken:" + accessToken);
                    request.setAttribute("oauthSession", "offline");
                }
                /*else if (0 == accessToken.activeMillisecond ())
                {
                    // 退出
                    LOGGER.info ("token active millsecond is zero.");
                }*/
                /*else if(accessToken.tokenExpired())
                {
                    LOGGER.info("token expire :" + accessToken.tokenExpired());
                    request.setAttribute("oauthSession", "overtime");
                }*/
                else
                {
                    /* // token有效则自动登录
                     executeLogin (request, response);
                     if (isExclusion (requestURI))
                     {
                         chain.doFilter (request, response);
                         return;
                     }
                     httpRequest.getRequestDispatcher (requestURI).forward (request, response);
                     return;*/
                    LOGGER.info("accessToken:" + accessToken);
                }
                chain.doFilter(request, response);
                return;
            }
            
            if(isExclusion(requestURI))
            {
            }
            else if(StringUtils.isNotBlank(tokenId))
            {
                //这一步做踢下线操作,踢下线后在login。jsp中设置cookie为null
                AccessToken accessToken = getAccessToken(tokenId);
                if(null == accessToken || (!tokenId.equals(accessToken.tokenId())) || accessToken.tokenExpired())
                {
                    // 如果客户端token与session中不一致
                    String offlineSwitch = ConfigHolder.getCfg(SINGLE_ACCOUNT_ON);
                    if(StringUtils.isNotBlank(offlineSwitch) && offlineSwitch.equals("true"))
                    {
                        LOGGER.info("offline: " + user.getName());
                        SecurityUtils.getSubject().logout();
                        httpRequest.getSession().invalidate();
                    }
                }
                else
                {
                    // 更新活跃时间
                    long last = accessToken.activeMillisecond();
                    long currTimes = System.currentTimeMillis();
                    long spaceTimes = currTimes - last;
                    if(spaceTimes > SESSION_ACTIVE_TIME)
                    {
                        // 每隔两分钟更新一把活跃时间吧
                        accessToken.activeMillisecond(currTimes);
                        final String key = CacheKeyGenerator.generateAccessTokenKey(accessToken.tokenId());
                        redisCacheUtil.setKeyexpire(key, TOKEN_EXP_1800);
                        LOGGER.info("update" + accessToken.username() + " accessToken active millisecond: "
                            + accessToken.activeMillisecond());
                    }
                }
            }
            
            chain.doFilter(request, response);
        }
        catch (Exception e)
        {
            LOGGER.error("session filter error!", e);
        }
        
    }
    
    protected AccessToken getAccessToken(String tokenId)
    {
        AccessToken accessToken = oAuthRSService.loadAccessTokenByTokenId(tokenId);
        
        return accessToken;
    }
    
    protected String getToken(ServletRequest request)
    {
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        Cookie[] cookies = httpRequest.getCookies();
        String tokenId = "";
        if(cookies != null)
        {
            for(int i = 0; i < cookies.length; i++)
            {
                if("access_token".equals(cookies[i].getName()))
                {
                    tokenId = cookies[i].getValue();
                    break;
                }
            }
        }
        
        return tokenId;
    }
    
    protected abstract AuthenticationToken createToken(ServletRequest request, ServletResponse response) throws Exception;
    
    protected boolean executeLogin(ServletRequest request, ServletResponse response) throws Exception
    {
        AuthenticationToken token = createToken(request, response);
        if(token == null)
        {
            String msg =
                "createToken method implementation returned null. A valid non-null AuthenticationToken "
                    + "must be created in order to execute a login attempt.";
            throw new IllegalStateException(msg);
        }
        try
        {
            Subject subject = getSubject(request, response);
            subject.login(token);
            return onLoginSuccess(token, subject, request, response);
        }
        catch (AuthenticationException e)
        {
            return onLoginFailure(token, e, request, response);
        }
    }
    
    protected boolean onLoginSuccess(AuthenticationToken token, Subject subject, ServletRequest request, ServletResponse response)
        throws Exception
    {
        return true;
    }
    
    protected boolean onLoginFailure(AuthenticationToken token, AuthenticationException e, ServletRequest request,
        ServletResponse response)
    {
        return false;
    }
    
    protected Subject getSubject(ServletRequest request, ServletResponse response)
    {
        return SecurityUtils.getSubject();
    }
    
    protected List<Role> queryRolesByUserId(String userId)
    {
        return oAuthRSService.queryRolesByUserId(userId);
    }
    
    protected User findUserById(String id)
    {
        return oAuthRSService.findUserById(id);
    }
    
    public boolean isExclusion(String requestURI)
    {
        if(StringUtils.isBlank(exclusions))
        {
            return false;
        }
        excludesPattern = new HashSet<String>(Arrays.asList(exclusions.split("\\s*,\\s*")));
        
        for(String pattern : excludesPattern)
        {
            if(GeneralUtils.fuzzyMatches(pattern, requestURI))
            {
                return true;
            }
        }
        
        return false;
    }
    
    @Override
    public void destroy()
    {
        
    }
    
    public String getExclusions()
    {
        return exclusions;
    }
    
    public void setExclusions(String exclusions)
    {
        this.exclusions = exclusions;
    }
    
    public OAuthRSService getoAuthRSService()
    {
        return oAuthRSService;
    }
    
    public void setoAuthRSService(OAuthRSService oAuthRSService)
    {
        this.oAuthRSService = oAuthRSService;
    }
    
}
