package com.icss.ebu.ami.report.business.controller;

import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.google.code.kaptcha.Constants;
import com.google.code.kaptcha.Producer;

/**
 * @deprecated: 验证码验证
 * @author tfl
 * @date:2016/12/5
 */
@Controller
public class IdentifyCodeController extends BaseController
{
    
    private Producer captchaProducer = null;
    
    @Autowired
    public void setCaptchaProducer (Producer captchaProducer)
    {
        this.captchaProducer = captchaProducer;
    }
    
    @RequestMapping ("/verifiCode")
    public void handleRequest (HttpServletRequest request, HttpServletResponse response)
    {
        response.setDateHeader ("Expires", 0);
        response.setHeader ("Cache-Control", "no-store, no-cache, must-revalidate");
        response.addHeader ("Cache-Control", "post-check=0, pre-check=0");
        response.setHeader ("Pragma", "no-cache");
        response.setContentType ("image/jpeg");
        String capText = captchaProducer.createText ();
        request.getSession ().setAttribute (Constants.KAPTCHA_SESSION_KEY, capText);
        BufferedImage bi = captchaProducer.createImage (capText);
        ServletOutputStream out = null;
        try
        {
            out = response.getOutputStream ();
            ImageIO.write (bi, "jpg", out);
            out.flush ();
        }
        catch (Exception e)
        {
            logger.error ("verifiCode write out errer : ", e);
        }
        finally
        {
            if (null != out)
            {
                try
                {
                    out.close ();
                }
                catch (IOException e)
                {
                    logger.error ("verifiCode out Stream close errer : ", e);
                }
            }
        }
    }
}
