package com.icss.ebu.ami.report.system.core.task;

import com.icss.ebu.ami.commons.util.DateUtils;
import org.quartz.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Date;
import java.util.Map;

/**
 * 任务计划调度触发器生成工厂
 *
 * @author Administrator
 *
 */
public class TriggerUtil
{
    
    private Logger logger = LoggerFactory.getLogger (getClass ());
    
    private static TriggerUtil triggerUtil = new TriggerUtil ();
    
    public static TriggerUtil getInstance()
    {
        return triggerUtil;
    }
    
    private TriggerUtil ()
    {
    }
    
    /**
     * 根据配置获取cron调度触发器
     *
     * @param jobClass
     *            任务处理类
     * @param jobExecParamAsMap
     *            任务处理类需要的相关参数
     * @param config
     *            cron表达式
     * @return CronTriggerBean
     */
    public CronTrigger generateCronTrigger(Class jobClass, Map <String, Object> jobExecParamAsMap, JobConfig config,
        boolean isMonth)
    {
        TriggerBuilder <Trigger> triggerBuilder = TriggerBuilder.newTrigger ();
        CronScheduleBuilder cromSchedule = CronScheduleBuilder.cronSchedule (config.getCronExpre ());
        if (config.getValidTime () != null)
        {
            if (isMonth)
            {
                String startTimeStr = DateUtils.date2String (config.getValidTime (), DateUtils.DATE_PATTERN);
                String nextTimeStr = DateUtils.getToday ().substring (0, 8) + startTimeStr.substring (8, 19);
                Date nextFireTime = DateUtils.string2Date (nextTimeStr, DateUtils.DATE_PATTERN);
                if ((nextFireTime.getTime () + 30000) < System.currentTimeMillis ())
                {
                    // 下一月
                    nextFireTime = CronExpreUtil.getNextMonth (nextFireTime);
                }
                triggerBuilder.startAt (nextFireTime);
            }
            else
            {
                triggerBuilder.startAt (config.getValidTime ());
            }
        }
        else
        {
            triggerBuilder.startNow ();
        }
        // 设置定时触发器的退出触发时间
        if ((config.getInvalidTime () != null) && (config.getInvalidTime ().compareTo (config.getValidTime ()) > 0))
        {
            triggerBuilder.endAt (config.getInvalidTime ());
        }
        //        triggerBuilder.withPriority (jobExecParamAsMap.get (key))
        try
        {
            
            CronTrigger trigger =
                triggerBuilder.withIdentity (config.getTaskId (), config.getGroup ()).withSchedule (cromSchedule)
                    .forJob (config.getTaskId (), config.getGroup ()).usingJobData (new JobDataMap (jobExecParamAsMap)).build ();
            trigger.getJobDataMap ().putAll (jobExecParamAsMap);
            return trigger;
        }
        catch (Exception e)
        {
            logger.error ("generateCronTrigger error:", e);
        }
        return null;
    }
    
    /**
     * 根据配置获取频度调度触发器
     *
     * @param jobExecParamAsMap
     *            任务处理类需要的相关参数
     * @param config
     *            重复间隔时间（毫秒计）
     * @return SimpleTrigger
     */
    @SuppressWarnings ("rawtypes")
    public SimpleTrigger generateTimeTrigger(Map <String, Object> jobExecParamAsMap, JobConfig config)
    {
        long spaceTime = config.getRepeatInterval () * 1000;
        TriggerBuilder <Trigger> triggerBuilder = TriggerBuilder.newTrigger ();
        SimpleScheduleBuilder simpleSchedule = SimpleScheduleBuilder.simpleSchedule ();
        simpleSchedule.withIntervalInMilliseconds (spaceTime);
        Date startTime;
        if (config.getValidTime () != null)
        {
            startTime = getStartTime (config.getValidTime (), spaceTime);
            triggerBuilder.startAt (startTime);
        }
        else
        {
            startTime = new Date ();
            triggerBuilder.startNow ();
        }
        if ((config.getInvalidTime () != null) && (config.getInvalidTime ().compareTo (config.getValidTime ()) > 0))
        {
            triggerBuilder.endAt (config.getInvalidTime ());
        }
        // 设置定时触发器的退出触发时间
        int timeCount = CronExpreUtil.calcRepeatCount (spaceTime, startTime, config.getInvalidTime ());
        simpleSchedule.withRepeatCount (timeCount);
        
        try
        {
            SimpleTrigger trigger =
                triggerBuilder.withIdentity (config.getTaskId (), config.getGroup ()).withSchedule (simpleSchedule)
                    .forJob (config.getTaskId (), config.getGroup ()).usingJobData (new JobDataMap (jobExecParamAsMap)).build ();
            trigger.getJobDataMap ().putAll (jobExecParamAsMap);
            return trigger;
        }
        catch (Exception e)
        {
            logger.error ("generateCronTrigger error:", e);
        }
        return null;
    }
    
    private Date getStartTime(Date startDate, Long intervalMisSecond)
    {
        Date nextFireTime = startDate;
        long interVal = intervalMisSecond.longValue ();
        long startTime = startDate.getTime ();
        long nextTime = startTime;
        long spaceTime = System.currentTimeMillis () - startTime;
        long residues = spaceTime % interVal;
        if (residues < 10000 || (interVal - residues) < 10000)
        {
            nextTime = System.currentTimeMillis () + 10000;
        }
        else
        {
            long spaceInt = spaceTime / interVal;
            nextTime = startTime + (spaceInt + 1) * interVal;
        }
        nextFireTime = new Date (nextTime);
        return nextFireTime;
    }
}
