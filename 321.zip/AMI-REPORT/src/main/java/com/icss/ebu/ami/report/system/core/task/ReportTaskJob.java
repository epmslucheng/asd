package com.icss.ebu.ami.report.system.core.task;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

@Service ("reportTaskJob")
public class ReportTaskJob extends AbstractTask
{
    
    private Logger logger = LoggerFactory.getLogger(ReportTaskJob.class);
    
    @Autowired
    private SupportBean supportBean;

    public ReportTaskJob(Long taskId, String name, List<TaskParam> params)
    {
        super(taskId, name, params);
    }
    
    public ReportTaskJob()
    {
        super();
    }
    
    @Override
    public void execTask()
    {
        logger.info("开始执行-ReportTaskJob: typeCode:" + this.getTaskCode() + ",TaskID:" + this.getTaskId());
        Date bgnDate = Calendar.getInstance().getTime();
        try
        {
            if("01".equals(this.getTaskCode()))
            {
                getSupportBean().getReportTaskService().taskGenerateReport(this.getTaskId().toString());
            }
        }
        catch (Exception e)
        {
            logger.error("reportTaskJob invoke service error ：", e);
        }
        logger.info("执行完成-ReportTaskJob: typeCode:" + this.getTaskCode() + ",TaskID:" + this.getTaskId() + ",耗时：" + (System.currentTimeMillis() - bgnDate.getTime()) + "ms");
    }
    
    public SupportBean getSupportBean()
    {
        if(supportBean == null)
        {
            supportBean = (SupportBean) applicationContext.getBean("supportBean");
        }
        return supportBean;
    }
}
