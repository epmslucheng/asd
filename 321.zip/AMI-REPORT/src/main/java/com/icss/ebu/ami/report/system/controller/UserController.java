package com.icss.ebu.ami.report.system.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.icss.ebu.ami.commons.constants.ConstantCode;
import com.icss.ebu.ami.commons.pagePlugin.Page;
import com.icss.ebu.ami.commons.util.AesKeyUtils;
import com.icss.ebu.ami.commons.util.PasswordCheckUtils;
import com.icss.ebu.ami.commons.util.ServiceUtils;
import com.icss.ebu.ami.report.business.common.constant.CheckPwdInput;
import com.icss.ebu.ami.report.business.common.constant.CommonConstant;
import com.icss.ebu.ami.report.business.common.util.ConfigHolder;
import com.icss.ebu.ami.report.business.common.util.LogRenderUtils;
import com.icss.ebu.ami.report.business.common.util.PropertiesReader;
import com.icss.ebu.ami.report.business.common.util.SecurityLogUtils;
import com.icss.ebu.ami.report.business.controller.BaseController;
import com.icss.ebu.ami.report.business.model.CubeBean;
import com.icss.ebu.ami.report.business.model.DataSourceBean;
import com.icss.ebu.ami.report.business.model.ObjectTreeNode;
import com.icss.ebu.ami.report.business.model.Template;
import com.icss.ebu.ami.report.business.result.UserVo;
import com.icss.ebu.ami.report.business.service.CubeService;
import com.icss.ebu.ami.report.business.service.DataSourceService;
import com.icss.ebu.ami.report.business.service.LogService;
import com.icss.ebu.ami.report.business.service.ObjectTreeService;
import com.icss.ebu.ami.report.business.service.TemplateManagementService;
import com.icss.ebu.ami.report.business.service.UserService;
import com.icss.ebu.ami.report.system.common.util.UserPwdInputCache;
import com.icss.ebu.ami.report.system.model.User;
import com.icss.ebu.ami.report.system.model.UserGrant;
import com.icss.ebu.ami.report.system.model.UserPassword;

/**
 * @description：用户管理
 * @author：zhixuan.wang @date：2015/10/1 14:51
 */
@Controller
@RequestMapping ("/user")
public class UserController extends BaseController
{
    
    private static Logger securityLoger = LoggerFactory.getLogger ("securityLoger");
    
    @Autowired
    private UserService userService;
    
    @Autowired
    private DataSourceService dataSourceService;
    
    @Autowired
    private CubeService cubeService;
    
    @Autowired
    private TemplateManagementService templateManagementService;
    
    @Autowired
    private ObjectTreeService objectTreeService;
    
    @Autowired
    protected LogService logService;
    
    /**
     * 用户管理页
     *
     * @return
     */
    @RequestMapping (value = "/manager")
    public String manager ()
    {
        return "service/user/user";
    }
    
    @RequestMapping ("grant")
    public String grant ()
    {
        return "/service/user/userGrant";
    }
    
    /**
     * 用户管理列表
     *
     * @param userVo
     * @param request
     * @param response
     * @return
     */
    @RequestMapping (value = "/dataGrid", method = RequestMethod.POST)
    @ResponseBody
    public Object dataGrid (UserVo userVo, HttpServletRequest request, HttpServletResponse response)
    {
        Map <String, Object> map = new HashMap <String, Object> ();
        Page <UserVo> page = new Page <UserVo> (userVo);
        page.setPageNo (Integer.parseInt (request.getParameter ("page")));
        page.setPageSize (Integer.parseInt (request.getParameter ("rows")));
        
        page = userService.findUserByPage (page);
        map.put ("rows", page.getResults ());
        map.put ("total", page.getTotalRecord ());
        return map;
    }
    
    /**
     * 添加用户页
     *
     * @return
     */
    @RequestMapping (value = "/addPage")
    public String addPage (HttpServletRequest request)
    {
        return "service/user/userAdd";
    }
    
    /**
     * 添加用户
     *
     * @param userVo
     * @return
     */
    @RequestMapping (value = "/add", method = RequestMethod.POST)
    @ResponseBody
    public Object add (@RequestBody UserVo userVo, HttpServletRequest request)
    {
        User u = userService.findUserByLoginName (userVo.getLoginname ());
        if (u != null)
        {
            return renderError (super.getProperty ("username_exist"));
        }
        String chkStr = PasswordCheckUtils.checkPassword (userVo.getLoginname (), userVo.getPassword ());
        if (StringUtils.isNoneBlank (chkStr))
        {
            return renderError (chkStr);
        }
        try
        {
            String pwd = AesKeyUtils.encrypt (userVo.getPassword (), PropertiesReader.getUserPwdKey ());
            userVo.setPassword (pwd);
        }
        catch (IOException e)
        {
            logger.error (super.getProperty ("enPassword_fail") + "：{}", e);
            return renderError (super.getProperty ("enPassword_fail"));
        }
        
        userVo.setUsertype (UserVo.USER_TYPE_USER);
        try
        {
            userService.addUser (userVo, getCurrentUser (), ServiceUtils.getLikeClientIp (request), securityLoger);
        }
        catch (Exception e)
        {
            logger.error (super.getProperty ("oper_fail"), e);
            return renderError (super.getProperty ("oper_fail"));
        }
        //获取当前登录用户
        User curUser = getCurrentUser ();
        //获取操作描述 key = 类名+"_"+方法名 
        String funDesc = LogRenderUtils.getLogReqMap ("UserController_add");
        try
        {
            //分析删除对象的的关键内容
            String operDetail = userService.analyseAddContent (userVo);
            if (StringUtils.isNotBlank (operDetail))
            {
                //插入日志
                logService.insertSysLog (curUser, ConstantCode.STRING_02, getRemoteAddr (), funDesc, operDetail, null, null);
            }
        }
        catch (Exception ex)
        {
            logger.error (funDesc + "  bussness log insert error", ex);
        }
        
        return renderSuccess (super.getProperty ("oper_success"));
    }
    
    /**
     * 编辑用户
     *
     * @param userVo
     * @return
     */
    @RequestMapping ("/edit")
    @ResponseBody
    public Object edit (@RequestBody UserVo userVo, HttpServletRequest request)
    {
        if (StringUtils.isNotBlank (userVo.getPassword ()))
        {
            String chkStr = PasswordCheckUtils.checkPassword (userVo.getLoginname (), userVo.getPassword ());
            if (StringUtils.isNoneBlank (chkStr))
            {
                return renderError (chkStr);
            }
            try
            {
                String pwd = AesKeyUtils.encrypt (userVo.getPassword (), PropertiesReader.getUserPwdKey ());
                userVo.setPassword (pwd);
            }
            catch (IOException e)
            {
                logger.error (super.getProperty ("enPassword_fail") + "：{}", e);
                return renderError (super.getProperty ("enPassword_fail"));
            }
        }
        UserVo oldUserVo = userService.findUserVoById (userVo.getId ());
        try
        {
            userService.updateUser (userVo, getCurrentUser (), ServiceUtils.getLikeClientIp (request), securityLoger);
        }
        catch (Exception e)
        {
            logger.error ("updateUser error:", e);
            return renderError (super.getProperty ("oper_fail"));
        }
        
        //获取当前登录用户
        User curUser = getCurrentUser ();
        //获取操作描述 key = 类名+"_"+方法名 
        String funDesc = LogRenderUtils.getLogReqMap ("UserController_edit");
        try
        {
            //分析删除对象的的关键内容
            String operDetail = userService.analyseEditContent (oldUserVo, userVo);
            if (StringUtils.isNotBlank (operDetail))
            {
                //插入日志
                logService.insertSysLog (curUser, ConstantCode.STRING_02, getRemoteAddr (), funDesc, operDetail, null, null);
            }
        }
        catch (Exception ex)
        {
            logger.error (funDesc + "  bussness log insert error", ex);
        }
        return renderSuccess (super.getProperty ("edit_success"));
    }
    
    /**
     * 修改密码页
     *
     * @return
     */
    @RequestMapping (value = "/editPwdPage", method = RequestMethod.GET)
    public String editPwdPage ()
    {
        return "service/user/userEditPwd";
    }
    
    @RequestMapping ("/getUserName")
    @ResponseBody
    public Object getUserName ()
    {
        return renderSuccess (getCurrentUser ().getName ());
    }
    
    /**
     * 修改密码
     *
     * @param oldPwd
     * @param pwd
     * @return
     */
    @RequestMapping ("/editUserPwd")
    @ResponseBody
    public Object editUserPwd (@RequestBody UserPassword userPassword, HttpServletRequest request)
    {
        String oldPwd = userPassword.getOldPwd ();
        String pwd = userPassword.getNewPwd ();
        User curUser = getCurrentUser ();
        String checkPwdError = ConfigHolder.getCfg (CheckPwdInput.CHECK_ERROR);
        String pwdInput = CheckPwdInput.checkPwdInput (curUser.getLoginname ());
        if ("true".equals (checkPwdError))
        {
            if (StringUtils.isNotBlank (pwdInput) && !CheckPwdInput.EXIST_INPUT_FALG.equals (pwdInput))
            {
                return renderError (pwdInput);
            }
        }
        String tempStr = "";
        String newStr = "";
        try
        {
            tempStr = AesKeyUtils.encrypt (oldPwd, PropertiesReader.getUserPwdKey ());
            newStr = AesKeyUtils.encrypt (pwd, PropertiesReader.getUserPwdKey ());
        }
        catch (IOException e)
        {
            logger.error (super.getProperty ("enPassword_fail") + "：{}", e);
            return renderError (super.getProperty ("enPassword_fail"));
        }
        
        if (!curUser.getPassword ().equals (tempStr))
        {
            CheckPwdInput.addPwdErrorTimes (curUser.getLoginname ());
            return renderError (super.getProperty ("old_password_error"));
        }
        else
        {
            if ("true".equals (checkPwdError))
            {
                if (CheckPwdInput.EXIST_INPUT_FALG.equals (pwdInput))
                {
                    UserPwdInputCache.removeCache (curUser.getLoginname ());
                }
            }
        }
        if (pwd.equals (oldPwd))
        {
            return renderError (super.getProperty ("new_password_error"));
        }
        String chkStr = PasswordCheckUtils.checkPassword (curUser.getLoginname (), pwd);
        if (StringUtils.isNoneBlank (chkStr))
        {
            return renderError (chkStr);
        }
        /*if (userService.checkLastSamePwd (curUser.getId (), newStr))
        {
            return renderError (super.getProperty ("new_password_last_same"));
        }*/
        userService.updateUserPwdById (curUser.getId (), newStr, curUser.getPassword ());
        curUser.setPwdFirstUpdate ("1");
        getSession ().setAttribute (CommonConstant.CURRENT_LOGIN_USER, curUser);
        String className = this.getClass ().getSimpleName ();
        SecurityLogUtils.loggerLog (className, curUser, ServiceUtils.getLikeClientIp (request),
            SecurityLogUtils.EVENT_EDIT_PASSWOD, "password", " ** -> ## ", "", securityLoger);
        return renderSuccess (super.getProperty ("update_password_success"));
    }
    
    /**
     * 选择用户页
     *
     * @return
     */
    @RequestMapping ("/choseUser")
    public String choseUser ()
    {
        return "service/user/userChose";
    }
    
    /**
     * 删除用户
     *
     * @param id
     * @return
     */
    @RequestMapping ("/delete")
    @ResponseBody
    public Object delete (@RequestBody UserVo userVo, HttpServletRequest request)
    {
        String id = userVo.getId ();
        User curUser = this.getCurrentUser ();
        if (curUser != null && curUser.getId () != null && curUser.getId ().equals (id))
        {
            return renderError (super.getProperty ("system_user_del_tip"));
        }
        UserVo user = userService.findUserVoById (id);
        userService.deleteUserById (id);
        
        String funDesc = LogRenderUtils.getLogReqMap ("UserController_delete");
        try
        {
            //分析删除对象的的关键内容
            String operDetail = userService.analyseDelContent (user);
            if (StringUtils.isNotBlank (operDetail))
            {
                //插入日志
                logService.insertSysLog (curUser, ConstantCode.STRING_02, getRemoteAddr (), funDesc, operDetail, null, null);
            }
        }
        catch (Exception ex)
        {
            logger.error (funDesc + "  bussness log insert error", ex);
        }
        
        String userStr = user == null ? id : user.toString ();
        String className = this.getClass ().getSimpleName ();
        SecurityLogUtils.loggerLog (className, getCurrentUser (), ServiceUtils.getLikeClientIp (request),
            SecurityLogUtils.EVENT_DEL_USER, userStr, SecurityLogUtils.OPER_SUCCESS, id, securityLoger);
        return renderSuccess (super.getProperty ("delete_dept_success"));
    }
    
    /**
     * 编辑用户页
     *
     * @param id
     * @param model
     * @return
     */
    @RequestMapping ("/editPage")
    public String editPage (HttpServletRequest request)
    {
        return "service/user/userEdit";
    }
    
    @RequestMapping ("/getTreeListByUserId")
    @ResponseBody
    public Object getTreeListByUserId (HttpServletRequest request, HttpServletResponse response)
    {
        String id = request.getParameter ("id");
        List <Object> list = new ArrayList <Object> ();
        Map <String, Object> result = new HashMap <String, Object> ();
        
        List <DataSourceBean> allDataSource = dataSourceService.getAllDataSource ();
        
        List <String> cubeIdList = userService.findCubeIdByUserId (id);
        List <String> dataSourceIdList = userService.findDataSourceIdByUserId (id);
        
        for (DataSourceBean data : allDataSource)
        {
            List <CubeBean> cubeList = cubeService.getCubeByDsId (data.getId ());
            for (CubeBean cb : cubeList)
            {
                cb.setPid (cb.getId ());
                cb.setId (cb.getCubeId ());
                if (cubeIdList.contains (cb.getId ()))
                {
                    cb.setChecked (true);
                }
            }
            if (dataSourceIdList.contains (data.getId ()))
            {
                data.setChecked (true);
            }
            list.addAll (cubeList);
        }
        list.addAll (allDataSource);
        result.put ("list", list);
        
        List <Template> tmplist = templateManagementService.findAll ();
        List <String> tmpIdList = userService.findTmpIdByUserId (id);
        
        List <Template> tmpList = new ArrayList <Template> ();
        List <Template> selectTmpList = new ArrayList <Template> ();
        for (Template tmp : tmplist)
        {
            if (tmpIdList.contains (tmp.getTmpid ()))
            {
                selectTmpList.add (tmp);
            }
            else
            {
                tmpList.add (tmp);
            }
        }
        result.put ("tmpList", tmpList);
        result.put ("selectTmpList", selectTmpList);
        
        List <ObjectTreeNode> objlist = objectTreeService.findAll ();
        List <String> objIdlist = userService.findObjIdByUserId (id);
        for (ObjectTreeNode obj : objlist)
        {
            if (objIdlist.contains (obj.getTreeId ()))
            {
                obj.setChecked (true);
            }
        }
        result.put ("objlist", objlist);
        
        return renderSuccess (result);
    }
    
    @RequestMapping ("/saveTree")
    @ResponseBody
    public Object saveTree (HttpServletRequest request, HttpServletResponse response, @RequestBody UserGrant userGrant)
    {
        
        userService.updateUserCubeDataSource (userGrant);
        
        return renderSuccess ("success");
    }
    
}
