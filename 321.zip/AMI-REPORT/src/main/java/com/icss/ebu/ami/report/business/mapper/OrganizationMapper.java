package com.icss.ebu.ami.report.business.mapper;

import java.util.List;
import java.util.Map;

import com.icss.ebu.ami.commons.aspect.Param;
import com.icss.ebu.ami.commons.aspect.RedisCache;
import com.icss.ebu.ami.commons.bean.vo.Organization;
import com.icss.ebu.ami.commons.pagePlugin.Page;
import com.icss.ebu.ami.report.business.result.OrgTree;
import com.icss.ebu.ami.report.system.model.OrgMapRelation;

/**
  * @ClassName: OrganizationMapper
  * @Description:
  * @author Comsys-Administrator
  * @date 2017年6月10日 下午3:54:52
  *
  */
public interface OrganizationMapper
{
    /**
     * 删除部门
     *
     * @param id
     * @return
     */
    int deleteOrganizationById (String id);
    
    /**
     * 添加部门
     *
     * @param organization
     * @return
     */
    int insert (Organization organization);
    
    /**
     * 更新部门
     *
     * @param organization
     * @return
     */
    int updateOrganization (Organization organization);
    
    /**
     * 子部门个数
     *
     * @param id
     * @return
     */
    // @RedisCache(key="'querySubOrgCountOfPid_'+#id",expire =
    // -1,fieldKey="organization",nameSpace="portal")
    int querySubOrgCountOfPid (@Param ("id") String id);
    
    /**
     * 根据id查询部门
     *
     * @param id
     * @return
     */
    // @RedisCache(key="'findOrganizationById_'+#id",expire =
    // -1,fieldKey="organization",nameSpace="portal")
    Organization findOrganizationById (@Param ("id") String id);
    
    /**
     * 根据供电单位获取部门
     *
     * @param organization
     * @return
     */
    @RedisCache (key = "'findOrganizationByOrgNoAndType_'+#organization.orgNo+'_'+#organization.type", expire = -1, fieldKey = "ORGANIZATION", nameSpace = "MDM_TREE")
    List <Organization> findOrganizationByOrgNoAndType (@Param ("organization") Organization organization);
    
    /**
     * 根据供电单位查电网对象
     *
     * @param orgNo
     * @return
     */
    int countSubsByOrgNo (String orgNo);
    
    int countMtranByOrgNo (String orgNo);
    
    int countMlineByOrgNo (String orgNo);
    
    int countLineByOrgNo (String orgNo);
    
    int countTgByOrgNo (String orgNo);
    
    /**
     * 根据供电单位查资产设备
     *
     * @param orgNo
     * @return
     */
    int countMeterByOrgNo (String orgNo);
    
    int countItByOrgNo (String orgNo);
    
    int countEquipByOrgNo (String orgNo);
    
    int countSealByOrgNo (String orgNo);
    
    int countConsNumberByOrgNo (String orgNo);
    
    /**
     * 查询一级供电单位最大ID
     * 
     * @return 供电单位ID
     */
    String queryRootOrgMaxID ();
    
    /**
     * 查询子供电单位最大编号
     * 
     * @return
     */
    String querySubOrgMaxIdOfPidAndType (Organization org);
    
    /**
     * 查询供电单位
     * 
     */
    List <Organization> queryOrgTreeGrid (Organization organization);
    
    /**
     * 查询部门
     * 
     */
    List <Organization> queryDeptTreeGrid (Organization organization);
    
    /**
     * 根据pid查询子供电单位
     *
     *
     */
    List <Organization> findOrganizationAllByPid (Organization organization);
    
    /**
     * 根据pid查询子供电单位
     *
     *
     */
    List <Organization> treeOrgChoose (Organization organization);
    
    /**
     * 查询一级供电单位并且只按照id排序
     * 
     */
    List <Organization> findRootOrgOrderById (Organization organization);
    
    /**
     * 根据pid查询子供电单位并且只按照id排序
     *
     *
     */
    List <Organization> findSubOrgOrderById (Organization organization);
    
    /**
     * 根据id组查询供电单位
     */
    List <Organization> findOrganizationByIds (String ids);
    
    /**
     * 查询供电单位
     */
    List <Organization> findOrganization (Organization organization);
    
    /**
     * 根据供电单位获取部门 只查当前供电单位和底下部门
     *
     * @param organization
     * @return
     */
    // @RedisCache(key="'findOrganizationByOrgNoAndType_'+#organization.orgNo+'_'+#organization.type",expire
    // = -1,fieldKey="organization",nameSpace="portal")
    List <Organization> findOnlyOrganizationByOrgNoAndType (@Param ("organization") Organization organization);
    
    /**
     * 根据变电站ID查询供电单位
     * 
     * @param id
     * @return
     */
    Organization findOrganizationBySubId (String id);
    
    Map <String, Object> findParentOrgById (Map <String, Object> map);
    
    /**   
      * @Title: findDeptAndOrg   
      * @Description: 查询登录用户供电单位和部门的信息
      * @param organization
      * @return Object     
      * @throws  
      */
    List <Organization> findDeptAndOrg (Organization organization);
    
    List <Organization> treeOrgAndDeptAll ();
    
    List <Organization> findDeptsByPage (Page <Organization> page);
    
    List <Organization> findOrganizationByName (String name);
    
    /**
     * 新增修改供电单位时，处理对应map
     * @param orgMapRelation
     */
    void insertOrUpdateOrgMap (OrgMapRelation orgMapRelation);
    
    /**
     * 删除供电单位时删除该关联关系
     * @param orgMapRelation
     */
    void deleteOrgMap (String orgNo);
    
    /**
     *    根据ID查询地图名称
     */
    Organization findMapOrganizationById (String id);
    
    void updateMapEnable (OrgMapRelation orgMapRelation);
    
    List <Organization> findDeptTreeByChild (String id);
    
    List <OrgTree> findNode (Map <String, Object> map);
}