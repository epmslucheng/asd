package com.icss.ebu.ami.report.business.model;

import java.io.Serializable;
import java.util.List;

/**
 * 对象树节点实体类
 * @author 徐楠
 *
 */
public class ObjectTreeNode implements Serializable
{
    
    /**
     * 
     */
    private static final long serialVersionUID = 3410246390964599467L;
    
    private String treeId;
    
    private String treeName;
    
    private String treePid;
    
    private String treeCode;
    
    private Integer level;
    
    private String objectTreeId;
    
    private List <ObjectTreeNode> children;
    
    private boolean checked = false;
    
    private boolean disabled = false;
    
    private Integer isAuth;
    
    public boolean isChecked ()
    {
        return checked;
    }
    
    public void setChecked (boolean checked)
    {
        this.checked = checked;
    }
    
    public String getTreeId ()
    {
        return treeId;
    }
    
    public void setTreeId (String treeId)
    {
        this.treeId = treeId;
    }
    
    public String getTreeName ()
    {
        return treeName;
    }
    
    public void setTreeName (String treeName)
    {
        this.treeName = treeName;
    }
    
    public String getTreePid ()
    {
        return treePid;
    }
    
    public void setTreePid (String treePid)
    {
        this.treePid = treePid;
    }
    
    public String getTreeCode ()
    {
        return treeCode;
    }
    
    public void setTreeCode (String treeCode)
    {
        this.treeCode = treeCode;
    }
    
    public Integer getLevel ()
    {
        return level;
    }
    
    public void setLevel (Integer level)
    {
        this.level = level;
    }
    
    public String getObjectTreeId ()
    {
        return objectTreeId;
    }
    
    public void setObjectTreeId (String objectTreeId)
    {
        this.objectTreeId = objectTreeId;
    }
    
    public List <ObjectTreeNode> getChildren ()
    {
        return children;
    }
    
    public void setChildren (List <ObjectTreeNode> children)
    {
        this.children = children;
    }
    
    public boolean isDisabled ()
    {
        return disabled;
    }
    
    public void setDisabled (boolean disabled)
    {
        this.disabled = disabled;
    }
    
    public Integer getIsAuth ()
    {
        return isAuth;
    }
    
    public void setIsAuth (Integer isAuth)
    {
        this.isAuth = isAuth;
    }
    
}
