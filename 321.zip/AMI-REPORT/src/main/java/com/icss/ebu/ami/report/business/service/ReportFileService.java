package com.icss.ebu.ami.report.business.service;

import com.icss.ebu.ami.commons.pagePlugin.Page;
import com.icss.ebu.ami.report.business.model.ReportFile;
import com.icss.ebu.ami.report.business.model.ReportHtml;

import java.util.List;

public interface ReportFileService
{
    /**
     * 查询报表列表
     * 
     * @param page
     * @return page <ReportFile>
     */
    Page <ReportFile> queryReportFileByPage (Page <ReportFile> page);
    
    /**
     * 查询报表
     *
     * @param id
     * @return ReportFile
     */
    ReportFile queryReportFileById (String id);
    
    /**
     * 新增报表信息
     *
     * @param reportFile
     * @return int
     */
    int addReportFile (ReportFile reportFile);
    
    /**
     * 修改报表信息
     *
     * @param reportFile
     * @return int
     */
    int editReportFile (ReportFile reportFile);
    
    /**
     * 删除报表信息
     *
     * @param id
     * @return int
     */
    int delReportFileById (String id);
    
    /**
     * 新增报表页面信息
     *
     * @param htmls
     * @return int
     */
    int addReportHtml (List <ReportHtml> htmls);
    
    /**
     * 查询报表页面列表
     *
     * @param page
     * @return List <ReportHtml>
     */
    Page <ReportHtml> queryHtmlsByPage (Page <ReportHtml> page);
    
    /**
     * 查询报表页面信息
     *
     * @param id
     * @return List <ReportHtml>
     */
    List <ReportHtml> queryHtmlsByReportId (String id);
    
    /**
     * 修改报表页面信息
     *
     * @param reportHtml
     * @return int
     */
    int editReportHtml (ReportHtml reportHtml);
    
    /**
     * 删除报表页面信息
     *
     * @param id
     * @return List <ReportHtml>
     */
    int deleteReportHtmlsById (String id);
    
    int deleteReportFileTreeByReportId (String reportId);
    
    /**
     * 查询某个时间之前的报表
     * @param r
     * @return
     */
    List <ReportFile> queryReportFile (ReportFile r);
    
    List <ReportFile> queryReportFileByDesc (String desc);
    
    int deleteReport (ReportFile reportFile);
}
