package com.icss.ebu.ami.report.system.model;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public class SysLog implements Serializable
{
    
    private static final long serialVersionUID = -8690056878905494181L;
    
    private Long id;
    
    private String userId;
    
    private String loginName;
    
    private String roleName;
    
    private String optContent;
    
    private String params;
    
    private String clientIp;
    
    @JsonFormat (pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date createTime;
    
    private String logType;
    
    private String optDetail;
    
    private String sessionId;
    
    public Long getId()
    {
        return id;
    }
    
    public void setId(Long id)
    {
        this.id = id;
    }
    
    public String getLoginName()
    {
        return loginName;
    }
    
    public void setLoginName(String loginName)
    {
        this.loginName = loginName == null ? null : loginName.trim ();
    }
    
    public String getRoleName()
    {
        return roleName;
    }
    
    public void setRoleName(String roleName)
    {
        this.roleName = roleName == null ? null : roleName.trim ();
    }
    
    public String getOptContent()
    {
        return optContent;
    }
    
    public void setOptContent(String optContent)
    {
        this.optContent = optContent == null ? null : optContent.trim ();
    }
    
    public String getClientIp()
    {
        return clientIp;
    }
    
    public void setClientIp(String clientIp)
    {
        this.clientIp = clientIp == null ? null : clientIp.trim ();
    }
    
    public Date getCreateTime()
    {
        if (createTime == null)
        {
            return null;
        }
        return (Date) createTime.clone ();
    }
    
    public void setCreateTime(Date createTime)
    {
        if (createTime == null)
        {
            this.createTime = null;
        }
        else
        {
            this.createTime = (Date) createTime.clone ();
        }
    }
    
    public String getUserId()
    {
        return userId;
    }
    
    public void setUserId(String userId)
    {
        this.userId = userId;
    }
    
    public String getParams()
    {
        return params;
    }
    
    public void setParams(String params)
    {
        this.params = params;
    }
    
    public String getLogType()
    {
        return logType;
    }
    
    public void setLogType(String logType)
    {
        this.logType = logType;
    }
    
    public String getOptDetail()
    {
        return optDetail;
    }
    
    public void setOptDetail(String optDetail)
    {
        this.optDetail = optDetail;
    }
    
    public String getSessionId()
    {
        return sessionId;
    }
    
    public void setSessionId(String sessionId)
    {
        this.sessionId = sessionId;
    }
    
    @Override
    public String toString()
    {
        return "SysLog{id=" + id + ", userId=\"" + userId + "\", loginName=\"" + loginName + "\", roleName=\"" + roleName
            + "\", optContent=\"" + optContent + "\", params=\"" + params + "\", logType=\"" + logType + "\", optDetail=\""
            + optDetail + "\", createTime=" + createTime + ", sessionId=" + sessionId + ", clientIp=" + clientIp + "}";
    }
}