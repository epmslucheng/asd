package com.icss.ebu.ami.report.business.service.impl;

import java.io.File;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.icss.ebu.ami.commons.pagePlugin.Page;
import com.icss.ebu.ami.report.business.common.util.FtpUtils;
import com.icss.ebu.ami.report.business.mapper.ReportFileMapper;
import com.icss.ebu.ami.report.business.model.ReportFile;
import com.icss.ebu.ami.report.business.model.ReportHtml;
import com.icss.ebu.ami.report.business.service.ReportFileService;

@Service
public class ReportFileServiceImpl implements ReportFileService
{
    private static Logger LOGGER = LoggerFactory.getLogger (ReportFileServiceImpl.class);
    
    @Autowired
    private ReportFileMapper reportFileMapper;
    
    @Override
    public Page <ReportFile> queryReportFileByPage (Page <ReportFile> page)
    {
        page.setResults (reportFileMapper.queryReportFileByPage (page));
        return page;
    }
    
    @Override
    public ReportFile queryReportFileById (String id)
    {
        return reportFileMapper.queryReportFileById (id);
    }
    
    @Override
    public int addReportFile (ReportFile reportFile)
    {
        int result = 0;
        try
        {
            
            result = reportFileMapper.addReportFile (reportFile);
            
        }
        catch (Exception e)
        {
            LOGGER.error ("add report file error.", e);
        }
        
        return result;
    }
    
    @Override
    public int editReportFile (ReportFile reportFile)
    {
        return reportFileMapper.editReportFile (reportFile);
    }
    
    @Override
    public int delReportFileById (String id)
    {
        return reportFileMapper.delReportFileById (id);
    }
    
    @Override
    public int addReportHtml (List <ReportHtml> htmls)
    {
        return reportFileMapper.addReportHtml (htmls);
    }
    
    @Override
    public Page <ReportHtml> queryHtmlsByPage (Page <ReportHtml> page)
    {
        
        List <ReportHtml> list = reportFileMapper.queryHtmlsByPage (page);
        for (ReportHtml reportHtml : list)
        {
            reportHtml
                .setDownPath (File.separator + "script" + File.separator + "file" + File.separator + reportHtml.getShowName ());
        }
        page.setResults (list);
        return page;
    }
    
    @Override
    public List <ReportHtml> queryHtmlsByReportId (String id)
    {
        return reportFileMapper.queryHtmlsByReportId (id);
    }
    
    @Override
    public int editReportHtml (ReportHtml reportHtml)
    {
        return reportFileMapper.editReportHtml (reportHtml);
    }
    
    @Override
    public int deleteReportHtmlsById (String id)
    {
        return reportFileMapper.deleteReportHtmlsById (id);
    }
    
    @Override
    public int deleteReportFileTreeByReportId (String reportId)
    {
        int result = 0;
        try
        {
            result = reportFileMapper.deleteReportFileTreeByReportId (reportId);
        }
        catch (Exception e)
        {
            LOGGER.error ("delete report file tree error.", e);
        }
        return result;
    }
    
    @Override
    public List <ReportFile> queryReportFile (ReportFile r)
    {
        return reportFileMapper.queryReportFile (r);
    }
    
    @Override
    public List <ReportFile> queryReportFileByDesc (String desc)
    {
        return reportFileMapper.queryReportFileByDesc (desc);
    }
    
    @Override
    public int deleteReport (ReportFile reportFile)
    {
        String reportId = reportFile.getReportId ();
        String pathname = reportFile.getReportPath ();
        String filename = reportFile.getReportName ();
        
        String preName = filename.substring (0, filename.lastIndexOf ("."));

        int flag = 0;
        try
        {
            flag = FtpUtils.deleteFile (pathname, filename) ? 1 : 2;

            List <ReportHtml> htmls = queryHtmlsByReportId (reportId);
            if (null != htmls && !htmls.isEmpty ())
            {
                try
                {
                    for (ReportHtml h : htmls)
                    {
                        String htmlName = preName + ";" + h.getSheetName () + ".html";
                        FtpUtils.deleteFile (pathname, htmlName);
                    }
                    deleteReportHtmlsById (reportId);
                }
                catch (Exception e)
                {
                    LOGGER.error ("reportFileService delete html error.", e);
                }
            }

            deleteReportFileTreeByReportId (reportId);
        }
        catch (Exception e)
        {
            LOGGER.error ("reportFileService delete file error.", e);
            return flag;
        }
        
        if (flag == 1)
        {
            try
            {
                flag = delReportFileById (reportId);
            }
            catch (Exception e)
            {
                flag = 0;
                LOGGER.error ("reportFileService deleteReport error.", e);
            }
        }
        return flag;
    }
}
