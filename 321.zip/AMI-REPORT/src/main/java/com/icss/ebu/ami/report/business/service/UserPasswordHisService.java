package com.icss.ebu.ami.report.business.service;

import java.util.List;

import com.icss.ebu.ami.report.system.model.UserPasswordHis;

public interface UserPasswordHisService
{
    
    int insert (String userId, String password);
    
    int deleteById (Long id);
    
    int deleteByUserId (String userId);
    
    List <UserPasswordHis> findUserPasswordByUserId (String userId);
    
}