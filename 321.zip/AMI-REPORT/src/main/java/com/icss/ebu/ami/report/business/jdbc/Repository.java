package com.icss.ebu.ami.report.business.jdbc;

public interface Repository
{
    
}
