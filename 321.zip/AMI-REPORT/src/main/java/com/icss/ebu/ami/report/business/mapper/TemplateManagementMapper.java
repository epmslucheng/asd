package com.icss.ebu.ami.report.business.mapper;

import java.util.List;

import com.icss.ebu.ami.commons.pagePlugin.Page;
import com.icss.ebu.ami.report.business.model.Template;
import com.icss.ebu.ami.report.system.model.User;

/** 
* @author  zhangkaining 
* @date 2017年10月23日 下午4:03:45 
* @version 1.0   
*/
public interface TemplateManagementMapper
{
    
    List <Template> queryTemplateListByPage (Page <Template> page);
    
    Template selectTemplateById (String tmpid);
    
    Template selectTemplateByName (String tmpname);
    
    int insert (Template template);
    
    List <Template> queryTemplateList (User user);
    
    int delete (String tmpid);
    
    void update (Template template);
    
    Template selectTemplateByFile (String tmpfile);
    
    List <Template> queryTempDesignListByPage (Page <Template> page);
    
    List <Template> findAll ();
    
    List <String> selectFileIdByTmpid (String tmpid);
    
    List <String> selectTaskIdByTmpid (String tmpid);
    
    Template selectTemplateByKey (String tmpkey);

    List <Template> queryListByVo (Template template);
}
