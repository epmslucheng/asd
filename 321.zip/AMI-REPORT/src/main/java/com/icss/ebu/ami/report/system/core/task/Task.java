package com.icss.ebu.ami.report.system.core.task;

import com.fasterxml.jackson.annotation.JsonFormat;

import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

/**
 * 任务定义主表
 * 
 * @author Administrator
 *
 */
@XmlRootElement
public class Task implements Serializable
{
    
    //任务重复方式-间隔时间
    public static final String REPEAT_MODE_SIMPLE = "0";
    
    //任务重复方式-CRON表达式
    public static final String REPEAT_MODE_CRON = "1";
    
    //任务有效
    public static final Integer TASK_ISVALID = 1;
    
    //任务状态:运行中
    public static final long STATUS_RUNNING = 1;
    
    //任务状态:暂停
    public static final long STATUS_PAUSE = 2;
    
    //任务类型-一级任务
    public static final String TASK_TYPE_ONE = "01";
    
    //任务类型-二级任务(含算费定时任务)
    public static final String TASK_TYPE_TWO = "02";
    
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    
    /**
     * 运行任务标识
     */
    private Long taskId;
    
    /**
     * 任务名称
     */
    private String name;
    
    /**
     * 任务 任务重复方式 分两种：0:间隔重复、1:定期重复 间隔重复模式就要设置重复间隔时间，已设定重复执行周期 定期重复模式，就要设置定期调度表达式
     */
    private String repeatMode;
    
    /**
     * 重复间隔,以秒为单位
     */
    @JsonFormat (pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Long repeatInterval;
    
    /**
     * 任务运行时间
     */
    @JsonFormat (pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Timestamp runTime;
    
    /**
     * 任务有效时间
     */
    @JsonFormat (pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date validTime;
    
    /**
     * 任务失效时间
     */
    @JsonFormat (pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date invalidTime;
    
    /**
     * 失败重试次数
     */
    private Integer retryTimes;
    
    /**
     * 失败重试间隔
     */
    @JsonFormat (pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date retryInterval;
    
    /**
     * 任务失败通知方式
     */
    private String failNoticeMode;
    
    /**
     * 失败通知人员
     */
    private String failReceiverNo;
    
    /**
     * 任务优先级 分为三级：1：一级；2:二级；3:三级
     */
    private Integer prio;
    
    /**
     * 任务状态通知方式
     */
    private String notifyMode;
    
    /**
     * 任务状态通知人员
     */
    private String notifyEmpNo;
    
    /**
     * 任务设置人员
     */
    private String setEmpNo;
    
    /**
     * 任务设置时间
     */
    @JsonFormat (pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date setTime;
    
    /**
     * 任务内容
     */
    private String content;
    
    /**
     * 任务状态:0:等待运行；1:运行中；2:暂停运行；3:已结束
     */
    private long status;
    
    /**
     * 任务调度表达式
     */
    private String cronExpre;
    
    /**
     * 任务有效标识:0：无效；1:有效 初始默认为有效
     */
    private Integer isValid = 1;
    
    /**
     * 任务处理对象
     */
    private String handler;
    
    /**
     * 任务中文别名
     */
    private String alias;
    
    /**
     * 重复次数
     */
    private Long repeatTimes;
    
    /**
     * 任务类型
     */
    private String taskType;
    
    /**
     * 任务编码
     */
    private String taskCode;
    
    public String getTaskCode ()
    {
        return taskCode;
    }
    
    public void setTaskCode (String taskCode)
    {
        this.taskCode = taskCode;
    }
    
    public String getAlias ()
    {
        return alias;
    }
    
    public void setAlias (String alias)
    {
        this.alias = alias;
    }
    
    public Long getRepeatTimes ()
    {
        return repeatTimes;
    }
    
    public void setRepeatTimes (Long repeatTimes)
    {
        this.repeatTimes = repeatTimes;
    }
    
    public String getHandler ()
    {
        return handler;
    }
    
    public void setHandler (String handler)
    {
        this.handler = handler;
    }
    
    public Long getTaskId ()
    {
        return taskId;
    }
    
    public void setTaskId (Long taskId)
    {
        this.taskId = taskId;
    }
    
    public String getName ()
    {
        return name;
    }
    
    public void setName (String name)
    {
        this.name = name;
    }
    
    /**
     * 任务重复方式 分两种：0:间隔重复、1:定期重复
     * 
     * @return
     */
    public String getRepeatMode ()
    {
        return repeatMode;
    }
    
    /**
     * 任务重复方式 分两种：0:间隔重复、1:定期重复
     */
    public void setRepeatMode (String repeatMode)
    {
        this.repeatMode = repeatMode;
    }
    
    public Long getRepeatInterval ()
    {
        return repeatInterval;
    }
    
    public void setRepeatInterval (Long repeatInterval)
    {
        this.repeatInterval = repeatInterval;
    }
    
    public Timestamp getRunTime ()
    {
        if (runTime == null)
        {
            return null;
        }
        return (Timestamp) runTime.clone ();
    }
    
    public void setRunTime (Timestamp runTime)
    {
        if (runTime == null)
        {
            this.runTime = null;
        }
        else
        {
            this.runTime = (Timestamp) runTime.clone ();
        }
    }
    
    public Date getValidTime ()
    {
        if (validTime == null)
        {
            return null;
        }
        return (Date) validTime.clone ();
    }
    
    public void setValidTime (Date validTime)
    {
        if (validTime == null)
        {
            this.validTime = null;
        }
        else
        {
            this.validTime = (Date) validTime.clone ();
        }
    }
    
    public Date getInvalidTime ()
    {
        if (invalidTime == null)
        {
            return null;
        }
        return (Date) invalidTime.clone ();
    }
    
    public void setInvalidTime (Date invalidTime)
    {
        if (invalidTime == null)
        {
            this.invalidTime = null;
        }
        else
        {
            this.invalidTime = (Date) invalidTime.clone ();
        }
    }
    
    public Integer getRetryTimes ()
    {
        return retryTimes;
    }
    
    public void setRetryTimes (Integer retryTimes)
    {
        this.retryTimes = retryTimes;
    }
    
    public Date getRetryInterval ()
    {
        if (retryInterval == null)
        {
            return null;
        }
        return (Date) retryInterval.clone ();
    }
    
    public void setRetryInterval (Date retryInterval)
    {
        if (retryInterval == null)
        {
            this.retryInterval = null;
        }
        else
        {
            this.retryInterval = (Date) retryInterval.clone ();
        }
    }
    
    public String getFailNoticeMode ()
    {
        return failNoticeMode;
    }
    
    public void setFailNoticeMode (String failNoticeMode)
    {
        this.failNoticeMode = failNoticeMode;
    }
    
    public String getFailReceiverNo ()
    {
        return failReceiverNo;
    }
    
    public void setFailReceiverNo (String failReceiverNo)
    {
        this.failReceiverNo = failReceiverNo;
    }
    
    public String getNotifyMode ()
    {
        return notifyMode;
    }
    
    public void setNotifyMode (String notifyMode)
    {
        this.notifyMode = notifyMode;
    }
    
    public String getNotifyEmpNo ()
    {
        return notifyEmpNo;
    }
    
    public void setNotifyEmpNo (String notifyEmpNo)
    {
        this.notifyEmpNo = notifyEmpNo;
    }
    
    public String getSetEmpNo ()
    {
        return setEmpNo;
    }
    
    public void setSetEmpNo (String setEmpNo)
    {
        this.setEmpNo = setEmpNo;
    }
    
    public Date getSetTime ()
    {
        if (setTime == null)
        {
            return null;
        }
        return (Date) setTime.clone ();
    }
    
    public void setSetTime (Date setTime)
    {
        if (setTime == null)
        {
            this.setTime = null;
        }
        else
        {
            this.setTime = (Date) setTime.clone ();
        }
    }
    
    public String getContent ()
    {
        return content;
    }
    
    public void setContent (String content)
    {
        this.content = content;
    }
    
    public Integer getPrio ()
    {
        return prio;
    }
    
    public void setPrio (Integer prio)
    {
        this.prio = prio;
    }
    
    public long getStatus ()
    {
        return status;
    }
    
    public void setStatus (long status)
    {
        this.status = status;
    }
    
    public String getCronExpre ()
    {
        return cronExpre;
    }
    
    public void setCronExpre (String cronExpre)
    {
        this.cronExpre = cronExpre;
    }
    
    public Integer getIsValid ()
    {
        return isValid;
    }
    
    public void setIsValid (Integer isValid)
    {
        this.isValid = isValid;
    }
    
    public String getTaskType ()
    {
        return taskType;
    }
    
    public void setTaskType (String taskType)
    {
        this.taskType = taskType;
    }
    
    public boolean compareEquals (Object obj)
    {
        boolean isFlag = true;
        if (obj instanceof Task)
        {
            Task task = (Task) obj;
            if (this.handler != null && !this.handler.equals (task.getHandler ()))
            {
                isFlag = false;
            }
            else if (this.handler == null && task.getHandler () != null)
            {
                isFlag = false;
            }
            else if (this.repeatInterval != null && !this.repeatInterval.equals (task.getRepeatInterval ()))
            {
                isFlag = false;
            }
            else if (this.repeatInterval == null && task.getRepeatInterval () != null)
            {
                isFlag = false;
            }
            else if (this.repeatMode != null && !this.repeatMode.equals (task.getRepeatMode ()))
            {
                isFlag = false;
            }
            else if (this.repeatMode == null && task.getRepeatMode () != null)
            {
                isFlag = false;
            }
            else if (this.status != task.getStatus ())
            {
                isFlag = false;
            }
            else if (this.validTime != null && task.getValidTime () != null
                && this.validTime.getTime () != task.getValidTime ().getTime ())
            {
                isFlag = false;
            }
            else if (this.invalidTime != null && task.getInvalidTime () != null
                && this.invalidTime.getTime () != task.getInvalidTime ().getTime ())
            {
                isFlag = false;
            }
            else if (this.cronExpre != null && !this.cronExpre.equals (task.getCronExpre ()))
            {
                isFlag = false;
            }
            else if (this.cronExpre == null && task.getCronExpre () != null)
            {
                isFlag = false;
            }
            else if (this.taskCode != null && !this.taskCode.equals (task.getTaskCode ()))
            {
                isFlag = false;
            }
            else if (this.name != null && !this.name.equals (task.getName ()))
            {
                isFlag = false;
            }
        }
        else
        {
            isFlag = false;
        }
        return isFlag;
    }
    
    public void copy (Task tmpTask)
    {
        taskType = tmpTask.getTaskType ();
        repeatMode = tmpTask.getRepeatMode ();
        repeatInterval = tmpTask.getRepeatInterval ();
        validTime = tmpTask.getValidTime ();
        invalidTime = tmpTask.getInvalidTime ();
        prio = tmpTask.getPrio ();
        cronExpre = tmpTask.getCronExpre ();
    }
    
}
