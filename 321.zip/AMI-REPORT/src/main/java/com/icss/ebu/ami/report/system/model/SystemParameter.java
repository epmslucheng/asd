package com.icss.ebu.ami.report.system.model;

import java.io.Serializable;

public class SystemParameter implements Serializable {
    private static final long serialVersionUID = 8495997693532264413L;

    /**
     * id
     */
    private String id;

    /**
     * 属性名
     */
    private String name;

    /**
     * 属性值
     */
    private String value;

    /**
     * 备注
     */
    private String remark;

    /**
     *  用于页面控制是否需要屏蔽真实数据
     *  0-否，1-是
     */
    private int isPassword;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public int getIsPassword() {
        return isPassword;
    }

    public void setIsPassword(int isPassword) {
        this.isPassword = isPassword;
    }
}
