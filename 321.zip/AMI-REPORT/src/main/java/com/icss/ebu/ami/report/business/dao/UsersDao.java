package com.icss.ebu.ami.report.business.dao;

import com.icss.ebu.ami.report.business.jdbc.Repository;
import com.icss.ebu.ami.report.system.model.User;

public interface UsersDao extends Repository
{
    User findUserById (String id);
}
