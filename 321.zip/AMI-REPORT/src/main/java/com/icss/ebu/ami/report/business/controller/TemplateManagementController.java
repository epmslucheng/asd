package com.icss.ebu.ami.report.business.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.icss.ebu.ami.report.business.model.*;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.poi.hssf.usermodel.HSSFName;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFName;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.alibaba.fastjson.JSONArray;
import com.icss.ebu.ami.commons.constants.ConstantCode;
import com.icss.ebu.ami.commons.pagePlugin.Page;
import com.icss.ebu.ami.commons.util.UUIDUtils;
import com.icss.ebu.ami.report.business.common.constant.CommonConstant;
import com.icss.ebu.ami.report.business.common.constant.ReportConstant;
import com.icss.ebu.ami.report.business.common.util.ConfigHolder;
import com.icss.ebu.ami.report.business.common.util.ExcelWrite;
import com.icss.ebu.ami.report.business.common.util.FileUtils;
import com.icss.ebu.ami.report.business.common.util.FtpUtils;
import com.icss.ebu.ami.report.business.common.util.LogRenderUtils;
import com.icss.ebu.ami.report.business.service.LogService;
import com.icss.ebu.ami.report.business.service.ReportDataPositionService;
import com.icss.ebu.ami.report.business.service.ReportDesignService;
import com.icss.ebu.ami.report.business.service.ReportFileService;
import com.icss.ebu.ami.report.business.service.TemplateManagementService;
import com.icss.ebu.ami.report.business.service.UserService;
import com.icss.ebu.ami.report.system.model.User;
import com.icss.ebu.ami.report.system.model.UserGrant;

/**
* @author  zhangkaining
* @date 2017年10月23日 上午11:00:16
* @version 1.0
*/
@Controller
public class TemplateManagementController extends BaseController
{
    
    @Autowired
    private TemplateManagementService templateManagementService;
    
    @Autowired
    private ReportDesignService reportDesignService;
    
    @Autowired
    private ReportDataPositionService reportDataPositionService;
    
    @Autowired
    private ReportFileService reportFileService;
    
    @Autowired
    private UserService userService;
    
    @Autowired
    protected LogService logService;
    
    /**
     * 模板管理页面
     * @return
     */
    @RequestMapping ("/templateManagement")
    public String messageTemplateManage ()
    {
        return "/service/template/templateManagement";
    }
    
    /**
    * 模板设计页面
    * @return
    */
    @RequestMapping ("/templateDesign")
    public String templateDesign ()
    {
        return "/service/template/templateDesign";
    }
    
    /**
     * html地址页面
     * @return
     */
    @RequestMapping ("/templateManagement/htmlList")
    public String htmlList (Model model, HttpServletRequest request, HttpServletResponse response)
    {
        return "/service/template/htmlList";
    }
    
    @RequestMapping ("/templateManagement/query")
    @ResponseBody
    public Object query (HttpServletRequest request)
    {
        String pageNo = request.getParameter (CommonConstant.PAGE_PARAM_PAGE);
        String rows = request.getParameter (CommonConstant.PAGE_PARAM_ROWS);
        Map <String, Object> map = new HashMap <String, Object> ();
        User currentUser = getCurrentUser ();
        /*if (StringUtils.isEmpty (pageNo) || StringUtils.isEmpty (rows))
        {
            List <Template> list = templateManagementService.queryTemplateList (currentUser);
            map.put (CommonConstant.PAGE_RESULT_ROWS, list);
            return map;
        }*/
        
        Template template = new Template ();
        if (!ReportConstant.REPORT_USERID_ROOT.equals (currentUser.getId ()))
        {
            template.setUserId (currentUser.getId ());
        }
        Page <Template> page = new Page <Template> (template);
        page.setPageNo (NumberUtils.toInt (pageNo));
        page.setPageSize (NumberUtils.toInt (rows));
        page = templateManagementService.queryTemplateList (page);
        
        map.put (CommonConstant.PAGE_RESULT_ROWS, page.getResults ());
        map.put (CommonConstant.PAGE_RESULT_TOTAL, page.getTotalRecord ());
        return map;
        
    }

    /**
    * 模板管理->模板管理页面-新增/修改
    * @param request 请求
    * @param response 响应
    * @return 模板管理页面-新增/修改
    */
    @RequestMapping (value = "/templateModel")
    public String templateModel (Model model, HttpServletRequest request, HttpServletResponse response)
    {
        String tmpid = request.getParameter ("tmpid");
        if (StringUtils.isNotEmpty (tmpid))
        {
            model.addAttribute ("template", templateManagementService.selectTemplateById (tmpid));
        }
        return "service/template/templateModel";
    }
    
    @RequestMapping ("/templateManagement/uploadFile")
    public @ResponseBody Object uploadFile (HttpServletRequest request, HttpServletResponse response)
    {
        
        Map <String, Object> map = new HashMap <String, Object> ();
        
        Template template = null;
        String pathname = ConfigHolder.getCfg (ReportConstant.FTP_CATALOG) + "/template";
        
        //属性
        String tmpid = request.getParameter ("tmpid");
        String tmpname = request.getParameter ("tmpname");
        String tmpkey = request.getParameter ("tmpkey");
        String tmpdesc = request.getParameter ("tmpdesc");
        String reporttype = request.getParameter ("reporttype");
        
        //定义必要元素
        String fileName = null;
        InputStream in = null;
        FileOutputStream os = null;
        String path = "";
        
        MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
        //1.得到上传的文件
        MultipartFile file = multipartRequest.getFile ("excelFile");
        if (StringUtils.isEmpty (tmpid))
        {
            if (file.isEmpty ())
            {
                map.put ("success", false);
                map.put ("error", super.getProperty ("No_file"));
                return map;
            }
            
            fileName = file.getOriginalFilename ();
            path = request.getSession ().getServletContext ().getRealPath ("/") + "script" + File.separator + "file"
                + File.separator + fileName;
            template = templateManagementService.selectTemplateByName (tmpname);
            if (template != null)
            {
                map.put ("error", super.getProperty ("Template_OtherName_Repeat"));
                map.put ("success", false);
                return map;
            }
            template = templateManagementService.selectTemplateByFile (fileName);
            if (template != null)
            {
                map.put ("error", super.getProperty ("Template_Name_Repeat"));
                map.put ("success", false);
                return map;
            }
            
            template = templateManagementService.selectTemplateByKey (tmpkey);
            
            if (template != null)
            {
                map.put ("error", super.getProperty ("Template_Key_Repeat"));
                map.put ("success", false);
                return map;
            }
            
            template = new Template ();
            template.setTmpid (UUIDUtils.generate16Str ());
            template.setTmpname (tmpname);
            template.setTmpfile (pathname);
            template.setTmpkey (tmpkey);
            template.setTmpdesc (tmpdesc);
            template.setReporttype (reporttype);
            template.setTmpfilename (fileName);
            
            try
            {
                if (fileName.substring (fileName.lastIndexOf (".")).equals (".xls"))
                {
                    writerToXLS (file, template, path);
                }
                else
                {
                    writerToXLSX (file, template, path);
                }
                
                File lfile = new File (path);
                
                boolean b = FtpUtils.uploadFile (pathname, fileName, new FileInputStream (lfile));
                if (!b)
                {
                    map.put ("error", super.getProperty ("ftp_delete_message"));
                    map.put ("success", false);
                    return map;
                }
                
                List <String> pathList = ExcelWrite.excelToHtml (path);
                
                File lsfile = null;
                ReportHtml reportHtml = new ReportHtml ();
                List <ReportHtml> htmls = new ArrayList <ReportHtml> ();
                for (String hpath : pathList)
                {
                    lsfile = new File (hpath);
                    reportHtml = new ReportHtml ();
                    reportHtml.setId (template.getTmpid ());
                    reportHtml.setHtmlType ("0");
                    reportHtml.setHtmlName (lsfile.getName ());
                    reportHtml.setHtmlPath (pathname);
                    String sheetName = "";
                    if (StringUtils.isNotBlank (lsfile.getName ()))
                    {
                        sheetName = lsfile.getName ().substring (lsfile.getName ().lastIndexOf (";") + 1,
                            lsfile.getName ().lastIndexOf ("."));
                    }
                    reportHtml.setSheetName (sheetName);
                    htmls.add (reportHtml);
                    ExcelWrite.uploadFileToFtp (hpath, pathname);
                    // 4.上传成功，删除临时文件
                    ExcelWrite.deleteExcel (hpath);
                }
                
                reportFileService.addReportHtml (htmls);
                
                if (lfile.exists ())
                {
                    lfile.delete ();
                }
            }
            catch (IOException e)
            {
                e.printStackTrace ();
                map.put ("error", super.getProperty ("Save_Exception"));
                map.put ("success", false);
                return map;
            }
            finally
            {
                IOUtils.closeQuietly (in);
                IOUtils.closeQuietly (os);
            }
            
            templateManagementService.insert (template);
            map.put ("template", template);
            User user = getCurrentUser ();
            if (!ReportConstant.REPORT_USERID_ROOT.equals (user.getId ()))
            {
                UserGrant userGrant = new UserGrant ();
                userGrant.setUserid (user.getId ());
                userGrant.setTmpid (template.getTmpid ());
                userService.insertUserGrant (userGrant);
            }
            //获取当前登录用户
            User curUser = getCurrentUser ();
            //获取操作描述 key = 类名+"_"+方法名 
            String funDesc = LogRenderUtils.getLogReqMap ("TemplateManagementController_add");
            try
            {
                //分析删除对象的的关键内容
                String operDetail = templateManagementService.analyseAddContent (template);
                if (StringUtils.isNotBlank (operDetail))
                {
                    //插入日志
                    logService.insertSysLog (curUser, ConstantCode.STRING_02, getRemoteAddr (), funDesc, operDetail, null, null);
                }
            }
            catch (Exception ex)
            {
                logger.error (funDesc + "  bussness log insert error", ex);
            }
            
        }
        else
        {
            Template oldtemplate = templateManagementService.selectTemplateById (tmpid);
            if (!file.isEmpty ())
            {
                path = oldtemplate.getTmpfile ();
                fileName = file.getOriginalFilename ();
                boolean b = FtpUtils.deleteFile (pathname, fileName);
                
                if (!b)
                {
                    map.put ("error", super.getProperty ("ftp_delete_message"));
                    map.put ("success", false);
                    return map;
                }
                
                List <ReportHtml> dlist = reportFileService.queryHtmlsByReportId (tmpid);
                
                FtpUtils.deleteFile (oldtemplate.getTmpfile (), oldtemplate.getTmpfilename ());
                for (ReportHtml r : dlist)
                {
                    FtpUtils.deleteFile (r.getHtmlPath (), r.getHtmlName ());
                }
                
                reportDataPositionService.deleteByTmpId (tmpid);
                reportDesignService.delete (tmpid);
                reportFileService.deleteReportHtmlsById (tmpid);
                
                path = request.getSession ().getServletContext ().getRealPath ("/") + "script" + File.separator + "file"
                    + File.separator + fileName;
                template = templateManagementService.selectTemplateByName (tmpname);
                if (!oldtemplate.getTmpname ().equals (tmpname))
                {
                    if (template != null)
                    {
                        map.put ("error", super.getProperty ("Template_OtherName_Repeat"));
                        map.put ("success", false);
                        return map;
                    }
                }
                template = templateManagementService.selectTemplateByKey (tmpkey);
                if (!oldtemplate.getTmpkey ().equals (tmpkey))
                {
                    if (template != null)
                    {
                        map.put ("error", super.getProperty ("Template_Key_Repeat"));
                        map.put ("success", false);
                        return map;
                    }
                }
                
                template = new Template ();
                template.setTmpfile (pathname);
                template.setTmpfilename (fileName);
                if (fileName.substring (fileName.lastIndexOf (".")).equals (".xls"))
                {
                    writerToXLS (file, oldtemplate, path);
                }
                else
                {
                    writerToXLSX (file, oldtemplate, path);
                }
                try
                {
                    
                    File lfile = new File (path);
                    
                    FtpUtils.uploadFile (pathname, fileName, new FileInputStream (lfile));
                    
                    List <String> pathList = ExcelWrite.excelToHtml (path);
                    
                    File lsfile = null;
                    ReportHtml reportHtml = new ReportHtml ();
                    List <ReportHtml> htmls = new ArrayList <ReportHtml> ();
                    for (String hpath : pathList)
                    {
                        lsfile = new File (hpath);
                        reportHtml = new ReportHtml ();
                        reportHtml.setId (oldtemplate.getTmpid ());
                        reportHtml.setHtmlType ("0");
                        reportHtml.setHtmlName (lsfile.getName ());
                        reportHtml.setHtmlPath (pathname);
                        String sheetName = "";
                        if (StringUtils.isNotBlank (lsfile.getName ()))
                        {
                            sheetName = lsfile.getName ().substring (lsfile.getName ().lastIndexOf (";") + 1,
                                lsfile.getName ().lastIndexOf ("."));
                        }
                        reportHtml.setSheetName (sheetName);
                        htmls.add (reportHtml);
                        ExcelWrite.uploadFileToFtp (hpath, pathname);
                        // 4.上传成功，删除临时文件
                        ExcelWrite.deleteExcel (hpath);
                    }
                    
                    reportFileService.addReportHtml (htmls);
                    
                    if (lfile.exists ())
                    {
                        lfile.delete ();
                    }
                }
                catch (IOException e)
                {
                    e.printStackTrace ();
                    map.put ("error", super.getProperty ("Save_Exception"));
                    map.put ("success", false);
                    return map;
                }
                finally
                {
                    IOUtils.closeQuietly (in);
                    IOUtils.closeQuietly (os);
                }
                
            }
            else
            {
                template = new Template ();
                template.setTmpfile (oldtemplate.getTmpfile ());
                template.setTmpfilename (oldtemplate.getTmpfilename ());
            }
            template.setTmpid (tmpid);
            template.setTmpname (tmpname);
            template.setTmpkey (tmpkey);
            template.setTmpdesc (tmpdesc);
            template.setReporttype (reporttype);
            
            templateManagementService.update (template);
            map.put ("template", template);
            
            //获取当前登录用户
            User curUser = getCurrentUser ();
            //获取操作描述 key = 类名+"_"+方法名 
            String funDesc = LogRenderUtils.getLogReqMap ("TemplateManagementController_edit");
            try
            {
                //分析删除对象的的关键内容
                String operDetail = templateManagementService.analyseEditContent (oldtemplate, template);
                if (StringUtils.isNotBlank (operDetail))
                {
                    //插入日志
                    logService.insertSysLog (curUser, ConstantCode.STRING_02, getRemoteAddr (), funDesc, operDetail, null, null);
                }
            }
            catch (Exception ex)
            {
                logger.error (funDesc + "  bussness log insert error", ex);
            }
            
        }
        
        map.put ("success", true);
        
        return map;
    }
    
    @RequestMapping ("/templateManagement/view")
    public Object view (HttpServletRequest request)
    {
        Map <String, Object> map = new HashMap <String, Object> ();
        
        String tmpid = request.getParameter ("tmpid");
        Template t = templateManagementService.selectTemplateById(tmpid);
        
        List <ReportHtml> list = reportFileService.queryHtmlsByReportId (tmpid);
        if (list.isEmpty ())
        {
            map.put ("success", false);
            return map;
        }
        List <String> namelist = new ArrayList <String> ();

        for (int i = 0; i < list.size (); i++)
        {
            FileUtils.downloadFile (list.get (i).getHtmlPath (), list.get (i).getHtmlName (),
                    request.getSession ().getServletContext ().getRealPath ("/") + "script" + File.separator + "file" + File.separator,
                    t.getTmpkey() + "_template" + i + ".html");
            namelist.add (list.get (i).getSheetName ());
        }
        //    	for(ReportHtml reportHtml: list){
        //    		FileUtils.downloadFile(hostname, port, username, password, reportHtml.getHtmlPath(), reportHtml.getHtmlName(), request.getSession().getServletContext().getRealPath("/")+"script\\file\\",reportHtml.getSheetName()+".html");
        //    		namelist.add(reportHtml.getSheetName()+".html");
        //    	}
        
        return "/service/template/htmlPreview";
    }
    
    @RequestMapping ("/templateManagement/htmlDatagrid")
    @ResponseBody
    public Map <String, Object> htmlDatagrid (HttpServletRequest request)
    {
        Map <String, Object> map = new HashMap <String, Object> ();
        String tmpid = request.getParameter ("tmpid");
        Template t = templateManagementService.selectTemplateById(tmpid);
        
        List <ReportHtml> list = reportFileService.queryHtmlsByReportId (tmpid);
        
        ReportHtml r = null;
        for (int i = 0; i < list.size (); i++)
        {
            r = list.get (i);
            r.setDownPath (File.separator + "script" + File.separator + "file" + File.separator + t.getTmpkey() + "_template" + i + ".html");
        }
        map.put (CommonConstant.PAGE_RESULT_ROWS, list);
        
        return map;
    }
    
    @RequestMapping ("/templateManagement/delete")
    @ResponseBody
    public Object delete (HttpServletRequest request)
    {
        Map <String, Object> map = new HashMap <String, Object> ();
        
        String tmpid = request.getParameter ("tmpid");
        if (StringUtils.isEmpty (tmpid))
        {
            map.put ("success", false);
            return map;
        }
        
        List <String> fileId = templateManagementService.selectFileIdByTmpid (tmpid);
        
        if (!fileId.isEmpty ())
        {
            map.put ("success", false);
            map.put ("messgae", super.getProperty ("Template_Report_Exception"));
            return map;
        }
        
        List <String> taskId = templateManagementService.selectTaskIdByTmpid (tmpid);
        
        if (!taskId.isEmpty ())
        {
            map.put ("success", false);
            map.put ("messgae", super.getProperty ("Template_Task_Exception"));
            return map;
        }
        
        Template oldtemplate = templateManagementService.selectTemplateById (tmpid);
        
        List <ReportHtml> list = reportFileService.queryHtmlsByReportId (tmpid);
        
        boolean b = FtpUtils.deleteFile (oldtemplate.getTmpfile (), oldtemplate.getTmpfilename ());
        if (!b)
        {
            map.put ("messgae", super.getProperty ("ftp_delete_message"));
            map.put ("success", false);
            return map;
        }
        for (ReportHtml r : list)
        {
            FtpUtils.deleteFile (r.getHtmlPath (), r.getHtmlName ());
        }
        
        //    	String path = oldtemplate.getTmpfile();
        //    	File oldfile = new File(path);
        //        File oldhtmlfile = new File(path.replace(".xls", ".html"));
        //        if(oldfile.exists()){
        //        	oldfile.delete();
        //        }
        //        if(oldhtmlfile.exists()){
        //        	oldhtmlfile.delete();
        //        }
        
        int i = templateManagementService.delete (tmpid);
        reportDataPositionService.deleteByTmpId (tmpid);
        reportDesignService.delete (tmpid);
        reportFileService.deleteReportHtmlsById (tmpid);
        User user = getCurrentUser ();
        UserGrant userGrant = new UserGrant ();
        if (!ReportConstant.REPORT_USERID_ROOT.equals (user.getId ()))
        {
            userGrant.setUserid (user.getId ());
        }
        userGrant.setTmpid (tmpid);
        userService.deleteUserGrant (userGrant);
        
        String funDesc = LogRenderUtils.getLogReqMap ("TemplateManagementController_delete");
        try
        {
            //分析删除对象的的关键内容
            String operDetail = templateManagementService.analyseDelContent (oldtemplate);
            if (StringUtils.isNotBlank (operDetail))
            {
                //插入日志
                logService.insertSysLog (user, ConstantCode.STRING_02, getRemoteAddr (), funDesc, operDetail, null, null);
            }
        }
        catch (Exception ex)
        {
            logger.error (funDesc + "  bussness log insert error", ex);
        }
        
        if (i == 1)
        {
            map.put ("success", true);
        }
        else
        {
            map.put ("success", false);
        }
        
        return map;
    }
    
    @RequestMapping ("/templateManagement/saveDesgin")
    @ResponseBody
    public Object saveDesgin (HttpServletRequest request)
    {
        Map <String, Object> map = new HashMap <String, Object> ();
        
        String tmpid = request.getParameter ("tmpid");
        String designList = request.getParameter ("designList");
        
        List <ReportDesign> list = JSONArray.parseArray (designList, ReportDesign.class);
        
        if (StringUtils.isEmpty (tmpid))
        {
            map.put ("success", false);
        }
        
        reportDesignService.delete (tmpid);
        
        reportDesignService.insertList (list);
        
        map.put ("success", true);
        
        return map;
    }
    
    @RequestMapping ("/templateManagement/getDesgin")
    @ResponseBody
    public Object getDesgin (HttpServletRequest request)
    {
        Map <String, Object> map = new HashMap <String, Object> ();
        
        String tmpid = request.getParameter ("tmpid");
        
        map.put ("list", reportDesignService.queryTemplateListById (tmpid));
        
        return map;
        
    }
    
    @RequestMapping ("/templateManagement/getData")
    @ResponseBody
    public Object getData (HttpServletRequest request)
    {
        Map <String, Object> map = new HashMap <String, Object> ();
        
        String tmpid = request.getParameter ("tmpid");
        
        map.put ("list", reportDataPositionService.queryListByTmpId (tmpid));
        
        return map;
        
    }

    @RequestMapping ("/templateManagement/queryList")
    @ResponseBody
    public Object queryList (@RequestBody ReportTask reportTask, HttpServletRequest request)
    {
        try{
            User currentUser = getCurrentUser ();
            Template t = new Template();
            t.setUserId(currentUser.getId());
            t.setReporttype(reportTask.getType());
            return renderSuccess(templateManagementService.queryListByVo (t));
        }catch (Exception e){
            return renderError("queryList error");
        }
    }

    private XSSFWorkbook writerToXLSX (MultipartFile file, Template template, String path)
    {
        InputStream in = null;
        FileOutputStream os = null;
        XSSFWorkbook work = null;
        try
        {
            in = file.getInputStream ();
            work = new XSSFWorkbook (in);
            int num = work.getNumberOfNames ();
            for (int i = 0; i < num; i++)
            {
                XSSFName name = work.getNameAt (i);
                
                ReportDataPosition reportDataPosition = new ReportDataPosition ();
                reportDataPosition.setDataid (UUIDUtils.generate16Str ());
                reportDataPosition.setDataname (name.getNameName ());
                reportDataPosition.setSheetname (name.getSheetName ());
                if (name.getRefersToFormula ().contains (":"))
                {
                    continue;
                }
                reportDataPosition.setPosition (name.getRefersToFormula ());
                reportDataPosition.setTmpid (template.getTmpid ());
                reportDataPositionService.insert (reportDataPosition);
                
            }
            os = new FileOutputStream (path);
            work.write (os);
        }
        catch (IOException e)
        {
            e.printStackTrace ();
        }
        finally
        {
            IOUtils.closeQuietly (in);
            IOUtils.closeQuietly (os);
        }
        return work;
        
    }
    
    private HSSFWorkbook writerToXLS (MultipartFile file, Template template, String path)
    {
        InputStream in = null;
        FileOutputStream os = null;
        HSSFWorkbook work = null;
        try
        {
            in = file.getInputStream ();
            work = new HSSFWorkbook (in);
            int num = work.getNumberOfNames ();
            for (int i = 0; i < num; i++)
            {
                HSSFName name = work.getNameAt (i);
                
                ReportDataPosition reportDataPosition = new ReportDataPosition ();
                reportDataPosition.setDataid (UUIDUtils.generate16Str ());
                reportDataPosition.setDataname (name.getNameName ());
                reportDataPosition.setSheetname (name.getSheetName ());
                if (name.getRefersToFormula ().contains (":"))
                {
                    continue;
                }
                reportDataPosition.setPosition (name.getRefersToFormula ());
                reportDataPosition.setTmpid (template.getTmpid ());
                reportDataPositionService.insert (reportDataPosition);
                
            }
            os = new FileOutputStream (path);
            work.write (os);
        }
        catch (IOException e)
        {
            e.printStackTrace ();
        }
        finally
        {
            IOUtils.closeQuietly (in);
            IOUtils.closeQuietly (os);
        }
        return work;
        
    }
    
}
