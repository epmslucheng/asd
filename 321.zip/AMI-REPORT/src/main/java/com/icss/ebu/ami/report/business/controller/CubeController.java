package com.icss.ebu.ami.report.business.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.icss.ebu.ami.commons.pagePlugin.Page;
import com.icss.ebu.ami.commons.util.UUIDUtils;
import com.icss.ebu.ami.report.business.common.constant.CommonConstant;
import com.icss.ebu.ami.report.business.common.constant.ReportConstant;
import com.icss.ebu.ami.report.business.model.CubeBean;
import com.icss.ebu.ami.report.business.model.DataSourceBean;
import com.icss.ebu.ami.report.business.model.DataSourceTable;
import com.icss.ebu.ami.report.business.model.DataSourceTableFiled;
import com.icss.ebu.ami.report.business.model.Table;
import com.icss.ebu.ami.report.business.model.TableField;
import com.icss.ebu.ami.report.business.service.CubeService;
import com.icss.ebu.ami.report.business.service.DataSourceService;
import com.icss.ebu.ami.report.business.service.UserService;
import com.icss.ebu.ami.report.system.model.User;
import com.icss.ebu.ami.report.system.model.UserGrant;

@Controller
@RequestMapping ("/cube")
public class CubeController extends BaseController
{
    private static final Logger LOGGER = LoggerFactory.getLogger (CubeController.class);
    
    @Autowired
    private CubeService cubeService;
    
    @Autowired
    private DataSourceService dataSourceService;
    
    @Autowired
    private UserService userService;
    
    @RequestMapping (value = "/index")
    public String index (HttpServletRequest request, HttpServletResponse response)
    {
        return "/service/cube/cube";
    }
    
    @RequestMapping ("/query")
    @ResponseBody
    public Object query (HttpServletRequest request, CubeBean cube)
    {
        Page <CubeBean> page = new Page <CubeBean> (cube);
        page.setPageNo (NumberUtils.toInt (request.getParameter (CommonConstant.PAGE_PARAM_PAGE)));
        page.setPageSize (NumberUtils.toInt (request.getParameter (CommonConstant.PAGE_PARAM_ROWS)));
        page = cubeService.queryCubeList (page);
        Map <String, Object> map = new HashMap <String, Object> ();
        map.put (CommonConstant.PAGE_RESULT_ROWS, page.getResults ());
        map.put (CommonConstant.PAGE_RESULT_TOTAL, page.getTotalRecord ());
        return map;
        
    }
    
    /**
     * 新增页
     *
     * @param model
     * @param id
     * @return
     */
    @RequestMapping ("/addPage")
    public String addPage (Model model, HttpServletRequest request, HttpServletResponse response, CubeBean cube)
    {
        
        return "/service/cube/cubeAdd";
    }
    
    @RequestMapping ("/getAllCubeList")
    @ResponseBody
    public Object getAllCubeList (HttpServletRequest request, HttpServletResponse response)
    {
        User currentUser = getCurrentUser ();
        Map <String, Object> result = new HashMap <String, Object> ();
        List <CubeBean> cubeList = null;
        if ("1".equals (currentUser.getId ()))
        {
            
            cubeList = cubeService.getAllCube ();
        }
        else
        {
            cubeList = cubeService.getAllCubeByUserId (currentUser.getId ());
            
        }
        result.put ("cubeList", cubeList);
        return renderSuccess (result);
    }
    
    @RequestMapping ("/getCubeListByDsId")
    @ResponseBody
    public Object getCubeListByDsId (HttpServletRequest request, HttpServletResponse response, @RequestBody CubeBean cube)
    {
        Map <String, Object> result = new HashMap <String, Object> ();
        User currentUser = getCurrentUser ();
        cube.setUserId (currentUser.getId ());
        List <CubeBean> cubeList = null;
        if ("1".equals (currentUser.getId ()))
        {
            
            cubeList = cubeService.getCubeByDsId (cube.getId ());
            
        }
        else
        {
            cubeList = cubeService.getCubeByDsIdAndUser (cube);
        }
        result.put ("cubeList", cubeList);
        return renderSuccess (result);
    }
    
    @RequestMapping ("/getTreeListByDsId")
    @ResponseBody
    public Object getTreeListByDsId (HttpServletRequest request, HttpServletResponse response, @RequestBody CubeBean cube)
    {
        List <Object> list = new ArrayList <Object> ();
        Map <String, Object> result = new HashMap <String, Object> ();
        User currentUser = getCurrentUser ();
        cube.setUserId (currentUser.getId ());
        List <CubeBean> cubeList = null;
        if ("1".equals (currentUser.getId ()))
        {
            
            cubeList = cubeService.getCubeByDsId (cube.getId ());
            
        }
        else
        {
            cubeList = cubeService.getCubeByDsIdAndUser (cube);
        }
        for (CubeBean cb : cubeList)
        {
            List <DataSourceTable> tableList = cubeService.getCubeTableNameById (cb.getCubeId ());
            for (DataSourceTable dataSourceTable : tableList)
            {
                if (dataSourceTable.getId () != null)
                {
                    dataSourceTable.setParentId (cb.getCubeId ());
                    dataSourceTable.setDraggable (true);
                    List <DataSourceTableFiled> tableFiledList = cubeService.getTableTreeByTable (dataSourceTable);
                    dataSourceTable.setId (UUIDUtils.generate16Str ());
                    for (DataSourceTableFiled dataSourceTableFiled : tableFiledList)
                    {
                        dataSourceTableFiled.setParentId (dataSourceTable.getId ());
                        dataSourceTableFiled.setId (UUIDUtils.generate16Str ());
                        dataSourceTableFiled.setDraggable (true);
                    }
                    list.addAll (tableFiledList);
                }
            }
            list.addAll (tableList);
            cb.setId (cb.getCubeId ());
        }
        list.addAll (cubeList);
        result.put ("list", list);
        return renderSuccess (result);
    }
    
    @RequestMapping ("/getDataList")
    @ResponseBody
    public Object getDataList (HttpServletRequest request, HttpServletResponse response, @RequestBody CubeBean cube)
    {
        Map <String, Object> result = new HashMap <String, Object> ();
        List <DataSourceBean> dsList = dataSourceService.getAllDataSource ();
        result.put ("dsList", dsList);
        return renderSuccess (result);
    }
    
    @RequestMapping ("/getTableListByDSId")
    @ResponseBody
    public Object getTableListByDSId (HttpServletRequest request, HttpServletResponse response, @RequestBody CubeBean cube)
    {
        Map <String, Object> result = new HashMap <String, Object> ();
        String id = cube.getId ();
        List <DataSourceTable> tableList = dataSourceService.getTableListByDataSourceId (id);
        result.put ("tableList", tableList);
        return renderSuccess (result);
    }
    
    @RequestMapping ("/getTableListByCubeId")
    @ResponseBody
    public Object getTableListByCubeId (HttpServletRequest request, HttpServletResponse response, @RequestBody CubeBean cube)
    {
        Map <String, Object> result = new HashMap <String, Object> ();
        String id = cube.getCubeId ();
        List <DataSourceTable> tableList = cubeService.getCubeTableNameById (id);
        result.put ("selTableList", tableList);
        return renderSuccess (result);
    }
    
    @RequestMapping ("/save")
    @ResponseBody
    public Object save (HttpServletRequest request, HttpServletResponse response, @RequestBody CubeBean cube)
    {
        
        try
        {
            cubeService.addCube (cube);
        }
        catch (Exception e)
        {
            LOGGER.error (e.getMessage ());
            return renderSuccess ("error");
        }
        return renderSuccess ("success");
    }
    
    /**
     * 查看页
     *
     * @param model
     * @param id
     * @return
     */
    @RequestMapping ("/viewPage")
    public String viewPage (Model model, HttpServletRequest request, HttpServletResponse response, @RequestBody CubeBean cube)
    {
        String id = cube.getCubeId ();
        CubeBean cubeBean = cubeService.getCubeById (id);
        
        List <DataSourceTable> tableNameList = cubeService.getCubeTableNameById (id);
        
        //        cubeBean.setTableNames(tableNameList);
        
        model.addAttribute ("cube", cubeBean);
        
        return "/service/dataSource/dataSourceView";
    }
    
    /**
     * 编辑页
     *
     * @param model
     * @param id
     * @return
     */
    @RequestMapping ("/editPage")
    public String editPage (Model model, HttpServletRequest request, HttpServletResponse response, @RequestBody CubeBean cube)
    {
        return "/service/cube/cubeEdit";
    }
    
    @RequestMapping ("/edit")
    @ResponseBody
    public Object edit (HttpServletRequest request, HttpServletResponse response, @RequestBody CubeBean cube)
    {
        
        try
        {
            cubeService.editCube (cube);
        }
        catch (Exception e)
        {
            LOGGER.error (e.getMessage ());
            return renderSuccess ("error");
        }
        
        return renderSuccess ("success");
    }
    
    @RequestMapping ("/delete")
    @ResponseBody
    public Object delete (HttpServletRequest request, @RequestBody CubeBean cube)
    {
        try
        {
            String id = cube.getCubeId ();
            cubeService.delCubeById (id);
            
            User user = getCurrentUser ();
            UserGrant userGrant = new UserGrant ();
            if (!ReportConstant.REPORT_USERID_ROOT.equals (user.getId ()))
            {
                userGrant.setUserid (user.getId ());
            }
            userGrant.setCubeid (cube.getCubeId ());
            userService.deleteUserGrant (userGrant);
        }
        catch (Exception e)
        {
            LOGGER.error (e.getMessage ());
            return renderSuccess ("error");
        }
        return renderSuccess ("success");
    }
    
    @RequestMapping ("/updateTable")
    @ResponseBody
    public Object updateTable (HttpServletRequest request, @RequestBody CubeBean cube)
    {
        return renderSuccess ("success");
    }
    
    @RequestMapping ("/getTableTreeByCubeId")
    @ResponseBody
    public Object getTableTreeByCubeId (HttpServletRequest request, HttpServletResponse response, @RequestBody CubeBean cube)
    {
        Map <String, Object> result = new HashMap <String, Object> ();
        String cubeId = cube.getCubeId ();
        List <Object> list = new ArrayList <Object> ();
        List <DataSourceTable> tableList = cubeService.getCubeTableNameById (cubeId);
        for (DataSourceTable dataSourceTable : tableList)
        {
            if (dataSourceTable.getId () != null)
            {
                dataSourceTable.setParentId (cubeId);
                dataSourceTable.setEditable (false);
                dataSourceTable.setTreeId (UUIDUtils.generate16Str ());
                List <DataSourceTableFiled> tableFiledList = cubeService.getTableTreeByTable (dataSourceTable);
                dataSourceTable.setId (UUIDUtils.generate16Str ());
                for (DataSourceTableFiled dataSourceTableFiled : tableFiledList)
                {
                    dataSourceTableFiled.setParentId (dataSourceTable.getTreeId ());
                    dataSourceTableFiled.setTreeId (UUIDUtils.generate16Str ());
                    dataSourceTableFiled.setId (cube.getId ());
                    dataSourceTableFiled.setEditable (true);
                }
                list.addAll (tableFiledList);
            }
        }
        list.addAll (tableList);
        result.put ("list", list);
        return renderSuccess (result);
    }
    
    @RequestMapping ("/reNameTableFiledAlias")
    @ResponseBody
    public Object reNameTableFiledAlias (HttpServletRequest request, @RequestBody DataSourceTableFiled dstf)
    {
        
        //别名修改
        try
        {
            cubeService.updateTableFiledAlias (dstf);
        }
        catch (Exception e)
        {
            LOGGER.error ("修改别名失败");
        }
        return renderSuccess ("success");
    }
    
    @RequestMapping ("/genertateCubeId")
    @ResponseBody
    public Object genertateCubeId (HttpServletRequest request, HttpServletResponse response)
    {
        Map <String, Object> result = new HashMap <String, Object> ();
        String id = UUIDUtils.generate16Str ();
        result.put ("id", id);
        return renderSuccess (result);
    }
    
    /**
     * 拖拽数据集页面，只需要立方指标表名的数据
     * @param request
     * @param response
     * @param cube
     * @return
     */
    @RequestMapping ("/getJumbTreeByDsId")
    @ResponseBody
    public Object getJumbTreeByDsId (HttpServletRequest request, HttpServletResponse response, @RequestBody CubeBean cube)
    {
        List <Object> list = new ArrayList <Object> ();
        Map <String, Object> result = new HashMap <String, Object> ();
        User currentUser = getCurrentUser ();
        cube.setUserId (currentUser.getId ());
        List <CubeBean> cubeList = null;
        List <TableField> fieldList = null;
        if ("1".equals (currentUser.getId ()))
        {
            
            cubeList = cubeService.getCubeByDsId (cube.getId ());
            
        }
        else
        {
            cubeList = cubeService.getCubeByDsIdAndUser (cube);
        }
        for (CubeBean cb : cubeList)
        {
            List <Table> tableList = cubeService.getTablesByCubeId (cb.getCubeId ());
            for (Table table : tableList)
            {
                table.setParentId (cb.getCubeId ());
                table.setDraggable (true);
                fieldList = cubeService.getFieldsByTable (table);
                for (TableField field : fieldList)
                {
                    field.setParentId (table.getId ());
                    field.setTableSql (table.getTableSql ());
                    field.setDraggable (false);
                }
                list.addAll (fieldList);
                table.setFieldList (fieldList);
            }
            list.addAll (tableList);
            cb.setId (cb.getCubeId ());
        }
        list.addAll (cubeList);
        result.put ("list", list);
        return renderSuccess (result);
    }
}
