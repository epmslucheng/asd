package com.icss.ebu.ami.report.business.model;

import java.io.Serializable;

/**
 * 模型树
 * @author lucheng
 *
 */
public class TableModel implements Serializable
{
    
    /**
     * 序列化
     */
    private static final long serialVersionUID = 4307757879543044634L;
    
    private String nodeId;
    
    private String nodeName;
    
    private String parentId;
    
    private String tableType;
    
    private String tableSql;
    
    private TableStyle style;
    
    private ConnectLine connectLine;
    
    public String getNodeId ()
    {
        return nodeId;
    }
    
    public void setNodeId (String nodeId)
    {
        this.nodeId = nodeId;
    }
    
    public String getNodeName ()
    {
        return nodeName;
    }
    
    public void setNodeName (String nodeName)
    {
        this.nodeName = nodeName;
    }
    
    public String getParentId ()
    {
        return parentId;
    }
    
    public void setParentId (String parentId)
    {
        this.parentId = parentId;
    }
    
    public String getTableType ()
    {
        return tableType;
    }
    
    public void setTableType (String tableType)
    {
        this.tableType = tableType;
    }
    
    public String getTableSql ()
    {
        return tableSql;
    }
    
    public void setTableSql (String tableSql)
    {
        this.tableSql = tableSql;
    }
    
    public TableStyle getStyle ()
    {
        return style;
    }
    
    public void setStyle (TableStyle style)
    {
        this.style = style;
    }
    
    public ConnectLine getConnectLine ()
    {
        return connectLine;
    }
    
    public void setConnectLine (ConnectLine connectLine)
    {
        this.connectLine = connectLine;
    }
    
}
