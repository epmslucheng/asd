package com.icss.ebu.ami.report.business.model;

import java.io.Serializable;
import java.util.List;

/**
 * sql对象
 * @author lucheng
 *
 */
public class SqlObject implements Serializable
{
    
    /**
     * 
     */
    private static final long serialVersionUID = 5156089466947138526L;
    
    // 主键
    private String id;
    
    // SELECT关键字
    private String sqlSelect;
    
    // 查询列名
    private List <TableField> sqlColumns;
    
    // FROM关键字
    private String sqlFrom;
    
    // 表关系处理
    List <TableModel> tableModels;
    
    // WHERE 关键字
    private String sqlWhere;
    
    // 条件
    private String sqlCondition;
    
    public String getId ()
    {
        return id;
    }
    
    public void setId (String id)
    {
        this.id = id;
    }
    
    public String getSqlFrom ()
    {
        return sqlFrom;
    }
    
    public void setSqlFrom (String sqlFrom)
    {
        this.sqlFrom = sqlFrom;
    }
    
    public String getSqlWhere ()
    {
        return sqlWhere;
    }
    
    public void setSqlWhere (String sqlWhere)
    {
        this.sqlWhere = sqlWhere;
    }
    
    public String getSqlCondition ()
    {
        return sqlCondition;
    }
    
    public void setSqlCondition (String sqlCondition)
    {
        this.sqlCondition = sqlCondition;
    }
    
    public String getSqlSelect ()
    {
        return sqlSelect;
    }
    
    public void setSqlSelect (String sqlSelect)
    {
        this.sqlSelect = sqlSelect;
    }
    
    public List <TableModel> getTableModels ()
    {
        return tableModels;
    }
    
    public void setTableModels (List <TableModel> tableModels)
    {
        this.tableModels = tableModels;
    }
    
    public List <TableField> getSqlColumns ()
    {
        return sqlColumns;
    }
    
    public void setSqlColumns (List <TableField> sqlColumns)
    {
        this.sqlColumns = sqlColumns;
    }
    
}
