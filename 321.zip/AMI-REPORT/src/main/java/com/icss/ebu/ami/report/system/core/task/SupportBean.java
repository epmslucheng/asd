package com.icss.ebu.ami.report.system.core.task;

import com.icss.ebu.ami.report.business.service.ReportService;
import com.icss.ebu.ami.report.business.service.ReportTaskService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class SupportBean
{
    @Autowired
    private ReportService reportService;

    @Autowired
    private ReportTaskService reportTaskService;

    public ReportService getReportService ()
    {
        return reportService;
    }

    public ReportTaskService getReportTaskService ()
    {
        return reportTaskService;
    }
}
