package com.icss.ebu.ami.report.business.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.icss.ebu.ami.report.business.mapper.ReportDesignMapper;
import com.icss.ebu.ami.report.business.model.ReportDesign;
import com.icss.ebu.ami.report.business.service.ReportDesignService;

/** 
* @author  zhangkaining 
* @date 2017年10月31日 上午9:42:48 
* @version 1.0   
*/
@Service
public class ReportDesignServiceImpl implements ReportDesignService {

	@Autowired
    private ReportDesignMapper reportDesignMapper;
	
	@Override
	public List<ReportDesign> queryTemplateListById(String reportid) {
		return reportDesignMapper.queryTemplateListById(reportid);
	}

	@Override
	public int insert(ReportDesign reportDesign) {
		return reportDesignMapper.insert(reportDesign);
	}

	@Override
	public int insertList(List<ReportDesign> list) {
		return reportDesignMapper.insertList(list);
	}

	@Override
	public int delete(String reportid) {
		return reportDesignMapper.delete(reportid);
	}

}
