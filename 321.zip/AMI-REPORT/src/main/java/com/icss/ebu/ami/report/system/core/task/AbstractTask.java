package com.icss.ebu.ami.report.system.core.task;

import org.apache.log4j.Logger;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.context.ApplicationContext;
import org.springframework.scheduling.quartz.QuartzJobBean;

import java.util.List;

/**
 * 任务定义基类
 *
 * @author Administrator
 *
 */
public abstract class AbstractTask extends QuartzJobBean
{
    
    private static final Logger LOGGER = Logger.getLogger (AbstractTask.class);
    
    /**
     * 任务相关的参数信息
     */
    private List <TaskParam> paramList;
    
    private boolean startStatus = true;
    
    protected ApplicationContext applicationContext;
    
    /**
     * 关联的任务ID
     */
    private Long taskId;
    
    /**
     * 配置的任务名称
     */
    private String taskName;
    
    /**
     * 任务详细名
     */
    private String taskNameAlias;
    
    /**
     * 任务处理
     */
    private String taskHandle;
    
    /**
     * 任务类型
     */
    private String taskCode;
    
    public AbstractTask(Long taskId, String taskName, List <TaskParam> params)
    {
        super ();
        this.taskId = taskId;
        this.taskName = taskName;
        this.paramList = params;
    }
    
    public AbstractTask()
    {
    }
    
    @Override
    protected void executeInternal (JobExecutionContext context) throws JobExecutionException
    {
        if (!startStatus)
        {
            return;
        }
        try
        {
            execTask ();
        }
        catch (Exception e)
        {
            LOGGER.error ("AbstractTask-executeInternal:", e);
        }
    }
    
    /**
     * 要执行的具体任务入口点
     */
    public abstract void execTask ();
    
    public List <TaskParam> getParamList ()
    {
        return paramList;
    }
    
    public void setParamList (List <TaskParam> paramList)
    {
        this.paramList = paramList;
    }
    
    public String getTaskName ()
    {
        return taskName;
    }
    
    public void setTaskName (String taskName)
    {
        this.taskName = taskName;
    }
    
    public boolean isStartStatus ()
    {
        return startStatus;
    }
    
    public void setStartStatus (boolean startStatus)
    {
        this.startStatus = startStatus;
    }
    
    public Long getTaskId ()
    {
        return taskId;
    }
    
    public void setTaskId (Long taskId)
    {
        this.taskId = taskId;
    }
    
    public void setApplicationContext (ApplicationContext applicationContext)
    {
        this.applicationContext = applicationContext;
    }
    
    public String getTaskNameAlias ()
    {
        return taskNameAlias;
    }
    
    public void setTaskNameAlias (String taskNameAlias)
    {
        this.taskNameAlias = taskNameAlias;
    }
    
    public String getTaskHandle ()
    {
        return taskHandle;
    }
    
    public void setTaskHandle (String taskHandle)
    {
        this.taskHandle = taskHandle;
    }
    
    public String getTaskCode ()
    {
        return taskCode;
    }
    
    public void setTaskCode (String taskCode)
    {
        this.taskCode = taskCode;
    }
    
}
