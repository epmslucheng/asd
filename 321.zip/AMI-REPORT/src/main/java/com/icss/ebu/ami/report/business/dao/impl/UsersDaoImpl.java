package com.icss.ebu.ami.report.business.dao.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.icss.ebu.ami.report.business.dao.UserRowMapper;
import com.icss.ebu.ami.report.business.dao.UsersDao;
import com.icss.ebu.ami.report.business.jdbc.AbstractJdbcRepository;
import com.icss.ebu.ami.report.system.model.User;

@Repository ("usersDao")
public class UsersDaoImpl extends AbstractJdbcRepository implements UsersDao
{
    private static UserRowMapper userRowMapper = new UserRowMapper ();
    
    @Override
    public User findUserById (String id)
    {
        String sql = "select ID,LOGINNAME,NAME,PASSWORD from t_sys_user where id = ?";
        List <User> usersList = jdbcTemplate.query (sql, userRowMapper, id);
        return usersList == null ? null : usersList.get (0);
    }
}
