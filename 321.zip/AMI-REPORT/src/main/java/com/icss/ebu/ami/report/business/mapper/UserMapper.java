package com.icss.ebu.ami.report.business.mapper;

import java.util.List;

import com.icss.ebu.ami.commons.pagePlugin.Page;
import com.icss.ebu.ami.commons.util.PageInfo;
import com.icss.ebu.ami.report.business.result.UserVo;
import com.icss.ebu.ami.report.system.model.User;
import com.icss.ebu.ami.report.system.model.UserAll;
import com.icss.ebu.ami.report.system.model.UserCube;
import com.icss.ebu.ami.report.system.model.UserDataSource;
import com.icss.ebu.ami.report.system.model.UserObjTree;
import com.icss.ebu.ami.report.system.model.UserTemplate;

public interface UserMapper
{
    /**
     * 删除用户
     *
     * @param id
     * @return
     */
    int deleteById(String id);
    
    /**
     * 添加用户
     *
     * @param user
     * @return
     */
    int insert(User user);
    
    /**
     * 修改用户
     *
     * @param user
     * @return
     */
    int updateUser(User user);
    
    /**
     * 根据用户名查询用户
     *
     * @param username
     * @return
     */
    User findUserByLoginName(String username);
    
    /**
     * 根据用户id查询用户
     *
     * @param id
     * @return
     */
    User findUserById(String id);
    
    /**
     * 用户列表
     *
     * @param pageInfo
     * @return
     */
    List findUserPageCondition(PageInfo pageInfo);
    
    /**
     * 统计用户
     *
     * @param pageInfo
     * @return
     */
    int findUserPageCount(PageInfo pageInfo);
    
    /**
     * 修改用户密码
     *
     * @param userId
     * @param pwd
     */
    void updateUserPwdById(User user);
    
    /**
     * 根据用户id查询用户带部门
     *
     * @param id
     * @return
     */
    UserVo findUserVoById(String id);
    
    /**
     * 分页
     * 
     * @param name
     * @return
     */
    
    List<UserVo> findUserByPage(Page<UserVo> page);
    
    User finActiduserbyUserName(String name);
    
    /**
     * 统计用户数量
     *
     * @return 统计数量
     */
    Integer countUser(User user);
    
    /**
     * 统计用户数量
     *
     * @return 统计数量
     */
    long countLongUser();
    
    /**
     * 分页查询系统用户
     * 
     * @param page
     * @return
     */
    List<User> findSysUserByPage(Page<User> page);
    
    void editPersonInfo(UserVo userVo);
    
    List<String> findDataSourceIdByUserId(String id);
    
    List<String> findCubeIdByUserId(String id);
    
    void deleteUserCubeByUserId(String id);
    
    void deleteUserDataSourceByUserId(String id);
    
    void insertUserDataSource(UserDataSource userDataSource);
    
    void insertUseCube(UserCube userCube);
    
    List<String> findTmpIdByUserId(String id);
    
    void insertUserTemplate(UserTemplate userTemplate);
    
    List<String> findObjIdByUserId(String id);
    
    void insertUserObjTree(UserObjTree userObjTree);
    
    void deleteUserTmpByUserId(String userid);
    
    void deleteUserObjTreeByUserId(String userid);
    
    int deleteUseCube(UserCube userCube);
    
    int deleteUserDataSource(UserDataSource userDataSource);
    
    int deleteUserTemplate(UserTemplate userTemplate);
    
    int deleteUserObjTree(UserObjTree userObjTree);
    
    void deleteUserBySourceUserid(String id);
    
    void insertSelective(UserAll userAll);
    
}