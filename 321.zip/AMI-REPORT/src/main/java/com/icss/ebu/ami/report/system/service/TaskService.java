package com.icss.ebu.ami.report.system.service;

import com.icss.ebu.ami.report.system.core.task.Task;

import java.util.List;

public interface TaskService extends AbstractTaskService
{
    /**
     * 获取所有的任务列表
     * @param taskType
     * 
     * @return
     */
    List<Task> getAllTask(String taskType);
    
    /**
     * 标注当前任务是否已经正在运行中
     * 
     * @param taskId
     * @param status
     */
    void updateTaskStatus(Long taskId, Long status);
    
    Task getTaskById(Long taskId);
}
