package com.icss.ebu.ami.report.business.mapper;

import java.util.List;

import com.icss.ebu.ami.commons.pagePlugin.Page;
import com.icss.ebu.ami.report.business.model.DataSetObject;
import com.icss.ebu.ami.report.business.model.ObjectTreeBean;
import com.icss.ebu.ami.report.business.model.ObjectTreeNode;
import com.icss.ebu.ami.report.business.model.ReportTaskTempObjs;

public interface ObjectTreeMapper
{
    List <ObjectTreeBean> getAllDataSource ();
    
    List <ObjectTreeBean> getObjectTreeList (Page <ObjectTreeBean> page);
    
    ObjectTreeBean getObjectTreeById (String id);
    
    ObjectTreeBean getObjectTreeKey (String key);
    
    Integer delObjectTreeById (String id);
    
    Integer addObjectTree (ObjectTreeBean objTree);
    
    Integer updateObjectTree (ObjectTreeBean objTree);
    
    List <ObjectTreeBean> queryAllObjectTree (ObjectTreeBean objectTreeBean);
    
    Integer addObjectTreeNode (ObjectTreeNode treeNode);
    
    Integer editObjectTreeNode (ObjectTreeNode treeNode);
    
    Integer delObjectTreeNode (String id);
    
    Integer delObjectTreeNodeByObjectId (String id);
    
    List <ObjectTreeNode> queryRootNodeByObjectId (ObjectTreeBean objTree);
    
    List <ObjectTreeNode> queryNodeListByObjectId (ObjectTreeBean objTree);
    
    List <ObjectTreeNode> findAll ();
    
    int insertDataSetObject (List <DataSetObject> list);
    
    int deleteDataSetObjectByQueryId (String queryId);
    
    List <ObjectTreeBean> queryObjectTreesListByTempIds (ReportTaskTempObjs reportTaskTempObjs);
}