package com.icss.ebu.ami.report.business.service;

import java.util.List;

import com.icss.ebu.ami.report.business.model.ReportDataPosition;

/** 
* @author  zhangkaining 
* @date 2017年11月1日 下午2:39:15 
* @version 1.0   
*/
public interface ReportDataPositionService {
	
	/**
	 * 根据模板ID查询数据
	 * @param tmpid
	 * @return
	 */
	List<ReportDataPosition> queryListByTmpId(String tmpid);
	
	/**
	 * 根据模板ID删除数据
	 * @param tmpid
	 * @return
	 */
	int deleteByTmpId(String tmpid);
	
	/**
	 * 插入数据
	 * @param reportDataPosition
	 * @return
	 */
	int insert(ReportDataPosition reportDataPosition);
	
	/**
	 * 批量插入
	 * @param list
	 * @return
	 */
	int insertList(List<ReportDataPosition> list);

}
