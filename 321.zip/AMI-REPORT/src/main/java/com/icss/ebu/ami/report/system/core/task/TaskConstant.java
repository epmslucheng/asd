package com.icss.ebu.ami.report.system.core.task;

public class TaskConstant
{
    public static final String SCAN_TASK = "SCANTASK";
    
    public static final String REPORT_TASK = "REPORTTASK";
    
    public static final String SUB_TASK_STATUS_01 = "01";//失败
    
    public static final String SUB_TASK_STATUS_02 = "02";//成功
    
    public static final String SUB_TASK_STATUS_03 = "03";//延时调度
    
}
