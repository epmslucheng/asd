package com.icss.ebu.ami.report.system.mapper;

import com.icss.ebu.ami.report.system.core.task.Task;
import com.icss.ebu.ami.report.system.core.task.TaskInfo;

import java.util.List;

public interface TaskMapper
{
    
    public List <Task> getAllTask(Task task);
    
    public void updateTaskStatus(Task task);
    
    public Task getTaskById(Long taskId);
    
    public List <TaskInfo> getAllTimeTask();
    
    public Integer countScheduleTaskLog();
    
    public TaskInfo getScheduleTaskLog(TaskInfo task);
    
    public TaskInfo getScheduleTaskRunLog(TaskInfo task);
    
//    public Integer insertMessageInfos(List<MessageInfo> messageInfo);
    
    public List <TaskInfo> getTaskInfo(String taskCode);

//    public MessageTemplate messageTemplateInfo(String templateKey);
}
