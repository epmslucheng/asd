package com.icss.ebu.ami.report.system.controller;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.icss.ebu.ami.commons.constants.GeneralConstant;
import com.icss.ebu.ami.commons.pagePlugin.Page;
import com.icss.ebu.ami.commons.util.DateUtils;
import com.icss.ebu.ami.report.business.common.constant.CommonConstant;
import com.icss.ebu.ami.report.business.controller.BaseController;
import com.icss.ebu.ami.report.business.service.LogService;
import com.icss.ebu.ami.report.system.model.SysLogBean;
import com.icss.ebu.ami.report.system.model.User;

/** 
* @author  zhangkaining 
* @date 2017年11月13日 下午2:39:06 
* @version 1.0   
*/
@Controller
@RequestMapping ("/syslog")
public class SyslogController extends BaseController
{
    
    @Autowired
    private LogService logService;
    
    @RequestMapping ("")
    public String role ()
    {
        return "/service/syslog/syslog";
    }
    
    @RequestMapping (value = "/dataGrid", method = RequestMethod.POST)
    @ResponseBody
    public Map <String, Object> dataGrid (SysLogBean sysLogBean, HttpServletRequest request)
    {
        Map <String, Object> map = new HashMap <String, Object> ();
        
        if (StringUtils.isBlank (sysLogBean.getStartTime ()))
        {
            Date curDate = new Date ();
            sysLogBean.setStartTime (DateUtils.formatDate (curDate) + " 00:00:00");
            sysLogBean.setEndTime (DateUtils.formatDateTime (curDate));
        }
        User user = getCurrentUser ();
        if (!"root".equals (user.getLoginname ()))
        {
            sysLogBean.setLoginName (user.getLoginname ());
        }
        try
        {
            Page <SysLogBean> page = new Page <SysLogBean> (sysLogBean);
            String sortCol = request.getParameter (CommonConstant.PAGE_PARAM_ORDER_COL);
            String order = request.getParameter (CommonConstant.PAGE_PARAM_ORDER);
            if (StringUtils.isNotEmpty (sortCol) && StringUtils.isNotEmpty (order))
            {
                if ("createTime".equals (sortCol))
                {
                    sortCol = "CREATE_TIME";
                }
                
                Map <String, Object> params = new HashMap <String, Object> ();
                params.put ("order", sortCol + GeneralConstant.SPACE + order);
                page.setConditions (params);
            }
            page.setPageNo (Integer.parseInt (request.getParameter ("page")));
            page.setPageSize (Integer.parseInt (request.getParameter ("rows")));
            page = logService.findSysLogByPage (page);
            map.put ("rows", page.getResults ());
            map.put ("total", page.getTotalRecord ());
        }
        catch (Exception e)
        {
            logger.error ("Service Error IntfLogController  intfLogList :   " + e);
        }
        return map;
    }
    
}
