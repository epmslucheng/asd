package com.icss.ebu.ami.report.business.model;

import java.io.Serializable;

/**
 * 用于处理sql树
 * @author lvzhengtao
 *
 */
public class TableTree implements Serializable
{
    
    /**
     * 
     */
    private static final long serialVersionUID = 4954484652141831016L;
    
    // 表Id
    private String id;
    
    // 展示名称
    private String text;
    
    // 具体表名
    private String value;
    
    // 指定是table 还是 自定义sql
    private String type;
    
    // 箭头指向的被关联表id
    private String parentId;
    
    // 如关联方式：LEFT JOIN
    private String action;
    
    // 是否是模型图中第一张主表
    private boolean isMainTable;
    
    // 表关联字段名
    private String column;
    
    // 箭头指向的被关联表字段名
    private String pColumn;
    
    public String getId ()
    {
        return id;
    }
    
    public void setId (String id)
    {
        this.id = id;
    }
    
    public String getText ()
    {
        return text;
    }
    
    public void setText (String text)
    {
        this.text = text;
    }
    
    public String getParentId ()
    {
        return parentId;
    }
    
    public void setParentId (String parentId)
    {
        this.parentId = parentId;
    }
    
    public String getAction ()
    {
        return action;
    }
    
    public void setAction (String action)
    {
        this.action = action;
    }
    
    public String getValue ()
    {
        return value;
    }
    
    public void setValue (String value)
    {
        this.value = value;
    }
    
    public String getType ()
    {
        return type;
    }
    
    public void setType (String type)
    {
        this.type = type;
    }
    
    public boolean isMainTable ()
    {
        return isMainTable;
    }
    
    public void setMainTable (boolean isMainTable)
    {
        this.isMainTable = isMainTable;
    }
    
    public String getColumn ()
    {
        return column;
    }
    
    public void setColumn (String column)
    {
        this.column = column;
    }
    
    public String getpColumn ()
    {
        return pColumn;
    }
    
    public void setpColumn (String pColumn)
    {
        this.pColumn = pColumn;
    }
    
}
