package com.icss.ebu.ami.report.system.shiro;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.SimpleAuthenticationInfo;
import org.apache.shiro.authc.UnknownAccountException;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.alibaba.fastjson.JSONObject;
import com.icss.ebu.ami.auth.exception.OAuth2AuthenticationException;
import com.icss.ebu.ami.auth.oauth.shiro.OAuth2Token;
import com.icss.ebu.ami.report.business.common.util.ConfigHolder;
import com.icss.ebu.ami.report.business.common.util.RESTClient;
import com.icss.ebu.ami.report.business.service.UserService;
import com.icss.ebu.ami.report.system.common.shiro.ShiroUser;
import com.icss.ebu.ami.report.system.model.User;
import com.icss.ebu.ami.report.system.service.RoleService;

/**
 * @description：shiro权限认证
 * @author：zhixuan.wang @date：2015/10/1 14:51
 */
public class ShiroDbRealm extends AuthorizingRealm
{
    
    private static final Logger LOGGER = LoggerFactory.getLogger (ShiroDbRealm.class);
    
    @Autowired
    private UserService userService;
    
    @Autowired
    private RoleService roleService;
    
    public ShiroDbRealm ()
    {
        super ();
        setAuthenticationTokenClass (AuthenticationToken.class);
        LOGGER.debug ("Initial Resources-Realm: {}, set authenticationTokenClass = {}", this, getAuthenticationTokenClass ());
    }
    
    /**
     * Shiro登录认证(原理：用户提交 用户名和密码 --- shiro 封装令牌 ---- realm 通过用户名将密码查询返回 ----
     * shiro 自动去比较查询出密码和用户输入密码是否一致---- 进行登陆控制 )
     */
    @Override
    protected AuthenticationInfo doGetAuthenticationInfo (AuthenticationToken authcToken) throws AuthenticationException
    {
        String loginname = null;
        Object credentials = null;
        boolean passwdCredentials = false;
        if (authcToken != null && authcToken instanceof OAuth2Token)
        {
            OAuth2Token upToken = (OAuth2Token) authcToken;
            loginname = (String) upToken.getPrincipal ();
            credentials = upToken.getCredentials ();
            validateToken (loginname, (String) upToken.getCredentials ());
        }
        else
        {
            UsernamePasswordToken upToken = (UsernamePasswordToken) authcToken;
            loginname = (String) upToken.getUsername ();
            passwdCredentials = true;
        }
        LOGGER.info ("Shiro开始登录认证");
        User user = userService.findUserByLoginName (loginname);
        // 账号不存在
        if (user == null)
        {
            return null;
        }
        
        // 后面根据用户id查询
        List <Long> roleList = roleService.findRoleIdListByUserId (user.getId ());
        ShiroUser shiroUser = new ShiroUser (user.getId (), user.getLoginname (), user.getName (), roleList);
        
        if (passwdCredentials)
        {
            credentials = user.getPassword ().toCharArray ();
        }
        // 认证缓存信息
        return new SimpleAuthenticationInfo (shiroUser, credentials, getName ());
        
    }
    
    private void validateToken (String username, String token) throws OAuth2AuthenticationException
    {
        String ssoResult = "";
        try
        {
            
            String paramStr = assemblePostDataJsonStr (username, token);
            String authzUrl = ConfigHolder.getCfg ("AUTH_CENTER_URL");
            String o = RESTClient.getInstance ().callBack (authzUrl, paramStr);
            JSONObject jsonObject = JSONObject.parseObject (o);
            if (null == o)
            {
                //若鉴权失败用之前的用户提示
                //鉴权中心鉴权失败会设置密码次数
                throw new UnknownAccountException ("oauth user fail!");
            }
            ssoResult = jsonObject.getString ("access_token");
        }
        catch (Exception e)
        {
            LOGGER.error ("Invalid access_token: {}", token);
        }
        
        if (StringUtils.isBlank (ssoResult))
        {
            LOGGER.error ("Invalid access_token: {}, because it is expired", token);
            throw new OAuth2AuthenticationException ("Invalid access_token: " + token);
        }
    }
    
    /**
     *   client_id=report&client_secret=report&grant_type=sso_token
     *   &sso_token=b36f4978-a172-4aa8-af89-60f58abe3ba1&scope=read,write&username=mobile
     * @param username
     * @param password
     * @return
     */
    public String assemblePostDataJsonStr (String username, String token)
    {
        
        String clientId = ConfigHolder.getCfg ("AUTH_CENTER_CLIENT");
        String clientSecret = ConfigHolder.getCfg ("AUTH_CENTER_SECERT");
        ;
        StringBuffer sb = new StringBuffer ();
        sb.append ("client_id=").append (clientId).append ("&client_secret=").append (clientSecret)
            .append ("&grant_type=sso").append ("&sso_token=").append (token).append ("&scope=read").append ("&username=")
            .append (username);
        return sb.toString ().trim ();
    }
    
    /**
     * Shiro权限认证
     */
    @Override
    protected AuthorizationInfo doGetAuthorizationInfo (PrincipalCollection principals)
    {
        ShiroUser shiroUser = (ShiroUser) principals.getPrimaryPrincipal ();
        List <Long> roleList = shiroUser.getRoleList ();
        
        Set <String> urlSet = new HashSet <String> ();
        for (Long roleId : roleList)
        {
            List <String> roleResourceList = roleService.findResourcesByRoleId (roleId);
            if (CollectionUtils.isNotEmpty (roleResourceList))
            {
                urlSet.addAll (roleResourceList);
            }
        }
        SimpleAuthorizationInfo info = new SimpleAuthorizationInfo ();
        info.addStringPermissions (urlSet);
        return info;
    }
}
