package com.icss.ebu.ami.report.business.model;

import java.io.Serializable;
import java.util.List;

/**
 * 模型连接线
 * @author lvzhengtao
 *
 */
public class ConnectLine implements Serializable
{
    /**
     * 
     */
    private static final long serialVersionUID = -5915803310098844997L;
    
    private String source;
    
    private String target;
    
    // left join 
    private String label;
    
    private List <TableAssociation> fieldList;
    
    public String getSource ()
    {
        return source;
    }
    
    public void setSource (String source)
    {
        this.source = source;
    }
    
    public String getTarget ()
    {
        return target;
    }
    
    public void setTarget (String target)
    {
        this.target = target;
    }
    
    public String getLabel ()
    {
        return label;
    }
    
    public void setLabel (String label)
    {
        this.label = label;
    }
    
    public List <TableAssociation> getFieldList ()
    {
        return fieldList;
    }
    
    public void setFieldList (List <TableAssociation> fieldList)
    {
        this.fieldList = fieldList;
    }
    
}
