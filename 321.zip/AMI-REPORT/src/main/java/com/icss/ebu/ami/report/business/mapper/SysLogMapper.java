package com.icss.ebu.ami.report.business.mapper;

import java.util.List;

import com.icss.ebu.ami.commons.pagePlugin.Page;
import com.icss.ebu.ami.commons.util.PageInfo;
import com.icss.ebu.ami.report.system.model.SysLog;
import com.icss.ebu.ami.report.system.model.SysLogBean;

public interface SysLogMapper
{
    int deleteByPrimaryKey (Long id);
    
    int insert (SysLog record);
    
    int insertSelective (SysLog record);
    
    SysLog selectByPrimaryKey (Long id);
    
    List findDataGrid (PageInfo pageInfo);
    
    int findDataGridCount (PageInfo pageInfo);
    
    List <SysLogBean> findSysLogByPage (Page <SysLogBean> page);
    
    int deleteByHisLogByKey (Long id);
    
    int insertList (List <SysLog> records);
}