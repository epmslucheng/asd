package com.icss.ebu.ami.report.business.common.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;

import com.alibaba.druid.pool.DruidDataSource;
import com.icss.ebu.ami.report.business.model.DataSourceBean;
import com.icss.ebu.ami.report.system.core.task.DataSourceThreadCache;

public class JDBCTemplateUtil
{
    
    private static final Logger LOGGER = LoggerFactory.getLogger (JDBCTemplateUtil.class);
    
    public static JdbcTemplate getJDBC(String id){
        
        DruidDataSource ds = DataSourceThreadCache.getCache(id);
        if(null!=ds){
            
            JdbcTemplate jc = new JdbcTemplate(ds);
            return jc;
        }else{
            LOGGER.error("ds is NULL");
            return null;
        }
    }
    
    /**
     * 组装 druidDataSource 数据
     * @param dsBean
     * @return
     */
    public static DruidDataSource pacakageDataSource(DataSourceBean dsBean){
        DruidDataSource ds = new DruidDataSource();
        /*
        * 基本属性
        */
        
        if("01".equals(dsBean.getDbType())){
            ds.setDriverClassName("oracle.jdbc.driver.OracleDriver");
        }
        
        if("02".equals(dsBean.getDbType())){
            ds.setDriverClassName("com.mysql.jdbc.Driver");
        }
        
        ds.setUrl(dsBean.getUrl());
        ds.setUsername(dsBean.getDbName());
        ds.setPassword(dsBean.getDbPwd());
        /*
        * 配置初始化大小、最小、最
        */
        ds.setInitialSize(1);
        ds.setMinIdle(1);
        ds.setMaxActive(10);
        /*
        * 配置获取连接等待超时的时间 
        */
        ds.setMaxWait(60000);
        /*
        * 配置间隔多久才进行一次检测，检测需要关闭的空闲连接，单位是毫秒 
        */
        ds.setTimeBetweenEvictionRunsMillis(60000);
        /*
        * 配置一个连接在池中最小生存的时间，单位是毫秒
        */
        ds.setMinEvictableIdleTimeMillis(300000);

        ds.setValidationQuery("SELECT 1 FROM DUAL");
        ds.setTestWhileIdle(true);
        ds.setTestOnBorrow(false);
        ds.setTestOnReturn(false);

        /*
        * 打开PSCache，并且指定每个连接上PSCache的大小 
        */
        ds.setPoolPreparedStatements(false);;
        ds.setMaxPoolPreparedStatementPerConnectionSize(20);
        
        return ds;
    }
}
