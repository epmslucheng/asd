package com.icss.ebu.ami.report.business.common.util;

import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * TaskScheduleUtils
 * 
 * @author tfl
 * 
 */
public class TaskScheduleUtils
{

	private TaskScheduleUtils() {
	    throw new IllegalStateException("Utility class");
	}
    private static Logger log = LoggerFactory.getLogger (TaskScheduleUtils.class);
    
    private static ThreadPoolExecutor taskPools = null;
    
    public synchronized static void initPools ()
    {
        if (taskPools == null)
        {
            taskPools = new ThreadPoolExecutor (10, 30, 2, TimeUnit.SECONDS, new LinkedBlockingQueue <Runnable> (800));
        }
    }
    
    public static void excTask (Runnable collTask)
    {
        if (taskPools == null)
        {
            initPools ();
        }
        try
        {
            taskPools.submit (collTask);
        }
        catch (RejectedExecutionException re)
        {
        	log.error ("too much coll task ： ", re);
        }
        catch (Exception e)
        {
        	log.error ("taskPools submit task exception ", e);
        }
    }
    
}
