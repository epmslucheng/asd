package com.icss.ebu.ami.report.business.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.icss.ebu.ami.commons.util.ShareServiceId;
import com.icss.ebu.ami.report.business.service.UserService;
import com.icss.ebu.ami.report.system.common.util.JsonUtil;
import com.icss.ebu.ami.report.system.model.User;
import com.icss.ebu.ami.report.system.model.UserAll;

/** 
* @author  zhangkaining 
* @date 2018年5月15日 上午9:23:59 
* @version 1.0   
*/

@Controller
@RequestMapping ("/interface")
public class InterfaceController extends BaseController
{
    @Autowired
    private UserService userService;
    
    @RequestMapping ("/synchronize")
    @ResponseBody
    public Object synchronize(HttpServletRequest request)
    {
        UserAll userAll = (UserAll) JsonUtil.JSONToObj((String) request.getParameterNames().nextElement(), UserAll.class);
        
        User findUser = null;
        userAll.setUsertype(1);
        userAll.setSourceUsername(userAll.getLoginname());
        userAll.setSourceUserid(userAll.getId());
        userAll.setSourceSystem("EPMS");
        userAll.setId(ShareServiceId.generateUUID() + "");
        boolean b = true;
        
        while(b)
        {
            findUser = userService.findUserByLoginName(userAll.getLoginname());
            if(findUser != null)
            {
                userAll.setLoginname(userAll.getLoginname() + "1");
            }
            else
            {
                b = false;
            }
        }
        userService.insertSelective(userAll);
        
        return renderSuccess();
    }
    
    @RequestMapping ("/delete")
    @ResponseBody
    public Object delete(HttpServletRequest request)
    {
        User user = (User) JsonUtil.JSONToObj((String) request.getParameterNames().nextElement(), User.class);
        
        userService.deleteUserBySourceUserid(user.getId());
        
        return renderSuccess();
    }
}
