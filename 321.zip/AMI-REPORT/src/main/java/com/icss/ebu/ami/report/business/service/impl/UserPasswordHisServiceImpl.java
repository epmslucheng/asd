package com.icss.ebu.ami.report.business.service.impl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.icss.ebu.ami.commons.util.UUIDUtils;
import com.icss.ebu.ami.report.business.mapper.UserPasswordHisMapper;
import com.icss.ebu.ami.report.business.service.UserPasswordHisService;
import com.icss.ebu.ami.report.system.model.UserPasswordHis;

@Service
public class UserPasswordHisServiceImpl implements UserPasswordHisService
{
    
    @Autowired
    private UserPasswordHisMapper userPasswordHisMapper;
    
    @Override
    public int insert (String userId, String password)
    {
        UserPasswordHis userPwd = new UserPasswordHis ();
        userPwd.setId (UUIDUtils.generate16Long ());
        userPwd.setUserId (userId);
        userPwd.setPassword (password);
        userPwd.setUpdateTime (new Date ());
        return userPasswordHisMapper.insert (userPwd);
    }
    
    @Override
    public int deleteById (Long id)
    {
        return userPasswordHisMapper.deleteById (id);
    }
    
    @Override
    public int deleteByUserId (String userId)
    {
        return userPasswordHisMapper.deleteByUserId (userId);
    }
    
    @Override
    public List <UserPasswordHis> findUserPasswordByUserId (String userId)
    {
        return userPasswordHisMapper.findUserPasswordByUserId (userId);
    }
    
}
