package com.icss.ebu.ami.report.business.service.impl;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.icss.ebu.ami.commons.pagePlugin.Page;
import com.icss.ebu.ami.commons.util.I18nUtils;
import com.icss.ebu.ami.commons.util.ServiceUtils;
import com.icss.ebu.ami.report.business.common.constant.SqlConstant;
import com.icss.ebu.ami.report.business.common.util.SqlUtils;
import com.icss.ebu.ami.report.business.mapper.CustomDataSetMapper;
import com.icss.ebu.ami.report.business.mapper.DataSourceMapper;
import com.icss.ebu.ami.report.business.model.DataSet;
import com.icss.ebu.ami.report.business.model.DataSourceTable;
import com.icss.ebu.ami.report.business.model.DataSourceTableFiled;
import com.icss.ebu.ami.report.business.model.Function;
import com.icss.ebu.ami.report.business.model.SqlObject;
import com.icss.ebu.ami.report.business.service.CustomDataSetService;

@Service
public class CustomDataSetServiceImpl implements CustomDataSetService
{
    private static Logger LOGGER = LoggerFactory.getLogger (CustomDataSetServiceImpl.class);
    
    @Autowired
    private CustomDataSetMapper customDataSetMapper;
    
    @Autowired
    private DataSourceMapper dataSourceMapper;
    
    @Override
    public Page <DataSet> findCustomDataSets (Page <DataSet> page)
    {
        
        List <DataSet> list = customDataSetMapper.findCustomDataSets (page);
        try
        {
            for (DataSet dataSet : list)
            {
                if (SqlConstant.DATASET_MULTI_TABLE_ASSOCIATION.equals (dataSet.getQueryType ()))
                {
                    
                    SqlObject sqlObject = SqlUtils.generateSqlObjectByJson (dataSet.getSqlJson ());
                    if (null != sqlObject)
                    {
                        dataSet.setTableModels (sqlObject.getTableModels ());
                        dataSet.setColTree (sqlObject.getSqlColumns ());
                        dataSet.setSqlWhere (sqlObject.getSqlWhere ());
                        //dataSet.setTableAssociationList (sqlObject.getTableAssociationList ());
                    }
                }
            }
            
        }
        catch (Exception e)
        {
            LOGGER.error ("assemble sql model error.", e);
        }
        page.setResults (list);
        
        return page;
    }
    
    @Override
    public int addDataSet (DataSet dataSet)
    {
        int result = 0;
        try
        {
            dataSet.setCreateTime (new Date ());
            dataSet.setMaxRow (10);
            dataSet.setIsPublish (1);
            result = customDataSetMapper.addDataSet (dataSet);
        }
        catch (Exception e)
        {
            LOGGER.error ("add data set error.", e);
        }
        return result;
    }
    
    @Override
    public int editDataSet (DataSet dataSet)
    {
        int result = 0;
        try
        {
            dataSet.setUpdateTime (new Date ());
            result = customDataSetMapper.editDataSet (dataSet);
        }
        catch (Exception e)
        {
            LOGGER.error ("edit data set error.", e);
        }
        
        return result;
    }
    
    @Override
    public DataSet findCustomDataSetById (String id)
    {
        return customDataSetMapper.findCustomDataSetById (id);
    }
    
    @Override
    public int delete (DataSet dataSet)
    {
        
        int result = 0;
        try
        {
            result = customDataSetMapper.delete (dataSet);
        }
        catch (Exception e)
        {
            LOGGER.error ("edit data set error.", e);
        }
        return result;
    }
    
    @Override
    public List <DataSet> queryAll ()
    {
        return customDataSetMapper.queryAll ();
    }
    
    @Override
    public List <Function> findAllFunction ()
    {
        return customDataSetMapper.findAllFunction ();
    }
    
    @Override
    public int insetDataSetCols (List <DataSourceTableFiled> list)
    {
        int result = 0;
        try
        {
            result = customDataSetMapper.insetDataSetCols (list);
        }
        catch (Exception e)
        {
            LOGGER.error ("inset data set cols error.", e);
        }
        return result;
    }
    
    @Override
    public int deleteDataSetCols (DataSourceTable dsb)
    {
        int result = 0;
        try
        {
            result = customDataSetMapper.deleteDataSetCols (dsb);
        }
        catch (Exception e)
        {
            LOGGER.error ("delete data set cols error.", e);
        }
        return result;
    }
    
    @Override
    public String analyseAddContent (DataSet dataSet)
    {
        if (dataSet == null)
        {
            return "data set is empty";
        }
        StringBuilder addSb = new StringBuilder ();
        ServiceUtils.addPropContent (I18nUtils.getI18nMsg ("ami.dataSource.title"), dataSet.getCnnId (), addSb);
        ServiceUtils.addPropContent (I18nUtils.getI18nMsg ("ami.dataset.name"), dataSet.getQueryName (), addSb);
        ServiceUtils.addPropContent (I18nUtils.getI18nMsg ("ami.dataset.key"), dataSet.getKey (), addSb);
        ServiceUtils.addPropContent (I18nUtils.getI18nMsg ("ami.dataset.sql"), dataSet.getQuerySql (), addSb);
        if (addSb.length () > 1)
        {
            addSb.setLength (addSb.length () - 1);
        }
        return addSb.toString ();
    }
    
    @Override
    public String analyseEditContent (DataSet oldDataSet, DataSet newdataSet)
    {
        if (oldDataSet == null)
        {
            return "old data set is empty";
        }
        StringBuilder updateSb = new StringBuilder ();
        ServiceUtils.compareChange (I18nUtils.getI18nMsg ("ami.dataSource.title"), oldDataSet.getCnnId (),
            newdataSet.getCnnId (), updateSb);
        ServiceUtils.compareChange (I18nUtils.getI18nMsg ("ami.dataset.name"), oldDataSet.getQueryName (),
            newdataSet.getQueryName (), updateSb);
        ServiceUtils.compareChange (I18nUtils.getI18nMsg ("ami.dataset.key"), oldDataSet.getKey (), newdataSet.getKey (),
            updateSb);
        ServiceUtils.compareChange (I18nUtils.getI18nMsg ("ami.dataset.sql"), oldDataSet.getQuerySql (),
            newdataSet.getQuerySql (), updateSb);
        
        if (updateSb.length () > 1)
        {
            updateSb.setLength (updateSb.length () - 1);
        }
        return updateSb.toString ();
    }
    
    @Override
    public String analyseDelContent (DataSet dataSet)
    {
        if (dataSet == null)
        {
            return "data set is empty";
        }
        StringBuilder delSb = new StringBuilder ();
        ServiceUtils.addPropContent (I18nUtils.getI18nMsg ("ami.dataset.name"), dataSet.getQueryName (), delSb);
        if (delSb.length () > 1)
        {
            delSb.setLength (delSb.length () - 1);
        }
        return delSb.toString ();
    }
    
    @Override
    public String analyseTestContent (DataSet dataSet)
    {
        if (dataSet == null)
        {
            return "data set is empty";
        }
        StringBuilder addSb = new StringBuilder ();
        ServiceUtils.addPropContent (I18nUtils.getI18nMsg ("ami.dataSource.title"), dataSet.getCnnId (), addSb);
        ServiceUtils.addPropContent (I18nUtils.getI18nMsg ("ami.dataset.sql"), dataSet.getQuerySql (), addSb);
        if (addSb.length () > 1)
        {
            addSb.setLength (addSb.length () - 1);
        }
        return addSb.toString ();
    }
    
}
