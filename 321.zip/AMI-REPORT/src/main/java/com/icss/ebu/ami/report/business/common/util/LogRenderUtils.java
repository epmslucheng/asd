package com.icss.ebu.ami.report.business.common.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;

import org.apache.commons.io.IOUtils;
import org.codehaus.jettison.json.JSONException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.icss.ebu.ami.commons.util.ServiceUtils;

/**
 * 日志描述文件读取
 * 
 * @author tfl
 * @date 2016.12.24
 * @version v1.0
 */
public final class LogRenderUtils
{
    private static final Logger LOGGER = LoggerFactory.getLogger (LogRenderUtils.class);
    
    private static final String LOG_DESC_DIR = "logDesc";
    
    private static final String LOG_DESC_REQ = "_req.properties";
    
    private static final String LOG_DESC_PARAM = "_param.properties";
    
    // 配置文件
    private static Map <String, String> logReqMap = new HashMap <String, String> ();
    
    private static Map <String, Map <String, String>> logParamMap = new HashMap <String, Map <String, String>> ();
    
    private LogRenderUtils ()
    {
        
    }
    
    public static void initLogDescMap ()
    {
        try
        {
            String filePath = Thread.currentThread ().getContextClassLoader ().getResource (File.separator).getPath ();
            
            File f = new File (filePath + LOG_DESC_DIR);
            readAllProperties (f);
        }
        catch (Exception e)
        {
            LOGGER.error ("read log description properties error : ", e);
        }
    }
    
    /**
     * 读取配置文件 并保存到系map中
     * 
     * @param map
     * @param inputStream
     * @throws IOException
     */
    public static void putReqProperties (Map <String, String> map, InputStream inputStream) throws IOException
    {
        Properties p = new Properties ();
        try
        {
            p.load (inputStream);
            for (Entry <Object, Object> entry : p.entrySet ())
            {
                map.put ((String) entry.getKey (), (String) entry.getValue ());
            }
        }
        finally
        {
            p.clear ();
            IOUtils.closeQuietly (inputStream);
        }
    }
    
    /**
     * 读取配置文件 并保存到系map中
     * 
     * @param map
     * @param inputStream
     * @throws IOException
     * @throws JSONException
     */
    public static void putParamProperties (Map <String, Map <String, String>> map, InputStream inputStream)
        throws IOException, JSONException
    {
        Properties p = new Properties ();
        try
        {
            p.load (inputStream);
            for (Entry <Object, Object> entry : p.entrySet ())
            {
                
                map.put ((String) entry.getKey (), ServiceUtils.jsonStrToMap ((String) entry.getValue ()));
            }
        }
        finally
        {
            p.clear ();
            IOUtils.closeQuietly (inputStream);
        }
    }
    
    /**
     * 读取配置文件
     * 
     * @param file
     * @throws IOException
     * @throws JSONException
     */
    private static void readAllProperties (File file) throws FileNotFoundException, IOException, JSONException
    {
        if (file == null)
        {
            return;
        }
        
        if (file.isDirectory ())
        {
            File[] files = file.listFiles ();
            if (files == null)
            {
                return;
            }
            
            for (File sf : files)
            {
                if (sf.isDirectory ())
                {
                    readAllProperties (sf);
                }
                else
                {
                    readProperties (sf);
                }
            }
        }
        else
        {
            readProperties (file);
        }
    }
    
    /**
     * 读取配置文件
     * 
     * @param file
     * @throws IOException
     * @throws JSONException
     */
    private static void readProperties (File file) throws FileNotFoundException, IOException, JSONException
    {
        String fileName = file.getName ();
        if (fileName.endsWith (LOG_DESC_PARAM))
        {
            putParamProperties (logParamMap, new FileInputStream (file));
        }
        else if (fileName.endsWith (LOG_DESC_REQ))
        {
            putReqProperties (logReqMap, new FileInputStream (file));
        }
    }
    
    /**
     * 获取配置项
     */
    public static String getLogReqMap (String key)
    {
        return logReqMap.get (key);
    }
    
    /**
     * 获取配置项
     */
    public static Map <String, String> getLogParamMap (String key)
    {
        return logParamMap.get (key);
    }
}
