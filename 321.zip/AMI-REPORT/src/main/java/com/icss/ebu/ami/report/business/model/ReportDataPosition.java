package com.icss.ebu.ami.report.business.model;

import java.io.Serializable;

/** 
* @author  zhangkaining 
* @date 2017年11月1日 下午2:17:10 
* @version 1.0   
*/
public class ReportDataPosition implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5191615182205170810L;
	
	
	/**
	 * 数据id
	 */
	private String dataid;
	
	/**
	 * 模板id
	 */
	private String tmpid;
	
	/**
	 * 数据名
	 */
	private String dataname;
	
	/**
	 * sheet页
	 */
	private String sheetname;
	
	/**
	 * 位置
	 */
	private String position;

	public String getDataid() {
		return dataid;
	}

	public void setDataid(String dataid) {
		this.dataid = dataid;
	}

	public String getTmpid() {
		return tmpid;
	}

	public void setTmpid(String tmpid) {
		this.tmpid = tmpid;
	}

	public String getDataname() {
		return dataname;
	}

	public void setDataname(String dataname) {
		this.dataname = dataname;
	}

	public String getSheetname() {
		return sheetname;
	}

	public void setSheetname(String sheetname) {
		this.sheetname = sheetname;
	}

	public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}
	
	

}
