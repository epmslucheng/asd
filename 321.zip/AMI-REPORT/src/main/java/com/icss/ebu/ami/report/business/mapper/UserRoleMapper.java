package com.icss.ebu.ami.report.business.mapper;

import java.util.List;

import com.icss.ebu.ami.commons.aspect.Param;
import com.icss.ebu.ami.report.system.model.UserRole;

public interface UserRoleMapper
{
    
    int insert (UserRole userRole);
    
    int updateByPrimaryKeySelective (UserRole userRole);
    
    int deleteById (Long id);
    
    //@RedisCache(key="'findUserRoleByUserId_'+#userId",expire = -1,fieldKey="userrole",nameSpace="portal")
    List <UserRole> findUserRoleByUserId (String userId);
    
    List <Long> findRoleIdListByUserId (String userId);
    
    //@RedisCache(key="'findUserIdListByRoleId_'+#userId",expire = -1,fieldKey="userrole",nameSpace="portal")
    List <String> findUserIdListByRoleId (@Param ("userId") Long userId);
}