package com.icss.ebu.ami.report.system.core.task;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;

import com.icss.ebu.ami.commons.util.GeneralUtils;
import com.icss.ebu.ami.commons.util.UUIDUtils;
import com.icss.ebu.ami.report.business.common.util.JDBCTemplateUtil;
import com.icss.ebu.ami.report.business.mapper.DataSourceMapper;
import com.icss.ebu.ami.report.business.model.DataSourceBean;
import com.icss.ebu.ami.report.business.model.DataSourceTable;
import com.icss.ebu.ami.report.business.model.DataSourceTableFiled;

public class DataSourceTableTask implements Runnable
{
    private static final Logger log = LoggerFactory.getLogger (DataSourceTableTask.class);
    
    private DataSourceMapper dataSourceMapper;
    
    private String dataSourceId;
    
    private String type;
    
    public DataSourceTableTask (String dataSourceId, String type, DataSourceMapper dataSourceMapper)
    {
        super ();
        this.dataSourceId = dataSourceId;
        this.type = type;
        this.dataSourceMapper = dataSourceMapper;
    }
    
    @Override
    public void run ()
    {
        //根据数据源  查询所有表和视图 以及字段
        
        DataSourceBean ds = dataSourceMapper.getDataSourceById (dataSourceId);
        
        if (null != ds)
        {
            
            //区分是新增还是修改
            
            if ("update".equals (type))
            {
                // TODO
                // FIXME   待完善               不删除指标生成的 表和字段
                //先删除
                //删除 表中字段
                dataSourceMapper.delDataSourceTableFiledById (dataSourceId);
                //删除 表
                dataSourceMapper.delDataSourceTableById (dataSourceId);
            }
            
            JdbcTemplate jc = JDBCTemplateUtil.getJDBC (ds.getId ());
            
            if (null == jc)
            {
                log.error ("JdbcTemplate 获取失败");
            }
            else
            {
                if ("01".equals (ds.getDbType ()))
                {
                    List <DataSourceTable> dsTableList = new ArrayList<> ();
                    DataSourceTable dsb = null;
                    //                    //查询所有表 
                    //                    String tableSql = "SELECT A.TABLE_NAME FROM DBA_TABLES A WHERE A.OWNER =  '" + ds.getDbName () + "'";
                    //                    
                    //                    List <Map <String, Object>> tableList = jc.queryForList (tableSql);
                    //                    
                    //                    Map <String, Object> tableMap = null;
                    //                    
                    //                    for (int i = 0; i < tableList.size (); i++)
                    //                    {
                    //                        tableMap = tableList.get (i);
                    //                        dsb = new DataSourceTable ();
                    //                        dsb.setId (dataSourceId);
                    //                        dsb.setTableId (UUIDUtils.generate16Str ());
                    //                        dsb.setTableName ((String) tableMap.get ("TABLE_NAME"));
                    //                        dsb.setTableType ("table");
                    //                        dsTableList.add (dsb);
                    //                    }
                    //                    
                    //                    //查询所有视图 
                    //                    String viewSql = "SELECT * FROM DBA_VIEWS A WHERE A.OWNER =   '" + ds.getDbName () + "'";
                    //                    
                    //                    List <Map <String, Object>> viewList = jc.queryForList (viewSql);
                    //                    Map <String, Object> viewMap = null;
                    //                    for (int i = 0; i < viewList.size (); i++)
                    //                    {
                    //                        viewMap = viewList.get (i);
                    //                        dsb = new DataSourceTable ();
                    //                        dsb.setId (dataSourceId);
                    //                        dsb.setTableId (UUIDUtils.generate16Str ());
                    //                        dsb.setTableName ((String) viewMap.get ("VIEW_NAME"));
                    //                        dsb.setTableType ("view");
                    //                        dsTableList.add (dsb);
                    //                    }
                    //                    
                    //                    //将表和视图插入数据库中
                    //                    try
                    //                    {
                    //                        dataSourceMapper.addDataSourceTable (dsTableList);
                    //                    }
                    //                    catch (Exception e)
                    //                    {
                    //                        log.error (e.getMessage ());
                    //                    }
                    
                    List <DataSourceTableFiled> dsTableFiledList = new ArrayList<> ();
                    //表 字段
                    Map <String, Object> filedMap = null;
                    String tableFiledSql =
                        "SELECT C.TABLE_NAME,C.COLUMN_NAME  FROM DBA_COL_COMMENTS C ,DBA_TABLES A where  A.TABLE_NAME = C.TABLE_NAME AND A.OWNER = '"
                            + ds.getDbName () + "' AND C.OWNER = '" + ds.getDbName () + "'";
                    
                    List <Map <String, Object>> filedList = jc.queryForList (tableFiledSql);
                    
                    DataSourceTableFiled dstf = null;
                    
                    //表名和 id
                    Map <String, String> tableNameMap = new HashMap<> ();
                    
                    for (int i = 0; i < filedList.size (); i++)
                    {
                        filedMap = filedList.get (i);
                        if (!tableNameMap.containsKey ((String) filedMap.get ("TABLE_NAME")))
                        {
                            //封装数据表对象
                            dsb = new DataSourceTable ();
                            dsb.setId (dataSourceId);
                            dsb.setTableId (UUIDUtils.generate16Str ());
                            dsb.setTableName ((String) filedMap.get ("TABLE_NAME"));
                            dsb.setTableType ("table");
                            dsTableList.add (dsb);
                            
                            tableNameMap.put (dsb.getTableName (), dsb.getTableId ());
                        }
                        
                        dstf = new DataSourceTableFiled ();
                        dstf.setId (dataSourceId);
                        dstf.setFiledId (UUIDUtils.generate16Str ());
                        dstf.setTableName ((String) filedMap.get ("TABLE_NAME"));
                        dstf.setTableType ("table");
                        dstf.setTableFiled ((String) filedMap.get ("COLUMN_NAME"));
                        dstf.setTableFiledSql (
                            (String) filedMap.get ("TABLE_NAME") + "." + (String) filedMap.get ("COLUMN_NAME"));
                        dstf.setTableFiledAlias ((String) filedMap.get ("COLUMN_NAME"));
                        
                        dstf.setTableId (tableNameMap.get ((String) filedMap.get ("TABLE_NAME")));
                        dsTableFiledList.add (dstf);
                    }
                    
                    //
                    Map <String, Object> viewFiledMap = null;
                    String viewFiledSql =
                        "SELECT C.TABLE_NAME,C.COLUMN_NAME  FROM DBA_COL_COMMENTS C ,DBA_VIEWS A where  A.VIEW_NAME = C.TABLE_NAME AND A.OWNER = '"
                            + ds.getDbName () + "'  AND C.OWNER ='" + ds.getDbName () + "'";
                    
                    List <Map <String, Object>> viewFiledList = jc.queryForList (viewFiledSql);
                    
                    for (int i = 0; i < viewFiledList.size (); i++)
                    {
                        viewFiledMap = viewFiledList.get (i);
                        dstf = new DataSourceTableFiled ();
                        dstf.setId (dataSourceId);
                        dstf.setFiledId (UUIDUtils.generate16Str ());
                        dstf.setTableName ((String) viewFiledMap.get ("TABLE_NAME"));
                        dstf.setTableType ("view");
                        dstf.setTableFiled ((String) viewFiledMap.get ("COLUMN_NAME"));
                        dstf.setTableFiledSql (
                            (String) viewFiledMap.get ("TABLE_NAME") + "." + (String) viewFiledMap.get ("COLUMN_NAME"));
                        dstf.setTableFiledAlias ((String) viewFiledMap.get ("COLUMN_NAME"));
                        dsTableFiledList.add (dstf);
                    }
                    
                    //将表和视图插入数据库中
                    try
                    {
                        dataSourceMapper.addDataSourceTable (dsTableList);
                    }
                    catch (Exception e)
                    {
                        log.error (e.getMessage ());
                    }
                    
                    //将表和视图的字段插入数据库中
                    try
                    {
                        List <List <DataSourceTableFiled>> list = GeneralUtils.createList (dsTableFiledList, 1000);
                        for (int i = 0; i < list.size (); i++)
                        {
                            dataSourceMapper.addDataSourceTableFiled (list.get (i));
                        }
                    }
                    catch (Exception e)
                    {
                        log.error (e.getMessage ());
                    }
                }
                
                if ("02".equals (ds.getDbType ()))
                {
                    // 从URL解析 schema
                    String url = ds.getUrl ();
                    String schema = "";
                    if (StringUtils.isNotEmpty (url))
                    {
                        schema = url.substring (url.lastIndexOf ("/") + 1, url.length ());
                    }
                    
                    if (StringUtils.isNotEmpty (schema))
                    {
                        List <DataSourceTable> dsTableList = new ArrayList<> ();
                        DataSourceTable dsb = null;
                        //查询所有表 和视图
                        //                        String tableSql =
                        //                            "SELECT table_name,table_type FROM information_schema.TABLES WHERE TABLE_SCHEMA='" + schema + "'";
                        //                        
                        //                        List <Map <String, Object>> tableList = jc.queryForList (tableSql);
                        //                        
                        //                        Map <String, Object> tableMap = null;
                        //                        
                        //                        Set <String> tableSet = new HashSet<> ();
                        //                        Set <String> viewSet = new HashSet<> ();
                        //                        
                        //                        for (int i = 0; i < tableList.size (); i++)
                        //                        {
                        //                            tableMap = tableList.get (i);
                        //                            dsb = new DataSourceTable ();
                        //                            dsb.setId (dataSourceId);
                        //                            dsb.setTableId (UUIDUtils.generate16Str ());
                        //                            dsb.setTableName ((String) tableMap.get ("TABLE_NAME"));
                        //                            
                        //                            if ("view".equals ((String) tableMap.get ("TABLE_NAME")))
                        //                            {
                        //                                dsb.setTableType ("view");
                        //                                dsTableList.add (dsb);
                        //                                viewSet.add ((String) tableMap.get ("TABLE_NAME"));
                        //                            }
                        //                            else
                        //                            {
                        //                                
                        //                                dsb.setTableType ("table");
                        //                                dsTableList.add (dsb);
                        //                                tableSet.add ((String) tableMap.get ("TABLE_NAME"));
                        //                            }
                        //                        }
                        //                        
                        //                        }
                        //                        
                        //                        //将表和视图插入数据库中
                        //                        try
                        //                        {
                        //                            dataSourceMapper.addDataSourceTable (dsTableList);
                        //                        }
                        //                        catch (Exception e)
                        //                        {
                        //                            log.error (e.getMessage ());
                        //                        }
                        //                        
                        List <DataSourceTableFiled> dsTableFiledList = new ArrayList<> ();
                        
                        //表 字段
                        Map <String, Object> filedMap = null;
                        String tableFiledSql =
                            "SELECT t.TABLE_TYPE , c.TABLE_NAME,c.COLUMN_NAME FROM  information_schema.TABLES t,information_schema.COLUMNS c "
                                + "WHERE t.TABLE_SCHEMA = c.TABLE_SCHEMA  and t.TABLE_NAME = c.TABLE_NAME  and t.table_schema ='"
                                + schema + "'";
                        
                        List <Map <String, Object>> filedList = jc.queryForList (tableFiledSql);
                        
                        DataSourceTableFiled dstf = null;
                        //表名和 id
                        Map <String, String> tableNameMap = new HashMap<> ();
                        Map <String, String> viewNameMap = new HashMap<> ();
                        for (int i = 0; i < filedList.size (); i++)
                        {
                            filedMap = filedList.get (i);
                            dstf = new DataSourceTableFiled ();
                            dstf.setId (dataSourceId);
                            dstf.setFiledId (UUIDUtils.generate16Str ());
                            dstf.setTableName ((String) filedMap.get ("TABLE_NAME"));
                            dstf.setTableFiled ((String) filedMap.get ("COLUMN_NAME"));
                            dstf.setTableFiledSql (
                                (String) filedMap.get ("TABLE_NAME") + "." + (String) filedMap.get ("COLUMN_NAME"));
                            dstf.setTableFiledAlias ((String) filedMap.get ("COLUMN_NAME"));
                            
                            if ("BASE TABLE".equals (filedMap.get ("TABLE_TYPE")))
                            {
                                if (!tableNameMap.containsKey ((String) filedMap.get ("TABLE_NAME")))
                                {
                                    //封装数据表对象
                                    dsb = new DataSourceTable ();
                                    dsb.setId (dataSourceId);
                                    dsb.setTableId (UUIDUtils.generate16Str ());
                                    dsb.setTableName ((String) filedMap.get ("TABLE_NAME"));
                                    dsb.setTableType ("table");
                                    dsTableList.add (dsb);
                                    
                                    tableNameMap.put (dsb.getTableName (), dsb.getTableId ());
                                }
                                dstf.setTableId (tableNameMap.get ((String) filedMap.get ("TABLE_NAME")));
                                dstf.setTableType ("table");
                            }
                            if ("VIEW".equals (filedMap.get ("TABLE_TYPE")))
                            {
                                if (!viewNameMap.containsKey ((String) filedMap.get ("TABLE_NAME")))
                                {
                                    //封装数据表对象
                                    dsb = new DataSourceTable ();
                                    dsb.setId (dataSourceId);
                                    dsb.setTableId (UUIDUtils.generate16Str ());
                                    dsb.setTableName ((String) filedMap.get ("TABLE_NAME"));
                                    dsb.setTableType ("view");
                                    dsTableList.add (dsb);
                                    
                                    viewNameMap.put (dsb.getTableName (), dsb.getTableId ());
                                }
                                dstf.setTableId (viewNameMap.get ((String) filedMap.get ("TABLE_NAME")));
                                dstf.setTableType ("view");
                            }
                            
                            dsTableFiledList.add (dstf);
                            //                            if (!tableNameMap.containsKey ((String) filedMap.get ("TABLE_NAME")))
                            //                            {
                            //                                //封装数据表对象
                            //                                dsb = new DataSourceTable ();
                            //                                dsb.setId (dataSourceId);
                            //                                dsb.setTableId (UUIDUtils.generate16Str ());
                            //                                dsb.setTableName ((String) filedMap.get ("TABLE_NAME"));
                            //                                dsb.setTableType ((String) filedMap.get ("TABLE_TYPE"));
                            //                                dsTableList.add (dsb);
                            //                                
                            //                                tableNameMap.put (dsb.getTableName (), dsb.getTableId ());
                            //                            }
                            //                            
                            //                            if (tableSet.contains ((String) filedMap.get ("TABLE_NAME")))
                            //                            {
                            //                                dstf.setTableType ("table");
                            //                                dstf.setTableFiled ((String) filedMap.get ("COLUMN_NAME"));
                            //                                dstf.setTableFiledSql (
                            //                                    (String) filedMap.get ("TABLE_NAME") + "." + (String) filedMap.get ("COLUMN_NAME"));
                            //                                dstf.setTableFiledAlias ((String) filedMap.get ("COLUMN_NAME"));
                            //                                
                            //                            }
                            //                            
                            //                            if (viewSet.contains ((String) filedMap.get ("TABLE_NAME")))
                            //                            {
                            //                                dstf.setTableType ("view");
                            //                                dstf.setTableFiled ((String) filedMap.get ("COLUMN_NAME"));
                            //                                dstf.setTableFiledSql (
                            //                                    (String) filedMap.get ("TABLE_NAME") + "." + (String) filedMap.get ("COLUMN_NAME"));
                            //                                dstf.setTableFiledAlias ((String) filedMap.get ("COLUMN_NAME"));
                            //                                
                            //                            }
                            //                            
                            //                            dsTableFiledList.add (dstf);
                        }
                        
                        //将表和视图插入数据库中
                        try
                        {
                            dataSourceMapper.addDataSourceTable (dsTableList);
                        }
                        catch (Exception e)
                        {
                            log.error (e.getMessage ());
                        }
                        
                        //将表和视图的字段插入数据库中
                        try
                        {
                            List <List <DataSourceTableFiled>> list = GeneralUtils.createList (dsTableFiledList, 1000);
                            for (int i = 0; i < list.size (); i++)
                            {
                                dataSourceMapper.addDataSourceTableFiled (list.get (i));
                            }
                        }
                        catch (Exception e)
                        {
                            log.error (e.getMessage ());
                        }
                    }
                    else
                    {
                        log.error ("mysql schema 解析失败");
                    }
                    
                }
            }
            
        }
        else
        {
            log.error ("查询不到数据源");
        }
        
    }
    
}
