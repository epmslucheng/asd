package com.icss.ebu.ami.report.business.controller;

import com.icss.ebu.ami.commons.pagePlugin.Page;
import com.icss.ebu.ami.commons.util.AesKeyUtils;
import com.icss.ebu.ami.report.business.common.constant.CommonConstant;
import com.icss.ebu.ami.report.business.common.util.PropertiesReader;
import com.icss.ebu.ami.report.business.service.SystemParameterService;
import com.icss.ebu.ami.report.system.model.SystemParameter;
import org.apache.commons.lang3.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping ("/systemParameter")
public class SystemParameterController extends BaseController
{
    private static final Logger LOGGER = LoggerFactory.getLogger (SystemParameterController.class);
    
    @Autowired
    private SystemParameterService systemParameterService;
    
    @RequestMapping ("")
    public String index ()
    {
        return "/service/systemParameter/systemParameter";
    }
    
    @RequestMapping ("/editPage")
    public String editPage ()
    {
        return "/service/systemParameter/systemParameterEdit";
    }
    
    @RequestMapping ("/personInfo")
    public String personInfo ()
    {
        return "/modal/personInfo";
    }
    
    @RequestMapping ("/datagrid")
    @ResponseBody
    public Map <String, Object> datagrid (SystemParameter systemParameter, HttpServletRequest request)
    {
        Map <String, Object> map = new HashMap <String, Object> ();
        Page <SystemParameter> page = new Page <SystemParameter> (systemParameter);
        page.setPageNo (NumberUtils.toInt (request.getParameter (CommonConstant.PAGE_PARAM_PAGE)));
        page.setPageSize (NumberUtils.toInt (request.getParameter (CommonConstant.PAGE_PARAM_ROWS)));
        
        page = systemParameterService.querySystemParameterByPage (page);
        List<SystemParameter> list = page.getResults ();
        for (SystemParameter s : list) {
            if (1 == s.getIsPassword ())
            {
                try
                {
                    s.setValue (AesKeyUtils.decrypt (s.getValue ().trim (), PropertiesReader.getUserPwdKey ()));
                }
                catch (IOException e)
                {
                    logger.error ("decrypt password error : ", e);
                }

            }
        }

        map.put (CommonConstant.PAGE_RESULT_ROWS, list);
        map.put (CommonConstant.PAGE_RESULT_TOTAL, page.getTotalRecord ());
        
        return map;
    }
    
    @RequestMapping ("/edit")
    @ResponseBody
    public Object edit (@RequestBody SystemParameter systemParameter)
    {
        
        try
        {
            if (systemParameter.getIsPassword () == 1)
            {
                systemParameter.setValue (AesKeyUtils.encrypt (systemParameter.getValue (), PropertiesReader.getUserPwdKey ()));
            }
            
            int rt = systemParameterService.editSystemParameter (systemParameter);
            if (rt == 1)
            {
                return renderSuccess (super.getProperty ("ami.common.optSuccess"));
            }
            else
            {
                return renderError (super.getProperty ("ami.common.optFail"));
            }
        }
        catch (Exception e)
        {
            LOGGER.error ("Edit SystemParameter Fail.", e);
            return renderError (super.getProperty ("ami.common.optFail"));
        }
    }
}
