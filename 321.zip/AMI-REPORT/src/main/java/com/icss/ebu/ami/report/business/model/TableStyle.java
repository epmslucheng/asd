package com.icss.ebu.ami.report.business.model;

import java.io.Serializable;

/**
 * 原型样式
 * 供后续拓展
 * @author lvzhengtao
 *
 */
public class TableStyle implements Serializable
{
    
    /**
     * 
     */
    private static final long serialVersionUID = -3291172601430619101L;
    
    private double top;
    
    private double left;
    
    public double getTop ()
    {
        return top;
    }
    
    public void setTop (double top)
    {
        this.top = top;
    }
    
    public double getLeft ()
    {
        return left;
    }
    
    public void setLeft (double left)
    {
        this.left = left;
    }
    
}
