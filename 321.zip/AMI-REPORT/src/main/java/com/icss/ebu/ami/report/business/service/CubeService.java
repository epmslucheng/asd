package com.icss.ebu.ami.report.business.service;

import java.util.List;

import com.icss.ebu.ami.commons.pagePlugin.Page;
import com.icss.ebu.ami.report.business.model.CubeBean;
import com.icss.ebu.ami.report.business.model.DataSourceTable;
import com.icss.ebu.ami.report.business.model.DataSourceTableFiled;
import com.icss.ebu.ami.report.business.model.Table;
import com.icss.ebu.ami.report.business.model.TableField;

/**
 * 立方service
 * @author xunan
 *
 */
public interface CubeService
{
    List <CubeBean> getAllCube ();
    
    List <CubeBean> getAllCubeByUserId (String userId);
    
    List <CubeBean> getCubeByDsId (String cnnid);
    
    /**
     * 获取立方
     * @return
     */
    Page <CubeBean> queryCubeList (Page <CubeBean> page);
    
    CubeBean getCubeById (String id);
    
    List <DataSourceTable> getCubeTableNameById (String id);
    
    void delCubeById (String id);
    
    void addCube (CubeBean Cube);
    
    void updateCube (CubeBean Cube);
    
    void editCube (CubeBean Cube);
    
    void getTableByCubeId (String id, String type);
    
    List <DataSourceTableFiled> getTableTreeByTable (DataSourceTable dataSourceTable);
    
    //更新字段别名
    void updateTableFiledAlias (DataSourceTableFiled dstf);
    
    List <CubeBean> getCubeByDsIdAndUser (CubeBean cube);
    
    /**
     * 根据数据源id和cubeName 查找Cube   数据集用
     * @param cube
     * @return
     */
    CubeBean getCubeByDsIdAndCubeName (CubeBean cube);
    
    List <Table> getTablesByCubeId (String cubeId);
    
    List <TableField> getFieldsByTable (Table table);
}
