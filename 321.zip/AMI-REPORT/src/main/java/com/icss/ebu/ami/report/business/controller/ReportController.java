package com.icss.ebu.ami.report.business.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.icss.ebu.ami.commons.constants.ConstantCode;
import com.icss.ebu.ami.commons.pagePlugin.Page;
import com.icss.ebu.ami.report.business.common.constant.CommonConstant;
import com.icss.ebu.ami.report.business.common.constant.ReportConstant;
import com.icss.ebu.ami.report.business.common.util.LogRenderUtils;
import com.icss.ebu.ami.report.business.model.Template;
import com.icss.ebu.ami.report.business.service.CustomDataSetService;
import com.icss.ebu.ami.report.business.service.LogService;
import com.icss.ebu.ami.report.business.service.ReportFileService;
import com.icss.ebu.ami.report.business.service.ReportService;
import com.icss.ebu.ami.report.business.service.TemplateManagementService;
import com.icss.ebu.ami.report.business.service.UserService;
import com.icss.ebu.ami.report.system.model.User;

/**
 * 报表生成
 * 
 * @author lucheng
 *
 */
@Controller
@RequestMapping ("/report")
public class ReportController extends BaseController
{
    private static final Logger LOGGER = LoggerFactory.getLogger (ReportController.class);
    
    @Autowired
    private ReportService reportService;
    
    @Autowired
    private TemplateManagementService templateManagementService;
    
    @Autowired
    private ReportFileService reportFileService;
    
    @Autowired
    private CustomDataSetService customDataSetService;
    
    @Autowired
    private UserService userService;
    
    @Autowired
    private LogService logService;
    
    @RequestMapping ("/index")
    public String index (HttpServletRequest request)
    {
        return "/service/report/report";
    }
    
    @RequestMapping ("/query")
    @ResponseBody
    public Object query (HttpServletRequest request)
    {
        Template template = new Template ();
        User currentUser = getCurrentUser ();
        if (!ReportConstant.REPORT_USERID_ROOT.equals (currentUser.getId ()))
        {
            template.setUserId (currentUser.getId ());
        }
        Page <Template> page = new Page <Template> (template);
        page.setPageNo (NumberUtils.toInt (request.getParameter (CommonConstant.PAGE_PARAM_PAGE)));
        page.setPageSize (NumberUtils.toInt (request.getParameter (CommonConstant.PAGE_PARAM_ROWS)));
        
        page = templateManagementService.queryTempDesignListByPage (page);
        Map <String, Object> map = new HashMap <String, Object> ();
        map.put (CommonConstant.PAGE_RESULT_ROWS, page.getResults ());
        map.put (CommonConstant.PAGE_RESULT_TOTAL, page.getTotalRecord ());
        return map;
        
    }
    
    @RequestMapping ("/gotoGenerateReport")
    public String gotoGenerateReport (HttpServletRequest request)
    {
        return "/service/report/reportGenerate";
    }
    
    @RequestMapping ("/generateReport")
    @ResponseBody
    public Object generateReport (HttpServletRequest request, @RequestBody Template template)
    {
        
        User currentUser = getCurrentUser ();
        try
        {
            template.setUserId (currentUser.getId ());
            reportService.generateReport (template);
            
        }
        catch (Exception e)
        {
            LOGGER.error ("generate report error.", e);
            return renderError ("error");
        }
        
        //获取操作描述 key = 类名+"_"+方法名 
        String funDesc = LogRenderUtils.getLogReqMap ("ReportController_generateReport");
        try
        {
            //分析删除对象的的关键内容
            String operDetail = reportService.analyseGenerateContent (template);
            if (StringUtils.isNotBlank (operDetail))
            {
                //插入日志
                logService.insertSysLog (currentUser, ConstantCode.STRING_02, getRemoteAddr (), funDesc, operDetail, null, null);
            }
        }
        catch (Exception ex)
        {
            logger.error (funDesc + "  bussness log insert error", ex);
        }
        
        return renderSuccess ("success");
    }
}
