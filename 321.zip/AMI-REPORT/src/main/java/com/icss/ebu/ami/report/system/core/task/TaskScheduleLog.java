package com.icss.ebu.ami.report.system.core.task;

import java.io.Serializable;
import java.util.Date;

/**
 * 任务运行日志记录
 * 
 * @author Administrator
 *
 */
public class TaskScheduleLog implements Serializable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -6442646528218204020L;
	/**
	 * 任务运行日志标识 TASK_LOG_ID
	 */
	private Long id;
	/**
	 * 运行任务标识 TASK_ID
	 */
	private Long taskId;
	/**
	 * 任务名称 name
	 */
	private String taskName;
	/**
	 * 任务类型 -区分扫描的任务
	 */
	private String taskType;
	/**
	 * 任务关键信息
	 */
	private String taskDesc;

	/**
	 * 任务运行结果 RUN_RSLT
	 */
	private String runResult;
	/**
	 * 任务运行信息 RUN_DESC
	 */
	private String runDesc;
	/**
	 * 任务开始执行时间 START_RUN_TIME
	 */
	private Date startRunTime;
	/**
	 * 任务执行结束时间 END_RUN_TIME
	 */
	private Date endRunTime;
	/**
	 * 耗时
	 */
	private Long consTime;
	/**
	 * 调度的任务处理
	 */
	private String handle;

	public Long getTaskId() {
		return taskId;
	}

	public void setTaskId(Long taskId) {
		this.taskId = taskId;
	}

	public String getTaskName() {
		return taskName;
	}

	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}

	public String getRunResult() {
		return runResult;
	}

	public void setRunResult(String runResult) {
		this.runResult = runResult;
	}

	public String getRunDesc() {
		return runDesc;
	}

	public void setRunDesc(String runDesc) {
		this.runDesc = runDesc;
	}

	public Date getStartRunTime() {
		if (startRunTime == null) {
			return null;
		}
		return (Date) startRunTime.clone();
	}

	public void setStartRunTime(Date startRunTime) {
		if (startRunTime == null) {
			this.startRunTime = null;
		} else {
			this.startRunTime = (Date) startRunTime.clone();
		}
	}

	public Date getEndRunTime() {
		if (endRunTime == null) {
			return null;
		}
		return (Date) endRunTime.clone();
	}

	public void setEndRunTime(Date endRunTime) {
		if (endRunTime == null) {
			this.endRunTime = null;
		} else {
			this.endRunTime = (Date) endRunTime.clone();
		}
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getTaskType() {
		return taskType;
	}

	public void setTaskType(String taskType) {
		this.taskType = taskType;
	}

	public String getTaskDesc() {
		return taskDesc;
	}

	public void setTaskDesc(String taskDesc) {
		this.taskDesc = taskDesc;
	}

	public Long getConsTime() {
		return consTime;
	}

	public void setConsTime(Long consTime) {
		this.consTime = consTime;
	}

	public String getHandle() {
		return handle;
	}

	public void setHandle(String handle) {
		this.handle = handle;
	}

}
