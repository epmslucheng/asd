package com.icss.ebu.ami.report.business.mapper;

import com.icss.ebu.ami.commons.pagePlugin.Page;
import com.icss.ebu.ami.report.system.model.SystemParameter;

import java.util.List;

public interface SystemParameterMapper {
    /**
     * 查询系统参数
     *
     * @param page
     * @return List <SystemParameter>
     */
    List<SystemParameter> querySystemParameterByPage (Page<SystemParameter> page);

    /**
     * ID查询系统参数
     *
     * @param id
     * @return SystemParameter
     */
    SystemParameter querySystemParameterById (String id);

    /**
     * 编辑系统参数
     *
     * @param systemParameter
     * @return int
     */
    int editSystemParameter (SystemParameter systemParameter);

    /**
     * 查询所有系统参数
     *
     *
     * @return List <SystemParameter>
     */
    List<SystemParameter> querySystemParameterAll();
}
