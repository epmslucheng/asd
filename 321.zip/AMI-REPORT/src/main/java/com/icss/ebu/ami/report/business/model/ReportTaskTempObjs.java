package com.icss.ebu.ami.report.business.model;

import java.io.Serializable;

public class ReportTaskTempObjs implements Serializable {
    private static final long serialVersionUID = 8476182374851110082L;

    private String userId;

    private String[] ids;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String[] getIds() {
        return ids;
    }

    public void setIds(String[] ids) {
        this.ids = ids;
    }
}
