package com.icss.ebu.ami.report.business.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.icss.ebu.ami.commons.aspect.RedisCacheUtil;
import com.icss.ebu.ami.commons.constants.GeneralConstant;
import com.icss.ebu.ami.commons.exception.ServiceException;
import com.icss.ebu.ami.commons.pagePlugin.Page;
import com.icss.ebu.ami.commons.util.DateUtils;
import com.icss.ebu.ami.commons.util.I18nUtils;
import com.icss.ebu.ami.commons.util.ServiceUtils;
import com.icss.ebu.ami.commons.util.ShareServiceId;
import com.icss.ebu.ami.commons.util.UUIDUtils;
import com.icss.ebu.ami.report.business.common.util.ConfigHolder;
import com.icss.ebu.ami.report.business.common.util.SecurityLogUtils;
import com.icss.ebu.ami.report.business.dao.UsersDao;
import com.icss.ebu.ami.report.business.mapper.DeptAdminMapper;
import com.icss.ebu.ami.report.business.mapper.UserMapper;
import com.icss.ebu.ami.report.business.mapper.UserRoleMapper;
import com.icss.ebu.ami.report.business.result.UserVo;
import com.icss.ebu.ami.report.business.service.ShareService;
import com.icss.ebu.ami.report.business.service.UserPasswordHisService;
import com.icss.ebu.ami.report.business.service.UserService;
import com.icss.ebu.ami.report.system.model.User;
import com.icss.ebu.ami.report.system.model.UserAll;
import com.icss.ebu.ami.report.system.model.UserCube;
import com.icss.ebu.ami.report.system.model.UserDataSource;
import com.icss.ebu.ami.report.system.model.UserGrant;
import com.icss.ebu.ami.report.system.model.UserObjTree;
import com.icss.ebu.ami.report.system.model.UserPasswordHis;
import com.icss.ebu.ami.report.system.model.UserRole;
import com.icss.ebu.ami.report.system.model.UserTemplate;

@Service
public class UserServiceImpl implements UserService
{
    
    private static final Logger LOGGER = LoggerFactory.getLogger(UserServiceImpl.class);
    
    private static final String RES_KEY = "portal_resource";
    
    private static final String ROLE_KEY = "portal_userrole";
    
    @Autowired
    private UserMapper userMapper;
    
    @Autowired
    private UserRoleMapper userRoleMapper;
    
    @Autowired
    private ShareService shareService;
    
    @Autowired
    private RedisCacheUtil redisCacheUtil;
    
    @Autowired
    private UserPasswordHisService userPasswordHisService;
    
    @Autowired
    private DeptAdminMapper deptAdminMapper;
    
    @Autowired
    private UsersDao usersDao;
    
    //private UsersDao usersDao = BeanProvider.getBean (UsersDao.class);
    
    @Override
    public User findUserByLoginName(String username)
    {
        return userMapper.findUserByLoginName(username);
    }
    
    @Override
    public User findUserById(String id)
    {
        User user = userMapper.findUserById(id);
        return user;
    }
    
    @Override
    public Page<UserVo> findUserByPage(Page<UserVo> page)
    {
        try
        {
            page.setResults(userMapper.findUserByPage(page));
        }
        catch (Exception e)
        {
            LOGGER.error("error", e);
        }
        
        return page;
    }
    
    @Override
    public UserVo findUserVoById(String id)
    {
        return userMapper.findUserVoById(id);
    }
    
    @Override
    public boolean checkLastSamePwd(String userId, String password)
    {
        List<UserPasswordHis> hisList = userPasswordHisService.findUserPasswordByUserId(userId);
        if(CollectionUtils.isNotEmpty(hisList))
        {
            int size = hisList.size();
            int i = 0;
            for(; i < size; i++)
            {
                if(i < 5 && hisList.get(i).getPassword().equals(password))
                {
                    return true;
                }
                else if(i >= 5)
                {
                    userPasswordHisService.deleteById(hisList.get(i).getId());
                }
            }
        }
        return false;
    }
    
    @Override
    public void checkPwdValidTime(User user)
    {
        int days = 90;
        try
        {
            days = Integer.valueOf(ConfigHolder.getCfg("PASSWORD_VALID_DAYS"));
        }
        catch (Exception e)
        {
            days = 90;
        }
        if(StringUtils.isBlank(user.getPwdFirstUpdate()))
        {
            user.setPwdFirstUpdate("0");
            return;
        }
        if("0".equals(user.getPwdFirstUpdate()))
        {
            return;
        }
        if(user.getPwdUpdateTime() == null || !DateUtils.isBelongTime(user.getPwdUpdateTime().getTime(), days * 86400l))
        {
            user.setPwdFirstUpdate("2");
        }
    }
    
    @Override
    public User finActiduserbyUserName(String Name)
    {
        return userMapper.finActiduserbyUserName(Name);
    }
    
    /**
     * 分析角色更改信息
     *
     * @param oldUserRoles
     * @param roleIds
     * @return
     */
    private String analyseEditRole(List<UserRole> oldUserRoles, String[] roleIds)
    {
        StringBuilder addSb = new StringBuilder().append("{").append("addRoleIds:[");
        StringBuilder delSb = new StringBuilder().append("delRoleIds:[");
        if(CollectionUtils.isEmpty(oldUserRoles))
        {
            delSb.append("]}");
            if(roleIds.length > 0)
            {
                addSb.append(roleIds[0]);
                for(int i = 1; i < roleIds.length; i++)
                {
                    addSb.append(",").append(roleIds[i]);
                }
            }
            addSb.append("],");
        }
        else
        {
            if(roleIds.length > 0)
            {
                List<String> addResList = new ArrayList<String>();
                UserRole temp;
                boolean isExist;
                int size;
                for(String newResId : roleIds)
                {
                    isExist = false;
                    size = oldUserRoles.size();
                    for(int i = size; i > 0; i--)
                    {
                        temp = oldUserRoles.get(i - 1);
                        if(temp.getRoleId().toString().equals(newResId))
                        {
                            isExist = true;
                            oldUserRoles.remove(i - 1);
                            break;
                        }
                    }
                    if(!isExist)
                    {
                        addResList.add(newResId);
                    }
                }
                if(addResList.size() > 0)
                {
                    addSb.append(addResList.get(0));
                    size = addResList.size();
                    for(int i = 1; i < size; i++)
                    {
                        addSb.append(",").append(addResList.get(i));
                    }
                }
                addSb.append("],");
                
                if(oldUserRoles.size() > 0)
                {
                    delSb.append(oldUserRoles.get(0));
                    size = oldUserRoles.size();
                    for(int i = 1; i < size; i++)
                    {
                        delSb.append(",").append(oldUserRoles.get(i));
                    }
                }
                delSb.append("]}");
                addResList.clear();
            }
            else
            {
                addSb.append("],");
                for(UserRole userRole : oldUserRoles)
                {
                    delSb.append(userRole.getRoleId()).append(",");
                }
                delSb.append("]}");
            }
        }
        return addSb.toString() + delSb.toString();
    }
    
    /**
     * 分析用戶更改信息
     *
     * @param oldUser
     * @param newUser
     * @return
     */
    private String analyseEditUser(User oldUser, User newUser)
    {
        if(oldUser == null)
        {
            return "old user is null";
        }
        StringBuilder updateSb = new StringBuilder().append(" edit[ ");
        ServiceUtils.compareChange("loginName", oldUser.getLoginname(), newUser.getLoginname(), updateSb);
        ServiceUtils.compareChange("name", oldUser.getName(), newUser.getName(), updateSb);
        ServiceUtils.compareChange("sex", oldUser.getSex(), newUser.getSex(), updateSb);
        ServiceUtils.compareChange("organizationId", oldUser.getOrganizationId(), newUser.getOrganizationId(), updateSb);
        ServiceUtils.compareChange("userType", oldUser.getUsertype(), newUser.getUsertype(), updateSb);
        ServiceUtils.compareChange("status", oldUser.getStatus(), newUser.getStatus(), updateSb);
        ServiceUtils.compareChange("phone", oldUser.getPhone(), newUser.getPhone(), updateSb);
        if(updateSb.length() > 7)
        {
            updateSb.setLength(updateSb.length() - 1);
        }
        updateSb.append("] ");
        return updateSb.toString();
    }
    
    private void copyUserProperties(User user, UserVo userVo)
    {
        user.setId(userVo.getId());
        user.setUsertype(userVo.getUsertype());
        user.setLoginname(userVo.getLoginname());
        user.setName(userVo.getName());
        user.setPassword(userVo.getPassword());
        user.setSex(userVo.getSex());
        user.setStatus(userVo.getStatus());
        user.setPhone(userVo.getPhone());
        user.setOrganizationId(userVo.getOrganizationId());
        user.setpOrganizationId(userVo.getpOrganizationId());
        user.setCreatedate(userVo.getCreatedate());
    }
    
    /**
     * 查询用户数量
     *
     * @param user
     * @return
     */
    public Integer countUser(User user)
    {
        return userMapper.countUser(user);
    }
    
    @Override
    public void editPersonInfo(UserVo userVo)
    {
        userMapper.editPersonInfo(userVo);
        
    }
    
    @Override
    public void addUser(UserVo userVo, User curUser, String client, Logger logger)
    {
        userVo.setId(ShareServiceId.generateUUID() + "");
        userVo.setCreatedate(new Date());
        User user = new User();
        try
        {
            copyUserProperties(user, userVo);
        }
        catch (Exception e)
        {
            LOGGER.error("类转换异常：{}", e);
            throw new ServiceException("copyProperties error ：", e);
        }
        user.setPwdFirstUpdate("0");
        user.setPwdUpdateTime(userVo.getCreatedate());
        userMapper.insert(user);
        
        String id = userVo.getId();
        String[] roles = {};
        if(StringUtils.isNotEmpty(userVo.getRoleIds()))
        {
            roles = userVo.getRoleIds().split(GeneralConstant.COMMA);
        }
        UserRole userRole = new UserRole();
        for(String string : roles)
        {
            userRole.setId(ShareServiceId.generateUUID());
            userRole.setUserId(id);
            userRole.setRoleId(Long.valueOf(string));
            userRoleMapper.insert(userRole);
        }
        
        // 添加日志
        String userStr = user.toString();
        String calssName = this.getClass().getSimpleName();
        SecurityLogUtils.loggerLog(calssName, curUser, client, SecurityLogUtils.EVENT_ADD_USER, userStr,
            SecurityLogUtils.OPER_SUCCESS, userStr, logger);
        if(roles.length > 0)
        {
            SecurityLogUtils.loggerLog(calssName, curUser, client, SecurityLogUtils.EVENT_ADD_USER_ROLE, userStr,
                SecurityLogUtils.OPER_SUCCESS, "RelaIds:" + userVo.getRoleIds(), logger);
        }
    }
    
    @Override
    public void updateUser(UserVo userVo, User curUser, String client, Logger logger)
    {
        // 用户角色发生变化 清空userrole
        // redisCacheUtil.deleteKeys(ROLE_KEY);
        // 清楚resource缓存
        // redisCacheUtil.deleteKeys(RES_KEY);
        
        User user = new User();
        try
        {
            copyUserProperties(user, userVo);
        }
        catch (Exception e)
        {
            LOGGER.error("类转换异常：{}", e);
            throw new ServiceException("copyProperties error ：", e);
        }
        User oldUser = findUserById(userVo.getId());
        if(StringUtils.isNotBlank(userVo.getPassword()) && !oldUser.getPassword().equals(userVo.getPassword()))
        {
            user.setPwdFirstUpdate("0");
            user.setPwdUpdateTime(new Date());
        }
        userMapper.updateUser(user);
        String id = userVo.getId();
        List<UserRole> userRoles = userRoleMapper.findUserRoleByUserId(id);
        if(CollectionUtils.isNotEmpty(userRoles))
        {
            for(UserRole userRole : userRoles)
            {
                userRoleMapper.deleteById(userRole.getId());
            }
        }
        
        String[] roles = {};
        if(StringUtils.isNotEmpty(userVo.getRoleIds()))
        {
            roles = userVo.getRoleIds().split(GeneralConstant.COMMA);
        }
        UserRole userRole = new UserRole();
        for(String string : roles)
        {
            userRole.setId(ShareServiceId.generateUUID());
            userRole.setUserId(id);
            userRole.setRoleId(Long.valueOf(string));
            userRoleMapper.insert(userRole);
        }
        
        // 添加日志
        String userStr = oldUser == null ? "User is null" : user.toString();
        String calssName = this.getClass().getSimpleName();
        SecurityLogUtils.loggerLog(calssName, curUser, client, SecurityLogUtils.EVENT_EDIT_USER, userStr,
            analyseEditUser(oldUser, user), user.toString(), logger);
        if(roles.length > 0)
        {
            SecurityLogUtils.loggerLog(calssName, curUser, client, SecurityLogUtils.EVENT_EDIT_USER_ROLE, userStr,
                analyseEditRole(userRoles, roles), "RelaIds:" + userVo.getRoleIds(), logger);
        }
    }
    
    @Override
    public void updateUserPwdById(String userId, String pwd, String oldPwd)
    {
        User user = new User();
        user.setId(userId);
        user.setPassword(pwd);
        user.setPwdFirstUpdate("1");
        user.setPwdUpdateTime(new Date());
        userMapper.updateUserPwdById(user);
        /*if (!checkLastSamePwd (userId, oldPwd))
        {
            userPasswordHisService.insert (userId, oldPwd);
        }
        userPasswordHisService.insert (userId, pwd);*/
    }
    
    @Override
    public void deleteUserById(String id)
    {
        userMapper.deleteById(id);
        List<UserRole> userRoles = userRoleMapper.findUserRoleByUserId(id);
        if(CollectionUtils.isNotEmpty(userRoles))
        {
            for(UserRole userRole : userRoles)
            {
                userRoleMapper.deleteById(userRole.getId());
            }
        }
        //userPasswordHisService.deleteByUserId (id);
    }
    
    @Override
    public List<String> findCubeIdByUserId(String id)
    {
        return userMapper.findCubeIdByUserId(id);
    }
    
    @Override
    public List<String> findDataSourceIdByUserId(String id)
    {
        return userMapper.findDataSourceIdByUserId(id);
    }
    
    @Override
    public void updateUserCubeDataSource(UserGrant userGrant)
    {
        
        userMapper.deleteUserCubeByUserId(userGrant.getUserid());
        userMapper.deleteUserDataSourceByUserId(userGrant.getUserid());
        userMapper.deleteUserTmpByUserId(userGrant.getUserid());
        userMapper.deleteUserObjTreeByUserId(userGrant.getUserid());
        String[] datas = userGrant.getCnnid().split(",");
        String[] cubes = userGrant.getCubeid().split(",");
        String[] tmps = userGrant.getTmpid().split(",");
        String[] objs = userGrant.getObjid().split(",");
        UserDataSource userDataSource = new UserDataSource();
        for(String dataid : datas)
        {
            if(!dataid.isEmpty())
            {
                userDataSource.setId(UUIDUtils.generate16Long());
                userDataSource.setUserId(userGrant.getUserid());
                userDataSource.setCnnid(dataid);
                userMapper.insertUserDataSource(userDataSource);
            }
        }
        
        UserCube userCube = new UserCube();
        for(String cubeid : cubes)
        {
            if(!cubeid.isEmpty())
            {
                userCube.setId(UUIDUtils.generate16Long());
                userCube.setUserId(userGrant.getUserid());
                userCube.setCubeId(cubeid);
                userMapper.insertUseCube(userCube);
            }
        }
        
        UserTemplate userTemplate = new UserTemplate();
        for(String tmpid : tmps)
        {
            if(!tmpid.isEmpty())
            {
                userTemplate.setId(UUIDUtils.generate16Long());
                userTemplate.setUserId(userGrant.getUserid());
                userTemplate.setReportId(tmpid);
                userMapper.insertUserTemplate(userTemplate);
            }
        }
        
        UserObjTree userObjTree = new UserObjTree();
        for(String objid : objs)
        {
            if(!objid.isEmpty())
            {
                userObjTree.setId(UUIDUtils.generate16Long());
                userObjTree.setUserId(userGrant.getUserid());
                userObjTree.setObjId(objid);
                userMapper.insertUserObjTree(userObjTree);
            }
        }
    }
    
    @Override
    public List<String> findTmpIdByUserId(String id)
    {
        return userMapper.findTmpIdByUserId(id);
    }
    
    @Override
    public List<String> findObjIdByUserId(String id)
    {
        return userMapper.findObjIdByUserId(id);
    }
    
    @Override
    public int insertUserGrant(UserGrant userGrant)
    {
        int result = 0;
        try
        {
            if(null != userGrant)
            {
                if(StringUtils.isNotBlank(userGrant.getTmpid()))
                {
                    // 新增模板权限
                    UserTemplate userTemplate = new UserTemplate();
                    userTemplate.setId(UUIDUtils.generate16Long());
                    userTemplate.setReportId(userGrant.getTmpid());
                    userTemplate.setUserId(userGrant.getUserid());
                    userMapper.insertUserTemplate(userTemplate);
                }
                else if(StringUtils.isNotBlank(userGrant.getCnnid()))
                {
                    //新增数据源权限
                    UserDataSource userDataSource = new UserDataSource();
                    userDataSource.setId(UUIDUtils.generate16Long());
                    userDataSource.setCnnid(userGrant.getCnnid());
                    userDataSource.setUserId(userGrant.getUserid());
                    userMapper.insertUserDataSource(userDataSource);
                    
                }
                else if(StringUtils.isNotBlank(userGrant.getCubeid()))
                {
                    //新增立方权限
                    UserCube userCube = new UserCube();
                    userCube.setId(UUIDUtils.generate16Long());
                    userCube.setCubeId(userGrant.getCubeid());
                    userCube.setUserId(userGrant.getUserid());
                    userMapper.insertUseCube(userCube);
                }
                else if(StringUtils.isNotBlank(userGrant.getObjid()))
                {
                    //新增对象树权限
                    UserObjTree userObjTree = new UserObjTree();
                    userObjTree.setId(UUIDUtils.generate16Long());
                    userObjTree.setObjId(userGrant.getObjid());
                    userObjTree.setUserId(userGrant.getUserid());
                    userMapper.insertUserObjTree(userObjTree);
                }
            }
        }
        catch (Exception e)
        {
            LOGGER.error("insert user grant error...", e);
        }
        return result;
    }
    
    @Override
    public int deleteUserGrant(UserGrant userGrant)
    {
        int result = 0;
        try
        {
            if(null != userGrant)
            {
                if(StringUtils.isNotBlank(userGrant.getTmpid()))
                {
                    // 删除模板权限
                    UserTemplate userTemplate = new UserTemplate();
                    userTemplate.setReportId(userGrant.getTmpid());
                    userTemplate.setUserId(userGrant.getUserid());
                    userMapper.deleteUserTemplate(userTemplate);
                }
                else if(StringUtils.isNotBlank(userGrant.getCnnid()))
                {
                    // 删除数据源权限
                    UserDataSource userDataSource = new UserDataSource();
                    userDataSource.setCnnid(userGrant.getCnnid());
                    userDataSource.setUserId(userGrant.getUserid());
                    userMapper.deleteUserDataSource(userDataSource);
                    
                }
                else if(StringUtils.isNotBlank(userGrant.getCubeid()))
                {
                    // 删除立方权限
                    UserCube userCube = new UserCube();
                    userCube.setCubeId(userGrant.getCubeid());
                    userCube.setUserId(userGrant.getUserid());
                    userMapper.deleteUseCube(userCube);
                }
                else if(StringUtils.isNotBlank(userGrant.getObjid()))
                {
                    //新增对象树权限
                    UserObjTree userObjTree = new UserObjTree();
                    userObjTree.setObjId(userGrant.getObjid());
                    userObjTree.setUserId(userGrant.getUserid());
                    userMapper.deleteUserObjTree(userObjTree);
                }
            }
        }
        catch (Exception e)
        {
            LOGGER.error("insert user grant error...", e);
        }
        return result;
    }
    
    @Override
    public String analyseAddContent(UserVo newUserVo)
    {
        if(newUserVo == null)
        {
            return "user is empty";
        }
        StringBuilder addSb = new StringBuilder();
        ServiceUtils.addPropContent(I18nUtils.getI18nMsg("ami.user.loginname"), newUserVo.getLoginname(), addSb);
        ServiceUtils.addPropContent(I18nUtils.getI18nMsg("ami.user.name"), newUserVo.getName(), addSb);
        ServiceUtils.addPropContent(I18nUtils.getI18nMsg("ami.user.sex"), newUserVo.getSex(), addSb);
        ServiceUtils.addPropContent(I18nUtils.getI18nMsg("ami.common.status"), newUserVo.getStatus(), addSb);
        ServiceUtils.addPropContent(I18nUtils.getI18nMsg("ami.user.role"), newUserVo.getRoleIds(), addSb);
        ServiceUtils.addPropContent(I18nUtils.getI18nMsg("ami.user.tel"), newUserVo.getPhone(), addSb);
        if(addSb.length() > 1)
        {
            addSb.setLength(addSb.length() - 1);
        }
        return addSb.toString();
    }
    
    @Override
    public String analyseEditContent(UserVo oldUserVo, UserVo newUserVo)
    {
        if(oldUserVo == null)
        {
            return "old user is empty";
        }
        StringBuilder updateSb = new StringBuilder();
        ServiceUtils.compareChange(I18nUtils.getI18nMsg("ami.user.name"), oldUserVo.getName(), newUserVo.getName(), updateSb);
        ServiceUtils.compareChange(I18nUtils.getI18nMsg("ami.user.sex"), oldUserVo.getSex(), newUserVo.getSex(), updateSb);
        ServiceUtils.compareChange(I18nUtils.getI18nMsg("ami.common.status"), oldUserVo.getStatus(), newUserVo.getStatus(),
            updateSb);
        ServiceUtils.compareChange(I18nUtils.getI18nMsg("ami.user.role"), oldUserVo.getRoleIds(), newUserVo.getRoleIds(),
            updateSb);
        ServiceUtils.compareChange(I18nUtils.getI18nMsg("ami.user.tel"), oldUserVo.getPhone(), newUserVo.getPhone(), updateSb);
        
        if(updateSb.length() > 1)
        {
            updateSb.setLength(updateSb.length() - 1);
        }
        return updateSb.toString();
    }
    
    @Override
    public String analyseDelContent(UserVo user)
    {
        if(user == null)
        {
            return "user is empty";
        }
        StringBuilder delSb = new StringBuilder();
        ServiceUtils.addPropContent(I18nUtils.getI18nMsg("ami.user.loginname"), user.getLoginname(), delSb);
        if(delSb.length() > 1)
        {
            delSb.setLength(delSb.length() - 1);
        }
        return delSb.toString();
    }
    
    @Override
    public void insertSelective(UserAll userAll)
    {
        userMapper.insertSelective(userAll);
    }
    
    @Override
    public void deleteUserBySourceUserid(String id)
    {
        userMapper.deleteUserBySourceUserid(id);
    }
}
