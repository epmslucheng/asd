package com.icss.ebu.ami.report.business.service;

import java.util.List;

import com.icss.ebu.ami.commons.pagePlugin.Page;
import com.icss.ebu.ami.report.business.model.DataSourceBean;
import com.icss.ebu.ami.report.business.model.DataSourceTable;
import com.icss.ebu.ami.report.business.model.DataSourceTableFiled;

/**
 * 数据源service
 * @author xunan
 *
 */
public interface DataSourceService
{
    List <DataSourceBean> getAllDataSource ();
    
    List <DataSourceBean> getAllDataSourceByUserId (String userId);
    
    /**
     * 获取数据源列表
     * @return
     */
    Page <DataSourceBean> queryDataSourceList (Page <DataSourceBean> page);
    
    DataSourceBean getDataSourceById (String id);
    
    DataSourceBean getDataSourceByKey (String key);
    
    void delDataSourceById (String id);
    
    void addDataSourceBean (DataSourceBean dataSourceBean);
    
    void updateDataSourceBean (DataSourceBean dataSourceBean);
    
    void editDataSourceBean (DataSourceBean dataSourceBean);
    
    List <DataSourceTable> getTableListByDataSourceId (String id);
    
    void getTableByDataSourceId (String id, String type);
    
    void addDataSourceTable (List <DataSourceTable> dsTableList);
    
    void addDataSourceTableFiled (List <DataSourceTableFiled> dstf);
    
    /**
     * 根据数据源id、表名 删除 表
     * @param dataSourceTable
     */
    void delTableByTableNameAndDsId (DataSourceTable dataSourceTable);
    
    /**
     * 获取数据源下该表数量
     * @param dataSourceTable
     * @return
     */
    int getTableCount (DataSourceTable dataSourceTable);
    
    String analyseAddContent (DataSourceBean dataSourceBean);
    
    String analyseEditContent (DataSourceBean oldDataSourceBean, DataSourceBean newDataSourceBean);
    
    String analyseDelContent (DataSourceBean dataSourceBean);
    
}
