package com.icss.ebu.ami.report.system.model;

import java.io.Serializable;

/** 
* @author  zhangkaining 
* @date 2017年11月15日 下午4:32:50 
* @version 1.0   
*/
public class UserCube implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7432458142264457943L;
	
	private Long id;
	
	private String userId;
	
	private String cubeId;
	
	private String cnnid;

	public String getCnnid() {
		return cnnid;
	}

	public void setCnnid(String cnnid) {
		this.cnnid = cnnid;
	}

	

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getCubeId() {
		return cubeId;
	}

	public void setCubeId(String cubeId) {
		this.cubeId = cubeId;
	}
	
}
