package com.icss.ebu.ami.report.business.model;

import java.io.Serializable;

public class Function implements Serializable
{
    
    /**
     * 
     */
    private static final long serialVersionUID = 7795215379345453811L;
    
    private String id;
    
    private String functionName;
    
    private String functionValue;
    
    private String functionType;
    
    public String getId ()
    {
        return id;
    }
    
    public void setId (String id)
    {
        this.id = id;
    }
    
    public String getFunctionName ()
    {
        return functionName;
    }
    
    public void setFunctionName (String functionName)
    {
        this.functionName = functionName;
    }
    
    public String getFunctionValue ()
    {
        return functionValue;
    }
    
    public void setFunctionValue (String functionValue)
    {
        this.functionValue = functionValue;
    }
    
    public String getFunctionType ()
    {
        return functionType;
    }
    
    public void setFunctionType (String functionType)
    {
        this.functionType = functionType;
    }
    
}
