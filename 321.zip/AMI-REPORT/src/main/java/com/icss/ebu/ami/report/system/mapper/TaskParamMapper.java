package com.icss.ebu.ami.report.system.mapper;

import com.icss.ebu.ami.report.system.core.task.TaskParam;

import java.util.List;

public interface TaskParamMapper {
	
	/**
	 * 获取制定任务id的任务关联的相应任务参数信息
	 * @param taskId
	 * @return
	 */
	List<TaskParam> getTaskParamsByTaskId(Long taskId);
}
