package com.icss.ebu.ami.report.business.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.icss.ebu.ami.commons.pagePlugin.Page;
import com.icss.ebu.ami.report.business.mapper.CubeMapper;
import com.icss.ebu.ami.report.business.model.CubeBean;
import com.icss.ebu.ami.report.business.model.CubeTable;
import com.icss.ebu.ami.report.business.model.DataSourceTable;
import com.icss.ebu.ami.report.business.model.DataSourceTableFiled;
import com.icss.ebu.ami.report.business.model.Table;
import com.icss.ebu.ami.report.business.model.TableField;
import com.icss.ebu.ami.report.business.service.CubeService;

@Service
public class CubeServiceImpl implements CubeService
{
    
    @Autowired
    private CubeMapper cubeMapper;
    
    @Override
    public List <CubeBean> getAllCube ()
    {
        return cubeMapper.getAllCube ();
    }
    
    @Override
    public List <CubeBean> getAllCubeByUserId (String userId)
    {
        return cubeMapper.getAllCubeByUserId (userId);
    }
    
    @Override
    public Page <CubeBean> queryCubeList (Page <CubeBean> page)
    {
        page.setResults (cubeMapper.getCubeList (page));
        return page;
    }
    
    @Override
    public CubeBean getCubeById (String id)
    {
        return cubeMapper.getCubeById (id);
    }
    
    @Override
    public void delCubeById (String id)
    {
        cubeMapper.delCubeById (id);
        //删除 立方表关联
        cubeMapper.delCubeTableRel (id);
    }
    
    @Override
    public void addCube (CubeBean Cube)
    {
        //遍历tableName
        if (null != Cube.getTableList () && !Cube.getTableList ().isEmpty ())
        {
            CubeBean cubeB = null;
            //封装数据
            cubeB = new CubeBean ();
            cubeB.setId (Cube.getId ());
            cubeB.setCubeId (Cube.getCubeId ());
            cubeB.setCubeName (Cube.getCubeName ());
            cubeB.setCubeDesc (Cube.getCubeDesc ());
            
            //增加立方表关联
            List <CubeTable> cbTableList = new ArrayList<> ();
            //遍历tableList
            if (null != Cube.getTableList () && !Cube.getTableList ().isEmpty ())
            {
                
                CubeTable cubeTable = null;
                for (int i = 0; i < Cube.getTableList ().size (); i++)
                {
                    cubeTable = new CubeTable ();
                    cubeTable.setCubeId (cubeB.getCubeId ());
                    cubeTable.setTableId (Cube.getTableList ().get (i).getTableId ());
                    cbTableList.add (cubeTable);
                }
            }
            cubeMapper.addCube (cubeB);
            
            cubeMapper.addCubeTable (cbTableList);
        }
        
    }
    
    @Override
    public void updateCube (CubeBean Cube)
    {
        
    }
    
    @Override
    public void editCube (CubeBean Cube)
    {
        
        cubeMapper.updateCube (Cube);
        //先删除  后增加
        
        //删除 立方表关联
        cubeMapper.delCubeTableRel (Cube.getCubeId ());
        
        //增加立方表关联
        List <CubeTable> cbTableList = new ArrayList<> ();
        //遍历tableList
        if (null != Cube.getTableList () && !Cube.getTableList ().isEmpty ())
        {
            
            CubeTable cubeTable = null;
            for (int i = 0; i < Cube.getTableList ().size (); i++)
            {
                if (null != Cube.getTableList ().get (i).getTableId ())
                {
                    cubeTable = new CubeTable ();
                    cubeTable.setCubeId (Cube.getCubeId ());
                    cubeTable.setTableId (Cube.getTableList ().get (i).getTableId ());
                    cbTableList.add (cubeTable);
                }
            }
        }
        
        cubeMapper.addCubeTable (cbTableList);
        
    }
    
    @Override
    public void getTableByCubeId (String id, String type)
    {
        
    }
    
    @Override
    public List <DataSourceTable> getCubeTableNameById (String id)
    {
        return cubeMapper.getCubeTableNameById (id);
    }
    
    @Override
    public List <CubeBean> getCubeByDsId (String cnnid)
    {
        return cubeMapper.getCubeByDsId (cnnid);
    }
    
    @Override
    public List <DataSourceTableFiled> getTableTreeByTable (DataSourceTable dataSourceTable)
    {
        return cubeMapper.getTableTreeByTable (dataSourceTable);
    }
    
    @Override
    public void updateTableFiledAlias (DataSourceTableFiled dstf)
    {
        cubeMapper.updateTableFiledAlias (dstf);
    }
    
    @Override
    public List <CubeBean> getCubeByDsIdAndUser (CubeBean cube)
    {
        return cubeMapper.getCubeByDsIdAndUser (cube);
    }
    
    @Override
    public CubeBean getCubeByDsIdAndCubeName (CubeBean cube)
    {
        return cubeMapper.getCubeByDsIdAndCubeName (cube);
    }
    
    @Override
    public List <Table> getTablesByCubeId (String cubeId)
    {
        return cubeMapper.getTablesByCubeId (cubeId);
    }
    
    @Override
    public List <TableField> getFieldsByTable (Table table)
    {
        return cubeMapper.getFieldsByTable (table);
    }
}
