package com.icss.ebu.ami.report.system.core.task;

import org.springframework.stereotype.Component;

import java.sql.Timestamp;

@Component
public class TaskInfo
{
    private String taskId;
    
    private String name;
    
    private String taskCode;
    
    //间隔
    private String collCycle;
    
    // 1-秒 2-分 3-时 4-天 5-周 6-旬 7-月 8-季 9-年   空-秒
    private String timeCyc;
    
    private Timestamp runTime;
    
    private Timestamp startTime;
    
    private Timestamp endTime;
    
    private Long timeOut;
    
    private String pid;
    
    private String failPhone;
    
    private String failEmail;
    
    private String status;
    
    private String taskName;
    
    private String taskHandle;
    
    private String taskNameAlias;
    
    // 任务重发次数
    private int times;
    
    private String taskExceptionInfo;
    
    private Timestamp beginTime;
    
    public String getTaskId ()
    {
        return taskId;
    }
    
    public void setTaskId (String taskId)
    {
        this.taskId = taskId;
    }
    
    public String getName ()
    {
        return name;
    }
    
    public void setName (String name)
    {
        this.name = name;
    }
    
    public String getCollCycle ()
    {
        return collCycle;
    }
    
    public void setCollCycle (String collCycle)
    {
        this.collCycle = collCycle;
    }
    
    public String getTimeCyc ()
    {
        return timeCyc;
    }
    
    public void setTimeCyc (String timeCyc)
    {
        this.timeCyc = timeCyc;
    }
    
    public Timestamp getRunTime ()
    {
        return runTime;
    }
    
    public void setRunTime (Timestamp runTime)
    {
        this.runTime = runTime;
    }
    
    public Timestamp getStartTime ()
    {
        return startTime;
    }
    
    public void setStartTime (Timestamp startTime)
    {
        this.startTime = startTime;
    }
    
    public Timestamp getEndTime ()
    {
        return endTime;
    }
    
    public void setEndTime (Timestamp endTime)
    {
        this.endTime = endTime;
    }
    
    public Long getTimeOut ()
    {
        return timeOut;
    }
    
    public void setTimeOut (Long timeOut)
    {
        this.timeOut = timeOut;
    }
    
    public String getPid ()
    {
        return pid;
    }
    
    public void setPid (String pid)
    {
        this.pid = pid;
    }
    
    public String getTaskCode ()
    {
        return taskCode;
    }
    
    public void setTaskCode (String taskCode)
    {
        this.taskCode = taskCode;
    }
    
    public String getFailPhone ()
    {
        return failPhone;
    }
    
    public void setFailPhone (String failPhone)
    {
        this.failPhone = failPhone;
    }
    
    public String getFailEmail ()
    {
        return failEmail;
    }
    
    public void setFailEmail (String failEmail)
    {
        this.failEmail = failEmail;
    }
    
    public String getStatus ()
    {
        return status;
    }
    
    public void setStatus (String status)
    {
        this.status = status;
    }
    
    public String getTaskName ()
    {
        return taskName;
    }
    
    public void setTaskName (String taskName)
    {
        this.taskName = taskName;
    }
    
    public String getTaskHandle ()
    {
        return taskHandle;
    }
    
    public void setTaskHandle (String taskHandle)
    {
        this.taskHandle = taskHandle;
    }
    
    public String getTaskNameAlias ()
    {
        return taskNameAlias;
    }
    
    public void setTaskNameAlias (String taskNameAlias)
    {
        this.taskNameAlias = taskNameAlias;
    }
    
    public int getTimes ()
    {
        return times;
    }
    
    public void setTimes (int times)
    {
        this.times = times;
    }
    
    public String getTaskExceptionInfo ()
    {
        return taskExceptionInfo;
    }
    
    public void setTaskExceptionInfo (String taskExceptionInfo)
    {
        this.taskExceptionInfo = taskExceptionInfo;
    }

    public Timestamp getBeginTime()
    {
        return beginTime;
    }

    public void setBeginTime(Timestamp beginTime)
    {
        this.beginTime = beginTime;
    }
    
    
}
