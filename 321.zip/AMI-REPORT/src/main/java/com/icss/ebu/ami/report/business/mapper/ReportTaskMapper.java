package com.icss.ebu.ami.report.business.mapper;

import com.icss.ebu.ami.commons.pagePlugin.Page;
import com.icss.ebu.ami.report.business.model.ReportTask;
import com.icss.ebu.ami.report.business.model.ReportTaskObj;
import com.icss.ebu.ami.report.business.model.ReportTaskTemp;
import com.icss.ebu.ami.report.business.model.Template;

import java.util.List;

public interface ReportTaskMapper {
    /**
     * 查询任务列表
     *
     * @param page
     * @return List <ReportTask>
     */
    List<ReportTask> queryReportTaskByPage (Page<ReportTask> page);

    /**
     * 查询任务列表
     *
     * @param id
     * @return ReportTask
     */
    ReportTask queryReportTaskById (String id);

    /**
     * 新增任务
     *
     * @param reportTask
     * @return int
     */
    int addReportTask (ReportTask reportTask);

    /**
     * 修改任务
     *
     * @param reportTask
     * @return int
     */
    int editReportTask (ReportTask reportTask);

    /**
     * 删除任务
     *
     * @param id
     * @return int
     */
    int delReportTaskById (String id);

    /**
     * 新增任务报表
     *
     * @param reportTaskTemp
     * @return int
     */
    int addTaskReports(ReportTaskTemp reportTaskTemp);

    /**
     * 删除任务报表
     *
     * @param taskId
     * @return int
     */
    int delTaskReportsByTaskId (String taskId);

    /**
     * 新增任务报表对象
     *
     * @param reportTaskObj
     * @return int
     */
    int addTaskObjects(ReportTaskObj reportTaskObj);

    /**
     * 删除任务报表对象
     *
     * @param taskId
     * @return int
     */
    int delTaskObjectsByTaskId (String taskId);

    /**
     * 查询所有任务
     *
     * @param status
     * @return List <ReportTask>
     */
    List<ReportTask> queryAllReportTask(String status);

    /**
     * 查询需要生成的报表
     *
     * @param id
     * @return List <Template>
     */
    List<Template> queryTemplatesByTaskId(String id);

    /**
     * 查询任务报表对象
     *
     * @param id
     * @return List <ReportTaskObj>
     */
    List<ReportTaskObj> queryObjsByTaskId(String id);
}
