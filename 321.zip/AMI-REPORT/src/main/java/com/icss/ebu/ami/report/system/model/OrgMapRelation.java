package com.icss.ebu.ami.report.system.model;

import java.io.Serializable;

public class OrgMapRelation implements Serializable
{
    
    /**
     * 
     */
    private static final long serialVersionUID = -6632869706201912883L;
    
    private String id; // 主键
    
    private String orgNo; //供电单位
    
    private String mapId; //地图
    
    private String enableFlag;
    
    public String getId ()
    {
        return id;
    }
    
    public void setId (String id)
    {
        this.id = id;
    }
    
    public String getOrgNo ()
    {
        return orgNo;
    }
    
    public void setOrgNo (String orgNo)
    {
        this.orgNo = orgNo;
    }
    
    public String getMapId ()
    {
        return mapId;
    }
    
    public void setMapId (String mapId)
    {
        this.mapId = mapId;
    }
    
    public String getEnableFlag ()
    {
        return enableFlag;
    }
    
    public void setEnableFlag (String enableFlag)
    {
        this.enableFlag = enableFlag;
    }
    
}
