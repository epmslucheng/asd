package com.icss.ebu.ami.report.system.service;

import javax.ws.rs.Path;

@Path("/abstractTaskService")
public interface AbstractTaskService {

}
