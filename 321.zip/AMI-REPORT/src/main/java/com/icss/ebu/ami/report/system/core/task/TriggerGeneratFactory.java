package com.icss.ebu.ami.report.system.core.task;

import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.quartz.CronTrigger;
import org.quartz.SimpleTrigger;
import org.quartz.Trigger;

import com.icss.ebu.ami.report.business.model.ReportTask;

/**
 * 定时触发器生成工厂
 * 
 * @author Administrator
 *
 */
public class TriggerGeneratFactory
{
    
    private static TriggerGeneratFactory triggerGeneratFactory = new TriggerGeneratFactory ();
    
    public static TriggerGeneratFactory getInstance ()
    {
        return triggerGeneratFactory;
    }
    
    private TriggerGeneratFactory ()
    {
    }
    
    /**
     * 获取触发器，并绑定任务对象
     * 
     * @param task
     * @param jobClass
     * @return
     */
    @SuppressWarnings ("rawtypes")
    public Trigger getTrigger (Task task, Class jobClass, Map <String, Object> jobExecParamAsMap)
    {
        String repeatMode = task.getRepeatMode ();
        Trigger trigger = null;
        if (Task.REPEAT_MODE_SIMPLE.equals (repeatMode))
        {
            trigger = generateTimeTrigger (jobClass, jobExecParamAsMap, task);
        }
        else if (Task.REPEAT_MODE_CRON.equals (repeatMode))
        {
            trigger = generateCronTrigger (jobClass, jobExecParamAsMap, task);
        }
        else
        {
            return trigger;
        }
        return trigger;
    }
    
    /**
     * 获取触发器，并绑定任务对象
     * 
     * @param task
     * @param jobClass
     * @return
     */
    @SuppressWarnings ("rawtypes")
    public Trigger getReportTaskTrigger (ReportTask task, Class jobClass, Map <String, Object> jobExecParamAsMap)
    {
        Trigger trigger = null;
        if (StringUtils.isNotBlank (task.getHandle ()))
        {
            trigger = generateCronTrigger (jobClass, jobExecParamAsMap, task);
        }
        //        String timeCyc = task.getTimeCyc ();
        //        Trigger trigger = null;
        //        if (task.getExeCycle () == null || StringUtils.isBlank (timeCyc))
        //        {
        //            return trigger;
        //        }
        //        if (CronExpreUtil.isCronExpre (task.getExeCycle (), timeCyc))
        //        {
        //            // 表达式
        //            trigger = generateCronTrigger (jobClass, jobExecParamAsMap, task);
        //        }
        //        else
        //        {
        //            // 定時
        //            if (CronExpreUtil.getIntervalSecond (task.getExeCycle (), task.getTimeCyc ()) < 1)
        //            {
        //                return trigger;
        //            }
        //            trigger = generateTimeTrigger (jobClass, jobExecParamAsMap, task);
        //        }
        return trigger;
    }
    
    /**
     * 根据配置获取cron调度触发器
     *
     * @param jobClass
     *            任务处理类
     * @param jobExecParamAsMap
     *            任务处理类需要的相关参数
     * @param task
     *            cron表达式
     * @return
     */
    private CronTrigger generateCronTrigger (Class jobClass, Map <String, Object> jobExecParamAsMap, Task task)
    {
        JobConfig config = new JobConfig ();
        config.setCronExpre (task.getCronExpre ());
        config.setGroup (TaskConstant.SCAN_TASK);
        config.setName (task.getName ());
        config.setTaskId (task.getTaskId ().toString ());
        config.setValidTime (task.getValidTime ());
        config.setInvalidTime (task.getInvalidTime ());
        return TriggerUtil.getInstance ().generateCronTrigger (jobClass, jobExecParamAsMap, config, false);
    }
    
    /**
     * 根据配置获取cron调度触发器
     *
     * @param jobClass
     *            任务处理类
     * @param jobExecParamAsMap
     *            任务处理类需要的相关参数
     * @param task
     *            cron表达式
     * @return
     */
    private CronTrigger generateCronTrigger (Class jobClass, Map <String, Object> jobExecParamAsMap, ReportTask task)
    {
        
        //        String cronExpression = CronExpreUtil.generateCronExpre (task.getStartTime (), task.getExeCycle (), task.getTimeCyc ());
        String cronExpression = task.getHandle ();
        
        JobConfig config = new JobConfig ();
        config.setCronExpre (cronExpression);
        config.setGroup (TaskConstant.REPORT_TASK);
        config.setName (TaskConstant.REPORT_TASK + task.getId ());
        config.setTaskId (task.getId ().toString ());
        config.setValidTime (task.getStartTime ());
        config.setInvalidTime (task.getEndTime ());
        return TriggerUtil.getInstance ().generateCronTrigger (jobClass, jobExecParamAsMap, config, false);
    }
    
    /**
     * 根据配置获取频度调度触发器
     *
     * @param jobClass
     *            任务处理类
     * @param jobExecParamAsMap
     *            任务处理类需要的相关参数
     * @param task
     *            任务配置信息
     * @return
     */
    @SuppressWarnings ("rawtypes")
    private SimpleTrigger generateTimeTrigger (Class jobClass, Map <String, Object> jobExecParamAsMap, Task task)
    {
        
        JobConfig config = new JobConfig ();
        config.setRepeatInterval (task.getRepeatInterval ());
        config.setGroup (TaskConstant.SCAN_TASK);
        config.setName (task.getName ());
        config.setTaskId (task.getTaskId ().toString ());
        config.setValidTime (task.getValidTime ());
        config.setInvalidTime (task.getInvalidTime ());
        return TriggerUtil.getInstance ().generateTimeTrigger (jobExecParamAsMap, config);
    }
    
    /**
     * 根据配置获取频度调度触发器
     *
     * @param jobClass
     *            任务处理类
     * @param jobExecParamAsMap
     *            任务处理类需要的相关参数
     * @param task
     *            任务配置
     * @return
     */
    //    @SuppressWarnings ("rawtypes")
    //    private SimpleTrigger generateTimeTrigger(Class jobClass, Map <String, Object> jobExecParamAsMap, ReportTask task)
    //    {
    //        
    //        long spaceTime = CronExpreUtil.getIntervalSecond (task.getExeCycle (), task.getTimeCyc ());
    //        
    //        JobConfig config = new JobConfig ();
    //        config.setGroup (TaskConstant.REPORT_TASK);
    //        config.setName (TaskConstant.REPORT_TASK + task.getId ());
    //        config.setTaskId (task.getId ().toString ());
    //        config.setValidTime (task.getStartTime ());
    //        config.setInvalidTime (task.getEndTime ());
    //        config.setRepeatInterval (spaceTime);
    //        return TriggerUtil.getInstance ().generateTimeTrigger (jobExecParamAsMap, config);
    //    }
}
