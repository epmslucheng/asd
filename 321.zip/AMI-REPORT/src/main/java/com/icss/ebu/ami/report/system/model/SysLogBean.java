package com.icss.ebu.ami.report.system.model;

public class SysLogBean extends SysLog {
	/**
	 * 
	 */
	private static final long serialVersionUID = -2982215708620861692L;
	private String startTime;
	private String endTime;

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

}
