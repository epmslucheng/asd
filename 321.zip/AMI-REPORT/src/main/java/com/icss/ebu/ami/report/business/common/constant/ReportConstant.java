package com.icss.ebu.ami.report.business.common.constant;

import com.icss.ebu.ami.report.business.common.util.ConfigHolder;

/**
 * 报表系统常量
 * @author lvzhengtao
 *
 */
public class ReportConstant
{
    /**
     * ftp 日报表路径
     */
    public static final String REPORT_FTP_PATH_DAY = "REPORT_FTP_PATH_DAY";
    
    /**
     * ftp 月报表路径
     */
    public static final String REPORT_FTP_PATH_MONTH = "REPORT_FTP_PATH_MONTH";
    
    /**
     * ftp 目录路径
     */
    public static final String FTP_CATALOG = "FTP_CATALOG";
    
    /**
     * 临时文件路径
     */
    public static final String REPORT_TEMP_PATH = "REPORT_TEMP_PATH";
    
    /**
     * 日
     */
    public static final String REPORT_DAY = "day";
    
    /**
     * 月
     */
    public static final String REPORT_MONTH = "month";
    
    /**
     * 回车
     */
    public static final String REPORT_ENTER = "\n";
    
    /**
     * 空格
     */
    public static final String REPORT_SPACE = " ";
    
    /**
     * 分号
     */
    public static final String REPORT_SEMICOLON = ";";
    
    /**
     * 点号
     */
    public static final String REPORT_SPOT = ".";
    
    /**
     * 等号
     */
    public static final String REPORT_EQUAL = "=";
    
    /**
     * 左括号
     */
    public static final String REPORT_LEFT_BRACKET = "(";
    
    /**
     * 右括号
     */
    public static final String REPORT_RIGHT_BRACKET = ")";
    
    /**
     * 逗号
     */
    public static final String REPORT_COMMA = ",";
    
    /**
     * HTML类型 ：模板
     */
    public static final String HTML_TYPE_TEMPLATE = "0";
    
    /**
     * HTML类型：报表
     */
    public static final String HTML_TYPE_REPORT = "1";
    
    /**
     * 后缀名 .xls
     */
    public static final String REPORT_SUFFIX_XLS = ".xls";
    
    /**
     * 后缀名 .xlsx
     */
    public static final String REPORT_SUFFIX_XLSX = ".xlsx";
    
    /**
     * 后缀名 .html
     */
    public static final String REPORT_SUFFIX_HTML = ".html";
    
    /**
     * 坐标：行 
     */
    public static final String REPORT_SHEET_ROW = "row";
    
    /**
     * 坐标：列
     */
    public static final String REPORT_SHEET_COL = "col";
    
    public static final String REPORT_SHEET_SHEETNAME = "sheetName";
    
    public static final String REPORT_SYMBOL_$ = "\\$";
    
    public static final String REPORT_EXCLAMATORY = "!";
    
    /**
     * 字符集
     */
    public static final String REPORT_UTF_8 = "UTF-8";
    
    public static final String REPORT_ISO_8859_1 = "ISO-8859-1";
    
    public static final String REPORT_REPORT_DATE = "report_date";
    
    public static final String REPORT_TYPE_DAY = "0";
    
    public static final String REPORT_TYPE_MONTH = "1";
    
    /**
     * 失败、成功、处理中
     */
    public static final String REPORT_SUCCESS = "Success";
    
    public static final String REPORT_FAILURE = "Failure";
    
    public static final String REPORT_PROCESSING = "Processing";
    
    public static final int REPORT_PREVIEW_SIZE = 100;
    
    public static final String REPORT_USERID_ROOT = "1";
    
    /**
     * ftp变量
     * 
     */
    public static final String FTPHOST = "FTPHOST";;
    
    public static final String FTPPORT = "FTPPORT";
    
    public static final String FTPUSERNAME = "FTPUSERNAME";
    
    public static final String FTPPASSWORD = "FTPPASSWORD";
    
}
