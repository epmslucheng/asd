package com.icss.ebu.ami.report.business.service.impl;

import com.icss.ebu.ami.commons.pagePlugin.Page;
import com.icss.ebu.ami.commons.util.DateUtils;
import com.icss.ebu.ami.commons.util.UUIDUtils;
import com.icss.ebu.ami.report.business.mapper.ReportTaskMapper;
import com.icss.ebu.ami.report.business.model.ReportTask;
import com.icss.ebu.ami.report.business.model.ReportTaskObj;
import com.icss.ebu.ami.report.business.model.ReportTaskTemp;
import com.icss.ebu.ami.report.business.model.Template;
import com.icss.ebu.ami.report.business.service.ReportService;
import com.icss.ebu.ami.report.business.service.ReportTaskService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

@Service ("reportTaskService")
public class ReportTaskServiceImpl implements ReportTaskService
{
    
    @Autowired
    private ReportTaskMapper reportTaskMapper;
    
    @Autowired
    private ReportService reportService;
    
    @Override
    public Page <ReportTask> queryReportTaskByPage (Page <ReportTask> page)
    {
        page.setResults (reportTaskMapper.queryReportTaskByPage (page));
        return page;
    }
    
    @Override
    public ReportTask queryReportTaskById (String id)
    {
        return reportTaskMapper.queryReportTaskById (id);
    }
    
    @Override
    public int addReportTask (ReportTask reportTask)
    {
        reportTask.setId (UUIDUtils.generate16Str ());
        return reportTaskMapper.addReportTask (reportTask);
    }
    
    @Override
    public int editReportTask (ReportTask reportTask)
    {
        return reportTaskMapper.editReportTask (reportTask);
    }
    
    @Override
    public int delReportTaskById (String id)
    {
        return reportTaskMapper.delReportTaskById (id);
    }
    
    @Override
    public int addTaskReports (ReportTaskTemp reportTaskTemp)
    {
        reportTaskTemp.setId (UUIDUtils.generate16Str ());
        return reportTaskMapper.addTaskReports (reportTaskTemp);
    }
    
    @Override
    public int delTaskReportsByTaskId (String taskId)
    {
        return reportTaskMapper.delTaskReportsByTaskId (taskId);
    }
    
    @Override
    public int addTaskObjects (ReportTaskObj reportTaskObj)
    {
        reportTaskObj.setId (UUIDUtils.generate16Str ());
        return reportTaskMapper.addTaskObjects (reportTaskObj);
    }
    
    @Override
    public int delTaskObjectsByTaskId (String taskId)
    {
        return reportTaskMapper.delTaskObjectsByTaskId (taskId);
    }
    
    @Override
    public List <ReportTask> queryAllReportTask (String status)
    {
        return reportTaskMapper.queryAllReportTask (status);
    }
    
    @Override
    public List <Template> queryTemplatesByTaskId (String id)
    {
        return reportTaskMapper.queryTemplatesByTaskId (id);
    }
    
    @Override
    public List <ReportTaskObj> queryObjsByTaskId (String id)
    {
        return reportTaskMapper.queryObjsByTaskId (id);
    }
    
    @Override
    public void taskGenerateReport (String id)
    {
        ReportTask r = queryReportTaskById (id);
        Calendar c = Calendar.getInstance ();
        c.add (Calendar.DATE, r.getOffset ());
        
        String current = DateUtils.date2String (c.getTime (), DateUtils.DATE_PATTERN);
        Date time = DateUtils.string2Date (current, DateUtils.DATE_PATTERN);
        
        String start = "";
        String end = "";
        
        if ("0".equals (r.getType ()))
        {
            String cDate = DateUtils.date2String (c.getTime ());
            start = cDate + " 00:00:00";
            end = cDate + " 23:59:59";
        }
        else if ("1".equals (r.getType ()))
        {
            c.setTime (time);
            
            c.add (Calendar.MONTH, 0);
            c.set (Calendar.DAY_OF_MONTH, 1);
            start = DateUtils.date2String (c.getTime (), DateUtils.DATE_PATTERN);
            
            c.set (Calendar.DAY_OF_MONTH, c.getActualMaximum (Calendar.DAY_OF_MONTH));
            end = DateUtils.date2String (c.getTime (), DateUtils.DATE_PATTERN);
        }
        
        List <ReportTaskObj> os = queryObjsByTaskId (id);
        String treeMapStr = null;
        if (os.size () > 0)
        {
            StringBuilder treeMap = new StringBuilder ();
            for (ReportTaskObj o : os)
            {
                if (StringUtils.isNotBlank (o.getTreeCode ()))
                {
                    treeMap.append (o.getObjName ());
                    treeMap.append (",");
                    treeMap.append (o.getTreeCode ());
                    treeMap.append (",");
                    treeMap.append (o.getTreeId ());
                    treeMap.append (";");
                }
            }
            treeMapStr = treeMap.toString ();
        }
        
        List <Template> list = queryTemplatesByTaskId (id);
        for (Template t : list)
        {
            t.setTreeMap (treeMapStr);
            t.setStartTime (start);
            t.setEndTime (end);
            t.setCurrentTime (current);
            t.setUserId("0");
            t.setTmpdesc ("TaskID" + id);
            
            reportService.generateReport (t);
        }
    }
}
