package com.icss.ebu.ami.report.system.core.task;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.icss.ebu.ami.commons.aspect.RedisCacheUtil;
import com.icss.ebu.ami.commons.context.AbsrtactInitThread;
import com.icss.ebu.ami.commons.exception.ServiceException;
import com.icss.ebu.ami.report.business.common.util.ConfigHolder;

/**
 * 系统参数初始化进Redis
 * @author wanlilong
 *
 */
public class InitSystemPrarmThread extends AbsrtactInitThread
{
    
    private static final Logger LOGGER = LoggerFactory.getLogger(InitSystemPrarmThread.class);
    
    private static final int SYS_EXP = -1;
    
    private static String SYS_FALG_KEY = "report_sys_flag_key";
    
    private static String SYS_FALG_VALUE = "SUCC";
    
    private static final String SYS_SYN = "SYNING";
    
    @Autowired
    private RedisCacheUtil redisCacheUtil;
    
    @Override
    protected void updateInitData() throws ServiceException
    {
        LOGGER.info("initSystemPrarmThread start.");
        
        int sysExp = NumberUtils.toInt(ConfigHolder.getCfg("pcode_flag_exp"));
        String flag = redisCacheUtil.getDataFromRedis(SYS_FALG_KEY, String.class);
        //未到同步时间
        if(StringUtils.equals(flag, SYS_FALG_VALUE))
        {
            return;
        }
        //正在同步
        if(StringUtils.equals(flag, SYS_SYN))
        {
            return;
        }
        
        redisCacheUtil.saveDataInRedis(SYS_FALG_KEY, SYS_SYN, SYS_EXP);
        
        //接口调用参数保存redis
        //        saveSysConfig ();
        
        //部门组织保存redis
        //saveOrganization ();
        
        redisCacheUtil.saveDataInRedis(SYS_FALG_KEY, SYS_FALG_VALUE, sysExp);
        LOGGER.info("initSystemPrarmThread end.");
    }
    
}
