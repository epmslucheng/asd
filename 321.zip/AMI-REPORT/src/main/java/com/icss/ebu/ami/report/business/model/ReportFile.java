package com.icss.ebu.ami.report.business.model;

import java.io.Serializable;
import java.util.Date;

public class ReportFile implements Serializable
{
    
    /**
     * 
     */
    private static final long serialVersionUID = -9137601856086487003L;
    
    private String reportId;
    
    private String reportName;
    
    private String reportType;
    
    private String tempId;

    private String tempName;

    private String tmpKey;

    private String reportDesc;

    private String reportPath;

    private String subType;

    private Date createTime;

    /**
     * 报表生成状态： processing-生成中;success-生成成功;-failure生成失败
     */
    private String reportStatus;

    //用于用户权限控制查询
    private String userId;

    private String userName;

    /**
     * @return the reportId
     */
    public String getReportId ()
    {
        return reportId;
    }

    /**
     * @param reportId the reportId to set
     */
    public void setReportId (String reportId)
    {
        this.reportId = reportId;
    }

    /**
     * @return the reportName
     */
    public String getReportName ()
    {
        return reportName;
    }

    /**
     * @param reportName the reportName to set
     */
    public void setReportName (String reportName)
    {
        this.reportName = reportName;
    }

    /**
     * @return the reportType
     */
    public String getReportType ()
    {
        return reportType;
    }

    /**
     * @param reportType the reportType to set
     */
    public void setReportType (String reportType)
    {
        this.reportType = reportType;
    }

    /**
     * @return the tempId
     */
    public String getTempId ()
    {
        return tempId;
    }

    /**
     * @param tempId the tempId to set
     */
    public void setTempId (String tempId)
    {
        this.tempId = tempId;
    }

    /**
     * @return the tmpKey
     */
    public String getTmpKey ()
    {
        return tmpKey;
    }

    /**
     * @param tmpKey the tmpKey to set
     */
    public void setTmpKey (String tmpKey)
    {
        this.tmpKey = tmpKey;
    }

    /**
     * @return the reportDesc
     */
    public String getReportDesc ()
    {
        return reportDesc;
    }

    /**
     * @param reportDesc the reportDesc to set
     */
    public void setReportDesc (String reportDesc)
    {
        this.reportDesc = reportDesc;
    }

    /**
     * @return the reportPath
     */
    public String getReportPath ()
    {
        return reportPath;
    }

    /**
     * @param reportPath the reportPath to set
     */
    public void setReportPath (String reportPath)
    {
        this.reportPath = reportPath;
    }

    /**
     * @return the subType
     */
    public String getSubType ()
    {
        return subType;
    }

    /**
     * @param subType the subType to set
     */
    public void setSubType (String subType)
    {
        this.subType = subType;
    }

    public String getReportStatus ()
    {
        return reportStatus;
    }

    public void setReportStatus (String reportStatus)
    {
        this.reportStatus = reportStatus;
    }

    public String getUserId ()
    {
        return userId;
    }

    public void setUserId (String userId)
    {
        this.userId = userId;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getTempName() {
        return tempName;
    }

    public void setTempName(String tempName) {
        this.tempName = tempName;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }
}
