package com.icss.ebu.ami.report.system.model;

import java.io.Serializable;

/** 
* @author  zhangkaining 
* @date 2017年11月16日 下午2:01:57 
* @version 1.0   
*/
public class UserGrant implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6386935610830220346L;
	
	private String userid;
	
	private String cnnid;
	
	private String cubeid;
	
	private String tmpid;
	
	private String objid;

	public String getObjid() {
		return objid;
	}

	public void setObjid(String objid) {
		this.objid = objid;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getCnnid() {
		return cnnid;
	}

	public void setCnnid(String cnnid) {
		this.cnnid = cnnid;
	}

	public String getCubeid() {
		return cubeid;
	}

	public void setCubeid(String cubeid) {
		this.cubeid = cubeid;
	}

	public String getTmpid() {
		return tmpid;
	}

	public void setTmpid(String tmpid) {
		this.tmpid = tmpid;
	}
	
}
