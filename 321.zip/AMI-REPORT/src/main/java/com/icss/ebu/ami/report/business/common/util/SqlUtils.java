package com.icss.ebu.ami.report.business.common.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSONObject;
import com.icss.ebu.ami.commons.util.DateUtils;
import com.icss.ebu.ami.report.business.common.constant.ReportConstant;
import com.icss.ebu.ami.report.business.common.constant.SqlConstant;
import com.icss.ebu.ami.report.business.model.ConnectLine;
import com.icss.ebu.ami.report.business.model.Function;
import com.icss.ebu.ami.report.business.model.ObjectTreeBean;
import com.icss.ebu.ami.report.business.model.SqlObject;
import com.icss.ebu.ami.report.business.model.TableAssociation;
import com.icss.ebu.ami.report.business.model.TableField;
import com.icss.ebu.ami.report.business.model.TableModel;

/**
 * sql工具类
 * @author lucheng
 *
 */
public class SqlUtils
{
    
    private static Logger LOGGER = LoggerFactory.getLogger (SqlUtils.class);
    
    /**
     * 获取分页sql
     * @param pageNo
     * @param pageSize
     * @param sql
     * @param databaseType
     * @return
     */
    public static String getPageSql (int pageNo, int pageSize, String sql, String databaseType)
    {
        StringBuffer sqlBuffer = new StringBuffer (sql);
        if ("02".equalsIgnoreCase (databaseType))
        {
            return getMysqlPageSql (pageNo, pageSize, sqlBuffer);
        }
        else if ("01".equalsIgnoreCase (databaseType))
        {
            return getOraclePageSql (pageNo, pageSize, sqlBuffer);
        }
        
        return sqlBuffer.toString ();
    }
    
    /**
     * oracle分页sql
     * @param pageNo
     * @param pageSize
     * @param sqlBuffer
     * @return
     */
    public static String getOraclePageSql (int pageNo, int pageSize, StringBuffer sqlBuffer)
    {
        int offset;
        //计算第一条记录的位置，Oracle分页是通过rownum进行的，而rownum是从1开始的
        offset = pageNo * pageSize + 1;
        sqlBuffer.insert (0, "select u.*, rownum r from (").append (") u where rownum < ").append (offset);
        sqlBuffer.insert (0, "select * from (").append (") where r >= ").append (offset - pageSize);
        
        //上面的Sql语句拼接之后大概是这个样子：select * from (select u.*, rownum r from (select * from t_user) u where rownum < 31) where r >= 16
        return sqlBuffer.toString ();
    }
    
    /**
     * 获取Mysql数据库的分页查询语句
     *
     * @param page      分页对象
     * @param sqlBuffer 包含原sql语句的StringBuffer对象
     * @return Mysql数据库分页语句
     */
    public static String getMysqlPageSql (int pageNo, int pageSize, StringBuffer sqlBuffer)
    {
        int offset;
        offset = (pageNo - 1) * pageSize;
        sqlBuffer.append (" limit ").append (offset).append (",").append (pageSize);
        return sqlBuffer.toString ();
    }
    
    /**
     * 根据原Sql语句获取对应的查询总记录数的Sql语句
     *
     * @param sql
     * @return
     */
    public static String getCountSql (String sql)
    {
        
        return "select count(0) from (" + sql + ") report";
    }
    
    /**
     * 危险sql规则过滤
     * @param str
     * @return
     */
    public static boolean badSqlValidate (String sql)
    {
        String temp = sql;
        temp = temp.toLowerCase ();//统一转为小写
        String badStr = "insert|delete|update|drop|truncate|*";//过滤掉的sql关键字，可以手动添加
        String[] badStrs = badStr.split ("\\|");
        if (StringUtils.isNotBlank (sql))
        {
            List <String> sqlCut = Arrays.asList (temp.split (" "));
            if (null != sqlCut)
            {
                for (int i = 0; i < badStrs.length; i++)
                {
                    //循环检测，判断在请求参数当中是否包含SQL关键字
                    if (sqlCut.contains (badStrs[i]))
                    {
                        return true;
                    }
                }
                
            }
            
        }
        return false;
    }
    
    /**
     * 处理日期函数
     * @param dataSetSql
     * @param functions
     * @return
     */
    public static String assembleSqlFunction (String dataSetSql, String current, String start, String end,
        List <Function> functions)
    {
        if (StringUtils.isNotBlank (dataSetSql) && dataSetSql.indexOf ("%") > 0)
        {
            // 截取日期
            List <String> sl = new ArrayList <String> ();
            String[] s = dataSetSql.split ("\\(");
            for (int i = 0; i < s.length; i++)
            {
                String string = s[i];
                if (null != s[i] && "" != s[i] && s[i].indexOf (")") > -1)
                {
                    //.replaceAll ("'", "").replaceAll ("HH24", "HH").replaceAll ("mi", "mm")
                    sl.add (s[i].substring (0, s[i].indexOf (")")).trim ());
                }
                
            }
            
            String value = "";
            String functionName = "";
            for (String dateStr : sl)
            {
                if (dateStr.indexOf (",") < 0)
                {
                    continue;
                }
                for (Function func : functions)
                {
                    functionName = func.getFunctionName ();
                    if (dateStr.indexOf (functionName) > -1)
                    {
                        dateStr = dateStr.replaceAll ("'", "").replaceAll ("HH24", "HH").replaceAll ("mi", "mm");
                        String patten = dateStr.split (",")[1].trim ();
                        value = getTime (functionName, patten, current, start, end);
                        dataSetSql = dataSetSql.replaceAll (functionName, value);
                        
                    }
                }
            }
        }
        
        return dataSetSql;
    }
    
    /**
     * 处理对象树sql
     * @param dataSetSql
     * @param objectTreeList
     * @return
     */
    public static String assembleTreeSqlFunction (String dataSetSql, Map <String, String> idMap,
        List <ObjectTreeBean> objectTreeList)
    {
        if (null == idMap)
        {
            return dataSetSql;
        }
        if (StringUtils.isNotBlank (dataSetSql) && dataSetSql.indexOf ("%") > 0)
        {
            String value = "";
            String objname = "";
            for (ObjectTreeBean obj : objectTreeList)
            {
                objname = "%" + obj.getName () + "%";
                if (dataSetSql.indexOf (objname) > 0)
                {
                    dataSetSql = dataSetSql.replaceAll (objname, idMap.get (obj.getName ()));
                }
            }
        }
        
        return dataSetSql;
    }
    
    /**
     * 根据当前时间，开始时间，结束时间转化为需要的日期函数时间
     * @param functionName
     * @param current
     * @param start
     * @param end
     * @return
     */
    public static String getTime (String functionName, String patten, String current, String start, String end)
    {
        String value = "";
        Calendar c = Calendar.getInstance ();
        Date time = null;
        if (StringUtils.isBlank (current))
        {
            current = DateUtils.date2String (c.getTime (), patten);
        }
        switch (functionName)
        {
            case "%当前日期%":
                value = current;
                break;
            case "%开始日期%":
                if (StringUtils.isBlank (start))
                {
                    c.add (Calendar.MONTH, -1);
                    start = DateUtils.date2String (c.getTime (), patten);
                }
                value = start;
                break;
            case "%结束日期%":
                if (StringUtils.isBlank (end))
                {
                    end = DateUtils.date2String (c.getTime (), patten);
                }
                value = end;
                break;
            case "%上一日%":
                time = DateUtils.string2Date (current, patten);
                c.setTime (time);
                value = DateUtils.date2String (c.getTime (), patten);
                break;
            case "%本月初%":
                time = DateUtils.string2Date (current, patten);
                c.setTime (time);
                c.add (Calendar.MONTH, 0);
                c.set (Calendar.DAY_OF_MONTH, 1);
                value = DateUtils.date2String (c.getTime (), patten);
                break;
            case "%本月末%":
                time = DateUtils.string2Date (current, patten);
                c.setTime (time);
                c.set (Calendar.DAY_OF_MONTH, c.getActualMaximum (Calendar.DAY_OF_MONTH));
                value = DateUtils.date2String (c.getTime (), patten);
                break;
            
            default:
                break;
        }
        
        return value;
    }
    
    /**
     * sqlObject转化为json
     * @param sqlObject
     */
    public static String generateSqlJson (SqlObject sqlObject)
    {
        try
        {
            
            return JSONObject.toJSONString (sqlObject);
        }
        catch (Exception e)
        {
            LOGGER.error ("generate sql json error.", e);
            return "";
        }
    }
    
    /**
     * 将json字符串转化为可执行sql
     * @param sqlJson
     * @return
     */
    public static String generateSqlStr (String sqlJson)
    {
        SqlObject sqlObject = generateSqlObjectByJson (sqlJson);
        return generateSqlBySqlObject (sqlObject);
    }
    
    /**
     * SqlObject转为真实sql
     * @param sqlObject
     * @return
     */
    public static String generateSqlBySqlObject (SqlObject sqlObject)
    {
        if (null == sqlObject)
        {
            return "";
        }
        StringBuilder sqlSb = new StringBuilder ();
        sqlSb.append (sqlObject.getSqlSelect ());
        
        List <TableModel> tableModels = sqlObject.getTableModels ();
        StringBuilder tableSb = new StringBuilder ();
        StringBuilder colSb = new StringBuilder ();
        StringBuilder whereSb = new StringBuilder ();
        List <TableField> sqlColumns = sqlObject.getSqlColumns ();
        TableField tableField = null;
        for (int i = sqlColumns.size () - 1; i >= 0; i--)
        {
            tableField = sqlColumns.get (i);
            if (tableField.isChecked ())
            {
                colSb.append (ReportConstant.REPORT_SPACE).append (tableField.getTableFiledSql ())
                    .append (ReportConstant.REPORT_SPACE).append (SqlConstant.SQL_AS).append (ReportConstant.REPORT_SPACE)
                    .append (tableField.getTableFiledAlias ()).append (ReportConstant.REPORT_COMMA);
            }
        }
        if (StringUtils.isNotBlank (colSb))
        {
            
            colSb.setLength (colSb.length () - 1);
        }
        // 找到主表
        for (TableModel tableModel : tableModels)
        {
            if (StringUtils.isBlank (tableModel.getParentId ()))
            {
                appendTableModel (tableModel, tableSb);
                joinTable (tableModel, tableSb, tableModels);
                break;
            }
        }
        String sqlWhere = sqlObject.getSqlWhere ();
        String sqlWhereTemp = sqlWhere;
        if (StringUtils.isNotBlank (sqlWhereTemp))
        {
            if (sqlWhereTemp.toUpperCase ().startsWith (SqlConstant.SQL_WHERE))
            {
                whereSb.append (sqlWhere);
            }
            else
            {
                whereSb.append (SqlConstant.SQL_WHERE).append (ReportConstant.REPORT_SPACE).append (sqlWhere);
            }
        }
        sqlSb.append (ReportConstant.REPORT_SPACE).append (colSb.toString ()).append (ReportConstant.REPORT_SPACE)
            .append (sqlObject.getSqlFrom ()).append (ReportConstant.REPORT_SPACE).append (tableSb.toString ())
            .append (whereSb.toString ());
        return sqlSb.toString ();
    }
    
    /**
     * 拼表
     * @param tableModel
     * @param tableSb
     */
    private static void appendTableModel (TableModel tableModel, StringBuilder tableSb)
    {
        if (null != tableModel)
        {
            if (StringUtils.isBlank (tableModel.getParentId ()))
            {
                
                appendTable (tableModel, tableSb);
            }
            else
            {
                ConnectLine connectLine = tableModel.getConnectLine ();
                List <TableAssociation> tableAssociationList = connectLine.getFieldList ();
                tableSb.append (ReportConstant.REPORT_SPACE).append (connectLine.getLabel ())
                    .append (ReportConstant.REPORT_SPACE);
                appendTable (tableModel, tableSb);
                boolean flag = false;
                TableField sourceModel = null;
                TableField targetModel = null;
                for (TableAssociation tableAssociation : tableAssociationList)
                {
                    sourceModel = generateTableFieldByJson (tableAssociation.getSourceModel ());
                    targetModel = generateTableFieldByJson (tableAssociation.getTargetModel ());
                    if (!flag)
                    {
                        tableSb.append (ReportConstant.REPORT_SPACE).append (SqlConstant.SQL_ON);
                        flag = true;
                        
                    }
                    else
                    {
                        tableSb.append (ReportConstant.REPORT_SPACE).append (SqlConstant.SQL_AND);
                    }
                    if (null != sourceModel)
                    {
                        
                        tableSb.append (ReportConstant.REPORT_SPACE).append (sourceModel.getTableFiledSql ());
                    }
                    tableSb.append (ReportConstant.REPORT_SPACE).append (ReportConstant.REPORT_EQUAL);
                    if (null != targetModel)
                    {
                        tableSb.append (ReportConstant.REPORT_SPACE).append (targetModel.getTableFiledSql ())
                            .append (ReportConstant.REPORT_SPACE);
                    }
                    
                }
            }
        }
    }
    
    private static void appendTable (TableModel tableModel, StringBuilder tableSb)
    {
        if ("target".equals (tableModel.getTableType ()))
        {
            tableSb.append (ReportConstant.REPORT_SPACE).append (ReportConstant.REPORT_LEFT_BRACKET)
                .append (tableModel.getTableSql ()).append (ReportConstant.REPORT_RIGHT_BRACKET)
                .append (ReportConstant.REPORT_SPACE).append (tableModel.getNodeName ()).append (ReportConstant.REPORT_SPACE);
        }
        else
        {
            tableSb.append (ReportConstant.REPORT_SPACE).append (tableModel.getNodeName ()).append (ReportConstant.REPORT_SPACE);
        }
    }
    
    /**
     * 表关系处理
     * @param maintable 主表
     * @param tableSb 
     * @param trees 表集合
     * @return
     */
    public static boolean joinTable (TableModel tableModel, StringBuilder tableSb, List <TableModel> tableModels)
    {
        boolean flag = false;
        String parentId = "window" + tableModel.getNodeId ();
        for (TableModel model : tableModels)
        {
            if (parentId.equals (model.getParentId ()))
            {
                appendTableModel (model, tableSb);
                flag = joinTable (model, tableSb, tableModels);
            }
            
        }
        flag = true;
        return flag;
    }
    
    /**
     * json字符串转sqlObject
     * @param sqlJson
     * @return
     */
    public static SqlObject generateSqlObjectByJson (String sqlJson)
    {
        LOGGER.info ("Generate SqlObject by json : " + sqlJson);
        try
        {
            
            return JSONObject.toJavaObject (JSONObject.parseObject (sqlJson), SqlObject.class);
        }
        catch (Exception e)
        {
            LOGGER.error ("Generate SqlObject by json error.", e);
            return null;
        }
    }
    
    /**
     * json字符串转sqlObject
     * @param sqlJson
     * @return
     */
    public static TableField generateTableFieldByJson (String modelJson)
    {
        LOGGER.info ("Generate SqlObject by json : " + modelJson);
        try
        {
            
            return JSONObject.toJavaObject (JSONObject.parseObject (modelJson), TableField.class);
        }
        catch (Exception e)
        {
            LOGGER.error ("Generate SqlObject by json error.", e);
            return null;
        }
    }
    
    public static void main (String[] args)
    {/*
        
        SqlObject sqlObject = new SqlObject ();
        sqlObject.setSqlSelect ("SELECT");
        sqlObject.setSqlFrom ("FROM");
        sqlObject.setSqlWhere ("WHERE");
        sqlObject.setSqlColumns ("*");
        
        List <TableModel> tableModels = new ArrayList <TableModel> ();
        ConnectLine connectLine = null;
        List <TableAssociation> fieldList = null;
        TableAssociation tableAssociation = null;
        TableAssociation tableAssociation1 = null;
        TableModel tableModel = null;
        TableField sourceField = null;
        TableField targetField = null;
        TableField sourceField1 = null;
        TableField targetField1 = null;
        for (int i = 0; i < 5; i++)
        {
            connectLine = new ConnectLine ();
            tableModel = new TableModel ();
            sourceField = new TableField ();
            targetField = new TableField ();
            sourceField1 = new TableField ();
            targetField1 = new TableField ();
            tableAssociation = new TableAssociation ();
            tableAssociation1 = new TableAssociation ();
            fieldList = new ArrayList <TableAssociation> ();
            tableModel.setParentId (String.valueOf ((i - 1)));
            
            tableModel.setNodeId (String.valueOf (i));
            tableModel.setNodeName ("t_sys_user" + i);
            tableModel.setTableSql ("t_sys_user" + i);
            tableModel.setTableType ("table");
            if (i % 2 == 0)
            {
                tableModel.setTableSql ("select loginname,name,password from t_sys_user" + i);
                tableModel.setTableType ("target");
                
            }
            if (i == 0)
            {
                tableModel.setParentId ("");
            }
            else
            {
                
                sourceField.setTableFiledSql ("t_sys_user" + i + ".userId" + i);
                targetField.setTableFiledSql ("t_sys_user" + (i - 1) + ".userId" + (i - 1));
                sourceField1.setTableFiledSql ("t_sys_user" + i + ".loginname" + i);
                targetField1.setTableFiledSql ("t_sys_user" + (i - 1) + ".loginname" + (i - 1));
                tableAssociation.setSourceModel (sourceField);
                tableAssociation.setTargetModel (targetField);
                tableAssociation1.setSourceModel (sourceField1);
                tableAssociation1.setTargetModel (targetField1);
                fieldList.add (tableAssociation);
                fieldList.add (tableAssociation1);
                connectLine.setFieldList (fieldList);
                connectLine.setLabel ("LEFT JOIN");
                tableModel.setConnectLine (connectLine);
            }
            tableModels.add (tableModel);
        }
        sqlObject.setTableModels (tableModels);
        
        System.out.println (generateSqlJson (sqlObject));
        System.out.println (generateSqlBySqlObject (sqlObject));
        
     */
    }
}
