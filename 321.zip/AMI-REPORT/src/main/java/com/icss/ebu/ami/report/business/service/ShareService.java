package com.icss.ebu.ami.report.business.service;

/**
 * 共用方法
 * @author 李瑞
 *
 */
public interface ShareService {
	
	/**
	 * 生成ID(36位)
	 * @return String
	 */
	Long generateUUID();
}
