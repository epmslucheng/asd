package com.icss.ebu.ami.report.business.service;

import com.icss.ebu.ami.commons.pagePlugin.Page;
import com.icss.ebu.ami.report.system.model.SysLog;
import com.icss.ebu.ami.report.system.model.SysLogBean;
import com.icss.ebu.ami.report.system.model.User;

/**
 * @description：操作日志
 * @author：zhixuan.wang @date：2015/10/30 10:35
 */
public interface LogService
{
    
    void insertLog (SysLog sysLog);
    
    Page <SysLogBean> findSysLogByPage (Page <SysLogBean> page);
    
    /**
     * 添加业务日志
     * 
     * @param funDesc
     *            功能描述
     * @param operDetail
     *            操作细节
     * @param paramsOld
     *            修改前数据
     * @param paramsNew
     *            修改后数据
     *
     */
    void insertLog (String pOrgNo, String funDesc, String operDetail, String paramsOld, String paramsNew);
    
    /**
     * 添加日志
     */
    void insertSysLog (User user, String logType, String client, String funDesc, String operDetail, String paramsOld,
        String paramsNew);
    
    /**
     * 删除历史日志
     */
    int deleteSysLogByMaxId (Long sysLogId);
    
    void initLogTask ();
}
