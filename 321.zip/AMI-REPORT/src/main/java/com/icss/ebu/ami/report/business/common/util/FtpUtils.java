package com.icss.ebu.ami.report.business.common.util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import org.apache.commons.io.IOUtils;
import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;
import org.apache.commons.net.ftp.FTPReply;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.icss.ebu.ami.commons.util.AesKeyUtils;
import com.icss.ebu.ami.report.business.common.constant.ReportConstant;

/**
 * 文件处理工具类
 * @author lucheng
 *
 */
public class FtpUtils
{
    private static final Logger LOGGER = LoggerFactory.getLogger (FtpUtils.class);
    
    private final static int UPLOAD_BUFFER_SIZE = 1024 * 1024;
    
    /**
     * 此处需要的FTP服务器的参数，请从redis中获取
    * 上传文件（可供Controller层使用）
    * @param pathname FTP服务器保存目录
    * @param fileName 上传到FTP服务器后的文件名称
    * @param inputStream 输入文件流
    * @return
    */
    public static boolean uploadFile (String pathname, String fileName, InputStream inputStream)
    {
        boolean flag = false;
        FTPClient ftpClient = new FTPClient ();
        ftpClient.setControlEncoding (ReportConstant.REPORT_UTF_8);
        try
        { //设置超时时间
          //ftpClient.setConnectTimeout (1000 * 20);
            if (!ftpLogin (ftpClient))
            {
                return false;
            }
            ftpClient.setKeepAlive (true);
            ftpClient.setBufferSize (UPLOAD_BUFFER_SIZE);
            ftpClient.setFileType (FTPClient.BINARY_FILE_TYPE);
            ftpClient.setControlEncoding (ReportConstant.REPORT_UTF_8);
            createDirecroty (ftpClient, pathname);
            ftpClient.storeFile (pathname + "/" + fileName, inputStream);
            inputStream.close ();
            ftpClient.logout ();
            flag = true;
        }
        catch (Exception e)
        {
            LOGGER.error ("upload file error.", e);
        }
        finally
        {
            if (ftpClient.isConnected ())
            {
                try
                {
                    ftpClient.disconnect ();
                }
                catch (IOException e)
                {
                    LOGGER.error ("close ftp connection for upload error.", e);
                }
            }
            
            if (null != inputStream)
            {
                try
                {
                    inputStream.close ();
                }
                catch (IOException e)
                {
                    LOGGER.error ("close input Stream for upload error.", e);
                }
            }
        }
        return flag;
    }
    
    /**
     * 下载文件
     * @param pathname FTP服务器文件目录
     * @param filename 文件名称
     * @return
     */
    public static boolean downloadFile (String pathname, String filename, OutputStream out)
    {
        boolean flag = false;
        FTPClient ftpClient = new FTPClient ();
        try
        {
            //ftpClient.setConnectTimeout (1000 * 10);
            if (!ftpLogin (ftpClient))
            {
                return false;
            }
            
            ftpClient.setKeepAlive (true);
            ftpClient.setFileType (FTPClient.BINARY_FILE_TYPE);
            ftpClient.setFileTransferMode (FTPClient.BINARY_FILE_TYPE);
            ftpClient.setControlEncoding (ReportConstant.REPORT_UTF_8);
            //切换FTP目录
            ftpClient.changeWorkingDirectory (pathname);
            FTPFile[] ftpFiles = ftpClient.listFiles ();
            for (FTPFile file : ftpFiles)
            {
                if (filename.equalsIgnoreCase (file.getName ()))
                {
                    ftpClient.retrieveFile (new String (file.getName ().getBytes (ReportConstant.REPORT_UTF_8),
                        ReportConstant.REPORT_ISO_8859_1), out);
                    out.flush ();
                    out.close ();
                    break;
                }
            }
            
            flag = true;
        }
        catch (Exception e)
        {
            LOGGER.error ("download file error.", e);
        }
        finally
        {
            if (ftpClient.isConnected ())
            {
                try
                {
                    ftpClient.logout ();
                }
                catch (IOException e)
                {
                    LOGGER.error ("close connection for download file error.", e);
                }
            }
            
            if (null != out)
            {
                try
                {
                    out.close ();
                }
                catch (IOException e)
                {
                    LOGGER.error ("close outputStream for download file error.", e);
                }
            }
        }
        return flag;
    }
    
    /**
     * 删除文件
     * @param pathname FTP服务器保存目录
     * @param filename 要删除的文件名称
     * @return
     */
    public static boolean deleteFile (String pathname, String filename)
    {
        boolean flag = false;
        FTPClient ftpClient = new FTPClient ();
        try
        {
            if (!ftpLogin (ftpClient))
            {
                return false;
            }
            //切换FTP目录
            ftpClient.setControlEncoding (ReportConstant.REPORT_UTF_8);
            ftpClient.changeWorkingDirectory (pathname);
            ftpClient.dele (new String (filename.getBytes (ReportConstant.REPORT_UTF_8), ReportConstant.REPORT_ISO_8859_1));
            flag = true;
        }
        catch (Exception e)
        {
            LOGGER.error ("delete ftp file error.", e);
        }
        finally
        {
            if (ftpClient.isConnected ())
            {
                try
                {
                    ftpClient.logout ();
                }
                catch (IOException e)
                {
                    LOGGER.error ("close connection for delete ftp file error.", e);
                }
            }
        }
        return flag;
    }
    
    /**
     * 下载到指定目录下文件
     * @param pathname  FTP服务器文件目录
     * @param filename  文件名称
     * @param localpath 下载后的文件路径
     * @return
     */
    public static String downloadFile (String pathname, String filename, String localpath)
    {
        
        String downPath = "";
        FTPClient ftpClient = new FTPClient ();
        OutputStream os = null;
        try
        {
            if (!ftpLogin (ftpClient))
            {
                return downPath;
            }
            ftpClient.setControlEncoding (ReportConstant.REPORT_UTF_8); // 设置字符编码
            //切换FTP目录
            ftpClient.setKeepAlive (true);
            ftpClient.changeWorkingDirectory (pathname);
            ftpClient.setFileType (FTP.BINARY_FILE_TYPE);
            ftpClient.setControlEncoding (ReportConstant.REPORT_UTF_8);
            ftpClient.enterLocalPassiveMode ();
            FTPFile[] ftpFiles = ftpClient.listFiles ();
            for (FTPFile file : ftpFiles)
            {
                if (filename.equalsIgnoreCase (file.getName ()))
                {
                    downPath = localpath + File.separator + filename;
                    File localFile = new File (downPath);
                    if (!localFile.getParentFile ().mkdir ())
                    {
                        if (!localFile.exists ())
                        {
                            localFile.createNewFile ();
                        }
                    }
                    os = new FileOutputStream (localFile);
                    ftpClient.retrieveFile (new String (filename.getBytes (ReportConstant.REPORT_UTF_8),
                        ReportConstant.REPORT_ISO_8859_1), os);
                }
            }
        }
        catch (Exception e)
        {
            LOGGER.error ("downloadFile error : ", e);
        }
        finally
        {
            ftpQuit (ftpClient);
            IOUtils.closeQuietly (os);
        }
        return downPath;
    }
    
    /**
     * 下载文件
     * @param pathname  FTP服务器文件目录
     * @param filename  文件名称
     * @param localpath 下载后的文件路径
     * @return
     */
    public static String downloadTemplate (String pathname, String filename, String localpath)
    {
        String downPath = "";
        FTPClient ftpClient = new FTPClient ();
        OutputStream os = null;
        try
        {
            if (!ftpLogin (ftpClient))
            {
                return downPath;
            }
            ftpClient.setControlEncoding (ReportConstant.REPORT_UTF_8); // 设置字符编码
            //切换FTP目录
            ftpClient.setKeepAlive (true);
            ftpClient.changeWorkingDirectory (pathname);
            ftpClient.setFileType (FTP.BINARY_FILE_TYPE);
            ftpClient.setControlEncoding (ReportConstant.REPORT_UTF_8);
            ftpClient.enterLocalPassiveMode ();
            FTPFile[] ftpFiles = ftpClient.listFiles ();
            for (FTPFile file : ftpFiles)
            {
                if (filename.equalsIgnoreCase (file.getName ()))
                {
                    downPath = localpath;
                    File localFile = new File (downPath);
                    if (!localFile.getParentFile ().mkdir ())
                    {
                        if (!localFile.exists ())
                        {
                            localFile.createNewFile ();
                        }
                    }
                    os = new FileOutputStream (localFile);
                    ftpClient.retrieveFile (new String (file.getName ().getBytes (ReportConstant.REPORT_UTF_8),
                        ReportConstant.REPORT_ISO_8859_1), os);
                }
            }
        }
        catch (Exception e)
        {
            LOGGER.error ("downloadFile error : ", e);
        }
        finally
        {
            ftpQuit (ftpClient);
            IOUtils.closeQuietly (os);
        }
        return downPath;
    }
    
    /**
     * 重命名
     * @param pathname  FTP服务器文件目录
     * @param oldFileName  要重命名的文件名
     * @param newFileName  重命名后的文件名
     * @return
     */
    public static boolean renameFile (String pathname, String oldFileName, String newFileName)
    {
        boolean result = false;
        FTPClient ftpClient = new FTPClient ();
        try
        {
            if (!ftpLogin (ftpClient))
            {
                return result;
            }
            //切换FTP目录
            ftpClient.setControlEncoding (ReportConstant.REPORT_UTF_8);
            ftpClient.changeWorkingDirectory (pathname);
            ftpClient.enterLocalPassiveMode ();
            
            result =
                ftpClient.rename (new String (oldFileName.getBytes (ReportConstant.REPORT_UTF_8),
                    ReportConstant.REPORT_ISO_8859_1), new String (newFileName.getBytes (ReportConstant.REPORT_UTF_8),
                    ReportConstant.REPORT_ISO_8859_1));//重命名远程文件
        }
        catch (Exception e)
        {
            LOGGER.error ("rename file error : ", e);
        }
        finally
        {
            ftpQuit (ftpClient);
        }
        return result;
    }
    
    private static boolean ftpLogin (FTPClient ftpClient)
    {
        String hostname = ConfigHolder.getCfg (ReportConstant.FTPHOST);
        int port = Integer.valueOf (ConfigHolder.getCfg (ReportConstant.FTPPORT));
        String username = ConfigHolder.getCfg (ReportConstant.FTPUSERNAME);
        String password = ConfigHolder.getCfg (ReportConstant.FTPPASSWORD);
        return ftpLogin (ftpClient, hostname, port, username, password);
    }
    
    private static boolean ftpLogin (FTPClient ftpClient, String hostname, int port, String username, String password)
    {
        boolean revFlag = true;
        try
        {
            //连接FTP服务器
            ftpClient.connect (hostname, port);
            //登录FTP服务器
            ftpClient.login (username, AesKeyUtils.decrypt (password, PropertiesReader.getUserPwdKey ()));
            //是否成功登录FTP服务器
            int replyCode = ftpClient.getReplyCode ();
            if (!FTPReply.isPositiveCompletion (replyCode))
            {
                revFlag = false;
            }
        }
        catch (Exception e)
        {
            revFlag = false;
            LOGGER.error ("ftpLogin error : ", e);
        }
        return revFlag;
    }
    
    private static void ftpQuit (FTPClient ftpClient)
    {
        if (ftpClient.isConnected ())
        {
            try
            {
                ftpClient.logout ();
            }
            catch (Exception e)
            {
                LOGGER.error ("ftpQuit logout error  : ", e);
            }
            try
            {
                ftpClient.disconnect ();
            }
            catch (Exception e)
            {
                LOGGER.error ("ftpQuit disconnect error  : ", e);
            }
        }
    }
    
    public static boolean createDirecroty (FTPClient ftpClient, String directory) throws IOException
    {
        boolean success = true;
        // 如果远程目录不存在，则递归创建远程服务器目录  
        if (!directory.equalsIgnoreCase ("/") && !changeWorkingDirectory (ftpClient, new String (directory)))
        {
            String[] dirs = directory.split ("/");
            
            int start = 0;
            if (directory.startsWith ("/"))
            {
                start = 1;
            }
            else
            {
                start = 0;
            }
            String pathName = "";
            for (int i = start; i < dirs.length; i++)
            {
                String subDirectory =
                    new String (dirs[i].getBytes (ReportConstant.REPORT_UTF_8), ReportConstant.REPORT_ISO_8859_1);
                pathName = pathName + "/" + subDirectory;
                if (!changeWorkingDirectory (ftpClient, pathName))
                {
                    if (makeDirectory (ftpClient, pathName))
                    {
                        changeWorkingDirectory (ftpClient, pathName);
                    }
                    else
                    {
                        LOGGER.info ("create Direcroty[" + pathName + "]fail.");
                        success = false;
                        return success;
                    }
                }
                
            }
            
        }
        return success;
    }
    
    public static boolean makeDirectory (FTPClient ftpClient, String dir)
    {
        boolean flag = true;
        try
        {
            ftpClient.makeDirectory (dir);
            LOGGER.info ("makeDirectory " + dir + " success.");
            
        }
        catch (Exception e)
        {
            LOGGER.error ("makeDirectory error  : ", e);
        }
        return flag;
    }
    
    /**  
     * 进入到服务器的某个目录下  
     *  
     * @param directory  
     */
    public static boolean changeWorkingDirectory (FTPClient ftpClient, String directory)
    {
        boolean flag = true;
        try
        {
            flag = ftpClient.changeWorkingDirectory (directory);
            if (flag)
            {
                LOGGER.info ("change Working Directory " + directory + " success.");
                
            }
            else
            {
                LOGGER.info ("change Working Directory " + directory + " fail.");
            }
        }
        catch (IOException e)
        {
            LOGGER.error ("change Working Directory error  : ", e);
        }
        return flag;
    }
}
