package com.icss.ebu.ami.report.business.model;

import java.io.Serializable;

public class ReportTaskObj implements Serializable
{
    
    private static final long serialVersionUID = 1652270207798171674L;
    
    private String id;
    
    private String taskId;
    
    private String objId;

    private String objName;

    private String treeName;
    
    private String treeCode;
    
    private String treeId;
    
    public String getId ()
    {
        return id;
    }
    
    public void setId (String id)
    {
        this.id = id;
    }
    
    public String getTaskId ()
    {
        return taskId;
    }
    
    public void setTaskId (String taskId)
    {
        this.taskId = taskId;
    }
    
    public String getObjId ()
    {
        return objId;
    }
    
    public void setObjId (String objId)
    {
        this.objId = objId;
    }
    
    public String getTreeCode ()
    {
        return treeCode;
    }
    
    public void setTreeCode (String treeCode)
    {
        this.treeCode = treeCode;
    }
    
    public String getTreeId ()
    {
        return treeId;
    }
    
    public void setTreeId (String treeId)
    {
        this.treeId = treeId;
    }
    
    public String getTreeName ()
    {
        return treeName;
    }
    
    public void setTreeName (String treeName)
    {
        this.treeName = treeName;
    }

    public String getObjName() {
        return objName;
    }

    public void setObjName(String objName) {
        this.objName = objName;
    }
}
