package com.icss.ebu.ami.report.business.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.icss.ebu.ami.auth.domain.oauth.AccessToken;
import com.icss.ebu.ami.auth.domain.oauth.ClientDetails;
import com.icss.ebu.ami.auth.infrastructure.cache.CacheKeyGenerator;
import com.icss.ebu.ami.commons.aspect.RedisCacheUtil;
import com.icss.ebu.ami.report.business.mapper.DeptAdminMapper;
import com.icss.ebu.ami.report.business.mapper.OauthMapper;
import com.icss.ebu.ami.report.business.mapper.UserMapper;
import com.icss.ebu.ami.report.business.service.OAuthRSService;
import com.icss.ebu.ami.report.system.mapper.RoleMapper;
import com.icss.ebu.ami.report.system.model.Role;
import com.icss.ebu.ami.report.system.model.User;

/**
 * 2015/7/8
 *
 * @author Shengzhao Li
 */
@Service ("oAuthRSService")
public class OAuthRSServiceImpl implements OAuthRSService
{
    
    private static final Logger LOG = LoggerFactory.getLogger(OAuthRSServiceImpl.class);
    
    @Autowired
    private OauthMapper oauthMapper;
    
    @Autowired
    private RedisCacheUtil redisCacheUtil;
    
    @Autowired
    private RoleMapper roleMapper;
    
    @Autowired
    private DeptAdminMapper deptAdminMapper;
    
    @Autowired
    private UserMapper userMapper;
    
    //redis 是否缓存PCODE有效时间
    private static final int TOKEN_EXP = -1;
    
    @Override
    public AccessToken loadAccessTokenByTokenId(String tokenId)
    {
        
        final String key = CacheKeyGenerator.generateAccessTokenKey(tokenId);
        AccessToken accessToken = (AccessToken) redisCacheUtil.getDataFromRedis(key);
        
        /*if(accessToken == null)
        {
            accessToken = oauthMapper.findAccessTokenByTokenId(tokenId);
            if(null != accessToken)
            {
                accessToken.activeMillisecond(System.currentTimeMillis());
                redisCacheUtil.saveDataInRedis(key, accessToken, TOKEN_EXP);
                
            }
            LOG.info("Load AccessToken[{}] from DB and cache it, key = {}", accessToken, key);
        }*/
        
        return accessToken;
    }
    
    @Override
    public ClientDetails loadClientDetails(String clientId, String resourceIds)
    {
        
        final String key = CacheKeyGenerator.generateClientDetailsResourceIdsKey(clientId, resourceIds);
        ClientDetails clientDetails = (ClientDetails) redisCacheUtil.getDataFromRedis(key);
        
        if(clientDetails == null)
        {
            ClientDetails param = new ClientDetails();
            param.clientId(clientId);
            param.resourceIds(resourceIds);
            clientDetails = oauthMapper.findClientDetailsByClientIdAndResourceIds(param);
            redisCacheUtil.saveDataInRedis(key, clientDetails, TOKEN_EXP);
            LOG.info("Load ClientDetails[{}] from DB and cache it, key = {}", clientDetails, key);
        }
        
        return clientDetails;
    }
    
    @Override
    public List<Role> queryRolesByUserId(String userId)
    {
        return roleMapper.queryRolesByUserId(userId);
    }
    
    @Override
    public User findUserById(String id)
    {
        User user = userMapper.findUserById(id);
        /*if (user != null)
        {
            DeptAdmin deptAdmin = new DeptAdmin ();
            deptAdmin.setUserId (id);
            List <DeptAdmin> deptList = deptAdminMapper.queryDeptAdmin (deptAdmin);
            if (CollectionUtils.isNotEmpty (deptList))
            {
                user.setDeptLeader (ConstantCode.STRING_1);
            }
            else
            {
                user.setDeptLeader (ConstantCode.STRING_0);
            }
        }*/
        return user;
    }
}
