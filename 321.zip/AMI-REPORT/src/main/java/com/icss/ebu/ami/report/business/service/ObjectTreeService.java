package com.icss.ebu.ami.report.business.service;

import com.icss.ebu.ami.commons.pagePlugin.Page;
import com.icss.ebu.ami.report.business.model.DataSetObject;
import com.icss.ebu.ami.report.business.model.ObjectTreeBean;
import com.icss.ebu.ami.report.business.model.ObjectTreeNode;
import com.icss.ebu.ami.report.business.model.ReportTaskTempObjs;

import java.util.List;

/**
 * 对象树service
 * @author xunan
 *
 */
public interface ObjectTreeService
{
    Page <ObjectTreeBean> queryObjectTree (Page <ObjectTreeBean> page);
    
    Integer save (ObjectTreeBean objectTree);
    
    Integer update (ObjectTreeBean objectTree);
    
    Integer del (ObjectTreeBean objectTreeBean);
    
    List <ObjectTreeBean> queryAllObjectTree (ObjectTreeBean objectTreeBean);
    
    Integer saveTreeNode (ObjectTreeNode treeNode);
    
    Integer editTreeNode (ObjectTreeNode treeNode);
    
    Integer saveTreeRootNode (ObjectTreeNode treeNode);
    
    Integer delTreeNode (ObjectTreeNode treeNode);
    
    List <ObjectTreeNode> queryTreeRootNode (ObjectTreeBean objectTree);
    
    List <ObjectTreeNode> queryTreeNodeList (ObjectTreeBean objectTree);
    
    List <ObjectTreeNode> findAll ();
    
    int insertDataSetObject (List <DataSetObject> list);
    
    int deleteDataSetObjectByQueryId (String queryId);
    
    List <ObjectTreeBean> queryObjectTreesListByTempIds (ReportTaskTempObjs reportTaskTempObjs);
}
