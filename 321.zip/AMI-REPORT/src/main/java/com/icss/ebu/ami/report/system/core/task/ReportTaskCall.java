package com.icss.ebu.ami.report.system.core.task;

import java.util.concurrent.Callable;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.icss.ebu.ami.report.business.model.ReportTask;

/**
 * 采集任务调度任务
 * 
 * @author tfl
 *
 */
public class ReportTaskCall implements Callable <Boolean>
{
    private Logger logger = LoggerFactory.getLogger (ReportTaskCall.class);
    
    private ReportTask task;
    
    private ReportTaskScheduleManager reportTaskScheduleManager;
    
    public ReportTaskCall (ReportTask task, ReportTaskScheduleManager reportTaskScheduleManager)
    {
        this.task = task;
        this.reportTaskScheduleManager = reportTaskScheduleManager;
    }
    
    @Override
    public Boolean call () throws Exception
    {
        boolean flag = true;
        try
        {
            if (!reportTaskScheduleManager.checkTaskExist (task))
            {
                reportTaskScheduleManager.runInitTask (task);
            }
            else if (reportTaskScheduleManager.checkTaskModify (task))
            {
                reportTaskScheduleManager.addOrUpdateTaskToCached (task);
                reportTaskScheduleManager.removeTask (task.getId ());
                reportTaskScheduleManager.runInitTask (task);
            }
        }
        catch (Exception e)
        {
            flag = false;
            logger.error ("ReportTask: " + task.toString () + "schedule failure", e);
        }
        return flag;
    }
}
