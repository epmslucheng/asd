package com.icss.ebu.ami.report.business.controller;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.icss.ebu.ami.commons.pagePlugin.Page;
import com.icss.ebu.ami.report.business.common.constant.CommonConstant;
import com.icss.ebu.ami.report.business.common.constant.ReportConstant;
import com.icss.ebu.ami.report.business.common.util.FtpUtils;
import com.icss.ebu.ami.report.business.model.ReportFile;
import com.icss.ebu.ami.report.business.model.ReportHtml;
import com.icss.ebu.ami.report.business.service.ReportFileService;
import com.icss.ebu.ami.report.business.service.UserService;
import com.icss.ebu.ami.report.system.model.User;

@Controller
@RequestMapping ("/reportFile")
public class ReportFileController extends BaseController
{
    private static final Logger LOGGER = LoggerFactory.getLogger (ReportController.class);
    
    @Autowired
    private ReportFileService reportFileService;
    
    @Autowired
    private UserService userService;
    
    @RequestMapping ("")
    public String index ()
    {
        return "/service/reportFile/reportFile";
    }
    
    @RequestMapping ("/editPage")
    public String editPage ()
    {
        return "/service/reportFile/reportFileEdit";
    }
    
    @RequestMapping ("/datagrid")
    @ResponseBody
    public Map <String, Object> datagrid (ReportFile reportFile, HttpServletRequest request)
    {
        Map <String, Object> map = new HashMap <String, Object> ();
        
        User currentUser = getCurrentUser ();
        if (!ReportConstant.REPORT_USERID_ROOT.equals (currentUser.getId ()))
        {
            reportFile.setUserId (currentUser.getId ());
        }
        Page <ReportFile> page = new Page <ReportFile> (reportFile);
        page.setPageNo (NumberUtils.toInt (request.getParameter (CommonConstant.PAGE_PARAM_PAGE)));
        page.setPageSize (NumberUtils.toInt (request.getParameter (CommonConstant.PAGE_PARAM_ROWS)));
        
        page = reportFileService.queryReportFileByPage (page);
        map.put (CommonConstant.PAGE_RESULT_ROWS, page.getResults ());
        map.put (CommonConstant.PAGE_RESULT_TOTAL, page.getTotalRecord ());
        
        return map;
    }
    
    @RequestMapping ("/edit")
    @ResponseBody
    public Object edit (@RequestBody ReportFile reportFile)
    {
        String reportId = reportFile.getReportId ();
        String oldName = reportFileService.queryReportFileById (reportId).getReportName ();
        
        String pathname = reportFile.getReportPath ();
        String filename = reportFile.getReportName ();
        
        boolean ftpFlag = false;
        if (!oldName.equals (filename))
        {
            String oldPreName = oldName.substring (0, oldName.lastIndexOf ("."));
            String preName = filename.substring (0, filename.lastIndexOf ("."));
            try
            {
                ftpFlag = FtpUtils.renameFile (pathname, oldName, filename);
                
                List <ReportHtml> htmls = reportFileService.queryHtmlsByReportId (reportId);
                if (null != htmls && !htmls.isEmpty ())
                {
                    try
                    {
                        for (ReportHtml h : htmls)
                        {
                            String suffix = ";" + h.getSheetName () + ".html";
                            FtpUtils.renameFile (pathname, oldPreName + suffix, preName + suffix);
                            h.setHtmlName (preName + suffix);
                            reportFileService.editReportHtml (h);
                        }
                    }
                    catch (Exception e)
                    {
                        LOGGER.error ("editReportFile html error.", e);
                    }
                }
                
            }
            catch (Exception e)
            {
                LOGGER.error ("editReportFile error.", e);
            }
            finally
            {
                if (!ftpFlag)
                {
                    return renderError (super.getProperty ("ami.common.optFail"));
                }
            }
        }
        int rt = reportFileService.editReportFile (reportFile);
        if (rt == 1)
        {
            return renderSuccess (super.getProperty ("ami.common.optSuccess"));
        }
        else
        {
            return renderError (super.getProperty ("ami.common.optFail"));
        }
    }
    
    @RequestMapping ("/delete")
    @ResponseBody
    public Object delete (@RequestBody ReportFile reportFile)
    {
        int rt = reportFileService.deleteReport (reportFile);
        if (rt == 1)
        {
            return renderSuccess (super.getProperty ("ami.common.optSuccess"));
        }
        else if(rt == 2)
        {
            return renderError (super.getProperty ("ami.file.ftpError"));
        }
        else
        {
            return renderError (super.getProperty ("ami.common.optFail"));
        }
    }
    
    @RequestMapping ("/download")
    @ResponseBody
    public void download (HttpServletRequest request, HttpServletResponse response)
    {
        ReportFile reportFile = reportFileService.queryReportFileById (request.getParameter ("id"));
        String pathname = reportFile.getReportPath ();
        String filename = reportFile.getReportName ();
        
        OutputStream o = null;
        try
        {
            o = response.getOutputStream ();
            response.reset ();
            response.setContentType ("application/x-xls ;charset=UTF-8");
            response.setHeader ("Content-disposition", "attachment;filename="
                + new String (filename.getBytes (ReportConstant.REPORT_UTF_8), ReportConstant.REPORT_ISO_8859_1));
            FtpUtils.downloadFile (pathname, filename, o);
        }
        catch (Exception e)
        {
            LOGGER.error ("downloadReportFile error.", e);
        }
    }
    
    @RequestMapping ("/viewPage")
    public String viewPage (HttpServletRequest request)
    {
        List <ReportHtml> htmls = new ArrayList <ReportHtml> ();
        String reportId = request.getParameter ("id");
        if (StringUtils.isNotBlank (reportId))
        {
            htmls = reportFileService.queryHtmlsByReportId (reportId);
            
            if (null != htmls && !htmls.isEmpty ())
            {
                for (ReportHtml reportHtml : htmls)
                {
                    String pathname = reportHtml.getHtmlPath ();
                    String filename = reportHtml.getHtmlName ();
                    String localpath = request.getSession ().getServletContext ().getRealPath ("/") + "script" + File.separator
                        + "file" + File.separator + reportHtml.getShowName ();
                    InputStream is = null;
                    try
                    {
                        FtpUtils.downloadTemplate (pathname, filename, localpath);
                    }
                    catch (Exception e)
                    {
                        LOGGER.error ("download file error.", e);
                    }
                    finally
                    {
                        try
                        {
                            if (null != is)
                            {
                                is.close ();
                            }
                        }
                        catch (IOException e)
                        {
                            LOGGER.error ("view file error.", e);
                        }
                    }
                }
            }
        }
        return "/service/reportFile/reportHtml";
    }
    
    @RequestMapping ("/htmlDatagrid")
    @ResponseBody
    public Map <String, Object> htmlDatagrid (HttpServletRequest request)
    {
        ReportHtml reportHtml = new ReportHtml ();
        Map <String, Object> map = new HashMap <String, Object> ();
        reportHtml.setId (request.getParameter ("id"));
        Page <ReportHtml> page = new Page <ReportHtml> (reportHtml);
        page.setPageNo (NumberUtils.toInt (request.getParameter (CommonConstant.PAGE_PARAM_PAGE)));
        page.setPageSize (NumberUtils.toInt (request.getParameter (CommonConstant.PAGE_PARAM_ROWS)));
        
        page = reportFileService.queryHtmlsByPage (page);
        map.put (CommonConstant.PAGE_RESULT_ROWS, page.getResults ());
        map.put (CommonConstant.PAGE_RESULT_TOTAL, page.getTotalRecord ());
        
        return map;
    }
}
