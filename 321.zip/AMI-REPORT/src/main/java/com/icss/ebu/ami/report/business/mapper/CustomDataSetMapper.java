package com.icss.ebu.ami.report.business.mapper;

import java.util.List;

import com.icss.ebu.ami.commons.pagePlugin.Page;
import com.icss.ebu.ami.report.business.model.DataSet;
import com.icss.ebu.ami.report.business.model.DataSourceTable;
import com.icss.ebu.ami.report.business.model.DataSourceTableFiled;
import com.icss.ebu.ami.report.business.model.Function;

public interface CustomDataSetMapper
{
    List <DataSet> findCustomDataSets (Page <DataSet> page);
    
    DataSet findCustomDataSetById (String queryId);
    
    int addDataSet (DataSet dataSet);
    
    int editDataSet (DataSet dataSet);
    
    int delete (DataSet dataSet);
    
    List <DataSet> queryAll ();
    
    List <Function> findAllFunction ();
    
    int insetDataSetCols (List <DataSourceTableFiled> list);
    
    int deleteDataSetCols (DataSourceTable dsb);
}
