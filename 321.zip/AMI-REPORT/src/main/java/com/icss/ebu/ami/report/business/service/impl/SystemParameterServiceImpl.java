package com.icss.ebu.ami.report.business.service.impl;

import com.icss.ebu.ami.commons.pagePlugin.Page;
import com.icss.ebu.ami.report.business.common.util.ConfigHolder;
import com.icss.ebu.ami.report.business.mapper.SystemParameterMapper;
import com.icss.ebu.ami.report.business.service.SystemParameterService;
import com.icss.ebu.ami.report.system.model.SystemParameter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service("systemParameterService")
public class SystemParameterServiceImpl implements SystemParameterService {
    @Autowired
    private SystemParameterMapper systemParameterMapper;

    @Override
    public Page<SystemParameter> querySystemParameterByPage(Page<SystemParameter> page) {
        page.setResults(systemParameterMapper.querySystemParameterByPage(page));
        return page;
    }

    @Override
    public SystemParameter querySystemParameterById(String id) {
        return systemParameterMapper.querySystemParameterById(id);
    }

    @Override
    public int editSystemParameter(SystemParameter systemParameter) {
        int rt = systemParameterMapper.editSystemParameter(systemParameter);
        ConfigHolder.setCfg (systemParameter.getName (), systemParameter.getValue ());
        return rt;
    }

    @Override
    public List<SystemParameter> querySystemParameterAll() {
        return systemParameterMapper.querySystemParameterAll();
    }
}
