package com.icss.ebu.ami.report.business.model;

import java.io.Serializable;

/**
 * 数据源实体类
 * @author xunan
 *
 */
public class DataSourceBean implements Serializable
{
    
    /**
     * 
     */
    private static final long serialVersionUID = -4529592467104232061L;
    
    private String id;
    
    private String key;
    
    private String dbName;
    
    private String dbPwd;
    
    //01 Oracle 02 MySql
    private String dbType;
    
    private String url;
    
    private String driveClassName;
    
    private String name;
    
    private String userId;
    
    private boolean checked = false;
    
    public boolean isChecked ()
    {
        return checked;
    }
    
    public void setChecked (boolean checked)
    {
        this.checked = checked;
    }
    
    public String getName ()
    {
        return name;
    }
    
    public void setName (String name)
    {
        this.name = name;
    }
    
    public String getId ()
    {
        return id;
    }
    
    public void setId (String id)
    {
        this.id = id;
    }
    
    public String getKey ()
    {
        return key;
    }
    
    public void setKey (String key)
    {
        this.key = key;
        this.name = key;
    }
    
    public String getDbName ()
    {
        return dbName;
    }
    
    public void setDbName (String dbName)
    {
        this.dbName = dbName;
    }
    
    public String getDbPwd ()
    {
        return dbPwd;
    }
    
    public void setDbPwd (String dbPwd)
    {
        this.dbPwd = dbPwd;
    }
    
    public String getDbType ()
    {
        return dbType;
    }
    
    public void setDbType (String dbType)
    {
        this.dbType = dbType;
    }
    
    public String getUrl ()
    {
        return url;
    }
    
    public void setUrl (String url)
    {
        this.url = url;
    }
    
    public String getDriveClassName ()
    {
        return driveClassName;
    }
    
    public void setDriveClassName (String driveClassName)
    {
        this.driveClassName = driveClassName;
    }
    
    public String getUserId ()
    {
        return userId;
    }
    
    public void setUserId (String userId)
    {
        this.userId = userId;
    }
    
}
