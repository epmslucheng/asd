package com.icss.ebu.ami.report.system.core.task;

import com.icss.ebu.ami.report.business.model.ReportTask;
import com.icss.ebu.ami.report.business.service.ReportTaskService;
import com.icss.ebu.ami.report.system.service.TaskService;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.concurrent.Future;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

@Service ("generateReportScheduleJob")
public class GenerateReportScheduleJob extends AbstractTask {

    private Logger logger = LoggerFactory.getLogger(GenerateReportScheduleJob.class);

    @Autowired
    private ReportTaskService reportTaskService;

    @Autowired
    private ReportTaskScheduleManager reportTaskScheduleManager;

    private static ThreadPoolExecutor pools =
            new ThreadPoolExecutor(10, 30, 5, TimeUnit.SECONDS, new LinkedBlockingQueue<Runnable>(200));

    @Override
    public void execTask()
    {
        //FIXME 读取自定义报表，判断时间是否达到，如果达到则生成对应文件（使用异步线程）
        logger.info ("执行任务>>>{}" + this.getTaskId () + ":" + this.getTaskCode (), "generateReportScheduleJob");
        try
        {
            List<ReportTask> taskList = getReportTaskService ().queryAllReportTask (ReportTask.STATUS_RUNNING);
            if (!CollectionUtils.isEmpty (taskList))
            {
                // 过滤无效任务
                Iterator<ReportTask> taskIter = taskList.iterator ();
                ReportTask reportTask;
                while (taskIter.hasNext ())
                {
                    reportTask = taskIter.next ();

                    //  handle有效性判断，待优化
                    if (StringUtils.isBlank(reportTask.getHandle ()))
                    {
                        taskIter.remove ();
                    }
                }

                Set<Long> existTasks = new HashSet<> ();
                List <Future<Boolean>> futureList = new ArrayList <> (200);
                for (ReportTask task : taskList)
                {
                    existTasks.add (task.getLongId ());
                    futureList.add (
                            pools.submit (new ReportTaskCall (task, getReportTaskScheduleManager())));
                }

                // 删除调度任务
                getReportTaskScheduleManager().filterExistTask (existTasks);

                taskList.clear ();
                futureList.clear ();
                existTasks.clear ();

            }
            else
            {
                // 删除调度任务
                getReportTaskScheduleManager().filterExistTask (new HashSet <Long> ());
            }
            taskList.clear ();

        }
        catch (Exception e)
        {
            logger.error ("CronTimeJob调度任务执行异常：", e);
        }
    }

    public ReportTaskService getReportTaskService()
    {
        if (reportTaskService == null)
        {
            reportTaskService = (ReportTaskService) applicationContext.getBean ("reportTaskService");
        }
        return reportTaskService;
    }

    public ReportTaskScheduleManager getReportTaskScheduleManager()
    {
        if (reportTaskScheduleManager == null)
        {
            reportTaskScheduleManager = (ReportTaskScheduleManager) applicationContext.getBean ("reportTaskScheduleManager");
        }
        return reportTaskScheduleManager;
    }
}