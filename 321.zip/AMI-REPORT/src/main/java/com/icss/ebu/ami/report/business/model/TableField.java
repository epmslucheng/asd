package com.icss.ebu.ami.report.business.model;

import java.io.Serializable;

/**
 * 数据源表实体类
 * @author xunan
 *
 */
public class TableField implements Serializable
{
    
    /**
     * 
     */
    private static final long serialVersionUID = -9052100132585233831L;
    
    //字段id
    private String id;
    
    //对应数据源id
    private String cnnId;
    
    //表名称
    private String tableName;
    
    //表名称
    private String tableSql;
    
    //表id
    private String tableId;
    
    //表类型
    private String tableType;
    
    //表字段
    private String tableFiled;
    
    //表查询字段  表名.字段名
    private String tableFiledSql;
    
    //表字段别名  展示用
    private String tableFiledAlias;
    
    //树节点id
    private String treeId;
    
    //树名称
    private String name;
    
    //树节点是否可编辑
    private boolean editable;
    
    private String parentId;
    
    private boolean draggable;
    
    private boolean checked;
    
    public boolean isDraggable ()
    {
        return draggable;
    }
    
    public void setDraggable (boolean draggable)
    {
        this.draggable = draggable;
    }
    
    public String getParentId ()
    {
        return parentId;
    }
    
    public void setParentId (String parentId)
    {
        this.parentId = parentId;
    }
    
    public String getId ()
    {
        return id;
    }
    
    public String getCnnId ()
    {
        return cnnId;
    }
    
    public void setCnnId (String cnnId)
    {
        this.cnnId = cnnId;
    }
    
    public String getName ()
    {
        return name;
    }
    
    public void setName (String name)
    {
        this.name = name;
    }
    
    public void setId (String id)
    {
        this.id = id;
    }
    
    public String getTableName ()
    {
        return tableName;
    }
    
    public void setTableName (String tableName)
    {
        this.tableName = tableName;
    }
    
    public String getTableId ()
    {
        return tableId;
    }
    
    public void setTableId (String tableId)
    {
        this.tableId = tableId;
    }
    
    public String getTableType ()
    {
        return tableType;
    }
    
    public void setTableType (String tableType)
    {
        this.tableType = tableType;
    }
    
    public String getTableFiled ()
    {
        return tableFiled;
    }
    
    public void setTableFiled (String tableFiled)
    {
        this.tableFiled = tableFiled;
    }
    
    public String getTableFiledSql ()
    {
        return tableFiledSql;
    }
    
    public void setTableFiledSql (String tableFiledSql)
    {
        this.tableFiledSql = tableFiledSql;
    }
    
    public String getTableFiledAlias ()
    {
        return tableFiledAlias;
    }
    
    public void setTableFiledAlias (String tableFiledAlias)
    {
        this.tableFiledAlias = tableFiledAlias;
        this.name = tableFiledAlias;
    }
    
    public boolean isEditable ()
    {
        return editable;
    }
    
    public void setEditable (boolean editable)
    {
        this.editable = editable;
    }
    
    public String getTreeId ()
    {
        return treeId;
    }
    
    public void setTreeId (String treeId)
    {
        this.treeId = treeId;
    }
    
    public String getTableSql ()
    {
        return tableSql;
    }
    
    public void setTableSql (String tableSql)
    {
        this.tableSql = tableSql;
    }
    
    public boolean isChecked ()
    {
        return checked;
    }
    
    public void setChecked (boolean checked)
    {
        this.checked = checked;
    }
    
}
