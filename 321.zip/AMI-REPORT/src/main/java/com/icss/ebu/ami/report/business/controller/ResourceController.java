package com.icss.ebu.ami.report.business.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.icss.ebu.ami.report.business.service.ResourceService;
import com.icss.ebu.ami.report.system.model.ResourceTree;
import com.icss.ebu.ami.report.system.model.User;

@Controller
@RequestMapping ("/resource")
public class ResourceController extends BaseController
{
    
    @Autowired
    private ResourceService resourceService;
    
    /**
    * 菜单树
    *
    * @return
    */
    @RequestMapping (value = "/tree")
    @ResponseBody
    public Object tree ()
    {
        User currentUser = getCurrentUser ();
        List <ResourceTree> list = resourceService.queryResourceTree (currentUser);
        
        Map <String, List <ResourceTree>> result = new HashMap <String, List <ResourceTree>> ();
        result.put ("menu", list);
        return result;
        
    }
}
