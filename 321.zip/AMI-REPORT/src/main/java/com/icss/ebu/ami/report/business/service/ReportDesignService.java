package com.icss.ebu.ami.report.business.service;

import java.util.List;

import com.icss.ebu.ami.report.business.model.ReportDesign;

/** 
* @author  zhangkaining 
* @date 2017年10月31日 上午9:36:51 
* @version 1.0   
*/

public interface ReportDesignService {

	/**
	 * 根据ID查询所有绑定数据
	 * @param reportid
	 * @return
	 */
	List<ReportDesign> queryTemplateListById(String reportid);
	
	/**
	 * 单个插入
	 * @param reportDesign
	 * @return
	 */
	int insert(ReportDesign reportDesign);
	
	/**
	 * 批量插入
	 * @param list
	 * @return
	 */
	int insertList(List<ReportDesign> list);
	
	/**
	 * 删除
	 * @param reportid
	 * @return
	 */
	int delete(String reportid);

}
