/**
 * 类名:JsonUtil.java
 * 描述: [描述]
 * @author:Administrator
 * 创建日期:2016年10月21日
 * 
 *
*/

package com.icss.ebu.ami.report.system.common.util;

import java.io.IOException;

import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.SerializerProvider;

/**
 * @author   Administrator
 * @version  [版本号]
 * @since    [产品/模块版本]
 * @see 	 [相关类/方法]
 */
public class JsonUtil
{
    
    private static final Logger LOGGER = LoggerFactory.getLogger (JsonUtil.class);
    
    private static final ObjectMapper objectMapper;
    
    static
    {
        objectMapper = new ObjectMapper ();
        objectMapper.configure (DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        objectMapper.configure (SerializationFeature.INDENT_OUTPUT, true);
        objectMapper.getSerializerProvider ().setNullValueSerializer (new JsonSerializer <Object> ()
        {
            public void serialize (Object value, JsonGenerator gen, SerializerProvider serializers)
                throws IOException, JsonProcessingException
            {
                gen.writeString ("");
            }
        });
    }
    
    /**
     * 将json转化为实体POJO
     * @param jsonStr
     * @param obj
     * @return
     */
    public static <T> Object JSONToObj (String jsonStr, Class <T> obj)
    {
        T t = null;
        try
        {
            t = objectMapper.readValue (jsonStr, obj);
        }
        catch (Exception e)
        {
            LOGGER.error ("", e);
        }
        return t;
    }
    
    /**
     * 将实体POJO转化为JSON
     * @param obj
     * @return
     * @throws JSONException
     * @throws IOException
     */
    public static <T> JSONObject objectToJson (T obj) throws JSONException, IOException
    {
        // Convert object to JSON string  
        String jsonStr = "";
        try
        {
            jsonStr = objectMapper.writeValueAsString (obj);
        }
        catch (IOException e)
        {
            throw e;
        }
        return new JSONObject (jsonStr);
    }
    
    public static String toJson (Object entity)
    {
        try
        {
            return objectMapper.writeValueAsString (entity);
        }
        catch (JsonProcessingException e)
        {
            LOGGER.error (e.getMessage (), e);
        }
        return "";
    }
    
    public static JsonNode readJsonAsTree (String json)
    {
        try
        {
            JsonNode rootNode = objectMapper.readTree (json);
            return rootNode;
        }
        catch (IOException e)
        {
            LOGGER.error (e.getMessage (), e);
            return null;
        }
    }
    
    public static <T> T toCollection (String json, TypeReference <T> typeReference)
    {
        try
        {
            return objectMapper.readValue (json, typeReference);
        }
        catch (Exception e)
        {
            LOGGER.error (e.getMessage (), e);
        }
        return null;
    }
}
