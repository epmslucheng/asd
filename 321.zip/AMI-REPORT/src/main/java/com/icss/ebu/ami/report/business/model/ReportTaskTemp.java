package com.icss.ebu.ami.report.business.model;

import java.io.Serializable;

public class ReportTaskTemp implements Serializable {
    private static final long serialVersionUID = 5297989820716648523L;

    private String id;

    private String taskId;

    private String tmpId;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTaskId() {
        return taskId;
    }

    public void setTaskId(String taskId) {
        this.taskId = taskId;
    }

    public String getTmpId() {
        return tmpId;
    }

    public void setTmpId(String tmpId) {
        this.tmpId = tmpId;
    }
}
