package com.icss.ebu.ami.report.system.core.task;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import org.quartz.CronTrigger;
import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.ObjectAlreadyExistsException;
import org.quartz.SchedulerException;
import org.quartz.SimpleTrigger;
import org.quartz.Trigger;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.icss.ebu.ami.commons.context.ContextHelper;
import com.icss.ebu.ami.report.business.model.ReportTask;

/**
 * 任务调度管理器 负责初始化自定义采集任务
 *
 * @author Administrator
 *
 */
@Service ("reportTaskScheduleManager")
public class ReportTaskScheduleManager
{
    
    private Logger logger = LoggerFactory.getLogger (getClass ());
    
    @Autowired
    private TaskScheduleManager taskScheduleManager;
    
    private ConcurrentHashMap <Long, ReportTask> cachedTaskMap = null;
    
    public ReportTaskScheduleManager ()
    {
        super ();
        cachedTaskMap = new ConcurrentHashMap <Long, ReportTask> ();
    }
    
    /*
    * 检查任务是否存在
    * */
    public boolean checkTaskExist (ReportTask reportTask)
    {
        return cachedTaskMap.containsKey (reportTask.getLongId ());
    }
    
    /*
    * 检查任务是否变更
    * */
    public boolean checkTaskModify (ReportTask reportTask)
    {
        Long key = generatorTaskKey (reportTask.getLongId ());
        return cachedTaskMap.containsKey (key) && !cachedTaskMap.get (key).compareEquals (reportTask);
    }
    
    public void filterExistTask (Set <Long> taskSet)
    {
        for (Entry <Long, ReportTask> entry : cachedTaskMap.entrySet ())
        {
            if (!taskSet.contains (entry.getKey ()))
            {
                removeTask (entry.getKey ().toString ());
            }
        }
    }
    
    /*
    * 启动任务
    * */
    public void runInitTask (ReportTask reportTask) throws SchedulerException
    {
        cachedTaskMap.put (reportTask.getLongId (), reportTask);
        runningTriggerByReportTask (reportTask);
    }
    
    /**
     * 从任务调度计划中删除一条计划任务
     *
     * @param taskName
     */
    public void removeTask (String taskName)
    {
        taskScheduleManager.removeTask (taskName, TaskConstant.REPORT_TASK);
    }
    
    public void addOrUpdateTaskToCached (ReportTask task)
    {
        cachedTaskMap.put (generatorTaskKey (task.getLongId ()), task);
    }
    
    /**
     * 增加一个任务到调度计划中
     *
     * @param reportTask
     */
    private void runningTriggerByReportTask (ReportTask reportTask)
    {
        Trigger t = getTriggerByReportTask (reportTask);
        if (t == null)
        {
            return;
        }
        try
        {
            Class job = ContextHelper.getContext ().getBean ("reportTaskJob").getClass ();
            JobBuilder jobBuilder = JobBuilder.newJob (job);
            jobBuilder.withIdentity (reportTask.getId (), TaskConstant.REPORT_TASK);
            jobBuilder.storeDurably (true);
            jobBuilder.withDescription (TaskConstant.REPORT_TASK + reportTask.getName ());
            JobDetail jobDetail = jobBuilder.build ();
            if (t instanceof SimpleTrigger)
            {
                taskScheduleManager.schedulerJob (jobDetail, t);
            }
            else
            {
                CronTrigger cronTrigger = (CronTrigger) t;
                taskScheduleManager.schedulerJob (jobDetail, cronTrigger);
            }
            
            taskScheduleManager.startScheduler ();
        }
        catch (ObjectAlreadyExistsException e)
        {
            logger.info ("Store Task:{} fail,, because one already exists with this identification", reportTask.getName ());
        }
        catch (SchedulerException e)
        {
            logger.error ("Start ReportTask:" + reportTask.getName () + " fail [" + e + "]", e);
        }
        
    }
    
    private Trigger getTriggerByReportTask (ReportTask task)
    {
        Object bean = ContextHelper.getContext ().getBean ("reportTaskJob");
        if (!(bean instanceof AbstractTask))
        {
            logger.info ("Start Report Task:" + task.getName () + " fail,Can't receive bean by task handler name ");
            return null; // 配置的Bean并不是一个真正的任务对象
        }
        return TriggerGeneratFactory.getInstance ().getReportTaskTrigger (task, bean.getClass (), getJobExecParamMap (task));
    }
    
    private Map <String, Object> getJobExecParamMap (ReportTask task)
    {
        Map <String, Object> jobExecParamAsMap = new HashMap <String, Object> ();
        jobExecParamAsMap.put ("taskId", task.getLongId ());
        jobExecParamAsMap.put ("taskName", task.getName ());
        jobExecParamAsMap.put ("taskCode", task.getCode ());
        jobExecParamAsMap.put ("taskNameAlias", task.toString ());
        jobExecParamAsMap.put ("startStatus", ReportTask.STATUS_RUNNING.equals(task.getStatus()));
        jobExecParamAsMap.put ("taskHandle", task.getHandle ());
        return jobExecParamAsMap;
    }
    
    private Long generatorTaskKey (Long taskId)
    {
        if (null != taskId)
        {
            return taskId;
        }
        return null;
    }
}
