package com.icss.ebu.ami.report.business.common.constant;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

/**
 * 
 *用于存放系统启动动态读取的初始化数据
 *
 * @author xugangfeng
 * @version [版本号, 2016-11-11]
 * @see  [相关类/方法]
 * @since  [产品/模块版本]
 */
public final class StaticInitData implements Serializable
{
    /**
     * 注释内容
     */
    private static final long serialVersionUID = 2700190543425898137L;
    
    /**
     * 保存系统参数配置
     */
    private static Map<String, String> sysConfigMap = new HashMap<String, String>();
    
    /**
     * <默认构造函数>
     */
    private StaticInitData()
    {
    }
    
    public static void setSysConfigMap(final Map<String, String> sysConfigMap)
    {
        StaticInitData.sysConfigMap = sysConfigMap;
    }
    
    public static Map<String, String> getSysConfigMap()
    {
        return sysConfigMap;
    }
    
}