package com.icss.ebu.ami.report.business.mapper;

import java.util.List;

import com.icss.ebu.ami.report.business.model.ReportDataPosition;

/** 
* @author  zhangkaining 
* @date 2017年11月1日 下午2:22:26 
* @version 1.0   
*/
public interface ReportDataPositionMapper {

	List<ReportDataPosition> queryListByTmpId(String tmpid);
	
	int deleteByTmpId(String tmpid);
	
	int insert(ReportDataPosition reportDataPosition);
	
	int insertList(List<ReportDataPosition> list);
	
}
