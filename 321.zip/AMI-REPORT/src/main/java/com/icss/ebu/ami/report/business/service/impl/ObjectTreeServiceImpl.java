package com.icss.ebu.ami.report.business.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.icss.ebu.ami.commons.pagePlugin.Page;
import com.icss.ebu.ami.commons.util.UUIDUtils;
import com.icss.ebu.ami.report.business.mapper.ObjectTreeMapper;
import com.icss.ebu.ami.report.business.model.DataSetObject;
import com.icss.ebu.ami.report.business.model.ObjectTreeBean;
import com.icss.ebu.ami.report.business.model.ObjectTreeNode;
import com.icss.ebu.ami.report.business.model.ReportTaskTempObjs;
import com.icss.ebu.ami.report.business.service.ObjectTreeService;

@Service
public class ObjectTreeServiceImpl implements ObjectTreeService
{
    @Autowired
    private ObjectTreeMapper objectTreeMapper;
    
    private Logger LOGGER = LoggerFactory.getLogger (ObjectTreeServiceImpl.class);
    
    @Override
    public Page <ObjectTreeBean> queryObjectTree (Page <ObjectTreeBean> page)
    {
        page.setResults (objectTreeMapper.getObjectTreeList (page));
        return page;
    }
    
    @Override
    public Integer save (ObjectTreeBean objectTree)
    {
        objectTree.setId (UUIDUtils.generate16Str ());
        return objectTreeMapper.addObjectTree (objectTree);
    }
    
    @Override
    public Integer update (ObjectTreeBean objectTree)
    {
        return objectTreeMapper.updateObjectTree (objectTree);
    }
    
    @Override
    public Integer del (ObjectTreeBean objectTreeBean)
    {
        //删除树数据
        objectTreeMapper.delObjectTreeNodeByObjectId (objectTreeBean.getId ());
        //删除对象树
        return objectTreeMapper.delObjectTreeById (objectTreeBean.getId ());
    }
    
    @Override
    public Integer saveTreeNode (ObjectTreeNode treeNode)
    {
        return objectTreeMapper.addObjectTreeNode (treeNode);
    }
    
    @Override
    public Integer saveTreeRootNode (ObjectTreeNode treeNode)
    {
        return objectTreeMapper.addObjectTreeNode (treeNode);
    }
    
    @Override
    public List <ObjectTreeNode> queryTreeRootNode (ObjectTreeBean objectTree)
    {
        return objectTreeMapper.queryRootNodeByObjectId (objectTree);
    }
    
    @Override
    public List <ObjectTreeBean> queryAllObjectTree (ObjectTreeBean objectTreeBean)
    {
        return objectTreeMapper.queryAllObjectTree (objectTreeBean);
    }
    
    @Override
    public Integer delTreeNode (ObjectTreeNode treeNode)
    {
        return objectTreeMapper.delObjectTreeNode (treeNode.getTreeId ());
    }
    
    @Override
    public List <ObjectTreeNode> queryTreeNodeList (ObjectTreeBean objectTree)
    {
        return objectTreeMapper.queryNodeListByObjectId (objectTree);
    }
    
    @Override
    public Integer editTreeNode (ObjectTreeNode treeNode)
    {
        return objectTreeMapper.editObjectTreeNode (treeNode);
    }
    
    @Override
    public List <ObjectTreeNode> findAll ()
    {
        return objectTreeMapper.findAll ();
    }
    
    @Override
    public int insertDataSetObject (List <DataSetObject> list)
    {
        int result = 0;
        try
        {
            result = objectTreeMapper.insertDataSetObject (list);
        }
        catch (Exception e)
        {
            LOGGER.error ("insert dataset object tree relationship error.", e);
        }
        return result;
    }
    
    @Override
    public int deleteDataSetObjectByQueryId (String queryId)
    {
        int result = 0;
        try
        {
            result = objectTreeMapper.deleteDataSetObjectByQueryId (queryId);
        }
        catch (Exception e)
        {
            LOGGER.error ("delete dataset object tree relationship error.", e);
        }
        return result;
    }
    
    @Override
    public List <ObjectTreeBean> queryObjectTreesListByTempIds (ReportTaskTempObjs reportTaskTempObjs)
    {
        return objectTreeMapper.queryObjectTreesListByTempIds (reportTaskTempObjs);
    }
}
