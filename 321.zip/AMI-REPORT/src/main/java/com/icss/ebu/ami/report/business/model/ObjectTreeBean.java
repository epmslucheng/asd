package com.icss.ebu.ami.report.business.model;

import java.io.Serializable;

/**
 * 对象树实体类
 * @author xunan
 *
 */
public class ObjectTreeBean implements Serializable
{
    
    /**
     * 
     */
    private static final long serialVersionUID = -7560777134096875192L;
    
    private String id;
    
    private String name;
    
    private String desc;
    
    private String objectTreeKey;
    
    private String userId;
    
    //用于报表生成页面选择每个对象树
    private String treeName;
    
    private String treeCode;
    
    private String treeId;
    
    private String tmpId;
    
    public String getObjectTreeKey ()
    {
        return objectTreeKey;
    }
    
    public void setObjectTreeKey (String objectTreeKey)
    {
        this.objectTreeKey = objectTreeKey;
    }
    
    public String getId ()
    {
        return id;
    }
    
    public void setId (String id)
    {
        this.id = id;
    }
    
    public String getName ()
    {
        return name;
    }
    
    public void setName (String name)
    {
        this.name = name;
    }
    
    public String getDesc ()
    {
        return desc;
    }
    
    public void setDesc (String desc)
    {
        this.desc = desc;
    }
    
    public String getUserId ()
    {
        return userId;
    }
    
    public void setUserId (String userId)
    {
        this.userId = userId;
    }
    
    public String getTreeName ()
    {
        if (null == treeName)
        {
            return "";
        }
        return treeName;
    }
    
    public void setTreeName (String treeName)
    {
        this.treeName = treeName;
    }
    
    public String getTreeCode ()
    {
        if (null == treeCode)
        {
            return "";
        }
        return treeCode;
    }
    
    public void setTreeCode (String treeCode)
    {
        this.treeCode = treeCode;
    }
    
    public String getTmpId ()
    {
        return tmpId;
    }
    
    public void setTmpId (String tmpId)
    {
        this.tmpId = tmpId;
    }
    
    public String getTreeId ()
    {
        return treeId;
    }
    
    public void setTreeId (String treeId)
    {
        this.treeId = treeId;
    }
    
}
