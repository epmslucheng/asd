package com.icss.ebu.ami.report.business.mapper;

import java.util.List;

import com.icss.ebu.ami.report.business.model.ReportDesign;

/** 
* @author  zhangkaining 
* @date 2017年10月31日 上午8:59:06 
* @version 1.0   
*/
public interface ReportDesignMapper {

	List<ReportDesign> queryTemplateListById(String reportid);
	
	int insert(ReportDesign reportDesign);
	
	int insertList(List<ReportDesign> list);
	
	int delete(String reportid);
	
}
