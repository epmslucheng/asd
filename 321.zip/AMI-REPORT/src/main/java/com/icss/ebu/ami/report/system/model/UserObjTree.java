package com.icss.ebu.ami.report.system.model;

import java.io.Serializable;

/** 
* @author  zhangkaining 
* @date 2017年11月16日 下午3:17:46 
* @version 1.0   
*/
public class UserObjTree implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3145872360518447484L;
	
	
	private Long id;
	
	private String userId;
	
	private String objId;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getObjId() {
		return objId;
	}

	public void setObjId(String objId) {
		this.objId = objId;
	}
	
	

}
