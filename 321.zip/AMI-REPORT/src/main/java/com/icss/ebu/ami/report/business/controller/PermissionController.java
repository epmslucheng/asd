package com.icss.ebu.ami.report.business.controller;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.icss.ebu.ami.report.business.service.ResourceService;
import com.icss.ebu.ami.report.system.common.shiro.ShiroUser;
import com.icss.ebu.ami.report.system.service.RoleService;

@Controller
@RequestMapping ("/permission")
public class PermissionController extends BaseController
{
    private static final Logger LOGGER = LoggerFactory.getLogger (PermissionController.class);
    
    @Autowired
    private RoleService roleService;
    
    @Autowired
    private ResourceService resourceService;
    
    @RequestMapping ("/init")
    @ResponseBody
    public Object init (HttpServletRequest request, HttpServletResponse response)
    {
        Map <String, String> map = new HashMap <String, String> ();
        //        map.put ("name", "123");
        //        map.put ("text", "234");
        //        
        //        User currentUser = getCurrentUser ();
        
        Subject userVo = SecurityUtils.getSubject ();
        ShiroUser shiroUser = (ShiroUser) userVo.getPrincipal ();
        
        List <Long> roleList = null;
        if (null != shiroUser && CollectionUtils.isNotEmpty (shiroUser.getRoleList ()))
        {
            roleList = shiroUser.getRoleList ();
        }
        
        //        Map <String, Object> result = new HashMap <String, Object> ();
        Set <String> urlSet = new HashSet <String> ();
        
        if (roleList.contains (1L))
        {
            
            urlSet.addAll (roleService.findResourcesByRoleId (1L));
        }
        else
        {
            for (Long roleId : roleList)
            {
                List <String> roleResourceList = roleService.findResourcesByRoleId (roleId);
                if (CollectionUtils.isNotEmpty (roleResourceList))
                {
                    urlSet.addAll (roleResourceList);
                }
            }
            
        }
        
        for (String url : urlSet)
        {
            map.put (url, url);
        }
        
        return map;
    }
}
