package com.icss.ebu.ami.report.business.common.util;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Name;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.streaming.SXSSFCell;
import org.apache.poi.xssf.streaming.SXSSFRow;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFName;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.jeecgframework.poi.excel.ExcelToHtmlUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.icss.ebu.ami.commons.exception.ServiceException;
import com.icss.ebu.ami.commons.util.DateUtils;
import com.icss.ebu.ami.report.business.common.constant.ReportConstant;

public class ExcelWrite
{
    private static HSSFWorkbook hworkbook = null;
    
    private static XSSFWorkbook xworkbook = null;
    
    private static SXSSFWorkbook sxworkbook = null;
    
    private static Logger LOGGER = LoggerFactory.getLogger (ExcelWrite.class);
    
    /** 
     * 判断文件的sheet是否存在. 
     * @param fileDir   文件路径 
     * @param sheetName  表格索引名 
     * @return 
     */
    public static boolean sheetExist (String fileDir, String sheetName) throws Exception
    {
        if (fileDir.endsWith (ReportConstant.REPORT_SUFFIX_XLS))
        {
            boolean flag = false;
            File file = new File (fileDir);
            FileInputStream in = null;
            HSSFSheet sheet = null;
            if (file.exists ())
            { //文件存在  
              //创建workbook  
                try
                {
                    in = new FileInputStream (file);
                    hworkbook = new HSSFWorkbook (in);
                    //添加Worksheet（不添加sheet时生成的xls文件打开时会报错)  
                    sheet = hworkbook.getSheet (sheetName);
                    if (sheet != null)
                        flag = true;
                }
                catch (Exception e)
                {
                    LOGGER.error ("sheet xsl error", e);
                    throw e;
                    
                }
                finally
                {
                    if (null != in)
                    {
                        in.close ();
                    }
                }
                
            }
            else
            { //文件不存在  
                flag = false;
            }
            return flag;
        }
        else
        {
            boolean flag = false;
            File file = new File (fileDir);
            FileInputStream in = null;
            XSSFSheet sheet = null;
            if (file.exists ())
            { //文件存在  
              //创建workbook  
                try
                {
                    in = new FileInputStream (file);
                    xworkbook = new XSSFWorkbook (in);
                    //添加Worksheet（不添加sheet时生成的xls文件打开时会报错)  
                    sheet = xworkbook.getSheet (sheetName);
                    if (sheet != null)
                        flag = true;
                }
                catch (Exception e)
                {
                    LOGGER.error ("sheet xsl error", e);
                    throw e;
                    
                }
                finally
                {
                    if (null != in)
                    {
                        in.close ();
                    }
                }
                
            }
            else
            { //文件不存在  
                flag = false;
            }
            return flag;
        }
        
    }
    
    /** 
     * 根据xls模板创建临时excel供poi数据生成，此项生成sheet并将表头生成. 
     * @param fileDir  excel的路径 
     * @param sheetName 要创建的表格索引 
     * @param titleRow excel的第一行即表格头 
     */
    public static String createTempExcel (String templatePath, String templateFileName, String targetPath, String targetDir,
        String date_formatter) throws Exception
    {
        
        //创建workbook 
        createTemFile (templatePath, templateFileName, targetDir);
        FileInputStream in = new FileInputStream (new File (targetDir));
        
        if (targetDir.endsWith (ReportConstant.REPORT_SUFFIX_XLS))
        {
            hworkbook = new HSSFWorkbook (in);
            //新建文件  
            FileOutputStream out = null;
            try
            {
                String reportDate = "";
                try
                {
                    reportDate = DateUtils.date2String (new Date (), date_formatter);
                }
                catch (Exception e)
                {
                    reportDate = DateUtils.date2String (new Date (), "yyyy-MM-dd HH:mm:ss");
                }
                
                //已创建sheet按照用户设置的位置先生成数据
                int num = hworkbook.getNumberOfNames ();
                int row = 0;
                int col = 0;
                for (int i = 0; i < num; i++)
                {
                    Name name = hworkbook.getNameAt (i);
                    if (ReportConstant.REPORT_REPORT_DATE.equals (name.getNameName ()))
                    {
                        String refersToFormula = name.getRefersToFormula ();
                        String shName =
                            refersToFormula.substring (0, refersToFormula.indexOf (ReportConstant.REPORT_EXCLAMATORY));
                        Map <String, Object> position = excelColStrToNum (refersToFormula);
                        //对每个sheet页中的report_date字段做处理
                        row = (int) position.get (ReportConstant.REPORT_SHEET_ROW);
                        col = (int) position.get (ReportConstant.REPORT_SHEET_COL);
                        HSSFSheet sheet = hworkbook.getSheet (shName);
                        HSSFRow reportDateRow = sheet.getRow (row);
                        if (reportDateRow == null)
                        {
                            reportDateRow = sheet.createRow (row);
                        }
                        HSSFCell reportDateCell = reportDateRow.getCell (col);
                        if (reportDateCell == null)
                        {
                            reportDateCell = reportDateRow.createCell (col);
                        }
                        reportDateCell.setCellValue (reportDate);
                    }
                }
                
                out = new FileOutputStream (targetDir);
                hworkbook.write (out);
                return targetDir;
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                try
                {
                    if (null != out)
                    {
                        out.close ();
                    }
                    if (null != in)
                    {
                        in.close ();
                    }
                }
                catch (IOException e)
                {
                    LOGGER.error ("create excel error", e);
                }
            }
        }
        else
        {
            xworkbook = new XSSFWorkbook (in);
            sxworkbook = new SXSSFWorkbook (xworkbook);
            //添加Worksheet（不添加sheet时生成的xls文件打开时会报错)  
            //新建文件  
            FileOutputStream out = null;
            try
            {
                String reportDate = "";
                try
                {
                    reportDate = DateUtils.date2String (new Date (), date_formatter);
                }
                catch (Exception e)
                {
                    reportDate = DateUtils.date2String (new Date (), "yyyy-MM-dd HH:mm:ss");
                }
                //已创建sheet按照用户设置的位置先生成数据
                int num = sxworkbook.getNumberOfNames ();
                int row = 0;
                int col = 0;
                for (int i = 0; i < num; i++)
                {
                    XSSFName name = xworkbook.getNameAt (i);
                    if (ReportConstant.REPORT_REPORT_DATE.equals (name.getNameName ()))
                    {
                        String refersToFormula = name.getRefersToFormula ();
                        String shName =
                            refersToFormula.substring (0, refersToFormula.indexOf (ReportConstant.REPORT_EXCLAMATORY));
                        Map <String, Object> position = excelColStrToNum (refersToFormula);
                        //对每个sheet页中的report_date字段做处理
                        row = (int) position.get (ReportConstant.REPORT_SHEET_ROW);
                        col = (int) position.get (ReportConstant.REPORT_SHEET_COL);
                        XSSFSheet sheet = xworkbook.getSheet (shName);
                        XSSFRow reportDateRow = sheet.getRow (row);
                        if (reportDateRow == null)
                        {
                            reportDateRow = sheet.createRow (row);
                        }
                        XSSFCell reportDateCell = reportDateRow.getCell (col);
                        if (reportDateCell == null)
                        {
                            reportDateCell = reportDateRow.createCell (col);
                        }
                        reportDateCell.setCellValue (reportDate);
                    }
                }
                
                out = new FileOutputStream (targetDir);
                sxworkbook.write (out);
                return targetDir;
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                try
                {
                    if (null != out)
                    {
                        out.close ();
                    }
                    if (null != in)
                    {
                        in.close ();
                    }
                }
                catch (IOException e)
                {
                    LOGGER.error ("create excel error", e);
                }
            }
        }
        
    }
    
    /** 
     * 删除文件. 
     * @param fileDir  文件路径 
     */
    public static boolean deleteExcel (String fileDir)
    {
        boolean flag = false;
        File file = new File (fileDir);
        // 判断目录或文件是否存在    
        if (!file.exists ())
        { // 不存在返回 false    
            return flag;
        }
        else
        {
            // 判断是否为文件    
            if (file.isFile ())
            { // 为文件时调用删除文件方法    
                file.delete ();
                flag = true;
            }
        }
        return flag;
    }
    
    /**
     * 导入
     * @param rd 模板设计类
     * @param targetPath 目标路径
     * @param targetDir 目标文件
     * @param datas 数据
     * @return
     */
    public static String writeToExcel (Workbook workBook, String targetDir, List <Map <String, Object>> datas,
        Map <String, Object> position, String[] title)
    {
        //临时文件全路径
        try
        {
            //获取填写数据的坐标
            writeToExcelByPosition (workBook, targetDir, datas, position, title);
            System.gc ();
        }
        catch (Exception e)
        {
            LOGGER.error ("write to excel error.", e);
        }
        return targetDir;
    }
    
    /** 
     * 往excel中对应sheet页写数据，不指定sheet页中坐标 
     * @param fileDir    文件路径 
     * @param sheetName  表格索引 
     * @param object 
     * @throws Exception 
     */
    public static void writeToExcelBySheet (String targetDir, String sheetName, int row, List <Map <String, Object>> mapList,
        String[] title) throws Exception
    {
        //创建workbook  
        FileInputStream in = null;
        if (targetDir.substring (targetDir.lastIndexOf (".")).equals (".xls"))
        {
            try
            {
                in = new FileInputStream (new File (targetDir));
                hworkbook = new HSSFWorkbook (in);
            }
            catch (FileNotFoundException e)
            {
                LOGGER.error ("write to excel - file not found.", e);
            }
            catch (IOException e)
            {
                LOGGER.error ("write to excel error", e);
            }
            //流  
            FileOutputStream out = null;
            HSSFSheet sheet = hworkbook.getSheet (sheetName);
            // 获取表头的列数  
            try
            {
                // 获得表头行对象  
                if (title != null)
                {
                    int columnCount = title.length;
                    int dataSize = mapList.size ();
                    Map <String, Object> data = null;
                    String mapKey = "";
                    HSSFRow dataRow = null;
                    HSSFCell dataCell = null;
                    for (int rowId = 0; rowId < dataSize; rowId++)
                    {
                        data = mapList.get (rowId);
                        dataRow = sheet.createRow (rowId + row); // 从sheet第几行开始写excel，目前写死2
                        
                        /**
                         * 根据表头title从data数据项中获取数据
                         */
                        for (short columnIndex = 0; columnIndex < columnCount; columnIndex++)
                        { //遍历表头  
                            mapKey = title[columnIndex];
                            dataCell = dataRow.createCell (columnIndex);
                            dataCell.setCellValue (data.get (mapKey) == null ? null : data.get (mapKey).toString ());
                        }
                    }
                    
                }
                
                out = new FileOutputStream (targetDir);
                hworkbook.write (out);
                
            }
            catch (Exception e)
            {
                LOGGER.error ("write to excel error.", e);
                throw e;
            }
            finally
            {
                try
                {
                    if (null != in)
                    {
                        in.close ();
                    }
                    if (null != out)
                    {
                        out.close ();
                    }
                }
                catch (IOException e)
                {
                    LOGGER.error ("write to excel error.", e);
                }
            }
        }
        else
        {
            try
            {
                in = new FileInputStream (new File (targetDir));
                xworkbook = new XSSFWorkbook (in);
            }
            catch (FileNotFoundException e)
            {
                LOGGER.error ("write to excel - file not found.", e);
            }
            catch (IOException e)
            {
                LOGGER.error ("write to excel error", e);
            }
            //流  
            FileOutputStream out = null;
            XSSFSheet sheet = xworkbook.getSheet (sheetName);
            // 获取表头的列数  
            try
            {
                // 获得表头行对象  
                if (title != null)
                {
                    int columnCount = title.length;
                    int dataSize = mapList.size ();
                    Map <String, Object> data = null;
                    String mapKey = "";
                    XSSFRow dataRow = null;
                    XSSFCell dataCell = null;
                    for (int rowId = 0; rowId < dataSize; rowId++)
                    {
                        data = mapList.get (rowId);
                        dataRow = sheet.createRow (rowId + row); // 从sheet第几行开始写excel，目前写死2
                        
                        /**
                         * 根据表头title从data数据项中获取数据
                         */
                        for (short columnIndex = 0; columnIndex < columnCount; columnIndex++)
                        { //遍历表头  
                            mapKey = title[columnIndex];
                            dataCell = dataRow.createCell (columnIndex);
                            dataCell.setCellValue (data.get (mapKey) == null ? null : data.get (mapKey).toString ());
                        }
                    }
                    
                }
                
                out = new FileOutputStream (targetDir);
                xworkbook.write (out);
                
            }
            catch (Exception e)
            {
                LOGGER.error ("write to excel error.", e);
                throw e;
            }
            finally
            {
                try
                {
                    if (null != in)
                    {
                        in.close ();
                    }
                    if (null != out)
                    {
                        out.close ();
                    }
                }
                catch (IOException e)
                {
                    LOGGER.error ("write to excel error.", e);
                }
            }
        }
        
    }
    
    /**
     * 数据填充从指定坐标位置位置开始填充
     * @param targetDir
     * @param mapList
     * @param position
     * @param title
     * @throws Exception
     */
    public static void writeToExcelByPosition (Workbook workBook, String targetDir, List <Map <String, Object>> datas,
        Map <String, Object> position, String[] title) throws Exception
    {
        //创建workbook  
        String sheetName = (String) position.get (ReportConstant.REPORT_SHEET_SHEETNAME);
        if (targetDir.endsWith (ReportConstant.REPORT_SUFFIX_XLS))
        {
            
            hssfToExcel (workBook, targetDir, datas, position, title, sheetName);
        }
        else
        {
            
            //流  
            sxssfToExcel (workBook, targetDir, datas, position, title, sheetName);
        }
        
    }
    
    private static void hssfToExcel (Workbook workBook, String targetDir, List <Map <String, Object>> datas,
        Map <String, Object> position, String[] title, String sheetName) throws Exception
    {
        HSSFWorkbook hworkbook = (HSSFWorkbook) workBook;
        FileInputStream in = new FileInputStream (new File (targetDir));
        //流  
        FileOutputStream out = null;
        HSSFSheet sheet = (HSSFSheet) hworkbook.getSheet (sheetName);
        if (sheet == null)
        {
            sheet = hworkbook.createSheet (sheetName);
        }
        // 获取表格的总行数  
        // 获取表头的列数  
        try
        {
            // 获得表头行对象  
            int beginRow = (int) position.get (ReportConstant.REPORT_SHEET_ROW);
            int beginCol = (int) position.get (ReportConstant.REPORT_SHEET_COL);
            
            Map <String, Object> data = null;
            HSSFRow dataRow = null;
            HSSFCell dataCell = null;
            String mapKey = null;
            if (null != datas && !datas.isEmpty ())
            {
                int lastRow = datas.size () + beginRow;
                
                for (int rowId = beginRow; rowId < lastRow; rowId++)
                {
                    data = datas.get (rowId - beginRow);
                    dataRow = sheet.getRow (rowId);
                    if (dataRow == null)
                    {
                        dataRow = sheet.createRow (rowId);
                    }
                    int lastCol = title.length + beginCol;
                    for (int columnIndex = beginCol; columnIndex < lastCol; columnIndex++)
                    { //遍历表头  
                        int dataIndex = columnIndex - beginCol;
                        mapKey = title[dataIndex];
                        if ("R".equals (mapKey))
                        {
                            continue;
                        }
                        dataCell = dataRow.getCell (columnIndex);
                        if (null == dataCell)
                        {
                            dataCell = dataRow.createCell (columnIndex);
                        }
                        
                        dataCell.setCellValue (data.get (mapKey) == null ? null : data.get (mapKey).toString ());
                    }
                }
                
            }
            
            out = new FileOutputStream (targetDir);
            workBook.write (out);
            out.flush ();
            
        }
        catch (Exception e)
        {
            LOGGER.error ("write to excel error.", e);
            throw e;
        }
        finally
        {
            try
            {
                if (null != in)
                {
                    in.close ();
                }
                if (null != out)
                {
                    out.close ();
                }
            }
            catch (IOException e)
            {
                LOGGER.error ("write to excel error.", e);
            }
        }
    }
    
    private static void sxssfToExcel (Workbook workBook, String targetDir, List <Map <String, Object>> datas,
        Map <String, Object> position, String[] title, String sheetName) throws Exception
    {
        
        SXSSFWorkbook sxworkbook = (SXSSFWorkbook) workBook;
        SXSSFSheet sheet = sxworkbook.getSheet (sheetName);//getSheet (sheetName);
        if (sheet == null)
        {
            sheet = sxworkbook.createSheet (sheetName);
        }
        
        //每当行数达到设置的值就刷新数据到硬盘,以清理内存
        ((SXSSFSheet) sheet).flushRows ();
        
        // 获取表格的总行数  
        // 获取表头的列数  
        try
        {
            // 获得表头行对象  
            int beginRow = (int) position.get (ReportConstant.REPORT_SHEET_ROW);
            int beginCol = (int) position.get (ReportConstant.REPORT_SHEET_COL);
            
            Map <String, Object> data = null;
            SXSSFRow dataRow = null;
            SXSSFCell dataCell = null;
            String mapKey = null;
            if (null != datas && !datas.isEmpty ())
            {
                int lastRow = datas.size () + beginRow;
                
                for (int rowId = beginRow; rowId < lastRow; rowId++)
                {
                    
                    data = datas.get (rowId - beginRow);
                    dataRow = sheet.getRow (rowId);
                    if (null == dataRow)
                    {
                        dataRow = sheet.createRow (rowId);
                    }
                    int lastCol = title.length + beginCol;
                    for (int columnIndex = beginCol; columnIndex < lastCol; columnIndex++)
                    { //遍历表头  
                        int dataIndex = columnIndex - beginCol;
                        mapKey = title[dataIndex];
                        if ("R".equals (mapKey))
                        {
                            continue;
                        }
                        dataCell = dataRow.createCell (columnIndex);
                        dataCell.setCellValue (data.get (mapKey) == null ? null : data.get (mapKey).toString ());
                    }
                }
                
            }
            
        }
        catch (Exception e)
        {
            LOGGER.error ("write to excel error.", e);
            throw e;
        }
    }
    
    public static Map <String, Object> uploadFileToFtp (String tempPath, String targetDir)
    {
        InputStream in = null;
        Map <String, Object> result = null;
        try
        {
            
            File file = new File (tempPath);
            String prefix = file.getName ().substring (0, file.getName ().lastIndexOf (ReportConstant.REPORT_SPOT));
            String suffix = tempPath.substring (tempPath.lastIndexOf (ReportConstant.REPORT_SPOT));
            in = new FileInputStream (file);
            String pathname = targetDir;
            String fileName = prefix + suffix;
            FtpUtils.uploadFile (pathname, fileName, in);
            result = new HashMap <String, Object> ();
            result.put ("fileName", fileName);
            result.put ("filePath", targetDir);
        }
        catch (Exception e)
        {
            LOGGER.error ("upload to ftp error", e);
            throw new ServiceException ("upload to ftp error");
        }
        finally
        {
            try
            {
                if (null != in)
                {
                    
                    in.close ();
                    
                }
            }
            catch (IOException e)
            {
                LOGGER.error ("upload to ftp - close io error", e);
            }
        }
        
        return result;
    }
    
    public static void createTemFile (String templatePath, String templateFileName, String targetPath)
    {
        File temFile = new File (targetPath);
        if (!temFile.getParentFile ().exists ())
        {
            temFile.getParentFile ().mkdir ();
            
        }
        if (!temFile.exists ())
        {
            FtpUtils.downloadTemplate (templatePath, templateFileName, targetPath);
            
        }
    }
    
    public static void copyFile (String oldPath, String newPath)
    {
        InputStream inStream = null;
        FileOutputStream out = null;
        try
        {
            int bytesum = 0;
            int byteread = 0;
            File oldfile = new File (oldPath);
            if (oldfile.exists ())
            { //文件存在时 
                inStream = new FileInputStream (oldPath); //读入原文件 
                out = new FileOutputStream (newPath);
                byte[] buffer = new byte[1444];
                int length;
                while ((byteread = inStream.read (buffer)) != -1)
                {
                    bytesum += byteread; //字节数 文件大小 
                    out.write (buffer, 0, byteread);
                }
                
            }
        }
        catch (Exception e)
        {
            LOGGER.error ("copy file", e);
            
        }
        finally
        {
            try
            {
                if (null != inStream)
                {
                    inStream.close ();
                }
                if (null != out)
                {
                    out.close ();
                }
            }
            catch (IOException e)
            {
                LOGGER.error ("copy file error", e);
            }
        }
        
    }
    
    /**
     * 返回多少行坐标
     * @param colStr
     * @param length
     * @return {row: ,col: , sheetName; }
     */
    public static Map <String, Object> excelColStrToNum (String toExcel)
    {
        Map <String, Object> position = new HashMap <String, Object> ();
        String sheetName = toExcel;
        if (StringUtils.isNotBlank (toExcel) && toExcel.indexOf (ReportConstant.REPORT_EXCLAMATORY) > 0)
        {
            int index = toExcel.indexOf (ReportConstant.REPORT_EXCLAMATORY);
            sheetName = toExcel.substring (0, index);
            String coordinate = toExcel.substring (index + 1);
            String[] strs = coordinate.split (ReportConstant.REPORT_SYMBOL_$);
            
            String colStr = strs[1];
            String rowStr = strs[2];
            
            int num = 0;
            int col = 0;
            int row = Integer.valueOf (rowStr);
            int length = colStr.length ();
            for (int i = 0; i < length; i++)
            {
                char ch = colStr.charAt (length - i - 1);
                num = (int) (ch - 'A' + 1);
                num *= Math.pow (26, i);
                col += num;
            }
            
            position.put (ReportConstant.REPORT_SHEET_ROW, row - 1);
            position.put (ReportConstant.REPORT_SHEET_COL, col - 1);
        }
        position.put (ReportConstant.REPORT_SHEET_SHEETNAME, sheetName);
        return position;
    }
    
    public static List <String> excelToHtml (String tempPath)
    {
        List <String> htmlPath = new ArrayList <String> ();
        File temXsl = new File (tempPath);
        String xlsPath = temXsl.getParent ();
        String xlsFileName = temXsl.getName ();
        FileInputStream in = null;
        FileOutputStream out = null;
        OutputStreamWriter outWrite = null;
        
        BufferedWriter bufferWritter = null;
        if (tempPath.substring (tempPath.lastIndexOf (ReportConstant.REPORT_SPOT)).equals (ReportConstant.REPORT_SUFFIX_XLS))
        {
            try
            {
                in = new FileInputStream (temXsl);
                
                hworkbook = new HSSFWorkbook (in);
                StringBuffer sb = null;
                for (int i = 0; i < hworkbook.getNumberOfSheets (); i++)
                {
                    sb = new StringBuffer ();
                    sb.append (xlsPath).append ("/")
                        .append (xlsFileName.substring (0, xlsFileName.lastIndexOf (ReportConstant.REPORT_SPOT)))
                        .append (ReportConstant.REPORT_SEMICOLON).append (hworkbook.getSheetAt (i).getSheetName ())
                        .append (ReportConstant.REPORT_SUFFIX_HTML);
                    String tempHtmlPath = sb.toString ();
                    
                    File temHtml = new File (tempHtmlPath);
                    if (!temHtml.exists ())
                    {
                        temHtml.createNewFile ();
                    }
                    out = new FileOutputStream (tempHtmlPath);
                    outWrite = new OutputStreamWriter (new FileOutputStream (tempHtmlPath), ReportConstant.REPORT_UTF_8);
                    bufferWritter = new BufferedWriter (outWrite);
                    String htmlcode = ExcelToHtmlUtil.toAllHtml (hworkbook, i);
                    //HtmlUtils.readExcelToHtml (tempPath, true, i);
                    
                    try
                    {
                        bufferWritter.write (htmlcode);
                        bufferWritter.flush ();
                        
                    }
                    catch (Exception e)
                    {
                        LOGGER.error ("excel to html error.", e);
                    }
                    finally
                    {
                        if (null != in)
                        {
                            bufferWritter.close ();
                            
                        }
                        if (null != outWrite)
                        {
                            outWrite.close ();
                            
                        }
                        if (null != out)
                        {
                            out.close ();
                            
                        }
                        
                    }
                    htmlPath.add (tempHtmlPath);
                }
                
            }
            catch (FileNotFoundException e)
            {
                LOGGER.error ("excel to html error.", e);
            }
            catch (IOException e)
            {
                LOGGER.error ("excel to html error.", e);
            }
            finally
            {
                try
                {
                    if (null != in)
                    {
                        in.close ();
                        
                    }
                    
                }
                catch (IOException e)
                {
                    LOGGER.error ("excel to html error.", e);
                }
            }
            return htmlPath;
        }
        else
        {
            try
            {
                in = new FileInputStream (temXsl);
                
                xworkbook = new XSSFWorkbook (in);
                //sxworkbook = new SXSSFWorkbook (xworkbook);
                StringBuffer sb = null;
                String htmlcode = null;
                for (int i = 0; i < xworkbook.getNumberOfSheets (); i++)
                {
                    sb = new StringBuffer ();
                    sb.append (xlsPath).append ("/")
                        .append (xlsFileName.substring (0, xlsFileName.lastIndexOf (ReportConstant.REPORT_SPOT)))
                        .append (ReportConstant.REPORT_SEMICOLON).append (xworkbook.getSheetAt (i).getSheetName ())
                        .append (ReportConstant.REPORT_SUFFIX_HTML);
                    String tempHtmlPath = sb.toString ();
                    
                    File temHtml = new File (tempHtmlPath);
                    if (!temHtml.exists ())
                    {
                        temHtml.createNewFile ();
                    }
                    out = new FileOutputStream (tempHtmlPath);
                    outWrite = new OutputStreamWriter (new FileOutputStream (tempHtmlPath), ReportConstant.REPORT_UTF_8);
                    bufferWritter = new BufferedWriter (outWrite);
                    htmlcode = ExcelToHtmlUtil.toAllHtml (xworkbook, i);//HtmlUtils.readExcelToHtml (tempPath, true, i);
                    
                    try
                    {
                        bufferWritter.write (htmlcode);
                        bufferWritter.flush ();
                        
                    }
                    catch (Exception e)
                    {
                        LOGGER.error ("excel to html error.", e);
                    }
                    finally
                    {
                        if (null != in)
                        {
                            bufferWritter.close ();
                            
                        }
                        if (null != outWrite)
                        {
                            outWrite.close ();
                            
                        }
                        if (null != out)
                        {
                            out.close ();
                            
                        }
                    }
                    htmlcode = null;
                    htmlPath.add (tempHtmlPath);
                }
                
            }
            catch (FileNotFoundException e)
            {
                LOGGER.error ("excel to html error.", e);
            }
            catch (IOException e)
            {
                LOGGER.error ("excel to html error.", e);
            }
            finally
            {
                try
                {
                    if (null != in)
                    {
                        in.close ();
                        
                    }
                    
                }
                catch (IOException e)
                {
                    LOGGER.error ("excel to html error.", e);
                }
            }
            return htmlPath;
        }
        
    }
}