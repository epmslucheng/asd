package com.icss.ebu.ami.report.system.core.task;

import java.util.Date;

public class JobConfig {
	/**
	 * 任务群组
	 */
	private String group;
	/**
	 * 运行任务标识
	 */
	private String taskId;
	/**
	 * 任务名称
	 */
	private String name;
	/**
	 * 任务有效时间
	 */
	private Date validTime;
	/**
	 * 任务失效时间
	 */
	private Date invalidTime;
	/**
	 * 任务调度表达式
	 */
	private String cronExpre;

    /**
     * 重复间隔,以秒为单位
     */
    private Long repeatInterval;

    public String getGroup() {
        return group;
    }

    public void setGroup(String group) {
        this.group = group;
    }

    public String getTaskId() {
        return taskId;
    }

    public void setTaskId(String taskId) {
        this.taskId = taskId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Date getValidTime() {
        return validTime;
    }

    public void setValidTime(Date validTime) {
        this.validTime = validTime;
    }

    public Date getInvalidTime() {
        return invalidTime;
    }

    public void setInvalidTime(Date invalidTime) {
        this.invalidTime = invalidTime;
    }

    public String getCronExpre() {
        return cronExpre;
    }

    public void setCronExpre(String cronExpre) {
        this.cronExpre = cronExpre;
    }

    public Long getRepeatInterval() {
        return repeatInterval;
    }

    public void setRepeatInterval(Long repeatInterval) {
        this.repeatInterval = repeatInterval;
    }
}
