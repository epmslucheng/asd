package com.icss.ebu.ami.report.business.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.icss.ebu.ami.commons.pagePlugin.Page;
import com.icss.ebu.ami.commons.util.I18nUtils;
import com.icss.ebu.ami.commons.util.ServiceUtils;
import com.icss.ebu.ami.report.business.common.util.TaskScheduleUtils;
import com.icss.ebu.ami.report.business.mapper.DataSourceMapper;
import com.icss.ebu.ami.report.business.model.DataSourceBean;
import com.icss.ebu.ami.report.business.model.DataSourceTable;
import com.icss.ebu.ami.report.business.model.DataSourceTableFiled;
import com.icss.ebu.ami.report.business.service.DataSourceService;
import com.icss.ebu.ami.report.system.core.task.DataSourceTableTask;

@Service
public class DataSourceServiceImpl implements DataSourceService
{
    @Autowired
    private DataSourceMapper dataSourceMapper;
    
    @Override
    public List <DataSourceBean> getAllDataSource ()
    {
        return dataSourceMapper.getAllDataSource ();
    }
    
    @Override
    public List <DataSourceBean> getAllDataSourceByUserId (String userId)
    {
        return dataSourceMapper.getAllDataSourceByUserId (userId);
    }
    
    @Override
    public Page <DataSourceBean> queryDataSourceList (Page <DataSourceBean> page)
    {
        page.setResults (dataSourceMapper.getDataSourceList (page));
        return page;
    }
    
    @Override
    public DataSourceBean getDataSourceById (String id)
    {
        return dataSourceMapper.getDataSourceById (id);
    }
    
    @Override
    public void delDataSourceById (String id)
    {
        //删除 数据源中表字段
        dataSourceMapper.delDataSourceTableFiledById (id);
        //删除数据源中表
        dataSourceMapper.delDataSourceTableById (id);
        //删除数据源
        dataSourceMapper.delDataSourceById (id);
    }
    
    @Override
    public void addDataSourceBean (DataSourceBean dataSourceBean)
    {
        dataSourceMapper.addDataSource (dataSourceBean);
    }
    
    @Override
    public void updateDataSourceBean (DataSourceBean dataSourceBean)
    {
        dataSourceMapper.updateDataSource (dataSourceBean);
    }
    
    @Override
    public void editDataSourceBean (DataSourceBean dataSourceBean)
    {
        dataSourceMapper.updateDataSource (dataSourceBean);
        
    }
    
    @Override
    public void getTableByDataSourceId (String id, String type)
    {
        TaskScheduleUtils.excTask (new DataSourceTableTask (id, type, dataSourceMapper));
    }
    
    @Override
    public List <DataSourceTable> getTableListByDataSourceId (String id)
    {
        return dataSourceMapper.getDataSourceTable (id);
    }
    
    @Override
    public DataSourceBean getDataSourceByKey (String key)
    {
        return dataSourceMapper.getDataSourceByKey (key);
    }
    
    @Override
    public void addDataSourceTableFiled (List <DataSourceTableFiled> dstf)
    {
        dataSourceMapper.addDataSourceTableFiled (dstf);
    }
    
    @Override
    public void addDataSourceTable (List <DataSourceTable> dsTableList)
    {
        dataSourceMapper.addDataSourceTable (dsTableList);
    }
    
    @Override
    public void delTableByTableNameAndDsId (DataSourceTable dataSourceTable)
    {
        dataSourceMapper.delTableByTableNameAndDsId (dataSourceTable);
        dataSourceMapper.delTableFiledByTableNameAndDsId (dataSourceTable);
    }
    
    @Override
    public int getTableCount (DataSourceTable dataSourceTable)
    {
        return dataSourceMapper.getTableCount (dataSourceTable);
    }
    
    @Override
    public String analyseAddContent (DataSourceBean dataSourceBean)
    {
        if (dataSourceBean == null)
        {
            return "dataSource is empty";
        }
        StringBuilder addSb = new StringBuilder ();
        ServiceUtils.addPropContent (I18nUtils.getI18nMsg ("ami.dataSource.key"), dataSourceBean.getKey (), addSb);
        ServiceUtils.addPropContent (I18nUtils.getI18nMsg ("ami.dataSource.type"), dataSourceBean.getDbType (), addSb);
        ServiceUtils.addPropContent (I18nUtils.getI18nMsg ("ami.dataSource.username"), dataSourceBean.getDbName (), addSb);
        ServiceUtils.addPropContent (I18nUtils.getI18nMsg ("ami.dataSource.url"), dataSourceBean.getUrl (), addSb);
        if (addSb.length () > 1)
        {
            addSb.setLength (addSb.length () - 1);
        }
        return addSb.toString ();
    }
    
    @Override
    public String analyseEditContent (DataSourceBean oldDataSourceBean, DataSourceBean newDataSourceBean)
    {
        if (oldDataSourceBean == null)
        {
            return "old dataSource is empty";
        }
        StringBuilder updateSb = new StringBuilder ();
        ServiceUtils.compareChange (I18nUtils.getI18nMsg ("ami.dataSource.type"), oldDataSourceBean.getDbType (),
            newDataSourceBean.getDbType (), updateSb);
        ServiceUtils.compareChange (I18nUtils.getI18nMsg ("ami.dataSource.username"), oldDataSourceBean.getDbName (),
            newDataSourceBean.getDbName (), updateSb);
        ServiceUtils.compareChange (I18nUtils.getI18nMsg ("ami.dataSource.url"), oldDataSourceBean.getUrl (),
            newDataSourceBean.getUrl (), updateSb);
        
        if (updateSb.length () > 1)
        {
            updateSb.setLength (updateSb.length () - 1);
        }
        return updateSb.toString ();
    }
    
    @Override
    public String analyseDelContent (DataSourceBean dataSourceBean)
    {
        if (dataSourceBean == null)
        {
            return "dataSource is empty";
        }
        StringBuilder delSb = new StringBuilder ();
        ServiceUtils.addPropContent (I18nUtils.getI18nMsg ("ami.dataSource.key"), dataSourceBean.getKey (), delSb);
        if (delSb.length () > 1)
        {
            delSb.setLength (delSb.length () - 1);
        }
        return delSb.toString ();
    }
    
}
