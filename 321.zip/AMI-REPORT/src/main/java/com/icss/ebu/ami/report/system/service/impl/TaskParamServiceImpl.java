package com.icss.ebu.ami.report.system.service.impl;

import com.alibaba.dubbo.config.annotation.Service;
import com.icss.ebu.ami.report.system.core.task.TaskParam;
import com.icss.ebu.ami.report.system.mapper.TaskParamMapper;
import com.icss.ebu.ami.report.system.service.TaskParamService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Service()
@Component("taskParamService")
public class TaskParamServiceImpl implements TaskParamService {
	@Autowired
	private TaskParamMapper taskParamMapper;

	@Override
	public List<TaskParam> getTaskParamsByTaskId(Long taskId) {
		return taskParamMapper.getTaskParamsByTaskId(taskId);
	}

}
