package com.icss.ebu.ami.report.business.task;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;

import com.icss.ebu.ami.report.business.common.constant.ReportConstant;
import com.icss.ebu.ami.report.business.common.util.ConfigHolder;
import com.icss.ebu.ami.report.business.common.util.ExcelWrite;
import com.icss.ebu.ami.report.business.common.util.JDBCTemplateUtil;
import com.icss.ebu.ami.report.business.common.util.SqlUtils;
import com.icss.ebu.ami.report.business.mapper.ObjectTreeMapper;
import com.icss.ebu.ami.report.business.mapper.ReportFileMapper;
import com.icss.ebu.ami.report.business.model.Function;
import com.icss.ebu.ami.report.business.model.ObjectTreeBean;
import com.icss.ebu.ami.report.business.model.ReportDesign;
import com.icss.ebu.ami.report.business.model.ReportFile;
import com.icss.ebu.ami.report.business.model.ReportHtml;
import com.icss.ebu.ami.report.business.model.Template;

/**
 * 生成html
 * @author lvzhengtao
 *
 */
public class HtmlGenerateTask implements Callable <Boolean>
{
    private Logger LOGGER = LoggerFactory.getLogger (HtmlGenerateTask.class);
    
    private ReportFileMapper reportFileMapper;
    
    private Template template;
    
    private List <ReportDesign> list;
    
    private List <Function> func;
    
    private String date_formatter;
    
    private ObjectTreeMapper objectTreeMapper;
    
    public HtmlGenerateTask (ReportFileMapper reportFileMapper, Template template, List <ReportDesign> list,
        List <Function> func, ObjectTreeMapper objectTreeMapper, String date_formatter)
    {
        this.reportFileMapper = reportFileMapper;
        this.template = template;
        this.list = list;
        this.func = func;
        this.objectTreeMapper = objectTreeMapper;
        this.date_formatter = date_formatter;
    }
    
    @Override
    public Boolean call ()
    {
        String reportId = template.getReportId ();
        String tempPath = template.getTempPath ();
        String startTime = template.getStartTime ();
        String endTime = template.getEndTime ();
        String currentTime = template.getCurrentTime ();
        String treeMap = template.getTreeMap ();
        String tmpkey = template.getTmpkey();
        ReportFile reportFile = new ReportFile ();
        reportFile.setReportId (reportId);
        FileOutputStream out = null;
        Map <String, String> map = new HashMap <String, String> ();
        try
        {
            if (StringUtils.isNotBlank (treeMap))
            {
                
                String[] treeList = treeMap.split (";");
                for (String tree : treeList)
                {
                    String[] split = tree.split (",");
                    map.put (split[0], split[1]);
                }
            }
        }
        catch (Exception e)
        {
            recordReportStatus (reportFile, ReportConstant.REPORT_FAILURE);
            LOGGER.error ("String split fail.", e);
            return false;
        }
        
        /**
         * ftp上传路径
         */
        String targetDir =
            ConfigHolder.getCfg (ReportConstant.FTP_CATALOG)
                + ConfigHolder.getCfg (ReportConstant.REPORT_FTP_PATH_DAY);
        if (ReportConstant.REPORT_TYPE_MONTH.equals (template.getReporttype ()))
        {
            targetDir =
                ConfigHolder.getCfg (ReportConstant.FTP_CATALOG)
                    + ConfigHolder.getCfg (ReportConstant.REPORT_FTP_PATH_MONTH);
        }
        
        /**
         * 下载模板处理report_date
         */
        try
        {
            ExcelWrite.createTempExcel (template.getTmpfile (), template.getTmpfilename (),
                ConfigHolder.getCfg (ReportConstant.REPORT_TEMP_PATH), tempPath, date_formatter);
        }
        catch (Exception e)
        {
            recordReportStatus (reportFile, ReportConstant.REPORT_FAILURE);
            LOGGER.error ("ExcelWrite createTempExcel fail", e);
            return false;
        }
        
        try
        {
            
            List <ObjectTreeBean> objectTreeList = objectTreeMapper.queryAllObjectTree (new ObjectTreeBean ());
            
            Workbook workBook = createWorkBook (tempPath);
            if (workBook == null)
            {
                recordReportStatus (reportFile, ReportConstant.REPORT_FAILURE);
                return false;
            }
            
            /**
             * 循环数据集
             */
            for (ReportDesign rd : list)
            {
                rd.setTmpFile (template.getTmpfile ());
                rd.setTmpFileName (template.getTmpfilename ());
                // 循环生成数据集插入报表
                List <Map <String, Object>> datas = null;
                String querySql = "";
                querySql = rd.getQuerySql ().replace (ReportConstant.REPORT_ENTER, ReportConstant.REPORT_SPACE);
                querySql = SqlUtils.assembleSqlFunction (querySql, currentTime, startTime, endTime, func);
                querySql = SqlUtils.assembleTreeSqlFunction (querySql, map, objectTreeList);
                
                JdbcTemplate jdbcTemplate = JDBCTemplateUtil.getJDBC (rd.getCnnId ());
                Map <String, Object> position = ExcelWrite.excelColStrToNum (rd.getToexcel ());
                
                String[] title = null;
                
                datas =
                    jdbcTemplate.queryForList (SqlUtils.getPageSql (1, ReportConstant.REPORT_PREVIEW_SIZE, querySql,
                        rd.getDbType ()));
                if (null != datas && 0 != datas.size ())
                {
                    title = (String[]) (datas.get (0).keySet ().toArray (new String[0]));
                }
                ExcelWrite.writeToExcel (workBook, tempPath, datas, position, title);
                datas.clear ();
                
            }
            out = new FileOutputStream (tempPath);
            workBook.setForceFormulaRecalculation (true);
            workBook.write (out);
            out.flush ();
            out.close ();
            
        }
        catch (Exception e)
        {
            LOGGER.error ("generate report - error", e);
            recordReportStatus (reportFile, ReportConstant.REPORT_FAILURE);
            return false;
        }
        finally
        {
            IOUtils.closeQuietly (out);
        }
        
        try
        {
            List <String> tempHtmlPath = ExcelWrite.excelToHtml (tempPath);
            ExcelWrite.deleteExcel (tempPath);
            List <ReportHtml> htmls = new ArrayList <ReportHtml> ();
            
            String sheetName = "";
            String tempHtml = "";
            for (int i = 0; i < tempHtmlPath.size (); i++)
            {
                tempHtml = tempHtmlPath.get (i);
                File file = new File (tempHtml);
                ReportHtml reportHtml = new ReportHtml ();
                reportHtml.setId (reportId);
                reportHtml.setHtmlType (ReportConstant.HTML_TYPE_REPORT);
                reportHtml.setHtmlName (file.getName ());
                reportHtml.setHtmlPath (targetDir);
                reportHtml.setShowName (tmpkey + "_sheet" + i + ReportConstant.REPORT_SUFFIX_HTML);
                if (StringUtils.isNotBlank (file.getName ()))
                {
                    sheetName =
                        file.getName ().substring (file.getName ().lastIndexOf (ReportConstant.REPORT_SEMICOLON) + 1,
                            file.getName ().lastIndexOf (ReportConstant.REPORT_SPOT));
                }
                reportHtml.setSheetName (sheetName);
                htmls.add (reportHtml);
                ExcelWrite.uploadFileToFtp (tempHtml, targetDir);
                // 4.上传成功，删除临时文件
                ExcelWrite.deleteExcel (tempHtml);
                
            }
            reportFileMapper.addReportHtml (htmls);
            recordReportStatus (reportFile, ReportConstant.REPORT_SUCCESS);
            
        }
        catch (Exception e)
        {
            LOGGER.error ("upload and save html to db - error", e);
            recordReportStatus (reportFile, ReportConstant.REPORT_FAILURE);
            return false;
        }
        
        return true;
    }
    
    private void recordReportStatus (ReportFile reportFile, String status)
    {
        reportFile.setReportStatus (status);
        reportFileMapper.editReportFile (reportFile);
        reportFileMapper.editReportLog (reportFile);
    }
    
    /**
     * 创建Workbook
     * @return
     */
    private Workbook createWorkBook (String tempPath)
    {
        Workbook workBook = null;
        try
        {
            FileInputStream in = new FileInputStream (new File (tempPath));
            if (tempPath.endsWith (ReportConstant.REPORT_SUFFIX_XLS))
            {
                workBook = new HSSFWorkbook (in);
            }
            else
            {
                XSSFWorkbook xwork = new XSSFWorkbook (in);
                workBook = new SXSSFWorkbook (xwork, 1000);
            }
        }
        catch (Exception e)
        {
            LOGGER.error ("createWorkBook fail.", e);
        }
        
        return workBook;
    }
}
