package com.icss.ebu.ami.report.business.model;

import java.io.Serializable;

/** 
* @author  zhangkaining 
* @date 2017年10月30日 下午5:24:02 
* @version 1.0   
*/
public class ReportDesign implements Serializable
{
    
    /**
     * 
     */
    private static final long serialVersionUID = 159217762822960565L;
    
    /**
     * 模板ID
     */
    private String reportid;
    
    /**
     * 数据集ID
     */
    private String queryid;
    
    /**
     *      
     */
    private String queryserial;
    
    /**
     * 到excel哪个位置
     */
    private String toexcel;
    
    private String querySql;
    
    private String cnnId;
    
    private String tmpId;
    
    private String tmpKey;
    
    private String tmpFile;
    
    private String tmpFileName;
    
    private String tmpName;
    
    /**
     * 
     */
    private String deptid;
    
    private String dbType;
    
    public String getReportid ()
    {
        return reportid;
    }
    
    public void setReportid (String reportid)
    {
        this.reportid = reportid;
    }
    
    public String getQueryid ()
    {
        return queryid;
    }
    
    public void setQueryid (String queryid)
    {
        this.queryid = queryid;
    }
    
    public String getQueryserial ()
    {
        return queryserial;
    }
    
    public void setQueryserial (String queryserial)
    {
        this.queryserial = queryserial;
    }
    
    public String getToexcel ()
    {
        return toexcel;
    }
    
    public void setToexcel (String toexcel)
    {
        this.toexcel = toexcel;
    }
    
    public String getDeptid ()
    {
        return deptid;
    }
    
    public void setDeptid (String deptid)
    {
        this.deptid = deptid;
    }
    
    public String getQuerySql ()
    {
        return querySql;
    }
    
    public void setQuerySql (String querySql)
    {
        this.querySql = querySql;
    }
    
    public String getCnnId ()
    {
        return cnnId;
    }
    
    public void setCnnId (String cnnId)
    {
        this.cnnId = cnnId;
    }
    
    public String getTmpId ()
    {
        return tmpId;
    }
    
    public void setTmpId (String tmpId)
    {
        this.tmpId = tmpId;
    }
    
    public String getTmpKey ()
    {
        return tmpKey;
    }
    
    public void setTmpKey (String tmpKey)
    {
        this.tmpKey = tmpKey;
    }
    
    public String getTmpFile ()
    {
        return tmpFile;
    }
    
    public void setTmpFile (String tmpFile)
    {
        this.tmpFile = tmpFile;
    }
    
    public String getTmpName ()
    {
        return tmpName;
    }
    
    public void setTmpName (String tmpName)
    {
        this.tmpName = tmpName;
    }
    
    public String getTmpFileName ()
    {
        return tmpFileName;
    }
    
    public void setTmpFileName (String tmpFileName)
    {
        this.tmpFileName = tmpFileName;
    }
    
    public String getDbType ()
    {
        return dbType;
    }
    
    public void setDbType (String dbType)
    {
        this.dbType = dbType;
    }
    
}
