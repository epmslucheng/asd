package com.icss.ebu.ami.report.business.model;

import java.io.Serializable;
import java.util.List;

/**
 * 数据源表实体类
 * @author xunan
 *
 */
public class Table implements Serializable
{
    
    /**
     * 
     */
    private static final long serialVersionUID = -7321259673858765167L;
    
    private String id;
    
    private String cnnId;
    
    //表名称
    private String tableName;
    
    //表类型
    private String tableType;
    
    //树名称
    private String name;
    
    //树节点是否可编辑
    private boolean editable;
    
    //树节点id
    private String treeId;
    
    private String parentId;
    
    private String queryId;
    
    private boolean draggable;
    
    private String tableSql;
    
    private List <TableField> fieldList;
    
    public String getParentId ()
    {
        return parentId;
    }
    
    public void setParentId (String parentId)
    {
        this.parentId = parentId;
    }
    
    public String getId ()
    {
        return id;
    }
    
    public void setId (String id)
    {
        this.id = id;
    }
    
    public String getTableName ()
    {
        return tableName;
    }
    
    public void setTableName (String tableName)
    {
        this.tableName = tableName;
        this.name = tableName;
    }
    
    public String getTableType ()
    {
        return tableType;
    }
    
    public void setTableType (String tableType)
    {
        this.tableType = tableType;
    }
    
    public String getName ()
    {
        return name;
    }
    
    public void setName (String name)
    {
        this.name = name;
    }
    
    public boolean isEditable ()
    {
        return editable;
    }
    
    public void setEditable (boolean editable)
    {
        this.editable = editable;
    }
    
    public String getTreeId ()
    {
        return treeId;
    }
    
    public void setTreeId (String treeId)
    {
        this.treeId = treeId;
    }
    
    public String getQueryId ()
    {
        return queryId;
    }
    
    public void setQueryId (String queryId)
    {
        this.queryId = queryId;
    }
    
    public boolean isDraggable ()
    {
        return draggable;
    }
    
    public void setDraggable (boolean draggable)
    {
        this.draggable = draggable;
    }
    
    public String getTableSql ()
    {
        return tableSql;
    }
    
    public void setTableSql (String tableSql)
    {
        this.tableSql = tableSql;
    }
    
    public List <TableField> getFieldList ()
    {
        return fieldList;
    }
    
    public void setFieldList (List <TableField> fieldList)
    {
        this.fieldList = fieldList;
    }
    
    public String getCnnId ()
    {
        return cnnId;
    }
    
    public void setCnnId (String cnnId)
    {
        this.cnnId = cnnId;
    }
    
}
