package com.icss.ebu.ami.report.business.controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.druid.pool.DruidDataSource;
import com.icss.ebu.ami.commons.constants.ConstantCode;
import com.icss.ebu.ami.commons.pagePlugin.Page;
import com.icss.ebu.ami.commons.util.UUIDUtils;
import com.icss.ebu.ami.report.business.common.constant.CommonConstant;
import com.icss.ebu.ami.report.business.common.constant.ReportConstant;
import com.icss.ebu.ami.report.business.common.util.JDBCTemplateUtil;
import com.icss.ebu.ami.report.business.common.util.LogRenderUtils;
import com.icss.ebu.ami.report.business.model.DataSourceBean;
import com.icss.ebu.ami.report.business.service.DataSourceService;
import com.icss.ebu.ami.report.business.service.LogService;
import com.icss.ebu.ami.report.business.service.UserService;
import com.icss.ebu.ami.report.system.core.task.DataSourceThreadCache;
import com.icss.ebu.ami.report.system.model.User;
import com.icss.ebu.ami.report.system.model.UserGrant;

@Controller
@RequestMapping ("/dataSource")
public class DataSourceController extends BaseController
{
    private static final Logger LOGGER = LoggerFactory.getLogger (DataSourceController.class);
    
    @Autowired
    private DataSourceService dataSourceService;
    
    @Autowired
    private UserService userService;
    
    @Autowired
    protected LogService logService;
    
    @RequestMapping (value = "/index")
    public String index (HttpServletRequest request, HttpServletResponse response)
    {
        return "/service/dataSource/dataSource";
    }
    
    @RequestMapping (value = "/dataSourceManager")
    public String dataSourceManager (HttpServletRequest request, HttpServletResponse response)
    {
        return "/service/dataSource/dataSourceManager";
    }
    
    @RequestMapping ("/getAllDataList")
    @ResponseBody
    public Object getAllDataList (HttpServletRequest request, HttpServletResponse response)
    {
        User currentUser = getCurrentUser ();
        Map <String, Object> result = new HashMap <String, Object> ();
        List <DataSourceBean> dsList = null;
        if ("1".equals (currentUser.getId ()))
        {
            
            dsList = dataSourceService.getAllDataSource ();
        }
        else
        {
            dsList = dataSourceService.getAllDataSourceByUserId (currentUser.getId ());
            
        }
        result.put ("dsList", dsList);
        return renderSuccess (result);
    }
    
    @RequestMapping ("/genertateDsId")
    @ResponseBody
    public Object genertateDsId (HttpServletRequest request, HttpServletResponse response)
    {
        Map <String, Object> result = new HashMap <String, Object> ();
        String id = UUIDUtils.generate16Str ();
        result.put ("id", id);
        return renderSuccess (result);
    }
    
    @RequestMapping (value = "/dataSourceManagerAdd")
    public String dataSourceManagerAdd (HttpServletRequest request, HttpServletResponse response)
    {
        return "/service/dataSource/dataSourceManagerAdd";
    }
    
    @RequestMapping ("/query")
    @ResponseBody
    public Object query (HttpServletRequest request, DataSourceBean dataSource)
    {
        //        DataSourceBean dataSource = new DataSourceBean ();
        Page <DataSourceBean> page = new Page <DataSourceBean> (dataSource);
        page.setPageNo (NumberUtils.toInt (request.getParameter (CommonConstant.PAGE_PARAM_PAGE)));
        page.setPageSize (NumberUtils.toInt (request.getParameter (CommonConstant.PAGE_PARAM_ROWS)));
        User currentUser = getCurrentUser ();
        if (!ReportConstant.REPORT_USERID_ROOT.equals (currentUser.getId ()))
        {
            dataSource.setUserId (currentUser.getId ());
        }
        page = dataSourceService.queryDataSourceList (page);
        Map <String, Object> map = new HashMap <String, Object> ();
        map.put (CommonConstant.PAGE_RESULT_ROWS, page.getResults ());
        map.put (CommonConstant.PAGE_RESULT_TOTAL, page.getTotalRecord ());
        return map;
        
    }
    
    /**
     * 新增页
     *
     * @param model
     * @param id
     * @return
     */
    @RequestMapping ("/addPage")
    public String addPage (Model model, HttpServletRequest request, HttpServletResponse response,
        @RequestBody DataSourceBean dataSource)
    {
        return "/service/dataSource/dataSourceAdd";
    }
    
    @RequestMapping ("/save")
    @ResponseBody
    public Object save (HttpServletRequest request, HttpServletResponse response, @RequestBody DataSourceBean dataSource)
    {
        
        try
        {
            
            DataSourceBean ds = dataSourceService.getDataSourceByKey (dataSource.getKey ());
            
            if (null != ds)
            {
                return renderError ("key repeat");
            }
            
            dataSourceService.addDataSourceBean (dataSource);
            
            User user = getCurrentUser ();
            if (!ReportConstant.REPORT_USERID_ROOT.equals (user.getId ()))
            {
                UserGrant userGrant = new UserGrant ();
                userGrant.setUserid (user.getId ());
                userGrant.setCnnid (dataSource.getId ());
                userService.insertUserGrant (userGrant);
            }
        }
        catch (Exception e)
        {
            return renderError ("error");
        }
        
        //
        DruidDataSource druidDataSource = null;
        druidDataSource = JDBCTemplateUtil.pacakageDataSource (dataSource);
        DataSourceThreadCache.setCache (dataSource.getId (), druidDataSource);
        //定义线程 查询所有表
        dataSourceService.getTableByDataSourceId (dataSource.getId (), "add");
        
        //获取当前登录用户
        User curUser = getCurrentUser ();
        //获取操作描述 key = 类名+"_"+方法名 
        String funDesc = LogRenderUtils.getLogReqMap ("DataSourceController_add");
        try
        {
            //分析删除对象的的关键内容
            String operDetail = dataSourceService.analyseAddContent (dataSource);
            if (StringUtils.isNotBlank (operDetail))
            {
                //插入日志
                logService.insertSysLog (curUser, ConstantCode.STRING_02, getRemoteAddr (), funDesc, operDetail, null, null);
            }
        }
        catch (Exception ex)
        {
            logger.error (funDesc + "  bussness log insert error", ex);
        }
        return renderSuccess ("success");
    }
    
    /**
     * 查看页
     *
     * @param model
     * @param id
     * @return
     */
    @RequestMapping ("/viewPage")
    public String viewPage (Model model, HttpServletRequest request, HttpServletResponse response, DataSourceBean dataSource)
    {
        String id = dataSource.getId ();
        DataSourceBean ds = dataSourceService.getDataSourceById (id);
        model.addAttribute ("dataSource", ds);
        return "/service/dataSource/dataSourceView";
    }
    
    /**
     * 编辑页
     *
     * @param model
     * @param id
     * @return
     */
    @RequestMapping ("/editPage")
    public String editPage (Model model, HttpServletRequest request, HttpServletResponse response,
        @RequestBody DataSourceBean dataSource)
    {
        return "/service/dataSource/dataSourceEdit";
    }
    
    @RequestMapping ("/edit")
    @ResponseBody
    public Object edit (HttpServletRequest request, HttpServletResponse response, @RequestBody DataSourceBean dataSource)
    {
        DataSourceBean oldDataSource = dataSourceService.getDataSourceById (dataSource.getId ());
        try
        {
            dataSourceService.editDataSourceBean (dataSource);
        }
        catch (Exception e)
        {
            return renderSuccess ("error");
        }
        
        //        //定义线程 查询所有表
        //        dataSourceService.getTableByDataSourceId(dataSource.getId(),"add");
        
        //获取当前登录用户
        User curUser = getCurrentUser ();
        //获取操作描述 key = 类名+"_"+方法名 
        String funDesc = LogRenderUtils.getLogReqMap ("DataSourceController_edit");
        try
        {
            //分析删除对象的的关键内容
            String operDetail = dataSourceService.analyseEditContent (oldDataSource, dataSource);
            if (StringUtils.isNotBlank (operDetail))
            {
                //插入日志
                logService.insertSysLog (curUser, ConstantCode.STRING_02, getRemoteAddr (), funDesc, operDetail, null, null);
            }
        }
        catch (Exception ex)
        {
            logger.error (funDesc + "  bussness log insert error", ex);
        }
        return renderSuccess ("success");
    }
    
    @RequestMapping ("/delete")
    @ResponseBody
    public Object delete (HttpServletRequest request, @RequestBody DataSourceBean dataSource)
    {
        String id = dataSource.getId ();
        dataSource = dataSourceService.getDataSourceById (id);
        dataSourceService.delDataSourceById (dataSource.getId ());
        User user = getCurrentUser ();
        UserGrant userGrant = new UserGrant ();
        if (!ReportConstant.REPORT_USERID_ROOT.equals (user.getId ()))
        {
            userGrant.setUserid (user.getId ());
        }
        userGrant.setCnnid (dataSource.getId ());
        userService.deleteUserGrant (userGrant);
        
        String funDesc = LogRenderUtils.getLogReqMap ("DataSourceController_del");
        try
        {
            //分析删除对象的的关键内容
            String operDetail = dataSourceService.analyseDelContent (dataSource);
            if (StringUtils.isNotBlank (operDetail))
            {
                //插入日志
                logService.insertSysLog (user, ConstantCode.STRING_02, getRemoteAddr (), funDesc, operDetail, null, null);
            }
        }
        catch (Exception ex)
        {
            logger.error (funDesc + "  bussness log insert error", ex);
        }
        
        return renderSuccess ("success");
    }
    
    @RequestMapping ("/updateTable")
    @ResponseBody
    public Object updateTable (HttpServletRequest request, @RequestBody DataSourceBean dataSource)
    {
        //刷新数据源中表结构
        //定义线程 查询所有表
        dataSourceService.getTableByDataSourceId (dataSource.getId (), "update");
        
        return renderSuccess ("success");
    }
    
    @RequestMapping ("/testConnection")
    @ResponseBody
    public Object testConnection (HttpServletRequest request, @RequestBody DataSourceBean dataSource)
    {
        //        try
        //        {
        //            
        //            DruidDataSource ds = new DruidDataSource ();
        //            
        //            ds = JDBCTemplateUtil.pacakageDataSource (dataSource);
        //            
        //            JdbcTemplate jc = new JdbcTemplate (ds);
        //            
        //            jc.queryForObject ("SELECT 1 FROM DUAL", String.class);
        //            
        //        }
        //        catch (Exception e)
        //        {
        //            LOGGER.error ("连接失败");
        //            return renderError ("error");
        //        }
        
        Connection conn = null;
        Statement stmt = null;
        String myDriver = "";
        if ("01".equals (dataSource.getDbType ()))
        {
            myDriver = "oracle.jdbc.driver.OracleDriver";
        }
        
        if ("02".equals (dataSource.getDbType ()))
        {
            myDriver = "com.mysql.jdbc.Driver";
        }
        String url = dataSource.getUrl ();
        try
        {
            Class.forName (myDriver);
            System.out.println ("驱动加裁成功");
        }
        catch (ClassNotFoundException e)
        {
            LOGGER.error (e.getMessage ());
            return renderError (e.getMessage ());
        }
        try
        {
            conn = DriverManager.getConnection (url, dataSource.getDbName (), dataSource.getDbPwd ());
            System.out.println ("连接成功");
            stmt = conn.createStatement ();
            stmt.executeQuery ("select 1 from dual");
        }
        catch (SQLException e)
        {
            LOGGER.error (e.getMessage ());
            return renderError (e.getMessage ());
        }
        
        if (conn != null)
        {
            try
            {
                conn.close ();
            }
            catch (SQLException e)
            {
                LOGGER.error (e.getMessage ());
            }
        }
        
        return renderSuccess ("success");
    }
}
