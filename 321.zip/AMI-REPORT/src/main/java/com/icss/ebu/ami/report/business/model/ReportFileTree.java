package com.icss.ebu.ami.report.business.model;

import java.io.Serializable;

/**
 * 报表对象树关系表
 * @author lvzhengtao
 *
 */
public class ReportFileTree implements Serializable
{
    
    /**
     * 
     */
    private static final long serialVersionUID = 334024802035917723L;
    
    private String id;
    
    private String reportId;
    
    private String treeId;
    
    public String getId ()
    {
        return id;
    }
    
    public void setId (String id)
    {
        this.id = id;
    }
    
    public String getReportId ()
    {
        return reportId;
    }
    
    public void setReportId (String reportId)
    {
        this.reportId = reportId;
    }
    
    public String getTreeId ()
    {
        return treeId;
    }
    
    public void setTreeId (String treeId)
    {
        this.treeId = treeId;
    }
    
}
