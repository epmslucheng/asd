package com.icss.ebu.ami.report.business.common.constant;

/**
 * 
 * sql关键字
 * @author lucheng
 *
 */
public class SqlConstant
{
    
    public static final String DATABASE_ORACLE = "ORACLE";
    
    /**
     * oracle  sql关键字
     */
    public static final String SQL_SELECT = "SELECT";
    
    public static final String SQL_FROM = "FROM";
    
    public static final String SQL_WHERE = "WHERE";
    
    public static final String SQL_ON = "ON";
    
    public static final String SQL_AND = "AND";
    
    public static final String SQL_AS = "AS";
    
    /**
     * 自定义sql
     */
    public static final String DATASET_USER_DEFINED = "0";
    
    /**
     * 多表关联
     */
    public static final String DATASET_MULTI_TABLE_ASSOCIATION = "1";
    
}
