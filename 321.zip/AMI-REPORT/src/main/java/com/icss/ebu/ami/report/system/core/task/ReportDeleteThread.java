package com.icss.ebu.ami.report.system.core.task;

import java.util.Date;
import java.util.List;
import java.util.TimerTask;

import com.icss.ebu.ami.report.business.service.ReportTaskService;
import org.springframework.beans.factory.annotation.Autowired;

import com.icss.ebu.ami.report.business.common.util.FtpUtils;
import com.icss.ebu.ami.report.business.model.ReportFile;
import com.icss.ebu.ami.report.business.model.ReportHtml;
import com.icss.ebu.ami.report.business.service.ReportFileService;
import com.icss.ebu.ami.report.business.service.SystemParameterService;
import com.icss.ebu.ami.report.system.model.SystemParameter;

public class ReportDeleteThread extends TimerTask
{
    
    @Autowired
    private ReportFileService reportFileService;

    @Autowired
    private SystemParameterService systemParameterService;
    
    @Override
    public void run ()
    {
        SystemParameter systemParameter = systemParameterService.querySystemParameterById ("10001");

        Long day = Long.parseLong (systemParameter.getValue ());
        ReportFile r = new ReportFile ();
        r.setCreateTime (new Date (new Date ().getTime () - day * 86400000));
        List <ReportFile> list = reportFileService.queryReportFile (r);
        for (ReportFile reportFile : list)
        {
            reportFileService.deleteReport(reportFile);
        }
    }
    
}
