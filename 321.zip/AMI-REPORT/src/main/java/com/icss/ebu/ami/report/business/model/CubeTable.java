package com.icss.ebu.ami.report.business.model;

import java.io.Serializable;

/**
 * 立方关联表
 * @author xunan
 *
 */
public class CubeTable implements Serializable
{
    /**
     * 
     */
    private static final long serialVersionUID = 5706830847482306689L;
    
    //立方id
    private String cubeId;
    
    //表名称
    private String tableId;
    
    //表名称
    private String tableName;
    
    public String getCubeId ()
    {
        return cubeId;
    }
    
    public void setCubeId (String cubeId)
    {
        this.cubeId = cubeId;
    }
    
    public String getTableId ()
    {
        return tableId;
    }
    
    public void setTableId (String tableId)
    {
        this.tableId = tableId;
    }
    
    public String getTableName ()
    {
        return tableName;
    }
    
    public void setTableName (String tableName)
    {
        this.tableName = tableName;
    }
    
}
