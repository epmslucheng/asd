package com.icss.ebu.ami.report.business.common.util;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DbUtils
{
    
    public static void main (String[] args) throws Exception
    {/*
        User user = new User ();
        user.setLoginName ("lucheng");
        user.setOrgId ("nanjing");
        Orgination org = new Orgination ();
        org.setId ("nanjing");
        
        Fee fee = new Fee ();
        fee.setUserName ("lucheng");
        Map map = assembleSql (org, user, fee);
        System.out.println (map);
     */
    }
    
    /**
     * 拼装sql与参数
     * 
     * @param firstObj
     * @param objs
     * @return
     * @throws Exception
     */
    public static Map <String, Object> assembleSql (Object firstObj, Object... objs) throws Exception
    {
        char aliasTmp = 'A';
        int i = 1;
        String alias = String.valueOf (aliasTmp) + i;
        Map <String, Object> result = new HashMap <String, Object> ();
        checkArguments (firstObj, objs);
        // 这个用来粗放返回值  
        Map <Class, List <Object>> container = new HashMap <Class, List <Object>> ();
        
        // 以下三行用来存放生成的params与sql语句  
        List <Object> params = new ArrayList <Object> ();
        StringBuffer headSql = new StringBuffer ("select * from ");
        StringBuffer tailSql = new StringBuffer (" where ");
        
        // //////////以下是处理第一个对象  
        // 获取映射分装类  
        DbMapping dbMapping = DbMapping.obtain (firstObj.getClass ());
        // 得到表名，生成sql  
        String tableName = dbMapping.getTableName ();
        headSql.append (tableName).append (" ").append (alias).append (" ");
        // 将对象中的属性添加到sql中的约束部分，并且添加params  
        Field[] fields = firstObj.getClass ().getDeclaredFields ();
        for (Field field : fields)
        {
            
            field.setAccessible (true);
            Object fieldValue = field.get (firstObj);
            // 那就说明这个属性需要转化成sql语句  
            if (fieldValue != null && !"".equals (fieldValue))
            {
                String columnName = dbMapping.getColumnMapping (field);
                tailSql.append (alias).append (".").append (columnName).append ("=? and ");
                params.add (fieldValue);
            }
        }
        List <Object> firstValues = new ArrayList <Object> ();
        container.put (firstObj.getClass (), firstValues);
        // //////第一个对象处理完毕  
        
        // //////---下面处理后面的对象  
        for (Object obj : objs)
        {
            String oldAlias = alias;
            if (i < 10)
            {
                i++;
            }
            else
            {
                aliasTmp = (char) (aliasTmp + 1);
                i = 1;
            }
            alias = String.valueOf (aliasTmp) + i;
            String oldPrimaryKey = dbMapping.getPrimaryKey ();
            dbMapping = DbMapping.obtain (obj.getClass ());
            // 先处理headSql  
            // 这里要把自己表名加上，还要把表与表之间的联系加上  
            tableName = dbMapping.getTableName ();
            String newForeignKey = dbMapping.getForeignKey ();
            headSql.append (" join ").append (tableName).append (" ").append (alias).append (" on ") //  
                .append (oldAlias).append (".").append (oldPrimaryKey) //  
                .append ("=") //  
                .append (alias).append (".").append (newForeignKey);
            
            // 再来第二段sql语句  
            fields = obj.getClass ().getDeclaredFields ();
            for (Field field : fields)
            {
                field.setAccessible (true);
                Object fieldValue = field.get (obj);
                if (fieldValue != null && !"".equals (fieldValue))
                {
                    String columnName = dbMapping.getColumnMapping (field);
                    tailSql.append (alias).append (".").append (columnName).append ("=? and ");
                    params.add (fieldValue);
                }
            }
            
            List <Object> values = new ArrayList <Object> ();
            container.put (obj.getClass (), values);
        }
        
        String finalSql = headSql.append (tailSql.delete (tailSql.length () - 4, tailSql.length () - 1)).toString ();
        
        result.put ("sql", finalSql);
        result.put ("params", params);
        return result;
    }
    
    /** 
     * 检查参数异常，抛出。 
     * */
    private static void checkArguments (Object firstObj, Object[] objs)
    {
        if (firstObj == null)
        {
            throw new RuntimeException ();
        }
    }
    
    public Map <Class, List <Object>> multiClassQuery (Object firstObj, Object... objs) throws Exception
    {
        checkArguments (firstObj, objs);
        // 这个用来粗放返回值  
        Map <Class, List <Object>> container = new HashMap <Class, List <Object>> ();
        
        // 以下三行用来存放生成的params与sql语句  
        List <Object> params = new ArrayList <Object> ();
        StringBuffer headSql = new StringBuffer ("select * from ");
        StringBuffer tailSql = new StringBuffer (" where ");
        
        // //////////以下是处理第一个对象  
        // 获取映射分装类  
        DbMapping dbMapping = DbMapping.obtain (firstObj.getClass ());
        // 得到表名，生成sql  
        String tableName = dbMapping.getTableName ();
        headSql.append (tableName);
        // 将对象中的属性添加到sql中的约束部分，并且添加params  
        Field[] fields = firstObj.getClass ().getDeclaredFields ();
        for (Field field : fields)
        {
            field.setAccessible (true);
            Object fieldValue = field.get (firstObj);
            // 那就说明这个属性需要转化成sql语句  
            if (fieldValue != null || !"".equals (fieldValue))
            {
                String columnName = dbMapping.getColumnMapping (field);
                tailSql.append (columnName).append ("=? and ");
                params.add (fieldValue);
            }
        }
        List <Object> firstValues = new ArrayList <Object> ();
        container.put (firstObj.getClass (), firstValues);
        // //////第一个对象处理完毕  
        
        // //////---下面处理后面的对象  
        for (Object obj : objs)
        {
            String oldTableName = tableName;
            String oldPrimaryKey = dbMapping.getPrimaryKey ();
            dbMapping = DbMapping.obtain (obj.getClass ());
            // 先处理headSql  
            // 这里要把自己表名加上，还要把表与表之间的联系加上  
            tableName = dbMapping.getTableName ();
            String newForeignKey = dbMapping.getForeignKey ();
            headSql.append (" join ").append (tableName).append (" on ") //  
                .append (oldTableName).append (".").append (oldPrimaryKey) //  
                .append ("=") //  
                .append (tableName).append (".").append (newForeignKey);
            
            // 再来第二段sql语句  
            fields = obj.getClass ().getDeclaredFields ();
            for (Field field : fields)
            {
                field.setAccessible (true);
                Object fieldValue = field.get (firstObj);
                if (fieldValue != null || !"".equals (fieldValue))
                {
                    String columnName = dbMapping.getColumnMapping (field);
                    tailSql.append (columnName).append ("=? and ");
                    params.add (fieldValue);
                }
            }
            
            List <Object> values = new ArrayList <Object> ();
            container.put (obj.getClass (), values);
        }
        
        String finalSql = headSql.append (tailSql.delete (tailSql.length () - 4, tailSql.length () - 1)).toString ();
        System.out.println ("sql = " + finalSql);
        System.out.println ("params = " + params);
        
        /* Connection conn = null;
         PreparedStatement ps = null;
         ResultSet rs = null;
         try
         {
             conn = ConnectionPool.getConnection ();
             ps = conn.prepareStatement (finalSql);
             for (int i = 0; i < params.size (); i++)
             {
                 ps.setObject (i + 1, params.get (i));
             }
             rs = ps.executeQuery ();
             while (rs.next ())
             {
                 int rsCursor = 1;
                 Object instance = firstObj.getClass ().newInstance ();
                 fields = firstObj.getClass ().getDeclaredFields ();
                 for (Field field : fields)
                 {
                     field.setAccessible (true);
                     field.set (instance, rs.getObject (rsCursor++));
                 }
                 container.get (firstObj.getClass ()).add (instance);
                 
                 for (Object obj : objs)
                 {
                     instance = obj.getClass ().newInstance ();
                     fields = obj.getClass ().getDeclaredFields ();
                     for (Field field : fields)
                     {
                         field.setAccessible (true);
                         field.set (instance, rs.getObject (rsCursor++));
                     }
                     container.get (obj.getClass ()).add (instance);
                 }
             }
         }
         finally
         {
             rs.close ();
             ps.close ();
             conn.close ();
         }*/
        
        return null;
    }
}
