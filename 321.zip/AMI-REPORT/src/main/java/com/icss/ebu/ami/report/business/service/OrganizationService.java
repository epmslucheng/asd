package com.icss.ebu.ami.report.business.service;

import java.util.List;
import java.util.Map;

import com.icss.ebu.ami.commons.bean.vo.Organization;
import com.icss.ebu.ami.commons.pagePlugin.Page;
import com.icss.ebu.ami.report.business.result.OrgTree;
import com.icss.ebu.ami.report.system.model.User;

/**
 * @description：部门管理
 * @author：zhixuan.wang
 * @date：2015/10/1 14:51
 */
public interface OrganizationService
{
    /**
     * 查询部门资源树(用户管理)
     *
     * @param id
     * @return
     */
    List <OrgTree> findTreeByUser (String id);
    
    /**
     * 根据类型查询部门资源树
     *
     * @return
     */
    List <OrgTree> findTreeByType (User user, String type);
    
    /**
     * 根据id查找部门
     *
     * @param id
     * @return
     */
    Organization findOrganizationById (String id);
    
    int querySubOrgCountOfPid (String id);
    
    /**
     * 查询一级供电单位最大ID
     * 
     * @return 供电单位ID
     */
    String queryRootOrgMaxID ();
    
    /**
     * 查询子供电单位最大编号
     * 
     * @param org
     * @return 子供电单位最大编号
     */
    String querySubOrgMaxIdOfPidAndType (Organization org);
    
    /**
     * 根据供电单位查找部门
     *
     * @param orgNo
     *            供电单位编号
     * @param state
     *            节点状态
     * @return
     */
    List <OrgTree> findDeptTreeByOrg (String orgNo, String state);
    
    /**
     * 删除供电单位时判断是否有电网对象
     *
     * @param orgNo
     *            供电单位编号
     */
    int queryObjByOrgNo (String orgNo);
    
    /**
     * 删除供电单位时判断是否有资产设备
     *
     * @param orgNo
     *            供电单位编号
     */
    int queryAssetByOrgNo (String orgNo);
    
    /**
     * 查询供电单位下的居民用户和非居民用户的数量
     * 
     * @param orgNo
     *            供电单位编号
     * @return
     */
    int queryConsCountByOrgNo (String orgNo);
    
    /**
     * 查询供电单位
     *
     *
     */
    List <Organization> queryOrgTreeGrid (Organization organization);
    
    /**
     * 查询部门
     *
     *
     */
    List <Organization> queryDeptTreeGrid (Organization organization);
    
    /**
     * 根据pid查询子供电单位
     *
     *
     */
    List <Organization> findOrganizationAllByPid (Organization organization);
    
    /**
     * 弹框选择供电单位列表
     *
     *
     */
    List <Organization> treeOrgChoose (User user, String type);
    
    /**
     * 弹框选择供电单位列表(所有单位)
     *
     *
     */
    List <Organization> treeOrgChooseAll (User user, String type);
    
    /**
     * 根据组织标识查询供电单位
     *
     * @param ids
     * @return
     */
    List <Organization> findOrganizationByIds (String ids);
    
    /**
     * 查询一级供电单位并且只按照id排序
     * 
     */
    List <Organization> findRootOrgOrderById (Organization organization);
    
    /**
     * 根据pid查询子供电单位并且只按照id排序
     *
     *
     */
    List <Organization> findSubOrgOrderById (Organization organization);
    
    /**
     * 查询供电单位
     *
     *
     */
    List <Organization> findOrganization (Organization organization);
    
    /**
     * 查询部门资源树(发送) 只查询当前供电单位和底下部门
     *
     * @param id
     * @return
     */
    List <OrgTree> findOnlyOrgOrDeptTreeByUser (String id);
    
    Organization findOrganizationBySubId (String id);
    
    /**
     * 根据机构和当前登录用户查询上一级单位 数据分析上钻使用
     * 
     * @param orgId
     */
    Map <String, Object> findParentOrgById (Map <String, Object> map);
    
    Object findDeptAndOrg (User user);
    
    List <Organization> treeOrgAndDeptAll ();
    
    /**
     * 部门列表
     *
     * @param page
     */
    Page <Organization> findDeptsByPage (Page <Organization> page);
    
    /**
     *  根据单位名称查找单位
     */
    Organization findOrganizationByName (String name);
    
    Organization findMapOrganizationById (String id);
    
    /**
     * 查询部门资源树(用户管理)
     *
     * @param id
     * @return
     */
    List <OrgTree> findDeptTreeByChild (String id);
    
    /**
     * 搜索节点
     * @param content 搜索内容
     * @return List
     */
    List <OrgTree> findNode (Map <String, Object> map);
    
}
