package com.icss.ebu.ami.report.business.mapper;

import java.util.List;

import com.icss.ebu.ami.commons.pagePlugin.Page;
import com.icss.ebu.ami.report.business.model.ReportDesign;

public interface ReportMapper
{
    List <ReportDesign> queryReportDesignList (Page <ReportDesign> page);
    
    List <ReportDesign> queryReportDesignById (String id);
}
