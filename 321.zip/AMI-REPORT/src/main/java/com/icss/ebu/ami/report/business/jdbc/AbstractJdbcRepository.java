package com.icss.ebu.ami.report.business.jdbc;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

public abstract class AbstractJdbcRepository implements Repository
{
    @Autowired
    protected JdbcTemplate jdbcTemplate;
}
