package com.icss.ebu.ami.report.business.mapper;

import java.util.List;

import com.icss.ebu.ami.commons.pagePlugin.Page;
import com.icss.ebu.ami.report.business.model.CubeBean;
import com.icss.ebu.ami.report.business.model.CubeTable;
import com.icss.ebu.ami.report.business.model.DataSourceTable;
import com.icss.ebu.ami.report.business.model.DataSourceTableFiled;
import com.icss.ebu.ami.report.business.model.Table;
import com.icss.ebu.ami.report.business.model.TableField;

public interface CubeMapper
{
    List <CubeBean> getAllCube ();
    
    List <CubeBean> getAllCubeByUserId (String userId);
    
    List <CubeBean> getCubeByDsId (String cnnid);
    
    List <CubeBean> getCubeList (Page <CubeBean> page);
    
    List <DataSourceTable> getCubeTableNameById (String id);
    
    Integer delCubeTableRel (String cubeId);
    
    CubeBean getCubeById (String id);
    
    Integer delCubeById (String id);
    
    Integer addCube (CubeBean cube);
    
    Integer addCubeTable (List <CubeTable> cubeTable);
    
    Integer updateCube (CubeBean cube);
    
    List <DataSourceTableFiled> getTableTreeByTable (DataSourceTable dataSourceTable);
    
    Integer updateTableFiledAlias (DataSourceTableFiled dstf);
    
    List <CubeBean> getCubeByDsIdAndUser (CubeBean cube);
    
    //根据数据源id和cubeName查立方  数据集用
    CubeBean getCubeByDsIdAndCubeName (CubeBean cube);
    
    List <Table> getTablesByCubeId (String cubeId);
    
    List <TableField> getFieldsByTable (Table table);
}