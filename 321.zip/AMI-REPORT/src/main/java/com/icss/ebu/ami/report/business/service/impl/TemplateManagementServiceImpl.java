package com.icss.ebu.ami.report.business.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.icss.ebu.ami.commons.pagePlugin.Page;
import com.icss.ebu.ami.commons.util.I18nUtils;
import com.icss.ebu.ami.commons.util.ServiceUtils;
import com.icss.ebu.ami.report.business.mapper.TemplateManagementMapper;
import com.icss.ebu.ami.report.business.model.Template;
import com.icss.ebu.ami.report.business.service.TemplateManagementService;
import com.icss.ebu.ami.report.system.model.User;

/** 
* @author  zhangkaining 
* @date 2017年10月23日 下午3:46:13 
* @version 1.0   
*/
@Service
public class TemplateManagementServiceImpl implements TemplateManagementService
{
    
    @Autowired
    private TemplateManagementMapper templateManagementMapper;
    
    @Override
    public Page <Template> queryTemplateList (Page <Template> page)
    {
        
        List <Template> list = templateManagementMapper.queryTemplateListByPage (page);
        page.setResults (list);
        return page;
    }
    
    @Override
    public Template selectTemplateById (String tmpid)
    {
        
        return templateManagementMapper.selectTemplateById (tmpid);
        
    }
    
    @Override
    public Template selectTemplateByName (String tmpname)
    {
        
        return templateManagementMapper.selectTemplateByName (tmpname);
        
    }
    
    @Override
    public int insert (Template template)
    {
        
        return templateManagementMapper.insert (template);
        
    }
    
    @Override
    public List <Template> queryTemplateList (User user)
    {
        
        return templateManagementMapper.queryTemplateList (user);
    }
    
    @Override
    public int delete (String tmpid)
    {
        
        return templateManagementMapper.delete (tmpid);
    }
    
    @Override
    public void update (Template template)
    {
        
        templateManagementMapper.update (template);
    }
    
    @Override
    public Template selectTemplateByFile (String tmpfile)
    {
        
        return templateManagementMapper.selectTemplateByFile (tmpfile);
        
    }
    
    @Override
    public Page <Template> queryTempDesignListByPage (Page <Template> page)
    {
        List <Template> list = templateManagementMapper.queryTempDesignListByPage (page);
        page.setResults (list);
        return page;
    }
    
    @Override
    public List <Template> findAll ()
    {
        return templateManagementMapper.findAll ();
    }
    
    @Override
    public List <String> selectFileIdByTmpid (String tmpid)
    {
        return templateManagementMapper.selectFileIdByTmpid (tmpid);
    }
    
    @Override
    public List <String> selectTaskIdByTmpid (String tmpid)
    {
        return templateManagementMapper.selectTaskIdByTmpid (tmpid);
    }
    
    @Override
    public Template selectTemplateByKey (String tmpkey)
    {
        return templateManagementMapper.selectTemplateByKey (tmpkey);
    }
    
    @Override
    public String analyseAddContent (Template template)
    {
        if (template == null)
        {
            return "template is empty";
        }
        StringBuilder addSb = new StringBuilder ();
        ServiceUtils.addPropContent (I18nUtils.getI18nMsg ("ami.template.name"), template.getTmpname (), addSb);
        ServiceUtils.addPropContent (I18nUtils.getI18nMsg ("ami.template.type"), template.getReporttype (), addSb);
        ServiceUtils.addPropContent (I18nUtils.getI18nMsg ("ami.template.key"), template.getTmpkey (), addSb);
        ServiceUtils.addPropContent (I18nUtils.getI18nMsg ("ami.template.file"), template.getTmpfilename (), addSb);
        ServiceUtils.addPropContent (I18nUtils.getI18nMsg ("ami.template.desc"), template.getTmpdesc (), addSb);
        if (addSb.length () > 1)
        {
            addSb.setLength (addSb.length () - 1);
        }
        return addSb.toString ();
    }
    
    @Override
    public String analyseEditContent (Template oldtemplate, Template template)
    {
        if (oldtemplate == null)
        {
            return "old template is empty";
        }
        StringBuilder updateSb = new StringBuilder ();
        ServiceUtils.compareChange (I18nUtils.getI18nMsg ("ami.template.name"), oldtemplate.getTmpname (), template.getTmpname (),
            updateSb);
        ServiceUtils.compareChange (I18nUtils.getI18nMsg ("ami.template.type"), oldtemplate.getReporttype (),
            template.getReporttype (), updateSb);
        ServiceUtils.compareChange (I18nUtils.getI18nMsg ("ami.template.key"), oldtemplate.getTmpkey (), template.getTmpkey (),
            updateSb);
        ServiceUtils.compareChange (I18nUtils.getI18nMsg ("ami.template.file"), oldtemplate.getTmpfilename (),
            template.getTmpfilename (), updateSb);
        ServiceUtils.compareChange (I18nUtils.getI18nMsg ("ami.template.desc"), oldtemplate.getTmpdesc (), template.getTmpdesc (),
            updateSb);
        
        if (updateSb.length () > 1)
        {
            updateSb.setLength (updateSb.length () - 1);
        }
        return updateSb.toString ();
    }
    
    @Override
    public String analyseDelContent (Template oldtemplate)
    {
        if (oldtemplate == null)
        {
            return "oldtemplate is empty";
        }
        StringBuilder delSb = new StringBuilder ();
        ServiceUtils.addPropContent (I18nUtils.getI18nMsg ("ami.template.name"), oldtemplate.getTmpname (), delSb);
        if (delSb.length () > 1)
        {
            delSb.setLength (delSb.length () - 1);
        }
        return delSb.toString ();
    }

    @Override
    public List<Template> queryListByVo(Template template) {
        return templateManagementMapper.queryListByVo(template);
    }
}
