package com.icss.ebu.ami.report.business.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.icss.ebu.ami.report.business.mapper.ReportDataPositionMapper;
import com.icss.ebu.ami.report.business.model.ReportDataPosition;
import com.icss.ebu.ami.report.business.service.ReportDataPositionService;

/** 
* @author  zhangkaining 
* @date 2017年11月1日 下午2:41:16 
* @version 1.0   
*/
@Service
public class ReportDataPositionServiceImpl implements ReportDataPositionService {

	@Autowired
	private ReportDataPositionMapper reportDataPositionMapper;
	
	@Override
	public List<ReportDataPosition> queryListByTmpId(String tmpid) {
		return reportDataPositionMapper.queryListByTmpId(tmpid);
	}

	@Override
	public int deleteByTmpId(String tmpid) {
		return reportDataPositionMapper.deleteByTmpId(tmpid);
	}

	@Override
	public int insert(ReportDataPosition reportDataPosition) {
		return reportDataPositionMapper.insert(reportDataPosition);
	}

	@Override
	public int insertList(List<ReportDataPosition> list) {
		return reportDataPositionMapper.insertList(list);
	}

}
