package com.icss.ebu.ami.report.business.model;

import java.io.Serializable;

/** 
* @author  zhangkaining 
* @date 2017年10月23日 下午3:31:10 
* @version 1.0   
*/
public class Template implements Serializable
{
    
    /**
     * 
     */
    private static final long serialVersionUID = 5735622005186734726L;
    
    /**
     * 模板ID
     */
    private String tmpid;
    
    /**
     * 模板名称
     */
    private String tmpname;
    
    /**
     * 模板路径
     */
    private String tmpfile;
    
    /**
     * 模板标识
     */
    private String tmpkey;
    
    /**
     * 模板说明
     */
    private String tmpdesc;
    
    /**
     * 报表类型
     */
    private String reporttype;
    
    /**
     * 模板名称
     */
    private String tmpfilename;
    
    private String startTime;
    
    private String endTime;
    
    private String currentTime;
    
    private String tempPath;
    
    private String reportId;
    
    private String userId;
    
    private String treeMap;
    
    public String getTreeMap() {
		return treeMap;
	}

	public void setTreeMap(String treeMap) {
		this.treeMap = treeMap;
	}

	public String getTmpfilename ()
    {
        return tmpfilename;
    }
    
    public void setTmpfilename (String tmpfilename)
    {
        this.tmpfilename = tmpfilename;
    }
    
    public String getTmpid ()
    {
        return tmpid;
    }
    
    public void setTmpid (String tmpid)
    {
        this.tmpid = tmpid;
    }
    
    public String getTmpname ()
    {
        return tmpname;
    }
    
    public void setTmpname (String tmpname)
    {
        this.tmpname = tmpname;
    }
    
    public String getTmpfile ()
    {
        return tmpfile;
    }
    
    public void setTmpfile (String tmpfile)
    {
        this.tmpfile = tmpfile;
    }
    
    public String getTmpkey ()
    {
        return tmpkey;
    }
    
    public void setTmpkey (String tmpkey)
    {
        this.tmpkey = tmpkey;
    }
    
    public String getTmpdesc ()
    {
        return tmpdesc;
    }
    
    public void setTmpdesc (String tmpdesc)
    {
        this.tmpdesc = tmpdesc;
    }
    
    public String getReporttype ()
    {
        return reporttype;
    }
    
    public void setReporttype (String reporttype)
    {
        this.reporttype = reporttype;
    }
    
    public String getStartTime ()
    {
        return startTime;
    }
    
    public void setStartTime (String startTime)
    {
        this.startTime = startTime;
    }
    
    public String getEndTime ()
    {
        return endTime;
    }
    
    public void setEndTime (String endTime)
    {
        this.endTime = endTime;
    }
    
    public String getTempPath ()
    {
        return tempPath;
    }
    
    public void setTempPath (String tempPath)
    {
        this.tempPath = tempPath;
    }
    
    public String getReportId ()
    {
        return reportId;
    }
    
    public void setReportId (String reportId)
    {
        this.reportId = reportId;
    }
    
    public String getCurrentTime ()
    {
        return currentTime;
    }
    
    public void setCurrentTime (String currentTime)
    {
        this.currentTime = currentTime;
    }
    
    public String getUserId ()
    {
        return userId;
    }
    
    public void setUserId (String userId)
    {
        this.userId = userId;
    }
    
}
