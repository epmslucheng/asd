package com.icss.ebu.ami.report.business.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringEscapeUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.icss.ebu.ami.commons.aspect.RedisCacheUtil;
import com.icss.ebu.ami.commons.bean.vo.Organization;
import com.icss.ebu.ami.commons.pagePlugin.Page;
import com.icss.ebu.ami.report.business.common.util.ConfigHolder;
import com.icss.ebu.ami.report.business.mapper.OrganizationMapper;
import com.icss.ebu.ami.report.business.result.OrgTree;
import com.icss.ebu.ami.report.business.service.OrganizationService;
import com.icss.ebu.ami.report.system.model.User;

@Service
public class OrganizationServiceImpl implements OrganizationService
{
    
    @Autowired
    private OrganizationMapper organizationMapper;
    
    private static final int SYS_EXP = -1;
    
    private RedisCacheUtil redisCacheUtil = new RedisCacheUtil ();
    
    private static final String organization = ConfigHolder.getCfg ("initThread_organization");
    
    @Override
    public List <Organization> queryOrgTreeGrid (Organization organization)
    {
        return organizationMapper.queryOrgTreeGrid (organization);
    }
    
    @Override
    public List <Organization> queryDeptTreeGrid (Organization organization)
    {
        return organizationMapper.queryDeptTreeGrid (organization);
    }
    
    @Override
    public List <OrgTree> findTreeByUser (String id)
    {
        Organization organization = new Organization ();
        organization.setOrgNo (id);
        List <Organization> organizationSonList = organizationMapper.findOrganizationByOrgNoAndType (organization);
        List <OrgTree> trees = generateOrgTee (organizationSonList);
        return trees;
    }
    
    /**
     * 将 部门/供电单位 转换成树结构
     *
     * @param list
     *            部门/供电单位列表
     * @return 树结构
     */
    private List <OrgTree> generateOrgTee (List <Organization> list)
    {
        List <OrgTree> trees = new ArrayList <OrgTree> ();
        
        if (CollectionUtils.isNotEmpty (list))
        {
            OrgTree tree = null;
            for (Organization org : list)
            {
                tree = new OrgTree ();
                tree.setId (org.getId ());
                tree.setPid (org.getPid ());
                tree.setText (StringEscapeUtils.unescapeHtml4 (org.getName ()));
                tree.setType (org.getType ());
                tree.setOrgNo (org.getOrgNo ());
                trees.add (tree);
            }
        }
        return trees;
    }
    
    @Override
    public List <OrgTree> findTreeByType (User user, String type)
    {
        Organization organization = new Organization ();
        organization.setOrgNo (user.getpOrganizationId ());
        organization.setType (type);
        
        List <Organization> organizationSonList = organizationMapper.findOrganizationByOrgNoAndType (organization);
        List <OrgTree> trees = generateOrgTee (organizationSonList);
        
        return trees;
    }
    
    @Override
    public Organization findOrganizationById (String id)
    {
        return organizationMapper.findOrganizationById (id);
    }
    
    @Override
    public int querySubOrgCountOfPid (String id)
    {
        return organizationMapper.querySubOrgCountOfPid (id);
    }
    
    @Override
    public String queryRootOrgMaxID ()
    {
        return organizationMapper.queryRootOrgMaxID ();
    }
    
    @Override
    public String querySubOrgMaxIdOfPidAndType (Organization org)
    {
        return organizationMapper.querySubOrgMaxIdOfPidAndType (org);
    }
    
    @Override
    public List <OrgTree> findDeptTreeByOrg (String orgNo, String state)
    {
        Organization organization = new Organization ();
        organization.setOrgNo (orgNo);
        // organization.setType(Organization.TYPE_DEPT);
        List <Organization> organizationSonList = organizationMapper.findOrganizationByOrgNoAndType (organization);
        List <OrgTree> trees = generateOrgTee (organizationSonList);
        return trees;
    }
    
    @Override
    public int queryObjByOrgNo (String orgNo)
    {
        int rt = 0;
        List <Integer> list = new ArrayList <> ();
        
        list.add (organizationMapper.countSubsByOrgNo (orgNo));
        list.add (organizationMapper.countMtranByOrgNo (orgNo));
        list.add (organizationMapper.countMlineByOrgNo (orgNo));
        list.add (organizationMapper.countLineByOrgNo (orgNo));
        list.add (organizationMapper.countTgByOrgNo (orgNo));
        
        // 找出最大的记录数
        for (Integer count : list)
        {
            rt = count > rt ? count : rt;
        }
        
        return rt;
    }
    
    @Override
    public int queryAssetByOrgNo (String orgNo)
    {
        int rt = 0;
        List <Integer> list = new ArrayList <> ();
        list.add (organizationMapper.countMeterByOrgNo (orgNo));
        list.add (organizationMapper.countItByOrgNo (orgNo));
        list.add (organizationMapper.countEquipByOrgNo (orgNo));
        list.add (organizationMapper.countSealByOrgNo (orgNo));
        
        // 找出最大的记录数
        for (Integer count : list)
        {
            rt = count > rt ? count : rt;
        }
        
        return rt;
    }
    
    @Override
    public int queryConsCountByOrgNo (String orgNo)
    {
        return organizationMapper.countConsNumberByOrgNo (orgNo);
    }
    
    @Override
    public List <Organization> findOrganizationAllByPid (Organization organization)
    {
        return organizationMapper.findOrganizationAllByPid (organization);
    }
    
    @Override
    public List <Organization> findOrganizationByIds (String ids)
    {
        return organizationMapper.findOrganizationByIds (ids);
    }
    
    @Override
    public List <Organization> findRootOrgOrderById (Organization organization)
    {
        return organizationMapper.findRootOrgOrderById (organization);
    }
    
    @Override
    public List <Organization> findSubOrgOrderById (Organization organization)
    {
        return organizationMapper.findSubOrgOrderById (organization);
    }
    
    @Override
    public List <Organization> treeOrgChoose (User user, String type)
    {
        Organization organization = new Organization ();
        organization.setId (user.getpOrganizationId ());
        organization.setType (type);
        return organizationMapper.treeOrgChoose (organization);
    }
    
    @Override
    public List <Organization> treeOrgChooseAll (User user, String type)
    {
        Organization organization = new Organization ();
        String orgId = user.getpOrganizationId ();
        String L = orgId.substring (0, 2).trim ();
        organization.setId (L);
        organization.setType (type);
        return organizationMapper.treeOrgChoose (organization);
    }
    
    @Override
    public List <Organization> findOrganization (Organization organization)
    {
        return organizationMapper.findOrganization (organization);
    }
    
    @Override
    public List <OrgTree> findOnlyOrgOrDeptTreeByUser (String id)
    {
        Organization organization = new Organization ();
        organization.setOrgNo (id);
        List <Organization> organizationSonList = organizationMapper.findOnlyOrganizationByOrgNoAndType (organization);
        List <OrgTree> trees = generateOrgTee (organizationSonList);
        
        return trees;
    }
    
    @Override
    public Organization findOrganizationBySubId (String id)
    {
        return organizationMapper.findOrganizationBySubId (id);
    }
    
    @Override
    public Map <String, Object> findParentOrgById (Map <String, Object> map)
    {
        return organizationMapper.findParentOrgById (map);
    }
    
    @Override
    public List <Organization> findDeptAndOrg (User user)
    {
        Organization organization = new Organization ();
        organization.setId (user.getpOrganizationId ());
        return organizationMapper.findDeptAndOrg (organization);
    }
    
    @Override
    public List <Organization> treeOrgAndDeptAll ()
    {
        return organizationMapper.treeOrgAndDeptAll ();
    }
    
    @Override
    public Page <Organization> findDeptsByPage (Page <Organization> page)
    {
        page.setResults (organizationMapper.findDeptsByPage (page));
        return page;
    }
    
    @Override
    public Organization findOrganizationByName (String name)
    {
        List <Organization> list = organizationMapper.findOrganizationByName (name);
        Organization org = null;
        if (list != null && !list.isEmpty ())
        {
            org = list.get (0);
        }
        
        return org;
    }
    
    @Override
    public Organization findMapOrganizationById (String id)
    {
        return organizationMapper.findMapOrganizationById (id);
    }
    
    @Override
    public List <OrgTree> findDeptTreeByChild (String id)
    {
        List <Organization> organizationSonList = organizationMapper.findDeptTreeByChild (id);
        List <OrgTree> trees = generateOrgTee (organizationSonList);
        return trees;
    }
    
    @Override
    public List <OrgTree> findNode (Map <String, Object> map)
    {
        return organizationMapper.findNode (map);
    }
    
}