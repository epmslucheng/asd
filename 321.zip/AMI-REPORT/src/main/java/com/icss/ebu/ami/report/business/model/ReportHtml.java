package com.icss.ebu.ami.report.business.model;

import java.io.Serializable;

/**
 * 报表相关html实体类
 * @author lvzhengtao
 *
 */
public class ReportHtml implements Serializable
{
    
    /**
     * 
     */
    private static final long serialVersionUID = 3196796023930284409L;
    
    private String id;
    
    private String sheetName;
    
    /**
     * 报表类型-0：模板类，1-报表类
     */
    private String htmlType;
    
    private String htmlPath;
    
    private String htmlName;
    
    private String downPath;
    
    private String showName;
    
    public String getId ()
    {
        return id;
    }
    
    public void setId (String id)
    {
        this.id = id;
    }
    
    public String getHtmlType ()
    {
        return htmlType;
    }
    
    public void setHtmlType (String htmlType)
    {
        this.htmlType = htmlType;
    }
    
    public String getSheetName ()
    {
        return sheetName;
    }
    
    public void setSheetName (String sheetName)
    {
        this.sheetName = sheetName;
    }
    
    public String getHtmlPath ()
    {
        return htmlPath;
    }
    
    public void setHtmlPath (String htmlPath)
    {
        this.htmlPath = htmlPath;
    }
    
    public String getHtmlName ()
    {
        return htmlName;
    }
    
    public void setHtmlName (String htmlName)
    {
        this.htmlName = htmlName;
    }
    
    public String getDownPath ()
    {
        return downPath;
    }
    
    public void setDownPath (String downPath)
    {
        this.downPath = downPath;
    }
    
    public String getShowName ()
    {
        return showName;
    }
    
    public void setShowName (String showName)
    {
        this.showName = showName;
    }
    
}
