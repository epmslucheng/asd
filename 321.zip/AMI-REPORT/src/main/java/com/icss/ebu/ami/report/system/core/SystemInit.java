package com.icss.ebu.ami.report.system.core;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Timer;
import java.util.TimerTask;

import javax.servlet.ServletContextEvent;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.context.ContextLoaderListener;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.icss.ebu.ami.commons.aspect.MyJedis;
import com.icss.ebu.ami.commons.constants.GeneralConstant;
import com.icss.ebu.ami.commons.util.AesKeyUtils;
import com.icss.ebu.ami.commons.util.ObjectUtils;
import com.icss.ebu.ami.report.business.common.util.BeanProvider;
import com.icss.ebu.ami.report.business.common.util.ConfigHolder;
import com.icss.ebu.ami.report.business.common.util.LogRenderUtils;
import com.icss.ebu.ami.report.business.service.LogService;
import com.icss.ebu.ami.report.business.service.SystemParameterService;
import com.icss.ebu.ami.report.system.core.task.InitDataSourceThread;
import com.icss.ebu.ami.report.system.core.task.ReportDeleteThread;
import com.icss.ebu.ami.report.system.core.task.TaskScheduleManager;
import com.icss.ebu.ami.report.system.model.SystemParameter;

/**
 * <一句话功能简述> <功能详细描述>
 *
 * @author xugangfeng
 * @version [版本号, 2016-11-11]
 * @see [相关类/方法]
 * @since [产品/模块版本]
 */
public class SystemInit extends ContextLoaderListener
{
    
    private static final Logger LOGGER = LoggerFactory.getLogger(SystemInit.class);
    
    private static Logger sysLogger = LoggerFactory.getLogger("sysLoger");
    
    private List<Timer> timerList = new ArrayList<Timer>();
    
    private static final String CONFIG_TIMER_PERIOD = "timertask_configration";
    
    private static final String SCAN_FLOW_INTERVAL_S = "SCAN_FLOW_INTERVAL_S";
    
    /**
     * WebApplicationContext对象
     */
    private static WebApplicationContext ctx = null;
    
    private static void setCtx(WebApplicationContext context)
    {
        ctx = context;
    }
    
    public void contextInitialized(ServletContextEvent contextEvent)
    {
        LOGGER.info("System initializing...");
        sysLogger.info("System initializing...");
        try
        {
            super.contextInitialized(contextEvent);
            setCtx(WebApplicationContextUtils.getRequiredWebApplicationContext(contextEvent.getServletContext()));
            BeanProvider.initialize(ctx);
            LOGGER.info("Load spring configurations successful.");
            sysLogger.info("Load spring configurations successful.");
            // 初始化缓存
            LOGGER.info("Start to load init data...");
            sysLogger.info("Start to load init data...");
            
            // 初始化
            init();
            
            LOGGER.info("TaskScheduleManager init begin.");
            TaskScheduleManager taskScheduleManager = (TaskScheduleManager) getBean("taskScheduleManager");
            taskScheduleManager.init();
        }
        catch (Exception e)
        {
            LOGGER.error("Initialized error", e);
        }
    }
    
    /**
     * 根据对象名获取对象
     *
     * @param name
     *            对象名
     * @return 返回对象信息
     * @author xugangfeng
     * @see [类、类#方法、类#成员]
     */
    public static Object getBean(String name)
    {
        return ctx.getBean(name);
    }
    
    /**
     * {@inheritDoc}
     */
    public void contextDestroyed(ServletContextEvent contextEvent)
    {
        sysLogger.info("System destroyed...");
        destroy();
        super.contextDestroyed(contextEvent);
    }
    
    /**
     * 获得当前系统的绝对路径
     *
     * @return 当前系统的绝对路径
     * @author xugangfeng
     * @see [类、类#方法、类#成员]
     */
    public static String getServletContextRealPath()
    {
        return getWebApplicationContext().getServletContext().getRealPath(GeneralConstant.BLANK);
    }
    
    /**
     * 返回WebApplicationContext对象
     *
     * @return WebApplicationContext - WebApplicationContext
     * @author xugangfeng
     * @see [类、类#方法、类#成员]
     */
    public static WebApplicationContext getWebApplicationContext()
    {
        return ctx;
    }
    
    private void loadThread(String name)
    {
        Runnable dicInit = (Runnable) (ctx.getBean(name));
        Map<String, String> param = ObjectUtils.parseParam("Thread", name);
        if(dicInit != null)
        {
            // 加载数据字典加载线程
            Thread initThread = new Thread(dicInit);
            initThread.setName(name);
            initThread.setDaemon(true);
            initThread.start();
            LOGGER.info("Load data thread started.", param);
        }
        else
        {
            LOGGER.error("Can't find load data thread.", param);
        }
    }
    
    /**
     * 初始化
     */
    private void init()
    {
        // 初始化系统配置项
        try
        {
            getConfiguration("configuration.properties");
            getConfiguration("redisConfig.properties");
            
            SystemParameterService ser = (SystemParameterService) getBean("systemParameterService");
            if(ser != null)
            {
                List<SystemParameter> list = ser.querySystemParameterAll();
                if(list != null && list.size() > 0)
                {
                    for(SystemParameter s : list)
                    {
                        ConfigHolder.setCfg(s.getName(), s.getValue());
                    }
                }
            }
            
        }
        catch (Exception e)
        {
            LOGGER.error("Initialized configuration。properties Fail.", e);
        }
        
        try
        {
            String ipAndPorts = ConfigHolder.getCfg("redisCluster");
            String[] ipAndPortArr = ipAndPorts.split(",");
            String requirepass = AesKeyUtils.decrypt(ConfigHolder.getCfg("REDIS_PASSWORD"), ConfigHolder.getCfg("REDIS_PWD_KEY"));
            MyJedis.init(ipAndPortArr, requirepass);
        }
        catch (Exception e)
        {
            //redis 异常
            LOGGER.error("Redis Error!!!", e);
            if(e.getMessage().contains("All"))
            {
                //所有redis都配置错误或者redis连接不上
                LOGGER.error("All Redis Error!!!", e);
                //发送告警短信
            }
        }
        
        // 日志描述文件
        LogRenderUtils.initLogDescMap();
        initTimer2();
        
        LogService licThread = (LogService) getBean("logServiceImpl");
        licThread.initLogTask();
    }
    
    /**
     * 读取系统配置文件 并缓存到系统内存中去
     * @throws IOException 
     */
    private void getConfiguration(String fileName) throws IOException
    {
        InputStream inputStream = null;
        try
        {
            Properties p = new Properties();
            inputStream = this.getClass().getClassLoader().getResourceAsStream(fileName);
            p.load(inputStream);
            for(Entry<Object, Object> entry : p.entrySet())
            {
                ConfigHolder.setCfg((String) entry.getKey(), (String) entry.getValue());
            }
        }
        finally
        {
            IOUtils.closeQuietly(inputStream);
        }
    }
    
    /**
     * 定时器
     */
    private void initTimer2()
    {
        long period = NumberUtils.toLong(ConfigHolder.getCfg(CONFIG_TIMER_PERIOD));
        Timer synTimer = new Timer();
        synTimer.schedule(new TimerTask()
        {
            public void run()
            {
                // 初始化系统配置项
                try
                {
                    getConfiguration("configuration.properties");
                }
                catch (Exception e)
                {
                    LOGGER.error("initTimer2 Initialized configuration。properties Fail.", e);
                }
            }
        }, 0, period);
        
        //多数据源
        long dbCheckTime = 0L;
        try
        {
            dbCheckTime = NumberUtils.toLong(ConfigHolder.getCfg("timertask_configration"));
        }
        catch (Exception e)
        {
            dbCheckTime = 12 * 60 * 60 * 1000L;
        }
        try
        {
            InitDataSourceThread thread = (InitDataSourceThread) getBean("initDataSourceThread");
            synTimer.schedule(thread, 0, dbCheckTime);
        }
        catch (Exception e)
        {
            LOGGER.error("LicenseThread Initialized Fail.", e);
        }
        //多数据源
        long deleteTime = 0L;
        try
        {
            deleteTime = NumberUtils.toLong(ConfigHolder.getCfg("deletetimertask_configration"));
        }
        catch (Exception e)
        {
            deleteTime = 12 * 60 * 60 * 1000L;
        }
        try
        {
            ReportDeleteThread rthread = (ReportDeleteThread) getBean("reportDeleteThread");
            synTimer.schedule(rthread, 0, deleteTime);
        }
        catch (Exception e)
        {
            LOGGER.error("ReportDeleteThread Initialized Fail.", e);
        }
        
        timerList.add(synTimer);
    }
    
    /**
     * 定时器销毁
     */
    private void destroy()
    {
        for(Timer timer : timerList)
        {
            timer.cancel();
        }
    }
    
    /**
     * 当前0点时间戳
     * 
     * @return
     */
    public long getDayBegin()
    {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MINUTE, 3);
        cal.set(Calendar.MILLISECOND, 1);
        return cal.getTimeInMillis();
    }
}
