package com.icss.ebu.ami.report.business.model;

import java.io.Serializable;
import java.util.List;

/**
 * 立方实体类
 * @author xunan
 *
 */
public class CubeBean implements Serializable
{
    /**
     * 
     */
    private static final long serialVersionUID = 7655158823377290819L;
    
    //数据源id
    private String id;
    
    private String cnName;
    
    private String dbType;
    
    //立方id
    private String cubeId;
    
    private String cubeName;
    
    private String cubeDesc;
    
    //表名称
    private String tableId;
    
    //表名称
    private String tableName;
    
    //表名称集合
    private List <String> tableNames;
    
    //表实体集合
    private List <DataSourceTable> tableList;
    
    private List <DataSourceBean> dsList;
    
    private String name;
    
    private String pid;
    
    //用于查询
    private String userId;
    
    private boolean checked = false;
    
    private String leftIndex;
    
    private String rightIndex;
    
    private String targetItem;
    
    public boolean isChecked ()
    {
        return checked;
    }
    
    public void setChecked (boolean checked)
    {
        this.checked = checked;
    }
    
    public String getPid ()
    {
        return pid;
    }
    
    public void setPid (String pid)
    {
        this.pid = pid;
    }
    
    public String getName ()
    {
        return name;
    }
    
    public void setName (String name)
    {
        this.name = name;
    }
    
    public String getId ()
    {
        return id;
    }
    
    public void setId (String id)
    {
        this.id = id;
    }
    
    public String getCnName ()
    {
        return cnName;
    }
    
    public void setCnName (String cnName)
    {
        this.cnName = cnName;
    }
    
    public String getDbType ()
    {
        return dbType;
    }
    
    public void setDbType (String dbType)
    {
        this.dbType = dbType;
    }
    
    public String getCubeId ()
    {
        return cubeId;
    }
    
    public void setCubeId (String cubeId)
    {
        this.cubeId = cubeId;
    }
    
    public String getCubeName ()
    {
        return cubeName;
    }
    
    public void setCubeName (String cubeName)
    {
        this.cubeName = cubeName;
        this.name = cubeName;
    }
    
    public String getCubeDesc ()
    {
        return cubeDesc;
    }
    
    public void setCubeDesc (String cubeDesc)
    {
        this.cubeDesc = cubeDesc;
    }
    
    public String getTableId ()
    {
        return tableId;
    }
    
    public void setTableId (String tableId)
    {
        this.tableId = tableId;
    }
    
    public String getTableName ()
    {
        return tableName;
    }
    
    public void setTableName (String tableName)
    {
        this.tableName = tableName;
    }
    
    public List <String> getTableNames ()
    {
        return tableNames;
    }
    
    public void setTableNames (List <String> tableNames)
    {
        this.tableNames = tableNames;
    }
    
    public List <DataSourceTable> getTableList ()
    {
        return tableList;
    }
    
    public void setTableList (List <DataSourceTable> tableList)
    {
        this.tableList = tableList;
    }
    
    public List <DataSourceBean> getDsList ()
    {
        return dsList;
    }
    
    public void setDsList (List <DataSourceBean> dsList)
    {
        this.dsList = dsList;
    }
    
    public String getUserId ()
    {
        return userId;
    }
    
    public void setUserId (String userId)
    {
        this.userId = userId;
    }
    
    public String getLeftIndex ()
    {
        return leftIndex;
    }
    
    public void setLeftIndex (String leftIndex)
    {
        this.leftIndex = leftIndex;
    }
    
    public String getTargetItem ()
    {
        return targetItem;
    }
    
    public void setTargetItem (String targetItem)
    {
        this.targetItem = targetItem;
    }
    
    public String getRightIndex ()
    {
        return rightIndex;
    }
    
    public void setRightIndex (String rightIndex)
    {
        this.rightIndex = rightIndex;
    }
    
}
