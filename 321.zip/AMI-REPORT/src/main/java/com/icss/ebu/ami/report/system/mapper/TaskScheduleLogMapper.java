package com.icss.ebu.ami.report.system.mapper;

import com.icss.ebu.ami.report.system.core.task.TaskScheduleLog;

/**
 * 任务日志操作，用来记录任务调用后的执行结果
 * @author Administrator
 *
 */
public interface TaskScheduleLogMapper
{
    /**
     * 对于任务的执行结果，记录到任务日志表中
     * @param log
     */
    public void add(TaskScheduleLog log);
    
//    /**
//     * 子任务调度日志记录
//     * @param log
//     */
//    public void addSubTaskSchLog(SubTaskSchLog log);

}
