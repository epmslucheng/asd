package com.icss.ebu.ami.report.system.core.task;

import java.util.concurrent.ConcurrentHashMap;

import com.alibaba.druid.pool.DruidDataSource;


/**
 * @date 2017.2.13
 * @version v1.0
 */
public final class DataSourceThreadCache
{
    
    // 主机状态集合
    private static ConcurrentHashMap <String, DruidDataSource> cache = new ConcurrentHashMap <String, DruidDataSource> ();
    
    private DataSourceThreadCache ()
    {
        
    }
    
    /**
     * 获取数据
     */
    public static DruidDataSource getCache (String key)
    {
        return cache.get (key);
    }
    
    /**
     * 获取数据
     */
    public static ConcurrentHashMap <String, DruidDataSource> getCache ()
    {
        return cache;
    }
    
    /**
     * 设置数据
     */
    public static void setCache (String key, DruidDataSource value)
    {
        cache.put (key, value);
    }
    
    //    /**
    //     * 获得主机状态集合
    //     * 
    //     * @param ipKey
    //     */
    //    public static String getRedisStatus (String ipKey)
    //    {
    //        return getCache (ipKey).getIsAlived ();
    //    }
    
    /**
     * 清空
     */
    public static void clear ()
    {
        cache.clear ();
    }
}