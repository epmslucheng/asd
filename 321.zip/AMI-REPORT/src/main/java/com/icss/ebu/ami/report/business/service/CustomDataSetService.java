package com.icss.ebu.ami.report.business.service;

import java.util.List;

import com.icss.ebu.ami.commons.pagePlugin.Page;
import com.icss.ebu.ami.report.business.model.DataSet;
import com.icss.ebu.ami.report.business.model.DataSourceTable;
import com.icss.ebu.ami.report.business.model.DataSourceTableFiled;
import com.icss.ebu.ami.report.business.model.Function;

public interface CustomDataSetService
{
    Page <DataSet> findCustomDataSets (Page <DataSet> page);
    
    int addDataSet (DataSet dataSet);
    
    int editDataSet (DataSet dataSet);
    
    int delete (DataSet dataSet);
    
    DataSet findCustomDataSetById (String id);
    
    List <DataSet> queryAll ();
    
    List <Function> findAllFunction ();
    
    int insetDataSetCols (List <DataSourceTableFiled> list);
    
    int deleteDataSetCols (DataSourceTable dsb);
    
    public String analyseAddContent (DataSet dataSet);
    
    public String analyseEditContent (DataSet oldDataSet, DataSet newdataSet);
    
    public String analyseDelContent (DataSet dataSet);
    
    public String analyseTestContent (DataSet dataSet);
}
