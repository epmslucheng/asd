package com.icss.ebu.ami.report.system.core.task;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.Callable;

/**
 * 二级任务调度任务
 * 
 * @author tfl
 *
 */
public class SubTaskCall implements Callable <Boolean>
{
    private Logger logger = LoggerFactory.getLogger (SubTaskCall.class);
    
    private Task task;
    
    private TaskScheduleManager taskScheduleManager;

    public SubTaskCall(Task task, TaskScheduleManager taskScheduleManager)
    {
        this.task = task;
        this.taskScheduleManager = taskScheduleManager;
    }
    
    @Override
    public Boolean call () throws Exception
    {
        boolean flag = true;
        Date bgnDate = Calendar.getInstance ().getTime ();
        try
        {
            if (!taskScheduleManager.checkTaskExist (task))
            {
                taskScheduleManager.runningTriggerByTask (task);
            }
            else if (taskScheduleManager.checkTaskModify (task))
            {
                taskScheduleManager.addOrUpdateTaskToCached (task);
                taskScheduleManager.removeTask (task.getTaskId ().toString (), TaskConstant.SCAN_TASK);
                taskScheduleManager.runningTriggerByTask (task);
            }
        }
        catch (Exception e)
        {
            flag = false;
            logger.error ("SubTaskCall: " + task.toString () + "schedule failure", e);
        }
        return flag;
    }
}
