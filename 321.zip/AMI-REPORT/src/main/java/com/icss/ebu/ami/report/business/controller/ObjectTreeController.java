package com.icss.ebu.ami.report.business.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.icss.ebu.ami.commons.pagePlugin.Page;
import com.icss.ebu.ami.commons.util.UUIDUtils;
import com.icss.ebu.ami.report.business.common.constant.CommonConstant;
import com.icss.ebu.ami.report.business.common.constant.ReportConstant;
import com.icss.ebu.ami.report.business.model.ObjectTreeBean;
import com.icss.ebu.ami.report.business.model.ObjectTreeNode;
import com.icss.ebu.ami.report.business.service.ObjectTreeService;
import com.icss.ebu.ami.report.system.model.User;

@Controller
@RequestMapping ("/objectTree")
public class ObjectTreeController extends BaseController
{
    private static final Logger LOGGER = LoggerFactory.getLogger (ObjectTreeController.class);
    
    @Autowired
    private ObjectTreeService objectTreeService;
    
    @RequestMapping (value = "/index")
    public String index (HttpServletRequest request, HttpServletResponse response)
    {
        return "/service/objectTree/objectTree";
    }
    
    @RequestMapping ("/query")
    @ResponseBody
    public Object query (HttpServletRequest request, ObjectTreeBean objectTreeBean)
    {
        User currentUser = getCurrentUser ();
        if (!ReportConstant.REPORT_USERID_ROOT.equals (currentUser.getId ()))
        {
            
            objectTreeBean.setUserId (currentUser.getId ());
        }
        
        Page <ObjectTreeBean> page = new Page <ObjectTreeBean> (objectTreeBean);
        page.setPageNo (NumberUtils.toInt (request.getParameter (CommonConstant.PAGE_PARAM_PAGE)));
        page.setPageSize (NumberUtils.toInt (request.getParameter (CommonConstant.PAGE_PARAM_ROWS)));
        page = objectTreeService.queryObjectTree (page);
        Map <String, Object> map = new HashMap <String, Object> ();
        map.put (CommonConstant.PAGE_RESULT_ROWS, page.getResults ());
        map.put (CommonConstant.PAGE_RESULT_TOTAL, page.getTotalRecord ());
        return map;
        
    }
    
    @RequestMapping ("/queryAll")
    @ResponseBody
    public Object queryAll (HttpServletRequest request)
    {
        Map <String, Object> result = new HashMap <String, Object> ();
        User currentUser = getCurrentUser ();
        ObjectTreeBean objectTreeBean = new ObjectTreeBean ();
        if (!ReportConstant.REPORT_USERID_ROOT.equals (currentUser.getId ()))
        {
            
            objectTreeBean.setUserId (currentUser.getId ());
        }
        List <ObjectTreeBean> list = objectTreeService.queryAllObjectTree (objectTreeBean);
        result.put ("objectTreeList", list);
        return renderSuccess (result);
        
    }
    
    /**
     * 新增页
     *
     * @param model
     * @param id
     * @return
     */
    @RequestMapping ("/addPage")
    public String addPage (Model model, HttpServletRequest request, HttpServletResponse response,
        @RequestBody ObjectTreeBean objectTreeBean)
    {
        return "/service/objectTree/objectTreeAdd";
    }
    
    @RequestMapping ("/save")
    @ResponseBody
    public Object save (HttpServletRequest request, HttpServletResponse response, @RequestBody ObjectTreeBean objectTreeBean)
    {
        
        try
        {
            objectTreeService.save (objectTreeBean);
        }
        catch (Exception e)
        {
            return renderSuccess ("error");
        }
        return renderSuccess ("success");
    }
    
    /**
     * 编辑页
     *
     * @param model
     * @param id
     * @return
     */
    @RequestMapping ("/editPage")
    public String editPage (Model model, HttpServletRequest request, HttpServletResponse response,
        @RequestBody ObjectTreeBean objectTreeBean)
    {
        return "/service/objectTree/objectTreeEdit";
    }
    
    @RequestMapping ("/edit")
    @ResponseBody
    public Object edit (HttpServletRequest request, HttpServletResponse response, @RequestBody ObjectTreeBean objectTreeBean)
    {
        
        try
        {
            objectTreeService.update (objectTreeBean);
        }
        catch (Exception e)
        {
            return renderSuccess ("error");
        }
        
        return renderSuccess ("success");
    }
    
    /**
     * 维护页
     *
     * @param model
     * @param id
     * @return
     */
    @RequestMapping ("/maintainPage")
    public String maintainPage (HttpServletRequest request, HttpServletResponse response,
        @RequestBody ObjectTreeBean objectTreeBean)
    {
        
        request.setAttribute ("objectTreeName", objectTreeBean);
        return "/service/objectTree/objectTreeMaintain";
    }
    
    @RequestMapping ("/getObjectTreeByObjectId")
    @ResponseBody
    public Object getObjectTreeByObjectId (HttpServletRequest request, HttpServletResponse response,
        @RequestBody ObjectTreeBean objectTreeBean)
    {
        List <Object> list = new ArrayList <Object> ();
        Map <String, Object> result = new HashMap <String, Object> ();
        
        List <ObjectTreeNode> rootNodeList = objectTreeService.queryTreeNodeList (objectTreeBean);
        list.addAll (rootNodeList);
        result.put ("list", list);
        return renderSuccess (result);
    }
    
    /**
     * 新增根节点
     *
     * @param model
     * @param id
     * @return
     */
    @RequestMapping ("/addRootNodePage")
    public String addRootNodePage (Model model, HttpServletRequest request, HttpServletResponse response,
        @RequestBody ObjectTreeNode objectTreeNode)
    {
        return "/service/objectTree/objectTreeRootNode";
    }
    
    @RequestMapping ("/saveRootNode")
    @ResponseBody
    public Object saveRootNode (HttpServletRequest request, HttpServletResponse response,
        @RequestBody ObjectTreeNode objectTreeNode)
    {
        try
        {
            objectTreeNode.setLevel (1);
            objectTreeService.saveTreeNode (objectTreeNode);
        }
        catch (Exception e)
        {
            return renderSuccess ("error");
        }
        return renderSuccess ("success");
    }
    
    /**
     * 新增节点
     *
     * @param model
     * @param id
     * @return
     */
    @RequestMapping ("/addNodePage")
    public String addNodePage (Model model, HttpServletRequest request, HttpServletResponse response,
        @RequestBody ObjectTreeNode objectTreeNode)
    {
        return "/service/objectTree/objectTreeNode";
    }
    
    @RequestMapping ("/saveNode")
    @ResponseBody
    public Object saveNode (HttpServletRequest request, HttpServletResponse response, @RequestBody ObjectTreeNode objectTreeNode)
    {
        try
        {
            objectTreeService.saveTreeNode (objectTreeNode);
        }
        catch (Exception e)
        {
            return renderSuccess ("error");
        }
        return renderSuccess ("success");
    }
    
    /**
     * 新增节点
     *
     * @param model
     * @param id
     * @return
     */
    @RequestMapping ("/editNodePage")
    public String editNodePage (Model model, HttpServletRequest request, HttpServletResponse response,
        @RequestBody ObjectTreeNode objectTreeNode)
    {
        return "/service/objectTree/objectTreeNodeEdit";
    }
    
    @RequestMapping ("/editNode")
    @ResponseBody
    public Object editNode (HttpServletRequest request, HttpServletResponse response, @RequestBody ObjectTreeNode objectTreeNode)
    {
        try
        {
            objectTreeService.editTreeNode (objectTreeNode);
        }
        catch (Exception e)
        {
            LOGGER.error (e.getMessage ());
            return renderSuccess ("error");
        }
        return renderSuccess ("success");
    }
    
    @RequestMapping ("/delNode")
    @ResponseBody
    public Object delNode (HttpServletRequest request, @RequestBody ObjectTreeNode objectTreeNode)
    {
        objectTreeService.delTreeNode (objectTreeNode);
        return renderSuccess ("success");
    }
    
    @RequestMapping ("/delete")
    @ResponseBody
    public Object delete (HttpServletRequest request, @RequestBody ObjectTreeBean objectTreeBean)
    {
        objectTreeService.del (objectTreeBean);
        return renderSuccess ("success");
    }
    
    @RequestMapping ("/genertateId")
    @ResponseBody
    public Object genertateId (HttpServletRequest request, HttpServletResponse response)
    {
        Map <String, Object> result = new HashMap <String, Object> ();
        String id = UUIDUtils.generate16Str ();
        result.put ("id", id);
        return renderSuccess (result);
    }
    
    /**
     * 选择页
     *
     * @param model
     * @param id
     * @return
     */
    @RequestMapping ("/choosePage")
    public String choosePage ()
    {
        return "/service/objectTree/chooseObjectTree";
    }
    
    @RequestMapping ("/getObjectTreeForChoose")
    @ResponseBody
    public Object getObjectTreeForChoose (HttpServletRequest request, HttpServletResponse response,
        @RequestBody ObjectTreeBean objectTreeBean)
    {
        List <Object> list = new ArrayList <Object> ();
        Map <String, Object> result = new HashMap <String, Object> ();
        User currentUser = getCurrentUser ();
        
        if (!ReportConstant.REPORT_USERID_ROOT.equals (currentUser.getId ()))
        {
            
            objectTreeBean.setUserId (currentUser.getId ());
        }
        List <ObjectTreeNode> rootNodeList = objectTreeService.queryTreeNodeList (objectTreeBean);
        
        if (!ReportConstant.REPORT_USERID_ROOT.equals (currentUser.getId ()))
        {
            for (ObjectTreeNode objectTreeNode : rootNodeList)
            {
                if (objectTreeNode.getIsAuth () == 0)
                {
                    objectTreeNode.setDisabled (true);
                }
            }
        }
        list.addAll (rootNodeList);
        result.put ("list", list);
        return renderSuccess (result);
    }
    
    /**
     * 报表生成页面根据报表模板绑定的对象树类型展示列表
     * @param request
     * @param objectTreeBean
     * @return
     */
    @RequestMapping ("/queryForReport")
    @ResponseBody
    public Object queryForReport (HttpServletRequest request)
    {
        ObjectTreeBean objectTreeBean = new ObjectTreeBean ();
        User currentUser = getCurrentUser ();
        if (!ReportConstant.REPORT_USERID_ROOT.equals (currentUser.getId ()))
        {
            
            objectTreeBean.setUserId (currentUser.getId ());
        }
        String tmpId = request.getParameter ("tmpId");
        objectTreeBean.setTmpId (tmpId);
        
        Page <ObjectTreeBean> page = new Page <ObjectTreeBean> (objectTreeBean);
        page.setPageNo (NumberUtils.toInt (request.getParameter (CommonConstant.PAGE_PARAM_PAGE)));
        page.setPageSize (NumberUtils.toInt (request.getParameter (CommonConstant.PAGE_PARAM_ROWS)));
        page = objectTreeService.queryObjectTree (page);
        Map <String, Object> map = new HashMap <String, Object> ();
        map.put (CommonConstant.PAGE_RESULT_ROWS, page.getResults ());
        map.put (CommonConstant.PAGE_RESULT_TOTAL, page.getTotalRecord ());
        return map;
        
    }
}
