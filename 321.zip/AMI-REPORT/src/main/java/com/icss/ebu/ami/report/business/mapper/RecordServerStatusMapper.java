package com.icss.ebu.ami.report.business.mapper;

import java.util.Map;

public interface RecordServerStatusMapper
{
    void recordServerStatus (Map <String, Object> map);
}
